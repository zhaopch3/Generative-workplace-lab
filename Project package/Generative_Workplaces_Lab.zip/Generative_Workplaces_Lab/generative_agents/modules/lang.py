# -*- coding: utf-8 -*-
"""Simulation language (V27).

A world runs in Chinese ("zh", the default and the only language before V27) or in
English ("en").  The language is chosen per world (``config["language"]``) and set
once when the simulation starts (``SimulateServer``), like the global timer.  Code
that builds prompt text or reads model output asks ``L(zh, en)`` for the wording, so
both versions sit next to each other and Chinese worlds behave exactly as before.

English worlds use their own prompt files (``data/prompts_en``), English agent
folders (Klaus, Ayesha, Maria, Wolfgang) and English location names.  The data of a
Chinese and an English world are never pooled: the language is part of the world
config and therefore of the comparison fingerprint.
"""

import threading
from contextlib import contextmanager

LANGUAGES = ("zh", "en")
_LANG = "zh"                 # process-wide: set when a world starts (also seen by its worker threads)
_LOCAL = threading.local()   # per-thread override for building a world config inside the web server


def set_language(lang):
    global _LANG
    lang = (lang or "zh").strip().lower()
    if lang not in LANGUAGES:
        raise ValueError("language must be zh or en")
    _LANG = lang
    return _LANG


def get_language():
    return getattr(_LOCAL, "lang", None) or _LANG


@contextmanager
def using(lang):
    """Switch the language for the current thread only (building a world config inside the web
    server, where a single-run world may be simulating in another thread)."""
    previous = getattr(_LOCAL, "lang", None)
    _LOCAL.lang = normalize(lang)
    try:
        yield
    finally:
        _LOCAL.lang = previous


def is_en():
    return get_language() == "en"


def L(zh, en):
    """The wording for the current simulation language."""
    return en if get_language() == "en" else zh


def normalize(lang):
    lang = (lang or "zh").strip().lower()
    if lang not in LANGUAGES:
        raise ValueError("模拟语言只能是 zh 或 en")
    return lang


def prompt_dir():
    return "data/prompts_en" if is_en() else "data/prompts"


# Agents of the office scenario: Chinese name -> English name (same sprites and roles).
NAMES = {"克劳斯": "Klaus", "阿伊莎": "Ayesha", "玛丽亚": "Maria", "沃尔夫冈": "Wolfgang",
         # V27.2: the other agents of the original town, by their English first names (李雷 has none: Lei)
         "乔治": "Giorgio", "亚当": "Adam", "亚瑟": "Arthur", "伊莎贝拉": "Isabella", "卡洛斯": "Carlos", "卡门": "Carmen",
         "埃迪": "Eddy", "塔玛拉": "Tamara", "山姆": "Sam", "山本百合子": "Yuriko", "弗朗西斯科": "Francisco", "拉吉夫": "Rajiv",
         "拉托亚": "Latoya", "李雷": "Lei", "梅": "Mei", "汤姆": "Tom", "海莉": "Hailey", "瑞恩": "Ryan",
         "简": "Jane", "约翰": "John", "詹妮弗": "Jennifer", "阿比盖尔": "Abigail",
         }
NAMES_ZH = {v: k for k, v in NAMES.items()}

# Map names (maze.json and the agents' spatial memory): Chinese -> English.
LOCATIONS = {
    "公司办公室": "company office",
    "开放办公区": "open office area",
    "领导办公室": "team lead office",
    "会议区": "meeting area",
    "茶水休息区": "break room",
    "休息宿舍区": "dormitory",
    "1号工位": "desk 1",
    "2号工位": "desk 2",
    "3号工位": "desk 3",
    "公共办公桌": "shared desk",
    "领导办公桌": "team lead desk",
    "领导椅": "team lead chair",
    "文件柜": "filing cabinet",
    "会议桌": "meeting table",
    "白板": "whiteboard",
    "书柜": "bookshelf",
    "沙发": "sofa",
    "饮水机": "water dispenser",
    "打印机": "printer",
    "床": "bed",
    "休息沙发": "lounge sofa",
}
LOCATIONS_ZH = {v: k for k, v in LOCATIONS.items()}


def loc(zh_name):
    """A map name in the current language (unknown names are returned unchanged)."""
    return LOCATIONS.get(zh_name, zh_name) if is_en() else zh_name


def name(zh_name):
    return NAMES.get(zh_name, zh_name) if is_en() else zh_name


def translate_maze(maze_config):
    """English map names for an English world (in place; returns the config)."""
    for tile in maze_config.get("tiles", []):
        if tile.get("address"):
            tile["address"] = [LOCATIONS.get(a, a) for a in tile["address"]]
    return maze_config


def translate_spatial(spatial):
    """English names in an agent's spatial memory (tree and address book)."""
    def tr(value):
        if isinstance(value, dict):
            return {LOCATIONS.get(k, k): tr(v) for k, v in value.items()}
        if isinstance(value, list):
            return [tr(v) for v in value]
        if isinstance(value, str):
            return LOCATIONS.get(value, value)
        return value
    out = dict(spatial or {})
    if "tree" in out:
        out["tree"] = tr(out["tree"])
    if "address" in out:
        keys = {"睡觉": "sleep", "工作": "work"}
        out["address"] = {keys.get(k, k): tr(v) for k, v in out["address"].items()}
    return out


def keywords(zh, en):
    """Keyword list for matching model output in the current language."""
    return list(en) if is_en() else list(zh)


def contains_any(text, zh, en):
    text = str(text or "")
    if is_en():
        low = text.lower()
        return any(w in low for w in en)
    return any(w in text for w in zh)
