"""Launcher: finds a free local port, starts the server in the background and opens the browser.

Messages follow the system language (Chinese or English); set SIM_LANG=zh or SIM_LANG=en to choose.
"""
import argparse
import importlib.util
import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "generative_agents"


def _console_is_zh():
    """Chinese console messages on a Chinese system, English otherwise (V27.2)."""
    choice = os.environ.get("SIM_LANG", "").strip().lower()
    if choice in ("zh", "en"):
        return choice == "zh"
    if os.name == "nt":
        try:
            import ctypes
            return (ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF) == 0x04
        except Exception:
            return False
    for key in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        if os.environ.get(key):
            return os.environ[key].lower().startswith("zh")
    return False


ZH = _console_is_zh()


def T(zh, en):
    return zh if ZH else en


def local_version():
    """SYSTEM_VERSION of the server in this folder (read from the file, without importing it)."""
    import re
    try:
        text = (PROJECT / "server.py").read_text(encoding="utf-8")
    except OSError:
        return ""
    match = re.search(r'^SYSTEM_VERSION = "([^"]+)"', text, re.M)
    return match.group(1) if match else ""


STOP_HINT = T(
    "请先结束旧程序（会同时停止正在运行的模拟；已存档的世界之后可在“实验与存档”里接着跑）：\n"
    "  Windows：在开始菜单打开 PowerShell，运行  Get-Process python | Stop-Process -Force\n"
    "  macOS / Linux：在终端运行  pkill -f server.py\n"
    "然后重新双击 Start.bat（或运行 python launch.py）。",
    "First stop the old program (this also stops running simulations; saved worlds can be resumed later "
    "under Experiments & archive):\n"
    "  Windows: open PowerShell from the Start menu and run  Get-Process python | Stop-Process -Force\n"
    "  macOS / Linux: run  pkill -f server.py  in a terminal\n"
    "Then double-click Start.bat again (or run python launch.py)."
)
INSTALL_HINT = T("请先运行安装程序（Windows 双击 Install.bat，macOS / Linux 运行 bash install.sh）。",
                 "Run the installer first (Windows: double-click Install.bat; macOS / Linux: bash install.sh).")


START_WAIT_SECONDS = 600


def print_log_tail(path, start, lines=40):
    """Show the end of this start attempt's server log in the launcher window."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            f.seek(start)
            text = f.read()
    except OSError:
        return
    tail = [line for line in text.splitlines() if line.strip()][-lines:]
    if not tail:
        return
    print(T("---- logs/server.log 最后 {} 行（求助时请把这一段一起发来）----",
            "---- last {} lines of logs/server.log (include them when asking for help) ----").format(len(tail)))
    for line in tail:
        print(line)
    print("-" * 60)


def status(port):
    try:
        with urllib.request.urlopen(
            "http://127.0.0.1:%d/api/version" % port, timeout=0.4
        ) as response:
            return json.load(response)
    except Exception:
        return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-browser", action="store_true")
    # 5060/5061 are browser-blocked SIP ports (ERR_UNSAFE_PORT).
    parser.add_argument("--port", type=int, default=5071)
    args = parser.parse_args()
    if not 1024 <= args.port <= 65520:
        raise SystemExit("Port must be between 1024 and 65520")

    logs = ROOT / "logs"
    logs.mkdir(exist_ok=True)
    lock = open(logs / "launcher.lock", "a+b")
    if os.name == "nt":
        import msvcrt

        lock.seek(0)
        lock.write(b"0")
        lock.flush()
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            print(T("另一个启动器正在启动程序，请稍候。", "Another launcher is starting the program. Please wait."))
            return
    try:
        port = None
        for candidate in range(args.port, args.port + 10):
            current = status(candidate)
            if current and os.path.normcase(current.get("project_path", "")) == os.path.normcase(str(PROJECT)):
                # V25.2: the server keeps running in the background after the launcher window closes,
                # so after overwriting the folder with a new version the old server may still be serving.
                mine = local_version()
                if mine and current.get("version") and current.get("version") != mine:
                    print(T("后台还在运行旧版本（{}），本文件夹已是新版本（{}）。",
                            "An older version ({}) is still running in the background; this folder has version {}.").format(
                        current.get("version"), mine))
                    print(STOP_HINT)
                    sys.exit(1)
                url = "http://127.0.0.1:%d/research" % candidate
                print(T("已就绪：", "Ready: ") + url)
                if not args.no_browser:
                    webbrowser.open(url)
                return
            if current and candidate == args.port:
                print(T("提示：端口 {} 已被另一个文件夹的程序占用（{}，{}），本次改用下一个端口。",
                        "Note: port {} is used by the program in another folder ({}, {}); using the next port.").format(
                    candidate, current.get("project_path", "?"), current.get("version", "?")))
                print(T("如不再需要那个程序，", "If you no longer need that program: ") + STOP_HINT)
            with socket.socket() as sock:
                try:
                    sock.bind(("127.0.0.1", candidate))
                except OSError:
                    continue
            if port is None:
                port = candidate
        if port is None:
            raise RuntimeError(T("指定范围内没有空闲的本地端口。", "No free local port in the selected range."))

        missing = [
            name
            for name in ("flask", "openai", "llama_index", "numpy", "pandas", "scipy")
            if importlib.util.find_spec(name) is None
        ]
        if missing:
            raise RuntimeError(T("缺少依赖：", "Missing dependencies: ") + ", ".join(missing) + T("。", ". ") + INSTALL_HINT)
        env = os.environ.copy()
        env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
        log_path = logs / "server.log"
        log_start = log_path.stat().st_size if log_path.exists() else 0
        with open(log_path, "a", encoding="utf-8") as log:
            process = subprocess.Popen(
                [sys.executable, "-u", "server.py", "--port", str(port)],
                cwd=PROJECT,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        print(T("正在启动 {} ……（程序在后台运行，关掉本窗口不会停止它）",
                "Starting {} ... (the program runs in the background; closing this window does not stop it)").format(
            local_version() or T("职场模拟实验室", "Workplace Simulation Lab")))
        # V27.1: a folder with many finished worlds can take a few minutes to start (antivirus
        # scanning on Windows makes reading old results slow). Wait while the server process is
        # alive, and say so, instead of giving up after one minute.
        started = time.time()
        next_note = started + 20
        while time.time() - started < START_WAIT_SECONDS:
            current = status(port)
            if current and os.path.normcase(current.get("project_path", "")) == os.path.normcase(str(PROJECT)):
                (logs / "instance.json").write_text(
                    json.dumps(
                        {"port": port, "pid": process.pid, "project": str(PROJECT), "version": current["version"]},
                        ensure_ascii=False,
                    ),
                    encoding="utf-8",
                )
                url = "http://127.0.0.1:%d/research" % port
                print(T("已就绪：", "Ready: ") + url)
                if not args.no_browser:
                    webbrowser.open(url)
                return
            if process.poll() is not None:
                break
            if time.time() >= next_note:
                print(T("  仍在启动（已等 {} 秒；历史世界多时需要几分钟，请勿关闭本窗口、也不要再次双击启动）……",
                        "  Still starting ({} s so far; with many saved worlds this takes a few minutes. "
                        "Do not close this window or start again) ...").format(int(time.time() - started)))
                next_note += 20
            time.sleep(0.5)
        code = process.poll()
        print("")
        if code is None:
            print(T("等待 {} 秒后服务仍未就绪，但它还在后台继续启动。",
                    "The server is not ready after {} s but is still starting in the background.").format(START_WAIT_SECONDS))
            print(T("请稍等几分钟后直接在浏览器打开 ", "Wait a few minutes, then open ") + "http://127.0.0.1:%d/research" % port)
        else:
            print(T("服务启动后退出了（退出码 {}）。", "The server exited after starting (exit code {}).").format(code))
        print_log_tail(log_path, log_start)
        raise RuntimeError(T("服务没有就绪，见 logs/server.log。", "Server did not become ready. See logs/server.log."))
    finally:
        lock.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(T("启动失败：", "Could not start:"), exc)
        if "server.log" not in str(exc):
            print(T("请用本文件夹 .venv 中的 Python 启动；环境没装好时", "Start with the Python in this folder's .venv. If the environment is not installed: ") + INSTALL_HINT)
        sys.exit(1)
