@echo off
rem Messages follow the system language: Chinese on a Chinese Windows, English otherwise.
rem Set SIM_LANG=zh or SIM_LANG=en to choose.
if not defined SIM_LANG (
  for /f "tokens=2 delims=:" %%a in ('chcp') do set "SIM_CP=%%a"
)
if not defined SIM_LANG (
  set "SIM_LANG=en"
  echo %SIM_CP% | findstr /r "936 950" >nul && set "SIM_LANG=zh"
)
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Install environment

rem ---- find Python 3.10-3.13 ----
set "PYEXE="
set "PYARG="
for %%V in (3.11 3.12 3.10 3.13) do call :trypy %%V
if defined PYEXE goto found
python -c "import sys; sys.exit(0 if (3,10)<=sys.version_info[:2]<=(3,13) else 1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=python"
if defined PYEXE goto found
for %%D in (Python311 Python312 Python310 Python313) do call :trydir %%D
if defined PYEXE goto found

echo.
if "%SIM_LANG%"=="zh" (echo 没有找到可用的 Python（需要 3.10-3.12，推荐 3.11）。) else (echo No usable Python found: 3.10-3.12 is needed, 3.11 recommended.)
where winget >nul 2>&1
if errorlevel 1 goto manual
if "%SIM_LANG%"=="zh" (choice /c YN /m "用 Windows 自带的 winget 自动安装 Python 3.11 吗") else (choice /c YN /m "Install Python 3.11 automatically with the built-in winget")
if errorlevel 2 goto manual
winget install -e --id Python.Python.3.11 --scope user --accept-package-agreements --accept-source-agreements
for %%D in (Python311) do call :trydir %%D
if defined PYEXE goto found
echo.
if "%SIM_LANG%"=="zh" (echo Python 已安装，但本窗口还找不到它。请关闭本窗口，重新双击 Install.bat。) else (echo Python is installed but this window cannot find it yet. Close this window and double-click Install.bat again.)
pause
exit /b 1

:manual
echo.
if "%SIM_LANG%"=="zh" (
  echo 请手动安装 Python 3.11：即将打开下载页面。
  echo 安装时务必勾选第一页下方的 "Add python.exe to PATH"，装好后重新双击 Install.bat。
) else (
  echo Please install Python 3.11 yourself: the download page opens now.
  echo Tick "Add python.exe to PATH" at the bottom of the first page, then double-click Install.bat again.
)
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1

:found
"%PYEXE%" %PYARG% -X utf8 "%~dp0setup_env.py" %*
if errorlevel 1 (
  echo.
  if "%SIM_LANG%"=="zh" (echo 安装没有完成，请看上面的提示。) else (echo Installation did not finish. See the messages above.)
  pause
  exit /b 1
)
if "%~1"=="--from-launcher" exit /b 0
pause
exit /b 0

:trypy
if defined PYEXE exit /b 0
py -%1 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  set "PYEXE=py"
  set "PYARG=-%1"
)
exit /b 0

:trydir
if defined PYEXE exit /b 0
if exist "%LOCALAPPDATA%\Programs\Python\%1\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\%1\python.exe"
exit /b 0
