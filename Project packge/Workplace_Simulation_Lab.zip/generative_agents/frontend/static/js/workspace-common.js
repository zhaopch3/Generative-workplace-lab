'use strict';
(function(root){
 const escape=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const number=x=>x!==null&&x!==undefined&&x!==''&&Number.isFinite(Number(x))?Number(x).toLocaleString('zh-CN',{maximumFractionDigits:2}):'—';
 const statuses=x=>Object.entries(x||{}).filter(([,n])=>n>0).map(([s,n])=>s+' '+n).join('，')||'未记录运行状态';
 function table(headers,rows){return '<div class="table-responsive"><table class="table table-bordered table-striped"><thead><tr>'+headers.map(h=>'<th scope="col">'+escape(h)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map(c=>'<td>'+c+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';}
 async function api(url,body){const response=await fetch(url,{...(body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),signal:AbortSignal.timeout(90000)});let result;try{result=await response.json();}catch{throw Error('服务未返回有效数据，请确认服务已启动后重试。');}if(!response.ok||result.ok===false)throw Error(result.error||'请求失败（'+response.status+'）');return result;}
 const error=(host,message)=>{host.innerHTML='<div class="alert alert-danger" role="alert">'+escape(message)+'</div>';};
 root.WorkspaceUI={escape,number,statuses,table,api,error};
 if(typeof module!=='undefined')module.exports=root.WorkspaceUI;
 // Open a linked historical batch after the archive's asynchronous list arrives.
 if(typeof document!=='undefined'&&location.pathname==='/experiments'&&location.hash.startsWith('#batch-row-')){
  let id;try{id=decodeURIComponent(location.hash.slice(1));}catch{return;}
  const open=()=>{const row=document.getElementById(id);if(!row)return false;const bid=id.slice('batch-row-'.length),body=document.getElementById('batch-history-'+bid);if(body?.style.display==='none')document.getElementById('batch-toggle-'+bid)?.click();row.scrollIntoView({block:'start'});return true;};
  if(!open()){const observer=new MutationObserver(()=>{if(open())observer.disconnect();});observer.observe(document.body,{childList:true,subtree:true});setTimeout(()=>observer.disconnect(),30000);}
 }
})(typeof globalThis!=='undefined'?globalThis:this);
