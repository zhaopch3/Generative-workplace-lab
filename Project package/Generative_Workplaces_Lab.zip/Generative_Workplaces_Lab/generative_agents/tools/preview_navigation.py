"""Local, synthetic navigation QA viewer. No model calls or result files."""
import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from flask import Flask, jsonify, render_template, request
from modules.maze import Maze
from modules.navigation import build_navigation, POLICY

ROOT = Path(__file__).resolve().parents[1]
STATIC = ROOT / "frontend/static"
maze = Maze(build_navigation(json.loads((STATIC/"assets/village/maze.json").read_text(encoding="utf-8")), STATIC), None)
app = Flask(__name__,template_folder=str(ROOT/"frontend/templates"),static_folder=str(STATIC))
starts = {"阿伊莎":[5,6],"玛丽亚":[8,10],"沃尔夫冈":[11,6],"克劳斯":maze.nearest_walkable([14,15])}
positions = dict(starts)
records = []
objects = ["会议桌","领导办公桌","饮水机","床","1号工位","文件柜"]
for i in range(6):
    agents = {}
    for k, name in enumerate(starts):
        obj = objects[(i+k)%len(objects)]
        address = next(a for a in maze.address_tiles if a.split(":")[-1] == obj)
        targets = maze.get_address_tiles(address.split(":"))
        paths = [maze.find_path(positions[name],t) for t in sorted(targets)]
        path = min((p for p in paths if p),key=len)
        agents[name] = {"prev_coord":list(positions[name]),"coord":list(path[-1]),
                        "path":[list(c) for c in path[1:]],"navigation_policy":POLICY,
                        "emoji":"测试：前往"+obj,"psych":{},"action":{},"chats":[]}
        positions[name] = list(path[-1])
    records.append({"step":i+1,"time":"TEST-{:02}:00".format(i+9),"agents":agents})

@app.route("/")
def viewer():
    return render_template("live.html",historical=True,embed=False,zoom=0,sim_name="导航验收 · 非研究数据",
                           condition="无 API 调用",persona_names=list(starts),persona_init_pos=starts,
                           navigation_policy=POLICY,steps_api="/api/steps")

@app.route("/api/steps/meta")
def meta(): return jsonify(min=1,max=len(records),latest_time=records[-1]["time"])

@app.route("/api/steps")
def steps():
    index = request.args.get("step",1,type=int)-1
    return jsonify(ok=0<=index<len(records),record=records[index] if 0<=index<len(records) else None)

if __name__ == "__main__": app.run(host="127.0.0.1",port=5039,debug=False)
