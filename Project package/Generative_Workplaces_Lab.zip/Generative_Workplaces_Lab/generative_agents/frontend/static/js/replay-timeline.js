'use strict';
(() => {
  const panel = document.getElementById('replay-timeline');
  if (!panel) return;
  const $ = id => document.getElementById(id);
  const list = $('replay-events'), status = $('replay-event-status');
  const more = $('replay-more'), retry = $('replay-retry');
  const types = {action:'行为', chat:'对话摘要', dialogue:'逐句对话', thought:'想法', event:'感知', psych:'心理', intervention:'干预', specified_action:'指定行为', world_setting:'世界设定', injection_reaction:'对注入的反应', revoke:'撤销设定'};
  let frame = null, offset = 0, shown = 0, revision = 0, controller = null;

  function cancel() {
    revision++;
    if (controller) controller.abort();
    more.hidden = true;
    retry.hidden = true;
    list.setAttribute('aria-busy', 'false');
  }
  function rowElement(row) {
    const article = document.createElement('article');
    article.className = 'replay-event';
    const header = document.createElement('header');
    const time = document.createElement('span');
    time.className = 'small text-muted';
    time.textContent = (row.step == null ? '未匹配回放步骤' : '第 ' + row.step + ' 步') + ' · ' + (row.sim_time || '时间未记录');
    const agent = document.createElement('strong');
    agent.textContent = row.agent || '世界';
    if (row.agent) agent.setAttribute('data-i18n-skip', '');
    const type = document.createElement('span');
    type.className = 'label label-default';
    type.textContent = types[row.type] || row.type || '记录';
    header.append(time, agent, type);
    if (row.researcher_injected) {
      const injected = document.createElement('span');
      injected.className = 'label label-warning';
      injected.textContent = '研究者指定';
      header.append(injected);
    }
    const text = document.createElement('div');
    text.className = 'event-text';
    text.setAttribute('data-i18n-skip', '');
    text.textContent = row.text ?? '';
    article.append(header);
    if (row.context) {
      const context = document.createElement('p');
      context.className = 'small text-muted';
      context.setAttribute('data-i18n-skip', '');
      context.textContent = row.context;
      article.append(context);
    }
    article.append(text);
    return article;
  }
  async function load(append = false) {
    const scope = $('replay-scope').value;
    cancel();
    if (scope === 'step' && !frame) {
      list.replaceChildren();
      status.textContent = '等待所选步骤载入…';
      return;
    }
    if (!append) {
      offset = 0; shown = 0;
      list.replaceChildren();
      list.scrollTop = 0;
    }
    const current = revision;
    controller = new AbortController();
    list.setAttribute('aria-busy', 'true');
    status.textContent = '正在读取历史记录…';
    const params = new URLSearchParams({source:'replay', offset, limit:100,
      agent:$('replay-agent').value, types:$('replay-type').value, q:$('replay-query').value.trim()});
    if (scope === 'step') params.set('step', frame.step);
    try {
      const response = await fetch(panel.dataset.eventsUrl + '?' + params, {signal:controller.signal});
      if (!response.ok) throw new Error('读取失败（HTTP ' + response.status + '）');
      const data = await response.json();
      if (current !== revision) return;
      if (!data.ok) throw new Error(data.error || '历史记录读取失败');
      const fragment = document.createDocumentFragment();
      for (const row of data.events) fragment.append(rowElement(row));
      list.append(fragment);
      shown += data.events.length;
      offset = data.next_offset;
      more.hidden = offset === null;
      const filtered = $('replay-agent').value || $('replay-type').value || $('replay-query').value.trim();
      status.textContent = !data.has_timeline && !data.has_conversations ? '这个世界未保存文字记录，仍可查看地图与人物状态。'
        : $('replay-type').value === 'dialogue' && !data.has_conversations ? '这个世界未保存逐句对话文件；可查看对话摘要，但不会根据摘要补写台词。'
        : !data.total ? (filtered ? '当前筛选下没有匹配记录。' : '本步骤没有新增事件记录，可切换到全部历史记录。')
        : '已显示 ' + shown + ' / ' + data.total + ' 条' + (scope === 'step' ? ' · 当前步骤' : ' · 全部历史');
      if (data.invalid_rows) status.textContent += ' · 有 ' + data.invalid_rows + ' 行损坏记录未能读取。';
    } catch (error) {
      if (current !== revision || error.name === 'AbortError') return;
      status.textContent = error.message;
      retry.hidden = false;
    } finally {
      if (current === revision) list.setAttribute('aria-busy', 'false');
    }
  }
  document.addEventListener('replay-seeking', event => {
    frame = null;
    $('replay-frame-label').textContent = '正在定位第 ' + event.detail.step + ' 步…';
    if ($('replay-scope').value === 'step') {
      cancel(); list.replaceChildren(); status.textContent = '等待所选步骤载入…';
    }
  });
  document.addEventListener('replay-frame', event => {
    frame = event.detail;
    $('replay-frame-label').textContent = '第 ' + frame.step + ' 步 · ' + (frame.time || '');
    if ($('replay-scope').value === 'step') load();
  });
  for (const id of ['replay-scope', 'replay-agent', 'replay-type']) $(id).addEventListener('change', () => load());
  $('replay-filters').addEventListener('submit', event => { event.preventDefault(); load(); });
  $('replay-query').addEventListener('search', () => load());
  more.addEventListener('click', () => load(true));
  retry.addEventListener('click', () => load());
  const pauseForReading = () => document.dispatchEvent(new CustomEvent('replay-pause'));
  panel.addEventListener('pointerdown', pauseForReading);
  panel.addEventListener('focusin', pauseForReading);
  list.addEventListener('wheel', pauseForReading, {passive:true});
})();
