# -*- coding: utf-8 -*-
"""地图管线（Tiled 单一事实来源）

目标：地图的"画面"与"逻辑语义"统一在 Tiled 的 tilemap.json 中维护，
maze.json 降级为自动生成的构建产物——从机制上根治"画面与逻辑错位"。

Tiled 中的四个语义对象层（objectgroup，矩形对象，名字即语义）：
    语义_场所   sector 层（本地图只有一个：公司办公室）
    语义_区域   arena 层（开放办公区 / 会议区 / 茶水休息区 / 休息宿舍区 / 领导办公室）
    语义_物品   object 层（床 / 会议桌 / 1号工位 / ...）
    语义_碰撞   碰撞层（矩形覆盖处不可通行）

编译规则：对每个格子取中心点——
    - 在哪个"场所"矩形内 → sector；在哪个"区域"矩形内 → arena；在哪个"物品"矩形内 → object
    - 同层多个矩形同时包含时，面积最小者优先（更具体的语义胜出）
    - 层级强制：object 仅在 arena 存在时生效，arena 仅在 sector 存在时生效
    - 中心点落在任一"碰撞"矩形内 → collision=True

命令行：
    python -m modules.mapgen export   # 从现有 maze.json 反向导出语义层到 tilemap.json（迁移用，幂等）
    python -m modules.mapgen build    # 从 tilemap.json 语义层编译生成 maze.json
    python -m modules.mapgen check    # 往返对等测试 + 智能体地址交叉校验（不写任何文件）
"""
import copy
import json
import os
import shutil

VILLAGE = os.path.join("frontend", "static", "assets", "village")
MAZE_PATH = os.path.join(VILLAGE, "maze.json")
TILEMAP_PATH = os.path.join(VILLAGE, "tilemap", "tilemap.json")
AGENTS_ROOT = os.path.join(VILLAGE, "agents")

LAYER_SECTOR = "语义_场所"
LAYER_ARENA = "语义_区域"
LAYER_OBJECT = "语义_物品"
LAYER_COLLISION = "语义_碰撞"
SEMANTIC_LAYERS = (LAYER_SECTOR, LAYER_ARENA, LAYER_OBJECT, LAYER_COLLISION)


def _load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# 矩形分解：把一组格子拆成尽量少的矩形（贪心最大矩形）
# ---------------------------------------------------------------------------
def decompose_rects(cells):
    remaining = set(cells)
    rects = []
    while remaining:
        x0, y0 = min(remaining, key=lambda c: (c[1], c[0]))
        w = 1
        while (x0 + w, y0) in remaining:
            w += 1
        h = 1
        while all((x0 + dx, y0 + h) in remaining for dx in range(w)):
            h += 1
        for dy in range(h):
            for dx in range(w):
                remaining.discard((x0 + dx, y0 + dy))
        rects.append((x0, y0, w, h))
    return rects


# ---------------------------------------------------------------------------
# 反向导出：maze.json -> Tiled 语义层（迁移引导，幂等：先删旧语义层再写）
# ---------------------------------------------------------------------------
def export_maze_to_tiled(maze_path=MAZE_PATH, tilemap_path=TILEMAP_PATH, backup=True):
    maze = _load(maze_path)
    tm = _load(tilemap_path)
    ts = maze["tile_size"]

    sector_cells, arena_cells, object_cells, collision_cells = {}, {}, {}, set()
    for t in maze["tiles"]:
        c = tuple(t["coord"])
        addr = t.get("address") or []
        if len(addr) >= 1:
            sector_cells.setdefault(addr[0], set()).add(c)
        if len(addr) >= 2:
            arena_cells.setdefault((addr[0], addr[1]), set()).add(c)
        if len(addr) >= 3:
            object_cells.setdefault((addr[0], addr[1], addr[2]), set()).add(c)
        if t.get("collision"):
            collision_cells.add(c)

    if backup and not os.path.exists(tilemap_path + ".bak"):
        shutil.copy(tilemap_path, tilemap_path + ".bak")

    tm["layers"] = [l for l in tm["layers"] if l.get("name") not in SEMANTIC_LAYERS]
    next_layer_id = tm.get("nextlayerid", len(tm["layers"]) + 1)
    next_obj_id = tm.get("nextobjectid", 1)

    def make_layer(name, entries, color):
        nonlocal next_layer_id, next_obj_id
        objects = []
        for label, cells in entries:
            for (x0, y0, w, h) in decompose_rects(cells):
                objects.append({
                    "id": next_obj_id, "name": label, "type": "",
                    "x": x0 * ts, "y": y0 * ts, "width": w * ts, "height": h * ts,
                    "rotation": 0, "visible": True, "point": False,
                })
                next_obj_id += 1
        layer = {
            "id": next_layer_id, "name": name, "type": "objectgroup",
            "objects": objects, "visible": True, "opacity": 1,
            "x": 0, "y": 0, "draworder": "topdown", "color": color,
        }
        next_layer_id += 1
        return layer

    tm["layers"].append(make_layer(
        LAYER_SECTOR, [(k, v) for k, v in sector_cells.items()], "#4444ff"))
    tm["layers"].append(make_layer(
        LAYER_ARENA, [(k[1], v) for k, v in arena_cells.items()], "#44cc44"))
    tm["layers"].append(make_layer(
        LAYER_OBJECT, [(k[2], v) for k, v in object_cells.items()], "#ffaa00"))
    tm["layers"].append(make_layer(
        LAYER_COLLISION, [("collision", collision_cells)] if collision_cells else [], "#ff4444"))
    tm["nextlayerid"] = next_layer_id
    tm["nextobjectid"] = next_obj_id
    _save(tilemap_path, tm)
    counts = {LAYER_SECTOR: len(tm["layers"][-4]["objects"]),
              LAYER_ARENA: len(tm["layers"][-3]["objects"]),
              LAYER_OBJECT: len(tm["layers"][-2]["objects"]),
              LAYER_COLLISION: len(tm["layers"][-1]["objects"])}
    return counts


# ---------------------------------------------------------------------------
# 正向编译：Tiled 语义层 -> maze.json
# ---------------------------------------------------------------------------
def _layer_rects(tm, layer_name):
    for l in tm["layers"]:
        if l.get("name") == layer_name and l.get("type") == "objectgroup":
            out = []
            for o in l.get("objects", []):
                w, h = o.get("width", 0), o.get("height", 0)
                if w > 0 and h > 0:
                    out.append((o.get("name", ""), o["x"], o["y"], w, h))
            return out
    return None


def _hit(rects, px, py):
    """返回包含点的最小面积矩形的名字；无命中返回None。"""
    best, best_area = None, None
    for (name, x, y, w, h) in rects:
        if x <= px < x + w and y <= py < y + h:
            area = w * h
            if best_area is None or area < best_area:
                best, best_area = name, area
    return best


def has_semantic_layers(tilemap_path=TILEMAP_PATH):
    try:
        tm = _load(tilemap_path)
    except (OSError, json.JSONDecodeError):
        return False
    names = {l.get("name") for l in tm.get("layers", [])}
    return LAYER_OBJECT in names and LAYER_ARENA in names


def compile_tiled_to_maze(tilemap_path=TILEMAP_PATH, template_maze_path=MAZE_PATH):
    tm = _load(tilemap_path)
    template = _load(template_maze_path)
    ts = template["tile_size"]
    cols, rows = tm["width"], tm["height"]

    sectors = _layer_rects(tm, LAYER_SECTOR) or []
    arenas = _layer_rects(tm, LAYER_ARENA) or []
    objects = _layer_rects(tm, LAYER_OBJECT) or []
    collisions = _layer_rects(tm, LAYER_COLLISION) or []
    # 碰撞以作者维护的 Collisions 图块层为主（画面原生），语义_碰撞矩形为辅，取并集
    coll_tiles = set()
    for l in tm["layers"]:
        if l.get("name") == "Collisions" and l.get("type") == "tilelayer":
            for i, g in enumerate(l.get("data", [])):
                if g:
                    coll_tiles.add((i % cols, i // cols))

    tiles = []
    stats = {"no_sector": 0, "no_arena": 0, "no_object": 0}
    for y in range(rows):
        for x in range(cols):
            px, py = (x + 0.5) * ts, (y + 0.5) * ts
            sector = _hit(sectors, px, py)
            arena = _hit(arenas, px, py) if sector else None
            obj = _hit(objects, px, py) if arena else None
            addr = [p for p in (sector, arena, obj) if p]
            if not sector:
                stats["no_sector"] += 1
            elif not arena:
                stats["no_arena"] += 1
            elif not obj:
                stats["no_object"] += 1
            tile = {"coord": [x, y], "address": addr,
                    "collision": (x, y) in coll_tiles or _hit(collisions, px, py) is not None}
            tiles.append(tile)

    maze = {k: copy.deepcopy(v) for k, v in template.items() if k != "tiles"}
    maze["size"] = [rows, cols]
    maze["tiles"] = tiles
    return maze, stats


def semantic_diff(maze_a, maze_b):
    """比较两份maze的每格 (address, collision)，返回差异列表。"""
    ta = {tuple(t["coord"]): (tuple(t.get("address") or []), bool(t.get("collision")))
          for t in maze_a["tiles"]}
    tb = {tuple(t["coord"]): (tuple(t.get("address") or []), bool(t.get("collision")))
          for t in maze_b["tiles"]}
    diffs = []
    for c in sorted(set(ta) | set(tb)):
        if ta.get(c) != tb.get(c):
            diffs.append((c, ta.get(c), tb.get(c)))
    return diffs


# ---------------------------------------------------------------------------
# 智能体地址交叉校验
# ---------------------------------------------------------------------------
def _walk_spatial(node, path, out):
    if isinstance(node, dict):
        for k, v in node.items():
            _walk_spatial(v, path + [k], out)
    elif isinstance(node, list):
        for leaf in node:
            if isinstance(leaf, str):
                out.add(tuple(path + [leaf]))
    if isinstance(node, dict) and not node:
        out.add(tuple(path))


def validate_agent_addresses(maze, agents_root=AGENTS_ROOT):
    """检查所有智能体空间树引用的地址是否存在于maze中。返回缺失列表。"""
    existing = set()
    for t in maze["tiles"]:
        addr = tuple(t.get("address") or [])
        for i in range(1, len(addr) + 1):
            existing.add(addr[:i])
    map_sectors = {tuple(t.get("address") or [])[0]
                   for t in maze["tiles"] if t.get("address")}
    missing = []
    if not os.path.isdir(agents_root):
        return missing
    for name in sorted(os.listdir(agents_root)):
        cfg_path = os.path.join(agents_root, name, "agent.json")
        if not os.path.exists(cfg_path):
            continue
        try:
            cfg = _load(cfg_path)
        except (OSError, json.JSONDecodeError):
            continue
        spatial = cfg.get("spatial", {}).get("tree", cfg.get("spatial", {}))
        refs = set()
        _walk_spatial(spatial, [], refs)
        world = maze.get("world", "")
        for ref in refs:
            # 空间树以 world 开头时剥掉
            r = ref[1:] if ref and ref[0] == world else ref
            # 只校验本地图内的场所；指向其他地图（如村庄）的引用不在本地图管辖范围
            if r and r[0] in map_sectors and r not in existing:
                missing.append((name, " : ".join(r)))
    return sorted(set(missing))


# ---------------------------------------------------------------------------
# 构建入口（含报告）；供 server 启动时与管理页按钮调用
# ---------------------------------------------------------------------------
def build(write=True):
    """编译 tilemap 语义层 -> maze.json。返回报告dict。"""
    if not has_semantic_layers():
        return {"ok": False, "skipped": True,
                "message": "tilemap.json 中无语义层（语义_区域/语义_物品），未执行编译。"}
    maze, stats = compile_tiled_to_maze()
    missing = validate_agent_addresses(maze)
    report = {
        "ok": len(missing) == 0,
        "skipped": False,
        "tiles": len(maze["tiles"]),
        "uncovered": stats,
        "agent_missing_addresses": ["{}: {}".format(n, a) for n, a in missing],
    }
    if missing:
        report["message"] = "编译完成但校验失败：有智能体空间树引用的地址在新地图中不存在，已拒绝写入。"
        return report
    if write:
        if not os.path.exists(MAZE_PATH + ".bak"):
            shutil.copy(MAZE_PATH, MAZE_PATH + ".bak")
        header_note = maze  # json不支持注释，README中说明勿手改
        _save(MAZE_PATH, header_note)
        report["message"] = "maze.json 已重建（{} 格）。".format(len(maze["tiles"]))
        try:
            png = render_overlay(maze)
            report["overlay"] = png
        except Exception as e:  # noqa: BLE001 PIL缺失等不影响构建
            report["overlay_error"] = str(e)
    return report


def needs_rebuild():
    """tilemap 比 maze 新且含语义层 -> 需要重建。"""
    try:
        return (has_semantic_layers()
                and os.path.getmtime(TILEMAP_PATH) > os.path.getmtime(MAZE_PATH))
    except OSError:
        return False


# ---------------------------------------------------------------------------
# POI 叠加检查图（构建副产品；需要 pillow，缺失时跳过）
# ---------------------------------------------------------------------------
def render_overlay(maze=None, out_png=os.path.join(VILLAGE, "poi_alignment_check.png")):
    from PIL import Image, ImageDraw, ImageFont

    if maze is None:
        maze = _load(MAZE_PATH)
    tm = _load(TILEMAP_PATH)
    ts = tm["tilewidth"]
    W, H = tm["width"], tm["height"]

    tilesets = []
    for t in tm["tilesets"]:
        img_path = os.path.join(os.path.dirname(TILEMAP_PATH), os.path.basename(t["image"]))
        img = Image.open(img_path).convert("RGBA")
        tilesets.append((t["firstgid"], img, img.width // ts))
    tilesets.sort(key=lambda x: -x[0])

    canvas = Image.new("RGBA", (W * ts, H * ts), (30, 30, 30, 255))
    for layer in tm["layers"]:
        if layer.get("type") != "tilelayer" or not layer.get("visible", True):
            continue
        for i, gid in enumerate(layer["data"]):
            if not gid:
                continue
            gid &= 0x0FFFFFFF
            for firstgid, img, cols in tilesets:
                if gid >= firstgid:
                    idx = gid - firstgid
                    sx, sy = (idx % cols) * ts, (idx // cols) * ts
                    canvas.alpha_composite(img.crop((sx, sy, sx + ts, sy + ts)),
                                           ((i % W) * ts, (i // W) * ts))
                    break

    from collections import defaultdict
    groups = defaultdict(list)
    for t in maze["tiles"]:
        addr = t.get("address") or []
        if len(addr) >= 2:
            groups[":".join(addr[1:])].append(tuple(t["coord"]))

    palette = [(231,76,60),(52,152,219),(46,204,113),(155,89,182),(241,196,15),
               (230,126,34),(26,188,156),(149,165,166),(192,57,43),(41,128,185),
               (39,174,96),(142,68,173),(243,156,18),(211,84,0),(22,160,133),(127,140,141)]
    overlay = Image.new("RGBA", canvas.size, (0,0,0,0))
    od = ImageDraw.Draw(overlay)
    for i, key in enumerate(sorted(groups)):
        color = palette[i % len(palette)]
        emph = "床" in key
        for (x, y) in groups[key]:
            od.rectangle([x*ts, y*ts, (x+1)*ts-1, (y+1)*ts-1],
                         fill=color + (150 if emph else 80,),
                         outline=color + (230,) if emph else None, width=3 if emph else 1)
    merged = Image.alpha_composite(canvas, overlay)

    font = None
    for p in ("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
              "C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/simhei.ttf"):
        if os.path.exists(p):
            font = ImageFont.truetype(p, 16)
            break
    md = ImageDraw.Draw(merged)
    for key in sorted(groups):
        pts = groups[key]
        cx = sum(p[0] for p in pts) / len(pts) * ts + ts // 2
        cy = sum(p[1] for p in pts) / len(pts) * ts + ts // 2
        label = key.split(":")[-1]
        bbox = md.textbbox((0, 0), label, font=font)
        w, h = bbox[2]-bbox[0], bbox[3]-bbox[1]
        md.rectangle([cx-w/2-3, cy-h/2-3, cx+w/2+3, cy+h/2+3], fill=(0,0,0,180))
        md.text((cx-w/2, cy-h/2-2), label, font=font, fill=(255,255,255,255))
    merged.convert("RGB").save(out_png, quality=95)
    return out_png


if __name__ == "__main__":
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else "check"
    if cmd == "export":
        counts = export_maze_to_tiled()
        print("已导出语义层到 tilemap.json：", counts)
        print("（原文件备份为 tilemap.json.bak）")
    elif cmd == "build":
        report = build(write=True)
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:  # check
        if not has_semantic_layers():
            print("tilemap.json 尚无语义层。先运行: python -m modules.mapgen export")
            sys.exit(1)
        compiled, stats = compile_tiled_to_maze()
        current = _load(MAZE_PATH)
        diffs = semantic_diff(current, compiled)
        print("往返对等: {} 处差异 | 未覆盖统计: {}".format(len(diffs), stats))
        for d in diffs[:10]:
            print("  差异@{}: 现有={} 编译={}".format(*d))
        missing = validate_agent_addresses(compiled)
        print("智能体地址校验: {}".format("全部通过" if not missing else missing))
