# -*- coding: utf-8 -*-
"""V27.1: the batch manager reads only the newest checkpoint of a world (fast startup)."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import server  # noqa: E402


class DiskStepTests(unittest.TestCase):
    def setUp(self):
        self.origin = os.getcwd()
        self.tmp = tempfile.TemporaryDirectory()
        os.chdir(self.tmp.name)
        self.folder = os.path.join("results", "checkpoints", "w1")
        os.makedirs(self.folder)
        self.manager = server.BatchManager.__new__(server.BatchManager)

    def tearDown(self):
        os.chdir(self.origin)
        self.tmp.cleanup()

    def write(self, name, step):
        with open(os.path.join(self.folder, name), "w", encoding="utf-8") as f:
            f.write(json.dumps({"step": step}) if step is not None else "{half-written")

    def test_newest_file_and_fallback(self):
        self.assertEqual(self.manager._disk_step("missing"), 0)
        self.assertEqual(self.manager._disk_step("w1"), 0)
        self.write("simulate-20240212-0900.json", 6)
        self.write("simulate-20240213-0900.json", 150)
        self.write("simulate-20240212-1800.json", 60)
        self.write("other.json", 999)
        self.assertEqual(self.manager._disk_step("w1"), 150)
        self.write("simulate-20240213-1000.json", None)   # newest unreadable -> the one before
        self.assertEqual(self.manager._disk_step("w1"), 150)

    def test_does_not_open_old_checkpoints(self):
        for i in range(30):   # 30 hourly checkpoints: 2024-02-12 00:00 ... 2024-02-13 05:00
            self.write("simulate-202402{}-{:02d}00.json".format(12 + i // 24, i % 24), i)
        opened = []
        real_open = open

        def spy(path, *a, **k):
            opened.append(os.path.basename(str(path)))
            return real_open(path, *a, **k)

        import builtins
        builtins.open, saved = spy, builtins.open
        try:
            step = self.manager._disk_step("w1")
        finally:
            builtins.open = saved
        self.assertEqual(step, 29)
        self.assertEqual(opened, ["simulate-20240213-0500.json"])


if __name__ == "__main__":
    unittest.main()
