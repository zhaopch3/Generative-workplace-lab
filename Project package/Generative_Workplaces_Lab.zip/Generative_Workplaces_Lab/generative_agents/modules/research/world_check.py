# -*- coding: utf-8 -*-
"""Template check (V23): final personas, condition conflicts, construct-label leaks.

Run automatically when a world is built (errors block the start) and available
through /api/presets/check and tools/check_templates.py for a preview of the
exact persona text every agent will see.
"""
import copy
import json
import os
from string import Template

BANNED_TERMS = ("辱虐", "苛责", "abusive", "Abusive", "幸灾乐祸", "实验条件", "操纵",
                "strict", "lenient", "智能体", "模拟",
                # V27 English worlds (matched case-insensitively)
                "abuse", "schadenfreude", "experimental condition", "manipulat", "simulation",
                "generative agent")


def _hits(text):
    low = str(text or "").lower()
    return [t for t in BANNED_TERMS if t.lower() in low]
# Researcher-facing fields that never reach an agent.
_NOT_AGENT_VISIBLE = ("title", "questions", "id", "description")

AGENTS_ROOT = os.path.join("frontend", "static", "assets", "village", "agents")


def _load_agent_file(name):
    with open(os.path.join(AGENTS_ROOT, name, "agent.json"), "r", encoding="utf-8") as handle:
        return json.load(handle)


def render_persona(name, agent_cfg):
    """The base description exactly as prompts build it (date and psych state omitted)."""
    base = _load_agent_file(name)
    scratch = dict(base.get("scratch") or {})
    scratch.update(agent_cfg.get("scratch") or {})
    currently = agent_cfg.get("currently") or base.get("currently", "")
    from modules import lang
    from modules.lang import L
    lines = []
    if str(scratch.get("background", "")).strip():
        lines.append(L("【固定背景】：", "[Background]: ") + scratch["background"].strip())
    if str(scratch.get("world_rules", "")).strip():
        lines.append(L("【世界规则】：\n", "[World rules]:\n") + scratch["world_rules"].strip())
    if str(scratch.get("conduct", "")).strip():
        lines.append(L("【领导风格】：", "[Leadership style]: ") + scratch["conduct"].strip())
    facts = [str(f.get("text", "")).strip() for f in scratch.get("world_facts") or []
             if str(f.get("text", "")).strip() and not f.get("from")]
    if facts:
        lines.append(L("【目前的情况】：", "[Current situation]: ") + L("；", "; ").join(facts))
    with open(os.path.join(lang.prompt_dir(), "base_desc.txt"), "r", encoding="utf-8") as handle:
        template = Template(handle.read())
    return template.substitute(
        name=name, age=scratch.get("age", ""), innate=scratch.get("innate", ""),
        learned=scratch.get("learned", ""), lifestyle=scratch.get("lifestyle", ""),
        daily_plan=scratch.get("daily_plan", ""), fixed_block=("\n".join(lines) + "\n") if lines else "",
        date=L("（日期）", "(date)"), currently=currently,
    )


def _condition_fields(condition):
    if not condition:
        return None, set()
    path = os.path.join("data", "experiment_conditions.json")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            conditions = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None, set()
    entry = conditions.get(condition) or {}
    from modules import lang
    if lang.is_en():
        entry = {**entry, **((entry.get("translations") or {}).get("en") or {})}
    overrides = entry.get("leader_overrides") or {}
    fields = set(k for k in overrides if k != "scratch") | set((overrides.get("scratch") or {}).keys())
    return entry.get("leader"), fields


def survey_schedule_warnings(schema, payload):
    """V24: measurement days outside the simulated period, and surveys that never run."""
    import datetime
    days = schema.get("days") or []
    if not days:
        return []
    try:
        start = datetime.datetime.strptime(str(payload.get("start_time")), "%Y%m%d-%H:%M")
        steps, stride = int(payload.get("step")), int(payload.get("stride"))
        trigger = datetime.datetime.strptime(str(schema.get("trigger_time", "22:00")), "%H:%M").time()
    except (TypeError, ValueError):
        return []
    final = start + datetime.timedelta(minutes=stride * max(0, steps - 1))
    first_date = start.date() if start.time() <= trigger else start.date() + datetime.timedelta(days=1)
    last_date = final.date() if final.time() >= trigger else final.date() - datetime.timedelta(days=1)
    first_day, last_day = (first_date - start.date()).days + 1, (last_date - start.date()).days + 1
    sid = schema.get("id")
    if last_day < first_day:
        return ["问卷 {} 的触发时间 {} 在模拟时段内一次也不会到达，不会施测。".format(sid, schema.get("trigger_time"))]
    numbers = [int(d) for d in days if str(d) != "last"]
    outside = [d for d in numbers if d < first_day or d > last_day]
    out = []
    if outside:
        out.append("问卷 {} 的第 {} 天不在模拟时段内（触发时间 {} 只在第 {}–{} 天出现），这些天不会施测。".format(
            sid, "、".join(map(str, outside)), schema.get("trigger_time"), first_day, last_day))
    if not any(str(d) == "last" for d in days) and len(outside) == len(numbers):
        out.append("问卷 {} 在这次模拟中一次也不会施测。".format(sid))
    return out


def check_world(payload, config):
    """Return {"personas", "errors", "warnings"} for one built world."""
    errors, warnings = [], []
    leader, cond_fields = _condition_fields(str(payload.get("condition") or "").strip())
    overrides = payload.get("persona_overrides") or {}
    if leader and cond_fields:
        mine = {k for k, v in (overrides.get(leader) or {}).items() if str(v).strip()}
        clash = sorted(mine & cond_fields)
        if clash:
            errors.append("模板对 {} 的人设覆盖了实验条件已设定的字段：{}。请只保留一处来源。".format(
                leader, "、".join(clash)))
    if (payload.get("personality") or {}).get("enabled"):
        for name, ov in overrides.items():
            if str((ov or {}).get("innate", "")).strip():
                warnings.append("{} 的先天特质同时来自人格抽样和模板覆盖，以人格抽样为准。".format(name))

    personas = {}
    for name, agent_cfg in (config.get("agents") or {}).items():
        try:
            personas[name] = render_persona(name, agent_cfg)
        except (OSError, KeyError, ValueError) as exc:
            errors.append("{} 的人设无法生成：{}".format(name, exc))
            continue
        hits = _hits(personas[name])
        if hits:
            errors.append("{} 的人设含有不应让智能体看到的词：{}".format(name, "、".join(hits)))
    for schema in config.get("custom_surveys") or []:
        shown = schema.get("display_title") or ""
        hits = _hits(shown)
        if hits:
            errors.append("问卷 {} 的显示标题含有：{}".format(schema.get("id"), "、".join(hits)))
        if not shown:
            warnings.append("问卷 {} 未设置显示标题，智能体将看到“今日工作日志”。".format(schema.get("id")))
        warnings.extend(survey_schedule_warnings(schema, payload))
    for event in config.get("scheduled_events") or []:
        hits = _hits(event.get("text", ""))
        if hits:
            errors.append("定时事件 {} 的文字含有：{}".format(event.get("id"), "、".join(hits)))
    return {"personas": personas, "errors": errors, "warnings": warnings}


_COMPARE_IGNORED = {"name", "seed", "_batch", "condition", "research_design", "scheduled_events",
                    "persona_overrides"}


def compare_worlds(items):
    """items: [(label, payload, personas)] -> list of human-readable differences.

    The declared manipulation (condition, scheduled events, persona overrides) is
    shown separately; anything else that differs is reported as a warning.
    """
    if len(items) < 2:
        return {"manipulated": [], "other": []}
    base_label, base_payload, base_personas = items[0]
    manipulated, other = [], []
    for label, payload, personas in items[1:]:
        for key in sorted(set(base_payload) | set(payload)):
            if key in _COMPARE_IGNORED:
                if base_payload.get(key) != payload.get(key):
                    manipulated.append("{} vs {}：{}".format(base_label, label, key))
                continue
            if json.dumps(base_payload.get(key), ensure_ascii=False, sort_keys=True) != \
                    json.dumps(payload.get(key), ensure_ascii=False, sort_keys=True):
                other.append("{} vs {}：{} 不同".format(base_label, label, key))
        for name in sorted(set(base_personas) | set(personas)):
            if base_personas.get(name) != personas.get(name):
                manipulated.append("{} vs {}：{} 的人设文字不同".format(base_label, label, name))
    return {"manipulated": manipulated, "other": other}


def preview_payload(payload):
    """Build a throwaway world config from a template payload and check it."""
    import server  # local import: server imports this module lazily
    probe = copy.deepcopy(payload)
    probe["name"] = "check-preview"
    probe.pop("_batch", None)
    _, _, config = server.build_experiment_config(probe, check=False)
    from modules import lang
    with lang.using(lang.normalize(probe.get("language"))):
        return check_world(probe, config), config
