const assert=require("assert");
const motion=require("../frontend/static/js/motion.js");
function run(hz){let p=[0,0],q=[[48,0],[48,48],[96,48]];for(let i=0;i<hz;i++)p=motion.advance(p,q,120/hz).position;return p;}
for(const hz of [30,60,120,144]){
  const p=run(hz);assert(Math.abs(p[0]-72)<1e-6);assert(Math.abs(p[1]-48)<1e-6);
}
const q=[[48,0],[48,48]];
assert.deepEqual(motion.advance([0,0],q,96).position,[48,48]);
assert.equal(q.length,0);
console.log("Motion passed: 30/60/120/144 Hz, exact endpoint, no dropped path points.");
const pix=c=>c.map(x=>x*48+24);
const policy="office-solid-v1";
let queue=[];
let result=motion.enqueueRecord(pix([0,0]),queue,{prev_coord:[0,0],coord:[1,1],path:[[1,0],[1,1]],navigation_policy:policy},pix);
assert(!result.error);assert.deepEqual(queue,[[72,24],[72,72]]);
motion.enqueueRecord([50,24],queue,{prev_coord:[1,1],coord:[1,1],path:[],navigation_policy:policy},pix);
assert.equal(queue.length,2,"idle records cannot drop unfinished routes");
assert(motion.enqueueRecord(pix([0,0]),[],{prev_coord:[0,0],coord:[1,1],path:[[1,1]],navigation_policy:policy},pix).error);
assert(motion.enqueueRecord(pix([0,0]),[],{prev_coord:[0,0],coord:[5,0],path:[],navigation_policy:policy},pix).error);
assert(motion.enqueueRecord(pix([0,0]),[],{coord:[5,0],path:[]},pix).legacy);
for(const hz of [30,60,120,144]){
 let p=pix([0,0]),q=[];
 motion.enqueueRecord(p,q,{prev_coord:[0,0],coord:[1,1],path:[[1,0],[1,1]],navigation_policy:policy},pix);
 for(let i=0;i<hz;i++) {p=motion.advance(p,q,120/hz).position; assert(p[1]===24 || Math.abs(p[0]-72)<1e-6);}
 assert.deepEqual(p,[72,72]);
}
console.log("Record queue passed: no corner cutting, idle queue preserved, invalid paths rejected.");
