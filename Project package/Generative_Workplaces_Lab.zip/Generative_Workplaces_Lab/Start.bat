@echo off
rem Messages follow the system language: Chinese on a Chinese Windows, English otherwise.
rem Set SIM_LANG=zh or SIM_LANG=en to choose.
if not defined SIM_LANG (
  for /f "tokens=2 delims=:" %%a in ('chcp') do set "SIM_CP=%%a"
)
if not defined SIM_LANG (
  set "SIM_LANG=en"
  echo %SIM_CP% | findstr /r "936 950" >nul && set "SIM_LANG=zh"
)
chcp 65001 >nul
if not exist "%~dp0.venv\Scripts\python.exe" call "%~dp0Install.bat" --from-launcher
if not exist "%~dp0.venv\Scripts\python.exe" exit /b 1
"%~dp0.venv\Scripts\python.exe" -X utf8 "%~dp0launch.py" %*
if errorlevel 1 pause
