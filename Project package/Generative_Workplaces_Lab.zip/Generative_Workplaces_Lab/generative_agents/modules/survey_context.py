# -*- coding: utf-8 -*-
"""Survey context in three memory layers with a fixed budget (V23).

V22 handed every survey the whole memory store, undated, plus the full schedule
JSON, so "today" items were answered from all past days and every call grew
with the length of the run.  V23 builds what a diary-study respondent would
plausibly recall (Robinson & Clore's accessibility model: episodic detail for
short time frames, consolidated beliefs for longer ones):

1. today's episodes  - today's interactions and thoughts with clock times,
                       without object-state events; today's dialogues verbatim;
2. relevant past     - earlier memories retrieved with the questionnaire (or the
                       rated colleague) as query, using the existing
                       recency x importance x relevance scoring, labelled "N天前";
3. settled views     - impressions of colleagues (relation summaries) and one
                       summary per earlier day (the morning reflection).

The whole context is capped (default 8000 estimated tokens); when over budget
the least salient items of today are dropped first, then older memories.
"""
import copy
import datetime
import re

DEFAULT_BUDGET_TOKENS = 8000
EARLIER_MAX = 10
SURVEY_TRACE = "研究问卷"
SURVEY_TRACE_EN = "research survey"


def _L(zh, en):
    from modules.lang import L
    return L(zh, en)


_EN_MONTHS = ("January", "February", "March", "April", "May", "June", "July", "August",
              "September", "October", "November", "December")


def _day_label(d):
    """Month and day in the simulation language ("02月13日" / "February 13")."""
    from modules import lang
    if lang.is_en():
        return "{} {}".format(_EN_MONTHS[d.month - 1], d.day)
    return d.strftime("%m月%d日")

_CJK = re.compile(r"[　-〿㐀-鿿＀-￯]")


def estimate_tokens(text):
    """Conservative estimate: one token per CJK character, 0.3 per other character."""
    text = text or ""
    cjk = len(_CJK.findall(text))
    return int(cjk + 0.3 * (len(text) - cjk)) + 1


def _world_agents(agent):
    try:
        from modules.game import get_game
        return set(get_game().agents.keys())
    except Exception:  # noqa: BLE001
        return {agent.name}


def _concepts(agent, node_types=("event", "thought", "chat")):
    out = []
    for node_type in node_types:
        for node_id in list(agent.associate.memory.get(node_type, [])):
            try:
                out.append(agent.associate.find_concept(node_id))
            except Exception:  # noqa: BLE001
                continue
    return out


def _is_episode(concept, people):
    describe = concept.describe or ""
    if SURVEY_TRACE in describe or "填写了" in describe and "问卷" in describe:
        return False
    if "filled in the research survey" in describe or "bedtime survey" in describe and "reported" in describe:
        return False
    if concept.node_type == "event":
        # Object-state events ("沙发 去茶水休息区…") are perception noise, not experiences.
        return concept.event.subject in people or bool(getattr(concept.event, "researcher_injected", False))
    return True


def _days_ago(day, today):
    delta = (today - day).days
    return _L("昨天", "yesterday") if delta == 1 else _L("{}天前", "{} days ago").format(delta)


def _todays_dialogues(agent, today_key, focus=None):
    dialogues = []
    for stamp in sorted(agent.conversation.keys()):
        if not stamp.startswith(today_key):
            continue
        for entry in agent.conversation[stamp]:
            for header, lines in entry.items():
                pair = header.split(" @ ")[0]
                names = [n.strip() for n in pair.split("->")]
                if agent.name not in names:
                    continue
                partner = [n for n in names if n != agent.name]
                partner = partner[0] if partner else ""
                where = header.split(" @ ")[1] if " @ " in header else ""
                dialogues.append({
                    "time": stamp[-5:], "partner": partner, "where": where,
                    "lines": [(n, t) for n, t in lines], "focus": bool(focus and partner == focus),
                })
    return dialogues


def _passive_retrieve(agent, focus, retrieve_max):
    """Retrieval that leaves memory access stamps untouched (measurement is passive)."""
    index = agent.associate.index
    docs = index._index.docstore.docs
    accesses = {key: node.metadata.get("access") for key, node in docs.items()}
    retrieve_config = copy.deepcopy(agent.associate._retrieve_config)
    strict_before = getattr(index, "strict_retrieval", False)
    index.strict_retrieval = True
    agent.associate._retrieve_config["read_only"] = True
    try:
        return agent.associate.retrieve_focus(focus, retrieve_max=retrieve_max)
    finally:
        for key, access in accesses.items():
            if key in docs:
                docs[key].metadata["access"] = access
        agent.associate._retrieve_config = retrieve_config
        index.strict_retrieval = strict_before


def _schedule_lines(agent):
    if not agent.schedule.scheduled():
        return []
    lines = []
    for plan in agent.schedule.daily_schedule:
        start, end = agent.schedule.plan_stamps(plan, time_format="%H:%M")
        lines.append("{}~{} {}".format(start, end, plan["describe"]))
    return lines


def _gather(agent, schema=None, ratee=None, now=None):
    """Collect the three layers (shared by the standard and the cache-friendly layout)."""
    from modules import utils
    now = now or utils.get_timer().get_date()
    today = now.date()
    today_key = now.strftime("%Y%m%d")
    people = _world_agents(agent)
    time_frame = (schema or {}).get("time_frame", "today")

    concepts = [c for c in _concepts(agent) if _is_episode(c, people)]
    todays = sorted([c for c in concepts if c.create.date() == today and c.node_type != "chat"],
                    key=lambda c: c.create)
    if ratee:
        todays = [c for c in todays if ratee in (c.describe or "")] + \
                 [c for c in todays if ratee not in (c.describe or "")]
    seen, today_items = set(), []
    for c in todays:
        key = c.describe
        if key in seen:
            continue
        seen.add(key)
        today_items.append({"text": "{} {}".format(c.create.strftime("%H:%M"), c.describe),
                            "poignancy": c.poignancy, "ratee": bool(ratee and ratee in c.describe)})

    dialogues = _todays_dialogues(agent, today_key, focus=ratee)

    # Layer 2: relevant earlier memories.
    if ratee:
        focus = [ratee, _L("{} 和 {} 的互动", "interactions between {} and {}").format(agent.name, ratee)]
    else:
        questions = [str(q.get("text", "")) for q in (schema or {}).get("questions", [])][:8]
        focus = [q.replace("{对象}", _L("同事", "a coworker")).replace("{ratee}", _L("同事", "a coworker")) for q in questions] or \
            [_L("今天的工作与人际互动", "today's work and interactions with others")]
    earlier = []
    try:
        retrieved = _passive_retrieve(agent, focus, retrieve_max=EARLIER_MAX * 2)
    except Exception:  # noqa: BLE001
        if agent.measurement_policy == "legacy_reactive":
            retrieved = []
        else:
            raise
    for c in retrieved:
        if c.create.date() >= today or not _is_episode(c, people) or c.describe in seen:
            continue
        seen.add(c.describe)
        earlier.append({"text": "{} {} {}".format(_days_ago(c.create.date(), today),
                                                  c.create.strftime("%H:%M"), c.describe),
                        "poignancy": c.poignancy})
        if len(earlier) >= EARLIER_MAX:
            break

    # Layer 3: settled views.
    relations = agent.scratch.config.get("relations") or {}
    impressions = []
    for name, info in sorted(relations.items()):
        if ratee and name != ratee:
            continue
        text = info.get("text") if isinstance(info, dict) else str(info)
        if text:
            impressions.append(_L("{}：{}", "{}: {}").format(name, text))
    summaries = []
    for day, text in sorted((agent.scratch.config.get("day_summaries") or {}).items()):
        try:
            day_date = datetime.datetime.strptime(day, "%Y%m%d").date()
        except ValueError:
            continue
        if day_date < today:
            summaries.append(_L("{}（{}）：{}", "{} ({}): {}").format(_day_label(day_date), _days_ago(day_date, today), text))

    current = []
    try:
        current.append(_L("现在的位置：", "Current location: ") + _L("，", ", ").join(agent.get_tile().get_address()[-2:]))
    except Exception:  # noqa: BLE001
        pass
    if agent.action:
        try:
            current.append(_L("刚才在做：", "Was just doing: ") + agent.action.event.get_describe())
        except Exception:  # noqa: BLE001
            pass
    current.append(_L("此刻的状态：", "Current status: ") + (agent.scratch.currently or ""))

    return {
        "now": now, "time_frame": time_frame, "today_items": today_items, "dialogues": dialogues,
        "earlier": earlier, "impressions": impressions, "summaries": summaries, "current": current,
    }


def build(agent, schema=None, ratee=None, budget_tokens=DEFAULT_BUDGET_TOKENS, now=None):
    """Return (context_text, meta) for one self-report (ratee=None) or dyadic survey."""
    g = _gather(agent, schema, ratee, now)
    now, time_frame = g["now"], g["time_frame"]
    today_items, dialogues, earlier = g["today_items"], g["dialogues"], g["earlier"]
    impressions, summaries, current = g["impressions"], g["summaries"], g["current"]

    def render(t_items, dlg, e_items):
        parts = []
        if time_frame in ("general", "recent", "week"):   # V24: multi-day frames lead with the earlier days
            if impressions:
                parts.append(_L("【对同事的印象】\n", "[Impressions of coworkers]\n") + "\n".join("- " + x for x in impressions))
            if summaries:
                parts.append(_L("【之前几天的概括】\n", "[Summaries of the previous days]\n") + "\n".join("- " + x for x in summaries))
        header = _L("【今天（{}）的经历】", "[Today's experiences ({})]").format(_day_label(now))
        parts.append(header + "\n" + ("\n".join("- " + x["text"] for x in t_items) or _L("（今天没有特别的经历记录）", "(no particular experiences recorded today)")))
        if dlg:
            blocks = []
            for d in dlg:
                lines = "\n".join(_L("  {}：{}", "  {}: {}").format(n, t) for n, t in d["lines"])
                blocks.append(_L("{} 与{}的对话（{}）：\n{}", "{} conversation with {} ({}):\n{}").format(d["time"], d["partner"], d["where"], lines))
            parts.append(_L("【今天的对话】\n", "[Today's conversations]\n") + "\n".join(blocks))
        sched = _schedule_lines(agent)
        if sched and not ratee:
            parts.append(_L("【今天的日程】\n", "[Today's schedule]\n") + _L("；", "; ").join(sched))
        if e_items:
            parts.append(_L("【想起的更早经历】\n", "[Earlier experiences that come to mind]\n") + "\n".join("- " + x["text"] for x in e_items))
        if time_frame not in ("general", "recent", "week"):
            if impressions:
                parts.append(_L("【对同事的印象】\n", "[Impressions of coworkers]\n") + "\n".join("- " + x for x in impressions))
            if summaries:
                parts.append(_L("【之前几天的概括】\n", "[Summaries of the previous days]\n") + "\n".join("- " + x for x in summaries))
        parts.append(_L("【此刻】\n", "[Right now]\n") + "\n".join(current))
        return "\n\n".join(parts)

    t_items, dlg, e_items = list(today_items), list(dialogues), list(earlier)
    dropped = {"today_items": 0, "earlier_items": 0, "dialogues": 0}
    text = render(t_items, dlg, e_items)
    while estimate_tokens(text) > budget_tokens:
        if t_items and len(t_items) > 5:
            idx = min(range(len(t_items)), key=lambda i: (t_items[i]["ratee"], t_items[i]["poignancy"]))
            t_items.pop(idx)
            dropped["today_items"] += 1
        elif e_items:
            idx = min(range(len(e_items)), key=lambda i: e_items[i]["poignancy"])
            e_items.pop(idx)
            dropped["earlier_items"] += 1
        elif len(dlg) > 1:
            idx = next((i for i, d in enumerate(dlg) if not d["focus"]), 0)
            dlg.pop(idx)
            dropped["dialogues"] += 1
        else:
            break
        text = render(t_items, dlg, e_items)

    meta = {
        "context_version": "three_layer_v1",
        "time_frame": time_frame,
        "est_tokens": estimate_tokens(text),
        "budget_tokens": budget_tokens,
        "today_items": len(t_items), "dialogues": len(dlg), "earlier_items": len(e_items),
        "dropped": dropped,
    }
    if ratee:
        meta["contact_dialogues_today"] = sum(1 for d in dialogues if d["partner"] == ratee)
        meta["contact_mentions_today"] = sum(1 for x in today_items if x["ratee"])
    return text, meta


SHARED_SHARE = 0.8   # cache layout: share of the budget for the part shared by all surveys of one moment


def build_cached(agent, schemas, ratee=None, budget_tokens=DEFAULT_BUDGET_TOKENS, now=None):
    """Cheap mode (H1/H5): the same layers as build(), laid out for prefix caching.

    Returns (shared_text, earlier_text, meta). shared_text does not depend on the
    questionnaire (fixed order: impressions, earlier days, today, dialogues,
    schedule, this moment) and is trimmed on its own, so every questionnaire of
    the same person (and rated colleague) at the same moment starts with exactly
    the same text. earlier_text holds the memories retrieved with the
    questionnaire(s) as query, placed after the shared part. ``schemas`` is one
    schema or a list (a merged call); the earlier memories are their union.
    """
    if isinstance(schemas, dict) or schemas is None:
        schemas = [schemas]
    gathered = [_gather(agent, s, ratee, now) for s in schemas]
    g = gathered[0]
    now, impressions, summaries, current = g["now"], g["impressions"], g["summaries"], g["current"]

    def render_shared(t_items, dlg):
        parts = []
        if impressions:
            parts.append(_L("【对同事的印象】\n", "[Impressions of coworkers]\n") + "\n".join("- " + x for x in impressions))
        if summaries:
            parts.append(_L("【之前几天的概括】\n", "[Summaries of the previous days]\n") + "\n".join("- " + x for x in summaries))
        header = _L("【今天（{}）的经历】", "[Today's experiences ({})]").format(_day_label(now))
        parts.append(header + "\n" + ("\n".join("- " + x["text"] for x in t_items) or _L("（今天没有特别的经历记录）", "(no particular experiences recorded today)")))
        if dlg:
            blocks = []
            for d in dlg:
                lines = "\n".join(_L("  {}：{}", "  {}: {}").format(n, t) for n, t in d["lines"])
                blocks.append(_L("{} 与{}的对话（{}）：\n{}", "{} conversation with {} ({}):\n{}").format(d["time"], d["partner"], d["where"], lines))
            parts.append(_L("【今天的对话】\n", "[Today's conversations]\n") + "\n".join(blocks))
        sched = _schedule_lines(agent)
        if sched and not ratee:
            parts.append(_L("【今天的日程】\n", "[Today's schedule]\n") + _L("；", "; ").join(sched))
        parts.append(_L("【此刻】\n", "[Right now]\n") + "\n".join(current))
        return "\n\n".join(parts)

    shared_budget = int(budget_tokens * SHARED_SHARE)
    t_items, dlg = list(g["today_items"]), list(g["dialogues"])
    dropped = {"today_items": 0, "earlier_items": 0, "dialogues": 0}
    shared = render_shared(t_items, dlg)
    while estimate_tokens(shared) > shared_budget:
        if t_items and len(t_items) > 5:
            idx = min(range(len(t_items)), key=lambda i: (t_items[i]["ratee"], t_items[i]["poignancy"]))
            t_items.pop(idx)
            dropped["today_items"] += 1
        elif len(dlg) > 1:
            idx = next((i for i, d in enumerate(dlg) if not d["focus"]), 0)
            dlg.pop(idx)
            dropped["dialogues"] += 1
        else:
            break
        shared = render_shared(t_items, dlg)

    seen, e_items = set(), []
    cap = EARLIER_MAX * min(2, len(gathered))
    for each in gathered:
        for item in each["earlier"]:
            if item["text"] not in seen:
                seen.add(item["text"])
                e_items.append(item)
    remaining = max(0, budget_tokens - estimate_tokens(shared))

    def render_earlier(items):
        return "\n".join("- " + x["text"] for x in items)

    while e_items and (len(e_items) > cap or estimate_tokens(render_earlier(e_items)) > remaining):
        idx = min(range(len(e_items)), key=lambda i: e_items[i]["poignancy"])
        e_items.pop(idx)
        dropped["earlier_items"] += 1
    earlier = render_earlier(e_items)

    meta = {
        "context_version": "three_layer_v1",
        "layout": "cache_v1",
        "time_frame": g["time_frame"] if len(gathered) == 1 else "mixed",
        "est_tokens": estimate_tokens(shared) + estimate_tokens(earlier),
        "budget_tokens": budget_tokens,
        "today_items": len(t_items), "dialogues": len(dlg), "earlier_items": len(e_items),
        "dropped": dropped,
    }
    if ratee:
        meta["contact_dialogues_today"] = sum(1 for d in g["dialogues"] if d["partner"] == ratee)
        meta["contact_mentions_today"] = sum(1 for x in g["today_items"] if x["ratee"])
    return shared, earlier, meta
