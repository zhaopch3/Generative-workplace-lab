# -*- coding: utf-8 -*-
"""Big Five personality sampling from real respondents (V23).

Each world draws one complete Big Five profile per agent from a pool of real
IPIP-50 respondents (Open Psychometrics BIG5 data, complete answers, age 22-55;
see data/personality/SOURCE.md).  Domain percentiles are mapped to nine levels
and rendered with bipolar trait adjectives and linguistic qualifiers, following
the shaping method of Serapio-Garcia et al. (2023, "Personality traits in large
language models").  The Chinese adjective list below is a working translation
of that marker set and should be checked against the paper's appendix before
publication.

Numbers never enter the prompt: only adjectives with qualifiers.
"""
import csv
import os
import random

POOL_PATH = os.path.join("data", "personality", "ipip_big5_pool.csv")

DOMAINS = ("extraversion", "agreeableness", "conscientiousness", "neuroticism", "openness")
DOMAIN_LABELS = {
    "extraversion": "外向性", "agreeableness": "宜人性", "conscientiousness": "尽责性",
    "neuroticism": "神经质", "openness": "开放性",
}

# (low pole, high pole) adjective pairs per domain.
ADJECTIVES = {
    "extraversion": [
        ("不友善", "友善"), ("内向", "外向"), ("沉默寡言", "健谈"), ("胆小", "大胆"),
        ("不爱表达主张", "敢于表达主张"), ("不活跃", "活跃"), ("缺乏活力", "精力充沛"),
        ("不爱冒险", "爱冒险"), ("忧郁", "开朗"),
    ],
    "agreeableness": [
        ("多疑", "信任他人"), ("不讲道德", "讲道德"), ("不诚实", "诚实"), ("不友好", "友好"),
        ("吝啬", "慷慨"), ("不利他", "利他"), ("不合作", "合作"), ("自负", "谦逊"),
        ("缺乏同情心", "富有同情心"), ("自私", "无私"), ("难相处", "随和"),
    ],
    "conscientiousness": [
        ("缺乏自信", "自我效能感强"), ("凌乱", "整洁有序"), ("不负责任", "负责任"),
        ("懒散", "勤奋"), ("缺乏自律", "自律"), ("不切实际", "务实"), ("铺张", "节俭"),
        ("没有条理", "有条理"), ("马虎疏忽", "认真尽责"), ("粗心", "周密细致"),
    ],
    "neuroticism": [
        ("放松", "紧张"), ("从容", "焦躁"), ("随遇而安", "容易焦虑"), ("平静", "易怒"),
        ("有耐心", "急躁"), ("快乐", "抑郁"), ("不在意别人眼光", "在意别人眼光"),
        ("沉着冷静", "冲动"), ("知足", "不满足"), ("情绪稳定", "情绪不稳定"),
    ],
    "openness": [
        ("缺乏想象力", "富有想象力"), ("缺乏创造力", "富有创造力"), ("不懂欣赏艺术", "懂得欣赏艺术"),
        ("缺乏审美", "有审美"), ("不爱反思", "爱反思"), ("情感上封闭", "情感上敏锐"),
        ("缺乏好奇心", "好奇"), ("循规蹈矩", "随性"), ("不够聪明", "聪明"),
        ("不善分析", "善于分析"), ("缺乏见识", "有见识"), ("思想保守", "思想开放"),
    ],
}

QUALIFIERS = {1: "极其", 2: "非常", 3: "", 4: "有点", 6: "有点", 7: "", 8: "非常", 9: "极其"}


def level_from_percentile(pct):
    """Nine equal-width percentile bands -> level 1..9."""
    pct = max(0.0, min(100.0, float(pct)))
    return min(9, int(pct // (100.0 / 9)) + 1)


def describe_domain(domain, level):
    words = []
    for low, high in ADJECTIVES[domain]:
        if level < 5:
            words.append(QUALIFIERS[level] + low)
        elif level > 5:
            words.append(QUALIFIERS[level] + high)
        else:
            words.append("既不{}也不{}".format(low, high))
    return "、".join(words)


def describe_profile(levels, style="markers"):
    """Prompt text for one agent; domains in a fixed order, no numbers."""
    if style == "bfi10":
        return describe_profile_bfi10(levels)
    if _en():
        # The English marker list of Serapio-Garcia et al. (2023) has not been verified in full
        # (Supplemental Table 13); English worlds use the BFI-10 descriptors only.
        raise ValueError("English worlds support personality style bfi10 only")
    return "；".join(describe_domain(d, levels[d]) for d in DOMAINS) + "。"


# V24 compact style: two descriptors per domain, one for each BFI-10 item
# (Rammstedt & John 2007; English items as listed by GESIS). The item keyed toward
# the low pole gives one phrase, the item keyed toward the high pole the other.
#   E: "is reserved" (R), "is outgoing, sociable"
#   A: "is generally trusting", "tends to find fault with others" (R)
#   C: "tends to be lazy" (R), "does a thorough job"
#   N: "is relaxed, handles stress well" (R), "gets nervous easily"
#   O: "has few artistic interests" (R), "has an active imagination"
BFI10_PHRASES = {
    # domain: (low pole, middle, high pole)
    "extraversion": ("拘谨、不爱交际", "内外向适中", "外向合群、不拘谨"),
    "agreeableness": ("多疑、爱挑剔别人", "对人信任和挑剔的程度一般", "信任别人、不爱挑剔别人"),
    "conscientiousness": ("马虎、懒散", "认真和勤快的程度一般", "认真周到、勤快"),
    "neuroticism": ("放松、不容易紧张、抗压能力强", "紧张程度和抗压能力一般", "容易紧张、难以放松、抗压能力差"),
    "openness": ("缺乏想象力、对艺术兴趣不大", "想象力和艺术兴趣一般", "富有想象力、喜欢艺术"),
}
BFI10_QUALIFIERS = {1: "极其", 2: "非常", 3: "比较", 4: "有点", 6: "有点", 7: "比较", 8: "非常", 9: "极其"}


# V27 English worlds: the same descriptors in English, built from the same BFI-10 items
# (low pole, middle, high pole). Each pole is an adjective phrase so a qualifier can lead it.
BFI10_PHRASES_EN = {
    "extraversion": ("reserved, not sociable", "neither particularly reserved nor particularly outgoing",
                     "outgoing and sociable, not reserved"),
    "agreeableness": ("distrustful, quick to find fault with others",
                      "average in trusting others and in finding fault with them",
                      "trusting, not inclined to find fault with others"),
    "conscientiousness": ("careless and lazy", "average in thoroughness and diligence",
                          "thorough and hard-working"),
    "neuroticism": ("relaxed, not easily nervous, good at handling stress",
                    "average in nervousness and in handling stress",
                    "easily nervous, unable to relax, poor at handling stress"),
    "openness": ("unimaginative, not interested in art", "average in imagination and interest in art",
                 "imaginative, fond of art"),
}
BFI10_QUALIFIERS_EN = {1: "extremely ", 2: "very ", 3: "fairly ", 4: "a bit ", 6: "a bit ",
                       7: "fairly ", 8: "very ", 9: "extremely "}


def _en():
    from modules import lang
    return lang.is_en()


def describe_domain_bfi10(domain, level):
    if _en():
        low, middle, high = BFI10_PHRASES_EN[domain]
        if level == 5:
            return middle
        return BFI10_QUALIFIERS_EN[level] + (low if level < 5 else high)
    low, middle, high = BFI10_PHRASES[domain]
    if level == 5:
        return middle
    return BFI10_QUALIFIERS[level] + (low if level < 5 else high)


def describe_profile_bfi10(levels):
    if _en():
        text = "; ".join(describe_domain_bfi10(d, levels[d]) for d in DOMAINS) + "."
        return text[0].upper() + text[1:]
    return "；".join(describe_domain_bfi10(d, levels[d]) for d in DOMAINS) + "。"


_POOL = None


def load_pool(path=POOL_PATH):
    global _POOL
    if _POOL is None or path != POOL_PATH:
        with open(path, "r", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        if path != POOL_PATH:
            return rows
        _POOL = rows
    return _POOL


def sample_profiles(agents, seed, pool=None, style="markers"):
    """Draw distinct respondents for ``agents`` with a private RNG.

    The same seed and agent list always return the same respondents, so paired
    high/low worlds that share a seed share personalities.
    """
    pool = pool if pool is not None else load_pool()
    rng = random.Random("big5-%s" % int(seed))
    picks = rng.sample(range(len(pool)), len(agents))
    profiles = {}
    for agent, index in zip(agents, picks):
        row = pool[index]
        scores = {d: float(row[d]) for d in DOMAINS}
        pcts = {d: float(row[d + "_pct"]) for d in DOMAINS}
        levels = {d: level_from_percentile(pcts[d]) for d in DOMAINS}
        profiles[agent] = {
            "source_row": int(row["source_row"]),
            "scores_1to5": scores,
            "percentiles": pcts,
            "levels_1to9": levels,
            "text": describe_profile(levels, style),
        }
    return profiles


def apply_to_config(config, agents, seed, settings=None):
    """Write sampled personalities into each agent's ``innate`` field and record provenance."""
    settings = settings or {}
    targets = [a for a in (settings.get("agents") or agents) if a in agents]
    # V24: "bfi10" = two descriptors per domain (default for new worlds);
    # "markers" = the V23 full adjective list. The sampled respondents do not depend on it.
    style = settings.get("style") or "bfi10"
    if style not in ("bfi10", "markers"):
        raise ValueError("personality style must be bfi10 or markers")
    profiles = sample_profiles(targets, seed, style=style)
    for agent, profile in profiles.items():
        agent_cfg = config["agents"][agent]
        scratch = dict(agent_cfg.get("scratch") or {})
        scratch["innate"] = profile["text"]
        agent_cfg["scratch"] = scratch
    config["personality"] = {
        "method": "ipip_big5_real_respondent_v1",
        "pool": POOL_PATH,
        "seed": int(seed),
        "levels": "9 equal-width percentile bands",
        "style": style,
        "text_method": ("two descriptors per domain from the BFI-10 items (Rammstedt & John 2007)"
                        if style == "bfi10" else "adjective markers after Serapio-Garcia et al. 2023"),
        "profiles": profiles,
    }
    return config
