# -*- coding: utf-8 -*-
"""V27: English simulation worlds.

An English world uses English prompts, personas, map names, leadership texts and surveys,
and its answers are parsed with English patterns. Chinese worlds are unchanged.
"""
import json
import os
import re
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import server  # noqa: E402
from modules import lang  # noqa: E402

CJK = re.compile(r"[一-鿿　-〿＀-￯]")
EN_TEMPLATES = ("Persona-manipulation-high-abuse", "Persona-manipulation-low-abuse",
                "Event-manipulation-high-abuse", "Event-manipulation-low-abuse")
ZH_OF = {"Persona-manipulation-high-abuse": "人设操纵-高辱虐组", "Persona-manipulation-low-abuse": "人设操纵-低辱虐组",
         "Event-manipulation-high-abuse": "事件操纵-高辱虐组", "Event-manipulation-low-abuse": "事件操纵-低辱虐组"}


def template(name):
    with open(ROOT / "data" / "world_presets" / (name + ".json"), encoding="utf-8") as f:
        return json.load(f)


def cjk_in(value):
    """CJK characters anywhere in a JSON-like value, except the ratee placeholder {对象}."""
    text = json.dumps(value, ensure_ascii=False).replace("{对象}", "")
    return CJK.findall(text)


class AssetTests(unittest.TestCase):
    def test_prompt_files_match(self):
        zh = sorted(os.listdir(ROOT / "data" / "prompts"))
        en = sorted(os.listdir(ROOT / "data" / "prompts_en"))
        self.assertEqual(zh, en)
        for name in zh:
            a = (ROOT / "data" / "prompts" / name).read_text(encoding="utf-8")
            b = (ROOT / "data" / "prompts_en" / name).read_text(encoding="utf-8")
            self.assertEqual(set(re.findall(r"\$\{(\w+)\}", a)), set(re.findall(r"\$\{(\w+)\}", b)), name)
            self.assertFalse(CJK.findall(b), name)

    def test_templates_have_no_chinese(self):
        # V27.2: English templates carry no Chinese at all, not even the ratee placeholder or battery grades
        for en_name in EN_TEMPLATES:
            text = (ROOT / "data" / "world_presets" / (en_name + ".json")).read_text(encoding="utf-8")
            self.assertFalse(CJK.findall(text), en_name)
            self.assertNotIn("{对象}", json.dumps(template(en_name), ensure_ascii=False))

    def test_templates_mirror_chinese(self):
        for en_name in EN_TEMPLATES:
            en, zh = template(en_name), template(ZH_OF[en_name])
            self.assertEqual(en["language"], "en")
            self.assertEqual(sorted(set(en) - {"language"}), sorted(zh))
            for key in zh:
                if key not in ("agents", "world_rules", "custom_surveys", "scheduled_events"):
                    self.assertEqual(en[key], zh[key], (en_name, key))
            self.assertEqual(en["agents"], [lang.NAMES[n] for n in zh["agents"]])
            self.assertEqual([s["id"] for s in en["custom_surveys"]], [s["id"] for s in zh["custom_surveys"]])
            for a, b in zip(en["custom_surveys"], zh["custom_surveys"]):
                self.assertEqual([q["id"] for q in a["questions"]], [q["id"] for q in b["questions"]])
                self.assertEqual([q.get("reverse", False) for q in a["questions"]],
                                 [q.get("reverse", False) for q in b["questions"]])
            self.assertFalse(cjk_in({k: v for k, v in en.items() if k != "custom_surveys"}), en_name)
            agent_visible = [{k: s.get(k) for k in ("display_title", "instructions", "questions")}
                             for s in en["custom_surveys"]]
            self.assertFalse(cjk_in(agent_visible), en_name)

    def test_english_agents_and_conditions(self):
        for zh, en in lang.NAMES.items():
            with open(ROOT / "frontend/static/assets/village/agents" / en / "agent.json", encoding="utf-8") as f:
                agent = json.load(f)
            self.assertEqual(agent["name"], en)
            self.assertFalse(cjk_in(agent), en)
            self.assertIn("sleep", agent["spatial"]["address"])
        with open(ROOT / "data" / "experiment_conditions.json", encoding="utf-8") as f:
            cond = json.load(f)
        for key in ("high_abuse", "low_abuse"):
            en = cond[key]["translations"]["en"]
            self.assertEqual(en["leader"], "Klaus")
            text = en["leader_overrides"]["scratch"]["conduct"]
            self.assertEqual(re.findall(r"^(\d)\. ", text, re.M), [str(i) for i in range(1, 10)])
            self.assertFalse(CJK.findall(text))
        high = cond["high_abuse"]["translations"]["en"]["leader_overrides"]["scratch"]["conduct"]
        for word in ("abus", "mean-spirited", "nasty", "harass", "lie ", "lying", "hurt", "harm", "incompetent"):
            self.assertNotIn(word, high.lower())

    def test_config_is_english_and_chinese_unchanged(self):
        payload = template("Persona-manipulation-high-abuse")
        payload.update(name="v27-en", offline=True)
        _, _, cfg = server.build_experiment_config(payload)
        self.assertEqual(cfg["language"], "en")
        self.assertIn("Klaus has led the team for many years", cfg["agents"]["Klaus"]["scratch"]["conduct"])
        self.assertTrue(cfg["agents"]["Ayesha"]["scratch"]["innate"][0].isupper())
        self.assertFalse(CJK.findall(cfg["agents"]["Ayesha"]["scratch"]["innate"]))
        self.assertEqual(lang.get_language(), "zh")       # building did not switch the process
        zh = template("人设操纵-高辱虐组")
        zh.update(name="v27-zh", offline=True)
        _, _, zcfg = server.build_experiment_config(zh)
        self.assertNotIn("language", zcfg)
        self.assertIn("克劳斯带组多年", zcfg["agents"]["克劳斯"]["scratch"]["conduct"])
        # different languages never share a comparison group
        self.assertNotEqual(server.comparison_signature(payload), server.comparison_signature(zh))

    def test_template_check_passes_in_english(self):
        from modules.research import world_check
        for name in EN_TEMPLATES:
            result, _ = world_check.preview_payload(template(name))
            self.assertEqual(result["errors"], [], name)
            self.assertIn("[Background]", result["personas"]["Klaus"])


class ParserTests(unittest.TestCase):
    def setUp(self):
        lang.set_language("en")

    def tearDown(self):
        lang.set_language("zh")

    def scratch(self):
        from modules.prompt.scratch import Scratch
        s = Scratch.__new__(Scratch)
        s.name = "Klaus"
        return s

    def test_yes_no_and_option(self):
        from modules.prompt.scratch import _yes_en
        self.assertTrue(_yes_en("Yes"))
        self.assertFalse(_yes_en("No."))
        self.assertTrue(_yes_en("I know they are not busy now. Answer: Yes"))
        self.assertFalse(_yes_en("Reasoning: ... Answer: no"))
        self.assertTrue(_yes_en("Not sure, but yes"))   # no "no" as a word -> yes, like the Chinese default

    def test_location_matching(self):
        from modules.prompt.scratch import _match_option
        options = ["open office area", "team lead office", "meeting area"]
        self.assertEqual(_match_option("The Meeting Area.", options), "meeting area")
        self.assertEqual(_match_option("<team lead office>", options), "team lead office")
        self.assertEqual(_match_option("go to the open office area", options), "open office area")

    def test_office_keywords(self):
        from modules.agent import Agent
        a = Agent.__new__(Agent)
        self.assertTrue(a._has_office_keyword("eating lunch in the break room", "meal"))
        self.assertFalse(a._has_office_keyword("creating a great campaign", "meal"))
        self.assertFalse(a._has_office_keyword("meeting with the team", "break"))   # "tea" in "team"
        self.assertTrue(a._has_office_keyword("getting ready for bed", "sleep"))
        self.assertTrue(a._has_office_keyword("going to the team lead office to report on progress", "leader"))
        self.assertFalse(a._has_office_keyword("writing copy for the campaign", "print"))

    def test_dates_and_events(self):
        import datetime
        from modules.utils.timer import Timer
        from modules.memory.event import Event
        timer = Timer(start="20240212-09:00")
        self.assertEqual(timer.daily_format_cn(), "Monday, February 12, 2024")
        self.assertEqual(timer.time_format_cn(datetime.datetime(2024, 2, 13, 15, 5)), "Tuesday, February 13, 2024 15:05")
        self.assertEqual(Event("Ayesha", "is", "x", describe="reviewing the draft").get_describe(),
                         "Ayesha is reviewing the draft")
        self.assertEqual(Event("Ayesha", "is", "x", describe="reviewing the draft").get_describe(False),
                         "reviewing the draft")
        self.assertEqual(Event("Ayesha").get_describe(), "Ayesha is idle")
        lang.set_language("zh")
        self.assertEqual(Timer(start="20240212-09:00").daily_format_cn(), "2024年02月12日（星期一）")
        self.assertEqual(Event("阿伊莎", describe="审阅草稿").get_describe(), "阿伊莎 审阅草稿")
        self.assertEqual(Event("阿伊莎").get_describe(), "阿伊莎 此时 空闲")


class FakeEnglishLLM:
    """Plausible English answers for every prompt type, run through the real callbacks."""

    def __init__(self, name):
        self.name = name
        self.prompts = []
        self.meta_responses = []
        self.failed = []

    def is_available(self):
        return True

    def get_summary(self):
        return {}

    def answer(self, caller, prompt):
        n = self.name
        if caller == "wake_up":
            return "7:00"
        if caller == "schedule_init":
            return "1. wake up at 7:00\n2. work on the weekly report at 9:00\n3. have lunch at 12:00\n4. go to bed at 22:00"
        if caller == "schedule_daily":
            hours = re.findall(r"\[(\d{1,2}):00\] <activity>", prompt)
            acts = ["working on the weekly report at my desk", "eating lunch in the break room",
                    "discussing the campaign with Maria in the meeting area", "getting ready for bed in the dormitory"]
            return "\n".join("[{}:00] {}".format(h, acts[i % len(acts)]) for i, h in enumerate(hours))
        if caller == "schedule_decompose":
            return ("1) {n} *plan* reviewing the draft (duration in minutes: 30, minutes left: 30)\n"
                    "2) {n} *plan* sending the draft to Klaus (duration in minutes: 30, minutes left: 0)").format(n=n)
        if caller in ("determine_sector", "determine_arena"):
            options = re.findall(r"\[([^\]]+)\]", prompt.split("Requirements:")[1])[0].split(", ")
            return "{} should go to: {}.".format(n, options[0].title())
        if caller == "determine_object":
            options = re.findall(r"\[([^\]]+)\]", prompt)[-1].split(", ")
            return "The most relevant object is: {}".format(options[-1])
        if caller in ("decide_chat",):
            return "Answer: Yes"
        if caller in ("decide_chat_terminate", "generate_chat_check_repeat"):
            return "No"
        if caller == "decide_wait":
            return "Answer: <Option B>"
        if caller == "summarize_relation":
            return "They are coworkers on the same team."
        if caller == "generate_chat":
            return json.dumps({n: "Do you have a minute to go over the report?", "end": False})
        if caller == "summarize_chats":
            return "They talked about the weekly report."
        if caller in ("poignancy_event", "poignancy_chat"):
            return "Rating: 6"
        if caller == "poignancy_batch":
            count = int(re.search(r"Here are the (\d+) events", prompt).group(1))
            return json.dumps([5] * count)
        if caller == "reflect_focus":
            return "1. How does Klaus see my work?\n2. What should I finish today?\n3. Who can help me?"
        if caller == "reflect_insights":
            return "1. I feel under pressure from Klaus (because of 0, 1)\n2. I want to finish the report early (because of 1)"
        if caller in ("reflect_chat_planing", "reflect_chat_memory", "retrieve_thought"):
            return "I should finish the report before Friday."
        if caller == "retrieve_plan":
            return "1. Finish the weekly report by Friday at 18:00."
        if caller == "retrieve_currently":
            return "Status: {} is preparing for a busy week and wants to keep good terms with the team.".format(n)
        if caller == "psych_appraisal":
            return '{"mood": -1, "stress": 1, "energy": 0, "sociality": 0}'
        if caller == "react_to_injection":
            return '{"keep_schedule": true, "next_activity": "", "area": "", "minutes": 30}'
        if caller == "schedule_revise":
            return "[10:00 to 10:30] continuing the weekly report"
        if caller.startswith("custom_survey"):
            return prompt.rsplit("Example output format:", 1)[1].strip()
        return None

    def completion(self, prompt, retry=10, callback=None, failsafe=None, caller="", **kwargs):
        self.prompts.append((caller, prompt))
        raw = self.answer(caller, prompt)
        if raw is None:
            return failsafe
        try:
            out = callback(raw) if callback else raw
        except Exception as exc:  # noqa: BLE001
            self.failed.append((caller, repr(exc)))
            return failsafe
        if out is None:
            self.failed.append((caller, "None"))
            return failsafe
        return out


class EnglishWorldTest(unittest.TestCase):
    """One offline English day (persona manipulation, high abuse) with an English fake model."""

    def test_one_day(self):
        from start import SimulateServer
        origin = Path.cwd()
        payload = template("Persona-manipulation-high-abuse")
        payload.update(name="v27-english", offline=True, step=16)
        _, args, cfg = server.build_experiment_config(payload)
        with tempfile.TemporaryDirectory() as root:
            os.chdir(root)
            try:
                run = SimulateServer(args.name, str(origin / "frontend/static"),
                                     "results/checkpoints/" + args.name, cfg, verbose="error")
                fakes = []
                for agent in run.game.agents.values():
                    agent.scratch.template_path = str(origin / "data/prompts_en")
                    agent._llm = FakeEnglishLLM(agent.name)
                    fakes.append(agent._llm)
                run.simulate(16, stride=60)
                rows = {}
                folder = "results/surveys/" + args.name
                for f in os.listdir(folder):
                    if f.startswith("custom_") and f.endswith(".jsonl"):
                        with open(os.path.join(folder, f), encoding="utf-8") as fh:
                            rows[f[7:-6]] = [json.loads(x) for x in fh]
                schedules = {a.name: [p["describe"] for p in a.schedule.daily_schedule]
                             for a in run.game.agents.values()}
                addresses = {a.name: a.get_tile().get_address() for a in run.game.agents.values()}
            finally:
                os.chdir(origin)
                lang.set_language("zh")
        prompts = [p for fake in fakes for p in fake.prompts]
        failed = [f for fake in fakes for f in fake.failed]
        callers = {c for c, _ in prompts}
        for needed in ("wake_up", "schedule_init", "schedule_daily", "custom_survey", "custom_survey_dyadic"):
            self.assertIn(needed, callers)
        leaks = [(c, sorted(set(CJK.findall(p)))[:10]) for c, p in prompts if CJK.search(p)]
        self.assertEqual(leaks[:5], [], "Chinese text in English prompts")
        self.assertEqual(failed, [], "English answers that the parsers rejected")
        self.assertTrue(rows)
        for sid, items in rows.items():
            for row in items:
                self.assertNotEqual((row.get("_quality") or {}).get("status"), "invalid", (sid, row.get("agent")))
        for name, plans in schedules.items():
            self.assertTrue(any("weekly report" in p for p in plans), (name, plans))
        for name, address in addresses.items():
            self.assertFalse(CJK.findall(":".join(address)), (name, address))


class EnglishAgentRosterTest(unittest.TestCase):
    """V27.3: every Chinese agent has an English counterpart, listed before the Chinese ones."""

    def test_every_chinese_agent_has_english_version(self):
        root = ROOT / "frontend/static/assets/village/agents"
        chinese = sorted(p.name for p in root.iterdir() if (p / "agent.json").exists() and CJK.search(p.name))
        self.assertEqual(sorted(lang.NAMES), chinese)
        self.assertEqual(len(set(lang.NAMES.values())), len(lang.NAMES))
        for en in lang.NAMES.values():
            self.assertTrue((root / en / "portrait.png").exists(), en)
            self.assertTrue((root / en / "texture.png").exists(), en)

    def test_english_agents_listed_first(self):
        names = [a["name"] for a in server.list_available_agents()]
        first_chinese = next(i for i, n in enumerate(names) if CJK.search(n))
        self.assertTrue(all(CJK.search(n) for n in names[first_chinese:]))
        self.assertEqual(names[:4], ["Klaus", "Ayesha", "Maria", "Wolfgang"])
        self.assertEqual(first_chinese, len(lang.NAMES))


if __name__ == "__main__":
    unittest.main()
