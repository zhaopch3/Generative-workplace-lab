# -*- coding: utf-8 -*-
"""V25.3: decorative surroundings drawn around the office map."""
import json
import unittest
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
TILEMAP = ROOT / "frontend" / "static" / "assets" / "village" / "tilemap"


class BackdropTests(unittest.TestCase):
    def test_backdrop_matches_map(self):
        meta = json.load(open(TILEMAP / "backdrop.json", encoding="utf-8"))
        m = json.load(open(TILEMAP / "tilemap.json", encoding="utf-8"))
        pad, tile = meta["pad_tiles"], meta["tile"]
        self.assertEqual(tile, m["tilewidth"])
        size = Image.open(TILEMAP / "backdrop.png").size
        self.assertEqual(size, ((m["width"] + pad["left"] + pad["right"]) * tile,
                                (m["height"] + pad["top"] + pad["bottom"]) * tile))
        self.assertEqual(list(size), meta["size"])

    def test_viewer_loads_backdrop_below_the_map(self):
        js = (ROOT / "frontend" / "templates" / "live_script.html").read_text(encoding="utf-8")
        self.assertIn('this.load.image("backdrop"', js)
        self.assertIn(".setDepth(-10)", js)


if __name__ == "__main__":
    unittest.main()
