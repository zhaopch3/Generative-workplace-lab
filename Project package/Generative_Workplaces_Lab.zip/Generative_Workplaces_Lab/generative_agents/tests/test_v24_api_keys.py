# -*- coding: utf-8 -*-
"""V24: the API settings panel saves the chat-model key and the embedding key in one request."""
import json
import os
import shutil
import tempfile
import unittest
from unittest import mock

import server

PROJECT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KEY_VARS = ("OPENROUTER_API_KEY", "DEEPSEEK_API_KEY", "OPENAI_API_KEY", "DASHSCOPE_API_KEY", "EMBEDDING_API_KEY")


class ApiKeySettingsTests(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp()
        os.makedirs(os.path.join(self.root, "data"))
        shutil.copy(os.path.join(PROJECT, "data", "config.json"), os.path.join(self.root, "data", "config.json"))
        self.old_cwd = os.getcwd()
        os.chdir(self.root)
        self.env = mock.patch.dict(os.environ, {k: "" for k in KEY_VARS})
        self.env.start()
        for k in KEY_VARS:
            os.environ.pop(k, None)
        self.client = server.create_app({"runner": None}).test_client()

    def tearDown(self):
        self.env.stop()
        os.chdir(self.old_cwd)
        shutil.rmtree(self.root)

    def post(self, **body):
        base = {"provider": "deepseek", "model": "deepseek-chat", "base_url": "",
                "embedding_type": "", "embedding_model": ""}
        base.update(body)
        return self.client.post("/api/llm_settings", json=base)

    def env_file(self):
        with open(".env", encoding="utf-8") as f:
            return f.read()

    def embedding(self):
        with open(os.path.join("data", "config.json"), encoding="utf-8") as f:
            return json.load(f)["agent"]["associate"]["embedding"]

    def test_deepseek_chat_and_openrouter_embedding_saved_together(self):
        r = self.post(api_key="sk-deepseek-test-000000", embedding_api_key="sk-or-test-1111111111")
        d = r.get_json()
        self.assertTrue(d["ok"], d)
        self.assertEqual(d["warnings"], [])
        text = self.env_file()
        self.assertIn("DEEPSEEK_API_KEY=sk-deepseek-test-000000", text)
        self.assertIn("OPENROUTER_API_KEY=sk-or-test-1111111111", text)
        emb = self.embedding()
        self.assertEqual(emb["type"], "openrouter")
        self.assertEqual(emb["model"], "openai/text-embedding-3-small")

    def test_missing_embedding_key_warns(self):
        d = self.post(api_key="sk-deepseek-test-000000").get_json()
        self.assertTrue(d["ok"])
        self.assertTrue(any("OPENROUTER_API_KEY" in w for w in d["warnings"]))

    def test_conflicting_keys_for_same_service_are_rejected_before_writing(self):
        r = self.post(provider="openrouter", model="deepseek/deepseek-v4-flash",
                      api_key="sk-or-aaaaaaaaaaaaaa", embedding_api_key="sk-or-bbbbbbbbbbbbbb")
        self.assertEqual(r.status_code, 400)
        self.assertFalse(os.path.exists(".env"))

    def test_local_embedding_rejects_key(self):
        r = self.post(api_key="sk-deepseek-test-000000", embedding_type="ollama", embedding_api_key="x" * 20)
        self.assertEqual(r.status_code, 400)
        self.assertFalse(os.path.exists(".env"))

    def test_local_model_name_not_sent_to_cloud_channel(self):
        d = self.post(api_key="sk-deepseek-test-000000", embedding_api_key="sk-or-test-1111111111",
                      embedding_type="openrouter", embedding_model="bge-m3:latest").get_json()
        self.assertTrue(d["ok"])
        self.assertEqual(self.embedding()["model"], "openai/text-embedding-3-small")

    def test_dashscope_embedding_saved_with_its_own_key(self):
        d = self.post(api_key="sk-deepseek-test-000000", embedding_type="dashscope",
                      embedding_api_key="sk-dashscope-test-2222").get_json()
        self.assertTrue(d["ok"], d)
        self.assertEqual(d["warnings"], [])
        self.assertIn("DASHSCOPE_API_KEY=sk-dashscope-test-2222", self.env_file())
        emb = self.embedding()
        self.assertEqual((emb["type"], emb["model"]), ("dashscope", "text-embedding-v4"))
        self.assertIn("dashscope.aliyuncs.com/compatible-mode/v1", emb["base_url"])

    def test_custom_embedding_needs_url_and_model(self):
        r = self.post(api_key="sk-deepseek-test-000000", embedding_type="custom", embedding_api_key="k" * 20)
        self.assertEqual(r.status_code, 400)
        d = self.post(api_key="sk-deepseek-test-000000", embedding_type="custom", embedding_api_key="k" * 20,
                      embedding_base_url="https://api.siliconflow.cn/v1/", embedding_model="BAAI/bge-m3").get_json()
        self.assertTrue(d["ok"], d)
        self.assertEqual(self.embedding(), {"type": "custom", "base_url": "https://api.siliconflow.cn/v1",
                                            "model": "BAAI/bge-m3"})
        self.assertIn("EMBEDDING_API_KEY=" + "k" * 20, self.env_file())

    def test_index_builds_dashscope_embedding_from_env(self):
        from modules.storage import index
        os.environ["DASHSCOPE_API_KEY"] = "sk-x"
        idx = index.LlamaIndex({"type": "dashscope", "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
                                "model": "text-embedding-v4"}, path=None)
        self.assertIsNotNone(idx)

    def test_cloud_model_name_not_sent_to_ollama(self):
        d = self.post(api_key="sk-deepseek-test-000000", embedding_type="ollama",
                      embedding_model="openai/text-embedding-3-small").get_json()
        self.assertTrue(d["ok"], d)
        self.assertEqual(self.embedding()["model"], "bge-m3:latest")

    def test_panel_has_separate_embedding_key_field(self):
        with open(os.path.join(PROJECT, "frontend", "templates", "experiments.html"), encoding="utf-8") as f:
            html = f.read()
        self.assertIn('id="emb-key"', html)
        self.assertIn("embedding_api_key", html)


if __name__ == "__main__":
    unittest.main()
