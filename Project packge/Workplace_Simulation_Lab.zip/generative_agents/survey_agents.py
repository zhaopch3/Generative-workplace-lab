import argparse
import csv
import json
import os
import re

from dotenv import load_dotenv, find_dotenv
from openai import OpenAI


EMPLOYEES = ["阿伊莎", "玛丽亚", "沃尔夫冈"]
SURVEY_FIELDS = [
    "perceived_leader_strictness",
    "stress",
    "psychological_safety",
    "leader_trust",
    "work_engagement",
    "turnover_intention",
]


def latest_checkpoint(checkpoints_folder):
    files = sorted(
        f for f in os.listdir(checkpoints_folder)
        if f.endswith(".json") and f != "conversation.json"
    )
    if not files:
        raise FileNotFoundError(f"No checkpoint json found in {checkpoints_folder}")
    return os.path.join(checkpoints_folder, files[-1])


def load_config(name):
    checkpoints_folder = os.path.join("results", "checkpoints", name)
    with open(latest_checkpoint(checkpoints_folder), "r", encoding="utf-8") as f:
        return json.load(f)


def make_client():
    load_dotenv(find_dotenv())
    api_key = os.getenv("OPENROUTER_API_KEY") or os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENROUTER_API_KEY or OPENAI_API_KEY is required")
    return OpenAI(
        api_key=api_key,
        base_url="https://openrouter.ai/api/v1",
        default_headers={
            "HTTP-Referer": os.getenv("OPENROUTER_SITE_URL", "http://localhost"),
            "X-OpenRouter-Title": os.getenv("OPENROUTER_APP_NAME", "GenerativeAgentsCN"),
        },
    )


def compact_agent_context(agent_name, agent):
    context = {
        "agent": agent_name,
        "currently": agent.get("currently", ""),
        "status": agent.get("status", {}),
        "current_action": agent.get("action", {}),
        "schedule": agent.get("schedule", {}),
        "recent_memory": agent.get("associate", {}),
        "recent_chats": agent.get("chats", []),
    }
    return json.dumps(context, ensure_ascii=False, indent=2)


def extract_json(text):
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if not match:
            raise
        return json.loads(match.group(0))


def survey_agent(client, model, condition, run_id, agent_name, agent):
    prompt = f"""
你正在为一个组织行为模拟实验收集问卷数据。请扮演智能体“{agent_name}”，根据其当前经历和记忆回答问卷。

实验条件：{condition}
运行编号：{run_id}

智能体状态：
{compact_agent_context(agent_name, agent)}

请只输出一个 JSON 对象，不要输出解释性文字。所有量表题均为 1-7 分，1 表示非常低，7 表示非常高。
字段必须包括：
- agent
- condition
- run_id
- perceived_leader_strictness
- stress
- psychological_safety
- leader_trust
- work_engagement
- turnover_intention
- reason
"""
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )
    data = extract_json(response.choices[0].message.content or "{}")
    data["agent"] = agent_name
    data["condition"] = condition
    data["run_id"] = run_id
    for field in SURVEY_FIELDS:
        data[field] = int(data[field])
    return data


def write_outputs(rows, out_prefix):
    os.makedirs(os.path.dirname(out_prefix), exist_ok=True)
    jsonl_path = out_prefix + ".jsonl"
    csv_path = out_prefix + ".csv"
    with open(jsonl_path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    fields = ["condition", "run_id", "agent", *SURVEY_FIELDS, "reason"]
    with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})
    return jsonl_path, csv_path


def main():
    parser = argparse.ArgumentParser(description="Survey employee agents from a completed simulation checkpoint")
    parser.add_argument("--name", required=True, help="Simulation name under results/checkpoints")
    parser.add_argument("--condition", default="", help="Condition label. Defaults to checkpoint experiment condition.")
    parser.add_argument("--run-id", default="", help="Run id. Defaults to simulation name.")
    parser.add_argument("--model", default="", help="OpenRouter/OpenAI model for survey. Defaults to simulation model.")
    parser.add_argument("--out", default="", help="Output path prefix without extension")
    args = parser.parse_args()

    config = load_config(args.name)
    condition = args.condition or config.get("experiment", {}).get("condition", "unknown")
    run_id = args.run_id or args.name
    model = args.model or config["agent_base"]["think"]["llm"]["model"]
    out_prefix = args.out or os.path.join("results", "surveys", args.name, "survey")

    client = make_client()
    rows = []
    for agent_name in EMPLOYEES:
        if agent_name not in config["agents"]:
            continue
        rows.append(survey_agent(client, model, condition, run_id, agent_name, config["agents"][agent_name]))

    jsonl_path, csv_path = write_outputs(rows, out_prefix)
    print(f"Wrote {jsonl_path}")
    print(f"Wrote {csv_path}")


if __name__ == "__main__":
    main()
