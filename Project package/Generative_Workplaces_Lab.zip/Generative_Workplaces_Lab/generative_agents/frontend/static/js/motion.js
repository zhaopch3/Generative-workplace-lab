/* Deterministic grid path interpolation: no discarded points, no diagonal shortcuts. */
(function(root){
  function advance(position, queue, distance) {
    let p=position.slice(), direction="", remaining=Math.max(0,distance), guard=0;
    while(queue.length && remaining>0 && guard++<10000) {
      const t=queue[0], dx=t[0]-p[0],dy=t[1]-p[1];
      if(Math.abs(dx)+Math.abs(dy)<1e-7){p=t.slice();queue.shift();continue;}
      const amount=Math.min(remaining,Math.abs(dx)>1e-7?Math.abs(dx):Math.abs(dy));
      if(Math.abs(dx)>1e-7){p[0]+=Math.sign(dx)*amount;direction=dx>0?"r":"l";}
      else {p[1]+=Math.sign(dy)*amount;direction=dy>0?"d":"u";}
      remaining-=amount;
      if(Math.abs(t[0]-p[0])+Math.abs(t[1]-p[1])<1e-7){p=t.slice();queue.shift();}
    }
    return {position:p,direction:direction};
  }
  function enqueueRecord(position, queue, record, toPixel) {
    const equal=(a,b)=>a&&b&&a[0]===b[0]&&a[1]===b[1];
    const valid=c=>Array.isArray(c)&&c.length===2&&c.every(Number.isInteger);
    if(!valid(record.coord))return {error:"invalid destination"};
    const path=record.path||[], start=record.prev_coord;
    let previous=start, checked=[];
    if(!valid(start))return {relocate:toPixel(record.coord),legacy:true};
    for(const c of path){
      if(!valid(c))return {error:"invalid waypoint"};
      if(equal(c,previous))continue;
      if(Math.abs(c[0]-previous[0])+Math.abs(c[1]-previous[1])!==1)
        return record.navigation_policy==="office-solid-v1"?{error:"discontinuous path"}:{relocate:toPixel(record.coord),legacy:true};
      checked.push(c);previous=c;
    }
    if(!equal(previous,record.coord))
      return record.navigation_policy==="office-solid-v1"?{error:"missing recorded path"}:{relocate:toPixel(record.coord),legacy:true};
    const origin=toPixel(start),tail=queue.length?queue[queue.length-1]:position;
    let relocate=null;
    if(!equal(tail,origin)) {queue.length=0;relocate=origin;}
    // An idle record must not erase a previous step still being animated.
    for(const c of checked)queue.push(toPixel(c));
    return {relocate};
  }
  root.StudioMotion={advance,enqueueRecord};
  if(typeof module!=="undefined")module.exports=root.StudioMotion;
})(typeof globalThis!=="undefined"?globalThis:this);
