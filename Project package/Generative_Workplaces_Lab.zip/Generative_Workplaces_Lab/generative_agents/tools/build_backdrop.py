# -*- coding: utf-8 -*-
"""Build the decorative backdrop drawn around the office map (V25.3).

The office is the only walkable part of the world. Around it the map viewer used to show
plain pale green, so screenshots looked like a floor plan floating in nothing. This script
draws a corridor and neighbouring rooms of the same building around the office, using the
office's own tiles (dimmed, mirrored and cropped so they read as other rooms), and fades
them into the page colour towards the edges. It is a picture only: agents never go there,
and the maze, coordinates and saved worlds are unchanged.

Run from generative_agents/ after editing the map:

    python tools/build_backdrop.py

Writes frontend/static/assets/village/tilemap/backdrop.png and backdrop.json.
"""
import json
import os
import sys

from PIL import Image, ImageEnhance, ImageOps

HERE = os.path.dirname(os.path.abspath(__file__))
TILEMAP_DIR = os.path.join(HERE, "..", "frontend", "static", "assets", "village", "tilemap")
PAD = {"left": 12, "right": 12, "top": 9, "bottom": 9}   # tiles of backdrop on each side
CORRIDOR_GID = 108          # light grey office floor, as inside the office
DIM = 0.55                  # brightness of neighbouring rooms
DESATURATE = 0.35           # colour kept in neighbouring rooms
FADE_START = 2.5            # tiles from the office edge where the fade begins
FADE_LENGTH = 8.0           # tiles over which the backdrop fades out
EDGE_COLOR = (223, 230, 221)  # page colour of the map area (#dfe6dd)

# Neighbouring rooms: crops of the office map (tile rectangles x0, y0, x1, y1, inclusive-exclusive),
# placed on the canvas at (cx, cy) in canvas tiles; "flip" mirrors left-right (never up-down,
# which would break the top-down perspective of the walls).
ROOMS = [
    # above the office: the row of small rooms, mirrored
    {"src": (4, 12, 25, 19), "at": (14, 1), "flip": True},
    {"src": (4, 12, 16, 19), "at": (-1, 1), "flip": False},
    {"src": (16, 12, 25, 19), "at": (38, 1), "flip": False},
    # below the office: open-plan offices and a meeting room
    {"src": (3, 3, 16, 12), "at": (13, 31), "flip": True},
    {"src": (16, 2, 26, 12), "at": (27, 30), "flip": True},
    {"src": (16, 2, 26, 12), "at": (1, 30), "flip": False},
    {"src": (3, 3, 16, 12), "at": (39, 31), "flip": False},
    # left of the office: rooms above and below the corridor that leads to the entrance
    {"src": (16, 2, 26, 12), "at": (0, 9), "flip": True, "crop_h": 4},
    {"src": (4, 12, 16, 19), "at": (0, 21), "flip": False},
    # right of the office
    {"src": (3, 3, 16, 12), "at": (41, 10), "flip": False},
    {"src": (16, 12, 25, 19), "at": (41, 21), "flip": True},
]


def load_map():
    with open(os.path.join(TILEMAP_DIR, "tilemap.json"), encoding="utf-8") as f:
        return json.load(f)


def tile_getter(m):
    sets = sorted(m["tilesets"], key=lambda t: t["firstgid"])
    size = m["tilewidth"]
    images = {}

    def tile(gid):
        gid &= 0x1FFFFFFF
        ts = [t for t in sets if t["firstgid"] <= gid][-1]
        if ts["name"] not in images:
            images[ts["name"]] = Image.open(os.path.join(TILEMAP_DIR, ts["image"])).convert("RGBA")
        im, tw, cols = images[ts["name"]], ts["tilewidth"], ts["columns"]
        i = gid - ts["firstgid"]
        t = im.crop(((i % cols) * tw, (i // cols) * tw, (i % cols + 1) * tw, (i // cols + 1) * tw))
        return t if tw == size else t.resize((size, size), Image.NEAREST)
    return tile


NEIGHBOUR_LAYERS = ("floor", "walls", "ground")   # rooms next door: structure and big furniture only


def render_map(m, tile, layers=None):
    w, h, s = m["width"], m["height"], m["tilewidth"]
    out = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0))
    for layer in m["layers"]:
        if layer.get("type") != "tilelayer" or layer["name"] == "Collisions" or not layer.get("visible", True):
            continue
        if layers and layer["name"] not in layers:
            continue
        for i, gid in enumerate(layer["data"]):
            if gid:
                out.alpha_composite(tile(gid), ((i % w) * s, (i // w) * s))
    return out


def soften(img):
    rgb = img.convert("RGB")
    rgb = ImageEnhance.Color(rgb).enhance(DESATURATE)
    rgb = ImageEnhance.Brightness(rgb).enhance(DIM)
    out = rgb.convert("RGBA")
    out.putalpha(img.getchannel("A"))
    return out


def build(edge_color=EDGE_COLOR):
    m = load_map()
    tile = tile_getter(m)
    s = m["tilewidth"]
    office = render_map(m, tile, NEIGHBOUR_LAYERS)
    cw, ch = m["width"] + PAD["left"] + PAD["right"], m["height"] + PAD["top"] + PAD["bottom"]
    canvas = Image.new("RGBA", (cw * s, ch * s), edge_color + (255,))

    floor = soften(tile(CORRIDOR_GID))
    floor = Image.blend(floor, Image.new("RGBA", floor.size, (255, 255, 255, 255)), 0.25)
    for ty in range(ch):
        for tx in range(cw):
            canvas.alpha_composite(floor, (tx * s, ty * s))

    for room in ROOMS:
        x0, y0, x1, y1 = room["src"]
        if room.get("crop_h"):
            y1 = y0 + room["crop_h"]
        piece = office.crop((x0 * s, y0 * s, x1 * s, y1 * s))
        if room.get("flip"):
            piece = ImageOps.mirror(piece)
        cx, cy = room["at"]
        canvas.alpha_composite(soften(piece), dest=(max(0, cx * s), cy * s),
                               source=(max(0, -cx * s), 0))

    # Fade towards the edges: fully clear near the office, page colour at the canvas border.
    ox0, oy0 = PAD["left"] * s, PAD["top"] * s
    ox1, oy1 = ox0 + m["width"] * s, oy0 + m["height"] * s
    fade = Image.new("L", canvas.size, 0)
    px = fade.load()
    start, length = FADE_START * s, FADE_LENGTH * s
    for y in range(canvas.size[1]):
        dy = max(oy0 - y, 0, y - oy1)
        for x in range(canvas.size[0]):
            dx = max(ox0 - x, 0, x - ox1)
            d = (dx * dx + dy * dy) ** 0.5
            t = min(1.0, max(0.0, (d - start) / length))
            px[x, y] = int(255 * t * t * (3 - 2 * t))
    canvas = Image.composite(Image.new("RGBA", canvas.size, edge_color + (255,)), canvas, fade)
    return canvas, {"pad_tiles": PAD, "tile": s, "edge_color": "#%02x%02x%02x" % edge_color,
                    "size": list(canvas.size)}


def main(out_dir=TILEMAP_DIR):
    canvas, meta = build()
    canvas.convert("RGB").save(os.path.join(out_dir, "backdrop.png"), optimize=True)
    with open(os.path.join(out_dir, "backdrop.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)
    print("backdrop", meta)


if __name__ == "__main__":
    main(*sys.argv[1:])
