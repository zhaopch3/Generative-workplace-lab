# -*- coding: utf-8 -*-
"""Generate the four V23 world templates from one shared base (run from generative_agents/).

persona manipulation : 人设操纵-高辱虐组 / 人设操纵-低辱虐组 (condition high_abuse / low_abuse)
event manipulation   : 事件操纵-高辱虐组 / 事件操纵-低辱虐组 (neutral leader; scheduled leader
                       actions toward 阿伊莎 on days 2-5 at 10:00 and 15:00)
Everything else is identical, which tools/check_templates.py verifies.
"""
import copy
import json
import os

EMP = ["阿伊莎", "玛丽亚", "沃尔夫冈"]
LEADER = "克劳斯"


def likert(qid, text, lo, hi, lo_label, hi_label, reverse=False):
    q = {"id": qid, "text": text, "type": "likert", "min": lo, "max": hi,
         "min_label": lo_label, "max_label": hi_label}
    if reverse:
        q["reverse"] = True
    return q


ABUSE_ITEMS = ["嘲笑或奚落了{o}", "说{o}的想法或感受很愚蠢", "当着他人的面贬低了{o}",
               "在别人面前对{o}作了负面评价", "说{o}无能或不能胜任工作"]

IPIP = [
    ("E1", "我是聚会上的活跃人物。", 0), ("E2", "我话不多。", 1), ("E3", "我在人群中感到自在。", 0),
    ("E4", "我喜欢待在不起眼的地方。", 1), ("E5", "我会主动开启对话。", 0), ("E6", "我没什么话可说。", 1),
    ("E7", "在聚会上我会和很多不同的人交谈。", 0), ("E8", "我不喜欢引起别人注意。", 1),
    ("E9", "我不介意成为关注的焦点。", 0), ("E10", "在陌生人面前我很安静。", 1),
    ("N1", "我很容易感到压力。", 0), ("N2", "大多数时候我很放松。", 1), ("N3", "我常为事情担心。", 0),
    ("N4", "我很少感到忧郁。", 1), ("N5", "我很容易心烦意乱。", 0), ("N6", "我很容易难过或生气。", 0),
    ("N7", "我的情绪变化很多。", 0), ("N8", "我的情绪起伏频繁。", 0), ("N9", "我很容易被激怒。", 0),
    ("N10", "我经常感到忧郁。", 0),
    ("A1", "我不太关心别人。", 1), ("A2", "我对别人感兴趣。", 0), ("A3", "我会出言冒犯别人。", 1),
    ("A4", "我能体会别人的感受。", 0), ("A5", "我对别人的问题不感兴趣。", 1), ("A6", "我心肠很软。", 0),
    ("A7", "我其实对别人不太感兴趣。", 1), ("A8", "我会抽出时间给别人。", 0),
    ("A9", "我能感受到别人的情绪。", 0), ("A10", "我能让别人感到自在。", 0),
    ("C1", "我总是准备充分。", 0), ("C2", "我会把东西到处乱放。", 1), ("C3", "我注意细节。", 0),
    ("C4", "我会把事情搞得一团糟。", 1), ("C5", "我会马上把杂事做完。", 0),
    ("C6", "我经常忘记把东西放回原处。", 1), ("C7", "我喜欢有秩序。", 0), ("C8", "我会逃避自己的职责。", 1),
    ("C9", "我按计划行事。", 0), ("C10", "我对工作要求严格。", 0),
    ("O1", "我词汇丰富。", 0), ("O2", "我很难理解抽象的概念。", 1), ("O3", "我想象力生动。", 0),
    ("O4", "我对抽象的想法不感兴趣。", 1), ("O5", "我有很好的点子。", 0), ("O6", "我想象力不太好。", 1),
    ("O7", "我理解事情很快。", 0), ("O8", "我会使用难词。", 0), ("O9", "我会花时间反思事情。", 0),
    ("O10", "我脑子里满是想法。", 0),
]


def surveys():
    s = []
    s.append({"id": "big5_check", "title": "IPIP 大五人格 50 题（人格装入检验，仅第 1 天）",
              "display_title": "个人特点问卷", "time_frame": "general", "trigger_time": "08:00", "days": [1],
              "mode": "self", "targets": [LEADER] + EMP, "include_reason": False,
              "source": "Goldberg IPIP-50 (Open Psychometrics BIG5)",
              "questions": [likert("ipip_" + k.lower(), t, 1, 5, "不同意", "同意", bool(r)) for k, t, r in IPIP]})
    s.append({"id": "recovery", "title": "晨间恢复水平", "display_title": "晨间状态", "time_frame": "today",
              "trigger_time": "08:00", "mode": "self", "targets": EMP, "include_reason": False,
              "questions": [likert("rec1", "今天早晨，我感到精力已经恢复。", 1, 5, "完全不符合", "完全符合"),
                            likert("rec2", "今天早晨，我感到很放松。", 1, 5, "完全不符合", "完全符合"),
                            likert("rec3", "今天早晨，我的心情很好。", 1, 5, "完全不符合", "完全符合")]})
    s.append({"id": "abusive_self", "title": "辱虐管理（员工自评：今天领导对我的行为频率；Mitchell & Ambrose 2007 五题）",
              "display_title": "今日工作感受（一）", "time_frame": "today", "trigger_time": "21:00",
              "mode": "self", "targets": EMP, "include_reason": True,
              "questions": [likert("abs%d" % (i + 1), "今天，我的直属领导" + t.format(o="我") + "。", 1, 5, "从不", "总是")
                            for i, t in enumerate(ABUSE_ITEMS)]})
    s.append({"id": "coworker_today",
              "title": "观察到的辱虐管理 + 幸灾乐祸 + 同情（同一被评者连续作答；Xu 等 2020 的顺序）",
              "display_title": "关于同事的今日观察", "time_frame": "today", "trigger_time": "21:00",
              "mode": "dyadic", "raters": EMP, "ratees": EMP, "include_reason": False,
              "questions": [likert("wabs%d" % (i + 1), "今天，我亲眼看到或了解到领导" + t.format(o="{对象}") + "。",
                                   1, 5, "从未", "总是") for i, t in enumerate(ABUSE_ITEMS)]
              + [likert("schad1", "看到或了解到领导今天这样对待{对象}，我感到满足/满意。", 1, 7, "完全没有", "非常强烈"),
                 likert("schad2", "看到或了解到领导今天这样对待{对象}，我感到如释重负/松了一口气。", 1, 7, "完全没有", "非常强烈"),
                 likert("schad3", "看到或了解到领导今天这样对待{对象}，我感到高兴。", 1, 7, "完全没有", "非常强烈"),
                 likert("schad4", "看到或了解到领导今天这样对待{对象}，我感到幸灾乐祸。", 1, 7, "完全没有", "非常强烈"),
                 likert("symp1", "看到领导今天这样对待{对象}，我对{对象}感到同情。", 1, 7, "完全没有", "非常强烈"),
                 likert("symp2", "看到领导今天这样对待{对象}，我对{对象}富有同情心并关切其处境。", 1, 7, "完全没有", "非常强烈"),
                 likert("symp3", "看到领导今天这样对待{对象}，我为{对象}的处境感到被触动。", 1, 7, "完全没有", "非常强烈")]})
    s.append({"id": "exhaustion", "title": "情绪耗竭（今天的状态）", "display_title": "今日工作感受（二）",
              "time_frame": "today", "trigger_time": "21:00", "mode": "self", "targets": EMP, "include_reason": False,
              "questions": [likert("ee1", "今天的工作使我感到情绪能量被耗尽。", 1, 7, "完全不符合", "完全符合"),
                            likert("ee2", "今天工作结束时，我感到精疲力竭。", 1, 7, "完全不符合", "完全符合"),
                            likert("ee3", "一想到明天还要面对新的工作日，我就感到疲惫。", 1, 7, "完全不符合", "完全符合"),
                            likert("ee4", "今天持续工作一整天对我来说非常消耗精力。", 1, 7, "完全不符合", "完全符合"),
                            likert("ee5", "我感到自己已经被工作耗竭了。", 1, 7, "完全不符合", "完全符合")]})
    s.append({"id": "work_anxiety", "title": "工作焦虑", "display_title": "工作中的担心", "time_frame": "general",
              "trigger_time": "21:00", "mode": "self", "targets": EMP, "include_reason": False,
              "questions": [likert("anx%d" % (i + 1), t, 1, 5, "非常不同意", "非常同意") for i, t in enumerate([
                  "一想到自己在工作中可能表现不佳，我就感到不堪重负。", "我担心自己的工作表现会不如其他员工。",
                  "想到自己可能达不到绩效目标，我会感到紧张不安。", "我担心自己得不到积极的绩效评价。",
                  "我经常因可能无法在规定时间内完成工作职责而感到焦虑。", "我担心别人不认为我是一个能够胜任工作的员工。",
                  "我担心自己无法妥善应对工作中的各种要求。", "即使已经尽了最大努力，我仍然担心自己的工作表现不够好。"])]})
    s.append({"id": "turnover", "title": "离职倾向", "display_title": "工作打算", "time_frame": "general",
              "trigger_time": "21:00", "mode": "self", "targets": EMP, "include_reason": True,
              "questions": [likert("ti%d" % (i + 1), t, 1, 5, "非常不同意", "非常同意") for i, t in enumerate([
                  "我经常考虑离开目前所在的组织。", "我打算寻找一份新的工作。", "我打算向他人了解新的工作机会。",
                  "我预计自己不会在目前的组织继续工作太长时间。"])]})
    s.append({"id": "leader_abuse_self",
              "title": "领导辱虐行为自评（对每位员工；Liao 等 2018 的施动者自评，同时作为操纵检验）",
              "display_title": "今天与员工的互动（一）", "time_frame": "today", "trigger_time": "21:00",
              "mode": "dyadic", "raters": [LEADER], "ratees": EMP, "include_reason": True,
              "questions": [likert("labs%d" % (i + 1), "今天，我" + t.format(o="{对象}") + "。", 1, 5, "从不", "四次或以上")
                            for i, t in enumerate(ABUSE_ITEMS)]})
    s.append({"id": "guilt", "title": "领导内疚（针对今天与该员工的互动）", "display_title": "今天与员工的互动（二）",
              "time_frame": "today", "trigger_time": "21:00", "mode": "dyadic", "raters": [LEADER], "ratees": EMP,
              "include_reason": True,
              "questions": [likert("glt1", "回想今天与{对象}的互动，我感到懊悔/悔恨。", 1, 5, "完全没有", "非常强烈"),
                            likert("glt2", "回想今天与{对象}的互动，我感到内疚。", 1, 5, "完全没有", "非常强烈"),
                            likert("glt3", "回想今天与{对象}的互动，我感到自责、觉得自己应受到责备。", 1, 5, "完全没有", "非常强烈")]})
    s.append({"id": "moral_credit", "title": "感知道德积分损失（今天与员工互动中）", "display_title": "今日自我反思",
              "time_frame": "today", "trigger_time": "21:00", "mode": "self", "targets": [LEADER], "include_reason": True,
              "questions": [likert("mcl%d" % (i + 1), t, 1, 5, "非常不同意", "非常同意") for i, t in enumerate([
                  "今天与员工互动中的不道德行为使我损失了一部分道德积分。",
                  "今天与员工互动中的不当行为使我失去了作为一个有道德之人的部分积分。",
                  "今天与员工互动中行为不当减少了我的道德积分账户余额。",
                  "今天与员工互动中每做出一项不当行为，我的道德积分都会有所减少。",
                  "今天以不道德的方式对待员工，使我的道德积分出现了亏空。"])]})
    s.append({"id": "power_sense", "title": "领导个人权力感（对下属）", "display_title": "与下属的相处",
              "time_frame": "general", "trigger_time": "21:00", "mode": "self", "targets": [LEADER], "include_reason": True,
              "questions": [likert("pow%d" % (i + 1), t, 1, 7, "非常不同意", "非常同意") for i, t in enumerate([
                  "我能让下属认真听取我所说的话。", "我的意愿对下属没有多大影响力。", "我能让下属按照我的意愿行事。",
                  "即使我表达自己的观点，这些观点也没有多少影响。", "在与下属的互动中，我觉得自己拥有很大的权力。",
                  "我的想法和意见经常被忽视。", "即使我努力争取，也常常无法让事情按照我的想法发展。",
                  "只要我愿意，通常能够由我作出决定。"])]})
    # V24: items presented in random order per respondent and occasion, except the
    # coworker battery, whose fixed order follows Xu et al. (2020).
    for item in s:
        item["randomize_items"] = item["id"] != "coworker_today"
    return s


BASE = {
    "start_time": "20240213-08:00", "step": 168, "stride": 60,
    "base_model": "", "api_base_url": "", "chat_iter": 8, "temperature": 1,
    "shuffle_think_order": True, "seed": 0, "offline": False, "legacy_survey": False,
    "measurement_policy": "passive", "agents": ["阿伊莎", "克劳斯", "玛丽亚", "沃尔夫冈"],
    "shared_context": "", "persona_overrides": {},
    "personality": {"enabled": True},
    "survey_context": {"version": "three_layer_v1", "budget_tokens": 8000},
    "custom_surveys": surveys(),
}

EVENTS = {
    "high": [("10:00", "克劳斯走到阿伊莎面前，说她的方案很愚蠢，说她根本不能胜任这份工作。"),
             ("15:00", "克劳斯看了阿伊莎刚交的进度，嘲笑她做得一塌糊涂，并说会把她的表现告诉其他人。")],
    "low": [("10:00", "克劳斯走到阿伊莎面前，具体指出她的方案中需要修改的地方，并肯定她已经付出的努力。"),
            ("15:00", "克劳斯看了阿伊莎刚交的进度，建议她下一步怎样改进，并表示会提供需要的资源。")],
}


def event_schedule(level):
    out = []
    for day in (2, 3, 4, 5):
        for k, (time, text) in enumerate(EVENTS[level]):
            out.append({"id": "d%d_%s_%d" % (day, level, k + 1), "day": day, "time": time,
                        "kind": "specified_action", "actor": LEADER, "object": "阿伊莎",
                        "targets": ["阿伊莎"], "text": text, "poignancy": 8, "duration": 30})
    return out


def main(out_dir=os.path.join("data", "world_presets")):
    worlds = {}
    for level, cond in (("high", "high_abuse"), ("low", "low_abuse")):
        w = copy.deepcopy(BASE)
        w["condition"] = cond
        w["research_design"] = {"condition_code": "persona_" + level, "manipulation": "persona",
                                "pair_key": "seed"}
        worlds["人设操纵-%s辱虐组" % ("高" if level == "high" else "低")] = w
        w = copy.deepcopy(BASE)
        w["condition"] = ""
        w["scheduled_events"] = event_schedule(level)
        w["research_design"] = {"condition_code": "event_" + level, "manipulation": "event",
                                "pair_key": "seed"}
        worlds["事件操纵-%s辱虐组" % ("高" if level == "high" else "低")] = w
    for name, payload in worlds.items():
        with open(os.path.join(out_dir, name + ".json"), "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        print("wrote", name)


if __name__ == "__main__":
    main()
