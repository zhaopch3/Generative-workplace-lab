"""Versioned office navigation; shared maps and old snapshots remain unchanged."""
import copy
import json
from collections import deque
from pathlib import Path

POLICY = "office-solid-v1"


def build_navigation(config, static_root):
    result = copy.deepcopy(config)
    root = Path(static_root) / "assets/village"
    geometry = json.loads((root / "navigation.json").read_text(encoding="utf-8"))
    tilemap = json.loads((root / "tilemap/tilemap.json").read_text(encoding="utf-8"))
    height, width = result["size"]
    if (width, height, result["tile_size"]) != (tilemap["width"], tilemap["height"], tilemap["tilewidth"]):
        raise ValueError("Navigation geometry does not match the map")
    size = result["tile_size"]
    rx, ry = geometry["footprint_half_size"]
    rects = geometry["rectangles"]

    def intersects(a, b):
        x1, x2 = min(a[0], b[0])*size+size/2-rx, max(a[0], b[0])*size+size/2+rx
        y1, y2 = min(a[1], b[1])*size+size/2-ry, max(a[1], b[1])*size+size/2+ry
        return any(x1 < r["x"]+r["width"] and x2 > r["x"] and
                   y1 < r["y"]+r["height"] and y2 > r["y"] for r in rects)

    blocked = {tuple(t["coord"]) for t in result["tiles"] if t.get("collision")}
    # Floor decorations and overhead artwork are not obstacles.
    for layer in tilemap["layers"]:
        if layer["name"] in ("furniture", "objects", "props"):
            blocked.update((i % width, i // width) for i, gid in enumerate(layer["data"]) if gid)
    cells = {(x, y) for y in range(height) for x in range(width)}
    blocked.update(c for c in cells if intersects(c, c))
    free = cells-blocked
    edges = {tuple(sorted((a, b))) for a in free for b in ((a[0]+1, a[1]), (a[0], a[1]+1))
             if b in free and intersects(a, b)}
    unseen, components = set(free), []
    while unseen:
        start = min(unseen); unseen.remove(start)
        queue, component = deque([start]), {start}
        while queue:
            x, y = queue.popleft()
            for b in ((x-1,y), (x+1,y), (x,y-1), (x,y+1)):
                if b in unseen and tuple(sorted(((x,y), b))) not in edges:
                    unseen.remove(b); component.add(b); queue.append(b)
        components.append(component)
    if not components:
        raise ValueError("Office navigation has no walkable component")
    # Do not spawn in isolated decorative pockets behind furniture.
    reachable = max(components, key=len)
    blocked.update(cells-reachable)
    for tile in result["tiles"]:
        tile["collision"] = tuple(tile["coord"]) in blocked
    result["navigation"] = {"version": POLICY, "footprint_half_size": [rx, ry],
                            "blocked_edges": sorted(edges), "walkable_count": len(reachable)}
    return result
