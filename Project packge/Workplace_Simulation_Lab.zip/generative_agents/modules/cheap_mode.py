# -*- coding: utf-8 -*-
"""Cheap mode (V25.1): optional savings for pilots, prompt tuning and model comparisons.

Off by default. When off, nothing here is consulted and every code path is the
main mode's. When on, the settings are stored with the world (config["cheap_mode"]
and agent_base["cheap_mode"]); batch worlds with cheap mode get their own
comparison group, so their data are never pooled with main-mode worlds.

Items (see docs/待解决问题.md, 第三部分第二节):
  cache_order    H1  survey prompts put the shared part (persona, today's memories)
                     first and the survey-specific part last, so the provider's
                     prefix cache can reuse it across the many surveys of one evening
  survey_dedupe  H2  identical questionnaires due at the same time are answered once
                     and the answers copied (marked in _context.copied_from)
  poignancy_batch H3 events perceived in one step are rated for importance in one call
  skip_decompose H4  with steps of 60 minutes or more, hourly plans are not split
                     into sub-tasks (with such steps only the first sub-task was used)
  survey_merge   H5  questionnaires due for the same person (and the same rated
                     colleague) at the same time are answered several per call
  short_context  H6  shorter memory context for questionnaires (off by default)
"""
import copy

DEFAULTS = {
    "enabled": False,
    "cache_order": True,
    "survey_dedupe": True,
    "poignancy_batch": True,
    "skip_decompose": True,
    "survey_merge": True,
    "merge_max_surveys": 5,
    "merge_max_items": 40,
    "short_context": False,
    "short_context_tokens": 3000,
}
BOOL_KEYS = ("cache_order", "survey_dedupe", "poignancy_batch", "skip_decompose",
             "survey_merge", "short_context")
VERSION = "cheap_v1"


def normalize(raw, stride=None):
    """Return the full settings dict when cheap mode is on, otherwise None."""
    if raw in (None, False, "", {}):
        return None
    if raw is True:
        raw = {"enabled": True}
    if not isinstance(raw, dict) or not raw.get("enabled"):
        return None
    out = copy.deepcopy(DEFAULTS)
    for key in BOOL_KEYS:
        if key in raw:
            out[key] = bool(raw[key])
    for key, lo, hi in (("merge_max_surveys", 2, 10), ("merge_max_items", 5, 120),
                        ("short_context_tokens", 1000, 8000)):
        if raw.get(key) not in (None, ""):
            try:
                out[key] = max(lo, min(hi, int(raw[key])))
            except (TypeError, ValueError):
                raise ValueError("便宜模式设置 {} 必须是整数".format(key))
    out["enabled"] = True
    out["version"] = VERSION
    if stride is not None:
        try:
            # Sub-task decomposition only matters when a step is shorter than an hour.
            out["skip_decompose_effective"] = bool(out["skip_decompose"] and int(stride) >= 60)
        except (TypeError, ValueError):
            out["skip_decompose_effective"] = False
    return out


def settings(config):
    """Settings stored in a world or agent config, or None when cheap mode is off."""
    value = (config or {}).get("cheap_mode")
    if isinstance(value, dict) and value.get("enabled"):
        return value
    return None


def on(config, key):
    s = settings(config)
    return bool(s and s.get(key))


def survey_signature(schema):
    """Two questionnaires with the same signature ask exactly the same thing in the same way."""
    import json
    keys = ("questions", "instructions", "time_frame", "mode", "targets", "raters", "ratees",
            "include_reason", "randomize_items")
    return json.dumps({k: schema.get(k) for k in keys}, ensure_ascii=False, sort_keys=True)


def chunk_surveys(schemas, max_surveys, max_items):
    """Greedy chunks in the original order; a chunk never exceeds either limit
    (a single survey longer than max_items stays alone)."""
    chunks, current, items = [], [], 0
    for schema in schemas:
        n = len(schema.get("questions") or [])
        if current and (len(current) >= max_surveys or items + n > max_items):
            chunks.append(current)
            current, items = [], 0
        current.append(schema)
        items += n
    if current:
        chunks.append(current)
    return chunks
