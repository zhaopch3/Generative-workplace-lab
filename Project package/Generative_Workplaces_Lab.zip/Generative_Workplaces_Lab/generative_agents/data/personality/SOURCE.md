# Source of the Big Five personality pool

`ipip_big5_pool.csv` is computed from the public BIG5 dataset of Open Psychometrics: the 50 IPIP Big Five items, 19,719 original responses (collected online around 2012; respondents agreed that the data could be used for research).

- Original data: http://openpsychometrics.org/_rawdata/ (BIG5.zip). The copy used here comes from https://github.com/haghish/openpsychometrics
- Included: respondents who answered all 50 items (no 0 = missing) and were aged 22–55, 9,830 in total
- Scoring: each trait is the mean of its 10 items (1–5). Reverse-keyed items: E2, E4, E6, E8, E10; N2, N4; A1, A3, A5, A7; C2, C4, C6, C8; O2, O4, O6
- Percentiles: ranks within these 9,830 respondents (0–100)
- Columns: `source_row` (row number in the original file, counted from 0), `age`, the five trait scores and their `_pct` percentiles
- The original answer sheets are not distributed with the project. Respondents come from many countries (about four in ten from the United States), so the full sample is used rather than a single-country subset

Please cite the data source in papers and READMEs.
