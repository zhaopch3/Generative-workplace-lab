# -*- coding: utf-8 -*-
"""V24: OpenRouter embedding requests retry on dropped connections instead of losing the memory."""
import unittest
from unittest import mock

import requests

from modules.storage import index


class Resp:
    status_code = 200

    def raise_for_status(self):
        pass

    def json(self):
        return {"data": [{"embedding": [0.1, 0.2]}]}


class EmbeddingRetryTests(unittest.TestCase):
    def make(self):
        return index.OpenRouterEmbedding(model_name="openai/text-embedding-3-small",
                                         api_base="https://openrouter.ai/api/v1", api_key="k")

    def test_retries_after_ssl_drop(self):
        emb = self.make()
        calls = [requests.exceptions.SSLError("EOF"), requests.exceptions.ConnectionError("reset"), Resp()]

        def post(**kwargs):
            item = calls.pop(0)
            if isinstance(item, Exception):
                raise item
            return item

        with mock.patch.object(index.requests, "post", side_effect=post), mock.patch.object(index.time, "sleep") as sleep:
            self.assertEqual(emb._get_embedding("x"), [0.1, 0.2])
        self.assertEqual(sleep.call_count, 2)

    def test_gives_up_after_six_attempts(self):
        emb = self.make()
        with mock.patch.object(index.requests, "post", side_effect=requests.exceptions.SSLError("EOF")) as post, \
                mock.patch.object(index.time, "sleep"):
            with self.assertRaises(requests.exceptions.SSLError):
                emb._get_embedding("x")
        self.assertEqual(post.call_count, 6)


if __name__ == "__main__":
    unittest.main()
