"""Read-only verification of migrated research records against a named source."""
import argparse
import hashlib
import json
from pathlib import Path

def sha(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()

def verify(source,destination):
    result={"source":str(source),"destination":str(destination),"checked":0,"bytes":0,"differences":[]}
    for kind in ("checkpoints","surveys","psych","monitor","interventions","batch"):
        for path in (source/"results"/kind).rglob("*"):
            if not path.is_file():continue
            relative=path.relative_to(source)
            target=destination/relative
            result["checked"]+=1;result["bytes"]+=path.stat().st_size
            if not target.is_file() or sha(path)!=sha(target):
                result["differences"].append(str(relative))
    return result

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("source",type=Path);p.add_argument("destination",type=Path)
    args=p.parse_args()
    report=verify(args.source.resolve(),args.destination.resolve())
    print(json.dumps(report,ensure_ascii=False,indent=2))
    raise SystemExit(bool(report["differences"]))
