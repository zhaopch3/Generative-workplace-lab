'use strict';
(()=>{
const {escape:e,number:n,statuses,table,api}=WorkspaceUI,$=id=>document.getElementById(id);
let busy=false;
const archive=b=>'/experiments#batch-row-'+encodeURIComponent(b);
async function refresh(){
 if(busy)return;busy=true;$('refresh-overview').disabled=true;
 const errors=[];
 await Promise.all([
  (async()=>{try{const d=await api('/api/studio/overview');$('archive-count').textContent='已保存 '+d.world_count+' 个世界，'+d.batch_count+' 个批次。';$('recent-batches').innerHTML=d.batches.length?table(['批次','创建时间','世界数','状态','操作'],d.batches.map(b=>[e(b.label)+'<span class="identifier">'+e(b.batch_id)+'</span>',e((b.created_at||'未记录').replace('T',' ')),n(b.run_count),e(statuses(b.statuses)),'<a class="btn btn-default btn-xs" href="'+archive(b.batch_id)+'">查看此批次</a>'])):'<div class="empty-block">暂无批次。可在“创建实验”中选择批量模式。</div>';$('single-panel').hidden=!d.single_worlds.length;$('recent-singles').innerHTML=table(['实验','已保存步数','操作'],d.single_worlds.map(w=>[e(w.name),n(w.step),'<a class="btn btn-default btn-xs" href="/research/world/'+encodeURIComponent(w.name)+'">回放</a>']));}catch(err){errors.push('存档目录：'+err.message);}})(),
  (async()=>{try{const [batch,state]=await Promise.all([api('/api/batch_state'),api('/api/state')]);let html='';if(batch.active){const runs=batch.runs||[],done=runs.filter(r=>r.status==='已完成').length;html+='<div class="task-row"><b>'+e(batch.label||batch.batch_id)+'</b><span class="identifier">'+e(batch.batch_id)+'</span><p>已完成 '+done+' / '+runs.length+' 个世界</p><a class="btn btn-primary btn-sm" href="/experiments">查看进度与管理任务</a></div>';}
   if(['running','paused','starting','initializing'].includes(state.status)){html+='<div class="task-row"><b>'+e(state.name||state.sim_name||'当前单次实验')+'</b><p>'+e({running:'运行中',paused:'已暂停',starting:'正在启动',initializing:'正在初始化'}[state.status])+' · '+n(state.step||0)+' / '+n(state.total_steps||0)+' 步</p><a class="btn btn-primary btn-sm" href="/cockpit">实时监控与干预</a></div>';}
   $('current-tasks').innerHTML=html||'<div class="empty-block">当前没有运行中的任务。<a href="/setup">创建实验</a>，或到<a href="/experiments">实验与存档</a>查看历史记录。</div>';
  }catch(err){errors.push('运行状态：'+err.message);$('current-tasks').textContent='无法读取当前状态，请点击“刷新状态”重试。';}})()
 ]);
 $('overview-error').hidden=!errors.length;$('overview-error').textContent=errors.join(' ');$('overview-updated').textContent=(errors.length?'部分读取失败 · ':'已更新 · ')+new Date().toLocaleTimeString('zh-CN');$('refresh-overview').disabled=false;busy=false;
}
$('refresh-overview').addEventListener('click',refresh);refresh();setInterval(()=>{if(!document.hidden)refresh();},30000);
})();
