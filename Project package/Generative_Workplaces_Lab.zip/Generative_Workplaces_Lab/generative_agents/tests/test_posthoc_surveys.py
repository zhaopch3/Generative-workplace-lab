# -*- coding: utf-8 -*-
import csv
import datetime
import hashlib
import json
import os
import tempfile
import time
import unittest
from unittest import mock

from modules import posthoc


def write_json(path, value):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False)


class PosthocSurveyTests(unittest.TestCase):
    def test_checkpoint_matching_uses_same_day_first_at_or_after(self):
        with tempfile.TemporaryDirectory() as root:
            run = "batch-low-01"
            folder = os.path.join(root, run)
            os.makedirs(folder)
            for name, step in (("simulate-20240101-2100.json", 1),
                               ("simulate-20240101-2230.json", 2),
                               ("simulate-20240102-0900.json", 3)):
                write_json(os.path.join(folder, name), {"step": step})
            options = posthoc.checkpoint_options(run, checkpoints_root=root)
            exact = posthoc.match_checkpoint(options, 1, "21:00")
            after = posthoc.match_checkpoint(options, 1, "22:00")
            missing = posthoc.match_checkpoint(options, 1, "23:00")
            day_two = posthoc.match_checkpoint(options, 2, "08:00")
            self.assertEqual(exact["clock"], "21:00")
            self.assertEqual(after["clock"], "22:30")
            self.assertIsNone(missing)
            self.assertEqual(day_two["clock"], "09:00")
            self.assertEqual(after["step"], 2)

    def test_prepare_task_locks_only_selected_comparison_group(self):
        schema = {
            "id": "mood", "title": "心情", "trigger_time": "22:00",
            "mode": "self", "targets": [], "include_reason": False,
            "questions": [{"id": "q1", "type": "likert", "text": "今天心情如何？", "min": 1, "max": 7}],
        }
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                for run, condition in (("b-low-01", "low"), ("b-low-02", "low")):
                    folder = os.path.join("results", "checkpoints", run)
                    os.makedirs(folder)
                    write_json(os.path.join(folder, "simulate-20240101-2200.json"), {
                        "time": "20240101-22:00", "step": 1,
                        "agents": {"甲": {}, "乙": {}}, "custom_surveys": [schema],
                    })
                group = {
                    "group_id": "lowhash", "label": "低辱虐管理组", "verified": True,
                    "runs": [
                        {"name": "b-low-01", "condition": "low", "group": "low"},
                        {"name": "b-low-02", "condition": "low", "group": "low"},
                    ],
                }
                prepared = posthoc.prepare_task(
                    "b", group,
                    [{"day": 1, "time": "21:30", "agents": ["甲", "乙"], "surveys": ["mood"]}],
                )
                self.assertEqual([w["name"] for w in prepared["worlds"]], ["b-low-01", "b-low-02"])
                self.assertEqual(prepared["estimated_calls"], 4)
                self.assertEqual(prepared["missing_frame_worlds"], 0)
                self.assertTrue(all(w["frames"][0]["actual_time"] == "20240101-22:00"
                                    for w in prepared["worlds"]))
            finally:
                os.chdir(old_cwd)

    def test_multiple_surveys_freeze_before_completion_and_never_change_checkpoint(self):
        schema_a = {
            "id": "a", "title": "A", "mode": "self", "include_reason": False,
            "questions": [{"id": "q1", "type": "likert", "text": "A?", "min": 1, "max": 5}],
        }
        schema_b = {
            "id": "b", "title": "B", "mode": "self", "include_reason": False,
            "questions": [{"id": "q1", "type": "likert", "text": "B?", "min": 1, "max": 5}],
        }
        events, loads = [], []

        class FakeAgent:
            name = "甲"

            def snapshot_survey_context(self, schema=None):
                events.append("snapshot")
                return {"survey_time": "20240101-22:00", "context_text": "frozen",
                        "address": [], "now": datetime.datetime(2024, 1, 1, 22)}

            def complete_custom_survey(self, schema, condition, run_id, survey_date, snapshot=None):
                events.append("complete-" + schema["id"])
                return {"survey_id": schema["id"], "run_id": run_id, "condition": condition,
                        "survey_date": survey_date, "survey_time": snapshot["survey_time"],
                        "agent": self.name, "q1": 4}

        class FakeGame:
            def __init__(self):
                self.agents = {"甲": FakeAgent()}

            def get_agent(self, name):
                return self.agents[name]

        with tempfile.TemporaryDirectory() as root:
            checkpoint = os.path.join(root, "source.json")
            write_json(checkpoint, {"immutable": True})
            with open(checkpoint, "rb") as handle:
                before = hashlib.sha256(handle.read()).hexdigest()
            task_dir = os.path.join(root, "task")
            os.makedirs(os.path.join(task_dir, "worlds"))
            source_hash = posthoc.sha256_file(checkpoint)
            frame = {
                "id": "F01", "day": 1, "time": "22:00", "agents": ["甲"],
                "surveys": ["a", "b"], "status": "ready", "checkpoint": "source.json",
                "checkpoint_path": checkpoint, "actual_time": "20240101-22:00",
                "source_step": 1, "source_checkpoint_sha256": source_hash,
            }
            frame_two = dict(frame)
            frame_two.update({"id": "F02", "day": 2, "actual_time": "20240102-22:00"})
            write_json(os.path.join(task_dir, "manifest.json"), {
                "task_id": "P1", "batch_id": "batch", "group_id": "group",
                "group_label": "低组", "schemas": {"a": schema_a, "b": schema_b},
                "worlds": [{"name": "run-01", "condition": "low", "frames": [frame, frame_two]}],
            })

            def fake_load(*args, **kwargs):
                loads.append(args[0])
                return FakeGame(), {"model_assignment": {"base": "offline", "per_agent": {}}}

            with mock.patch.object(posthoc, "_load_game", side_effect=fake_load):
                result = posthoc.execute_world(task_dir, "run-01")
            with open(checkpoint, "rb") as handle:
                after = hashlib.sha256(handle.read()).hexdigest()
            self.assertEqual(before, after)
            self.assertEqual(result["responses"], 4)
            self.assertEqual(events[:2], ["snapshot", "snapshot"])
            self.assertEqual(events[2:4], ["complete-a", "complete-b"])
            self.assertEqual(events[4:6], ["snapshot", "snapshot"])
            self.assertEqual(events[6:], ["complete-a", "complete-b"])
            self.assertEqual(len(loads), 2)
            event_count = len(events)
            second = posthoc.execute_world(task_dir, "run-01")
            self.assertEqual(second["responses"], 4)
            self.assertEqual(len(events), event_count, "重试不得再次调用已经成功的问卷项")

    def test_aggregate_exports_wide_long_codebook_and_issues(self):
        schema = {
            "id": "mood", "title": "心情", "mode": "self", "include_reason": False,
            "questions": [{"id": "q1", "type": "likert", "text": "心情？", "min": 1, "max": 7}],
        }
        with tempfile.TemporaryDirectory() as task_dir:
            os.makedirs(os.path.join(task_dir, "worlds"))
            write_json(os.path.join(task_dir, "manifest.json"), {
                "schemas": {"mood": schema}, "worlds": [{"name": "run-01"}],
            })
            meta = {key: "" for key in posthoc.RESPONSE_META}
            meta.update({"run_id": "run-01", "survey_id": "mood", "survey_title": "心情"})
            write_json(os.path.join(task_dir, "worlds", "run-01.json"), {
                "responses": [{"job_key": "x", "meta": meta, "answers": {"q1": 6}}],
                "issues": [{"status": "skipped", "run_id": "run-01", "error": "缺少存档"}],
            })
            counts = posthoc.write_aggregates(task_dir)
            self.assertEqual(counts, {"responses": 1, "issues": 1})
            for filename in ("responses.csv", "answers_long.csv", "codebook.csv", "issues.csv"):
                self.assertTrue(os.path.isfile(os.path.join(task_dir, filename)))
            with open(os.path.join(task_dir, "responses.csv"), encoding="utf-8-sig") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(rows[0]["mood__q1"], "6")

    def test_background_task_persists_missing_checkpoint_issue_and_download(self):
        schema = {
            "id": "mood", "title": "心情", "mode": "self", "include_reason": False,
            "questions": [{"id": "q1", "type": "likert", "text": "心情？", "min": 1, "max": 7}],
        }
        prepared = {
            "batch_id": "batch", "group_id": "group", "group_label": "低组",
            "verified": True, "agents": ["甲"], "schemas": {"mood": schema},
            "frames": [{"id": "F01", "day": 9, "time": "22:00", "agents": ["甲"], "surveys": ["mood"]}],
            "worlds": [{"name": "run-01", "condition": "low", "frames": [{
                "id": "F01", "day": 9, "time": "22:00", "agents": ["甲"],
                "surveys": ["mood"], "status": "missing", "error": "同日没有存档",
            }]}],
            "estimated_calls": 0, "missing_frame_worlds": 1,
        }
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                manager = posthoc.TaskManager()
                created = manager.create(prepared, "缺失点测试")
                deadline = time.time() + 20
                current = created
                while current["status"] in ("queued", "running", "cancelling") and time.time() < deadline:
                    time.sleep(0.1)
                    current = manager.get("batch", "group", created["task_id"])
                self.assertEqual(current["status"], "failed")
                self.assertEqual(current["issues"], 1)
                self.assertEqual(current["responses"], 0)
                bundle = manager.bundle("batch", "group", created["task_id"])
                self.assertIsNotNone(bundle)
                self.assertGreater(len(bundle.getvalue()), 0)
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()
