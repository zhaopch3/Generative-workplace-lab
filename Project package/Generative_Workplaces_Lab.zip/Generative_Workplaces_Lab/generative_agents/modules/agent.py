"""generative_agents.agent"""

import os
import math
import random
import datetime
import json
import copy
import re

from modules import memory, prompt, psych as psych_mod, utils
from modules import lang
from modules.lang import L
from modules import cheap_mode
from modules.model.llm_model import create_llm_model
from modules.memory.associate import Concept


OFFICE_WORLD = "the Ville"
OFFICE_SITE = "公司办公室"
OFFICE_ADDRESSES = {
    "workstation_1": [OFFICE_WORLD, OFFICE_SITE, "开放办公区", "1号工位"],
    "workstation_2": [OFFICE_WORLD, OFFICE_SITE, "开放办公区", "2号工位"],
    "workstation_3": [OFFICE_WORLD, OFFICE_SITE, "开放办公区", "3号工位"],
    "public_desk": [OFFICE_WORLD, OFFICE_SITE, "开放办公区", "公共办公桌"],
    "leader_desk": [OFFICE_WORLD, OFFICE_SITE, "领导办公室", "领导办公桌"],
    "meeting_table": [OFFICE_WORLD, OFFICE_SITE, "会议区", "会议桌"],
    "bookshelf": [OFFICE_WORLD, OFFICE_SITE, "会议区", "书柜"],
    "sofa": [OFFICE_WORLD, OFFICE_SITE, "茶水休息区", "沙发"],
    "water_dispenser": [OFFICE_WORLD, OFFICE_SITE, "茶水休息区", "饮水机"],
    "printer": [OFFICE_WORLD, OFFICE_SITE, "茶水休息区", "打印机"],
    "rest_sofa": [OFFICE_WORLD, OFFICE_SITE, "休息宿舍区", "休息沙发"],
    "bed": [OFFICE_WORLD, OFFICE_SITE, "休息宿舍区", "床"],
}
# 默认名单的兜底映射；一般情况由 agent.json 的 "workstation" 字段决定（可通用于任意名单）
OFFICE_AGENT_WORKSTATIONS = {
    "阿伊莎": "workstation_1",
    "玛丽亚": "workstation_2",
    "沃尔夫冈": "workstation_3",
    "克劳斯": "leader_desk",
    # V27 English worlds
    "Ayesha": "workstation_1",
    "Maria": "workstation_2",
    "Wolfgang": "workstation_3",
    "Klaus": "leader_desk",
}
OFFICE_KEYWORDS = {
    "meal": ["食堂", "餐厅", "吃饭", "早餐", "午饭", "午餐", "晚饭", "晚餐", "用餐"],
    "outside": ["回家", "家里", "下班", "外出", "通勤", "离开办公室", "校园其他", "办公室外"],
    # V25: only explicit sleep counts as sleep. "回休息宿舍区""在宿舍区吃晚饭/和家人通话" are evening life,
    # not sleep (V24 turned every dorm-area plan into sleep, so agents slept from about 19:00).
    "sleep": ["睡觉", "睡前", "上床", "入睡", "就寝", "睡下"],
    "dorm": ["宿舍"],
    "meeting": ["会议", "讨论", "同步", "开会", "团队会", "短会"],
    "leader": ["汇报", "检查", "反馈", "克劳斯", "领导办公室", "叫到办公室", "召集"],
    "print": ["打印", "复印", "取资料"],
    "break": ["喝水", "茶水", "咖啡", "休息", "放松", "交流", "缓一下"],
    "work": ["工作", "研究", "材料", "报告", "整理", "写", "电脑", "阅读", "推进"],
}
# V27 English worlds: the same groups as regular expressions on the lower-cased text. Words are
# matched from a word start (so "eat" does not match "great", "tea" does not match "team").
OFFICE_KEYWORDS_EN = {
    "meal": [r"\bcanteen", r"\bcafeteria", r"\brestaurant", r"\beat\b", r"\beating\b", r"\bbreakfast",
             r"\blunch", r"\bdinner", r"\bsupper", r"\bmeal"],
    "outside": [r"\bgo(?:ing)? home", r"\bat home", r"\bhome\b", r"\bleav(?:e|ing) work", r"\boff work",
                r"\bgo(?:ing)? out\b", r"\bcommut", r"\bleav(?:e|ing) the office", r"\boutside the office",
                r"\bcampus"],
    "sleep": [r"\bsleep", r"\basleep", r"\bgo(?:ing)? to bed", r"\bfor bed\b", r"\bbedtime",
              r"\bbefore bed\b", r"\bin bed\b", r"\bturn(?:ing)? in for the night"],
    "dorm": [r"\bdorm"],
    "meeting": [r"\bmeeting", r"\bdiscuss", r"\bsync", r"\bstand-?up", r"\bhuddle"],
    "leader": [r"\breport(?:ing|s)? (?:to|back)\b", r"\bcheck", r"\bfeedback", r"\bklaus\b",
               r"\bteam lead office", r"\bcalled (?:in|into)\b", r"\bsummon", r"\bcall(?:s|ing)? the team"],
    "print": [r"\bprint", r"\bphotocop", r"\bmake copies", r"\bpick(?:ing)? up (?:documents|materials)"],
    "break": [r"\bdrink", r"\bwater\b", r"\btea\b", r"\bcoffee", r"\brest\b", r"\bresting\b",
              r"\brelax", r"\bchat", r"\bbreak\b", r"\bunwind"],
    "work": [r"\bwork", r"\bresearch", r"\bmaterial", r"\breport", r"\borgani[sz]", r"\bsort",
             r"\bwrit", r"\bdraft", r"\bcomputer", r"\blaptop", r"\bread", r"\bdata\b", r"\banaly",
             r"\bemail", r"\bdocument", r"\bspreadsheet", r"\bcampaign", r"\bsocial media",
             r"\bslides", r"\bedit", r"\breview", r"\bpush(?:ing)? forward"],
}


def office_address(key):
    """A fixed office address in the current simulation language."""
    address = OFFICE_ADDRESSES[key]
    if lang.is_en():
        return [address[0]] + [lang.LOCATIONS.get(a, a) for a in address[1:]]
    return list(address)


def chat_predicate():
    """Predicate of a conversation event ("克劳斯 对话 阿伊莎" / "Klaus chat with Ayesha")."""
    return L("对话", "chat with")


def _en_match(text, patterns):
    low = str(text or "").lower()
    return any(re.search(p, low) for p in patterns)


# Fixed activities written by the office rules (both languages say the same thing).
ACT = {
    "bed_ready": ("在休息宿舍区准备睡觉", "getting ready for bed in the dormitory"),
    "bed": ("在休息宿舍区睡觉", "sleeping in the dormitory"),
    "meal_or_rest": ("去茶水休息区用餐或休息", "going to the break room to eat or rest"),
    "dorm_rest": ("在休息宿舍区休息", "resting in the dormitory"),
    "keep_working": ("在开放办公区继续办公室工作", "continuing office work in the open office area"),
    "leader_check": ("去开放办公区检查员工工作进展", "going to the open office area to check on the team members' progress"),
    "leader_feedback": ("在领导办公室整理团队反馈", "putting together feedback for the team in the team lead office"),
    "leader_break": ("在茶水休息区短暂休息并观察团队状态", "taking a short break in the break room and seeing how the team is doing"),
    "sync": ("去会议区同步工作进展", "going to the meeting area to sync on work progress"),
    "report": ("去领导办公室汇报工作进展", "going to the team lead office to report on work progress"),
    "wrap_up": ("在茶水休息区整理当天工作并短暂休息", "wrapping up the day's work and taking a short break in the break room"),
    "lunch": ("去茶水休息区吃午饭", "going to the break room for lunch"),
    "lead_meeting": ("在会议区主持小组例会", "leading the weekly team meeting in the meeting area"),
    "join_meeting": ("去会议区参加小组例会", "going to the meeting area for the weekly team meeting"),
}


def act(key):
    zh, en = ACT[key]
    return L(zh, en)


class Agent:
    cheap = None   # V25.1 cheap-mode settings; None = main mode

    def __init__(self, config, maze, conversation, logger):
        self.name = config["name"]
        self.workstation = str(config.get("workstation", "") or "")  # 本人工位/办公桌的物品名（中性地名体系）
        self.maze = maze
        self.conversation = conversation
        self._llm = None
        self.logger = logger
        self.metrics_path = config.get("metrics_path", "")
        self.measurement_policy = config.get("measurement_policy", "legacy_reactive")
        # Worlds saved before V25 have no setting and keep the V24 daily rhythm when resumed.
        self.office_rhythm = config.get("office_rhythm", "legacy_v24")
        # V25.1: optional cheap mode (None = main mode; nothing below changes then).
        self.cheap = cheap_mode.settings(config)
        self._resolved_config = {k: copy.deepcopy(v) for k, v in config.items()
                                 if k not in ("storage_root", "metrics_path", "api_keys")}

        # agent config
        self.percept_config = config["percept"]
        self.think_config = config["think"]
        self.chat_iter = config["chat_iter"]

        # memory
        self.spatial = memory.Spatial(**config["spatial"])
        self.schedule = memory.Schedule(**config["schedule"])
        associate_config = dict(config["associate"])
        associate_config.update({
            "metrics_path": self.metrics_path,
            "agent_name": self.name,
        })
        self.associate = memory.Associate(
            os.path.join(config["storage_root"], "associate"), **associate_config
        )
        self.concepts, self.chats = [], config.get("chats", [])

        # prompt
        self.scratch = prompt.Scratch(self.name, config["currently"], config["scratch"])
        # 结构化心理状态（阶段四）
        self.psych = psych_mod.PsychState.from_dict(config.get("psych"))
        self._psych_buffer = config.get("_psych_buffer", [])
        self._monitor_buffer = []  # 时间线监控：[(type, text, poignancy)]，每step被SimulateServer取走
        self._psych_last_drift = utils.to_date(config["_psych_last_drift"]) if config.get("_psych_last_drift") else utils.get_timer().get_date()
        self._psych_last_appraisal = utils.to_date(config["_psych_last_appraisal"]) if config.get("_psych_last_appraisal") else None
        self._last_seek_key = config.get("_last_seek_key")
        if self._last_seek_key:
            moment, description = self._last_seek_key
            if isinstance(moment, str):
                moment = utils.to_date(moment)
            self._last_seek_key = (moment, description)
        self._forced_intervention_id = None
        # V24 perception: set by SimulateServer from config["perception_policy"].
        # "step_end_v24" = everyone arrives, then everyone perceives the same
        # end-of-step snapshot; "legacy" = perceive at the start of one's own think.
        self.perception_policy = "legacy"
        self._percept_ready = False
        self.next_coord = None
        self._approach_target = None
        # V24: researcher injections this agent learned of and has not yet acted on.
        # When injection_reaction is on (new worlds), the next think gives the agent
        # one decision: keep the schedule or switch to something else.
        self.injection_reaction = False
        self._pending_reactions = []
        self._handled_injections = set()
        self.scratch.psych_text = self.psych.describe()

        # status
        status = {"poignancy": 0}
        self.status = utils.update_dict(status, config.get("status", {}))
        self.plan = config.get("plan", {})

        # record
        self.last_record = config.get("last_record", utils.get_timer().daily_duration())

        # action and events
        if "action" in config:
            self.action = memory.Action.from_dict(config["action"])
            tiles = self.maze.get_address_tiles(self.get_event().address)
            if "coord" not in config and tiles:
                config["coord"] = random.choice(list(tiles))
        else:
            tile = self.maze.tile_at(config["coord"])
            address = tile.get_address("game_object", as_list=True)
            self.action = memory.Action(
                memory.Event(self.name, address=address),
                memory.Event(address[-1], address=address),
            )

        # update maze
        self.coord, self.path = None, None
        self.move(config.get("_cognitive_coord", config["coord"]), config.get("path"))
        if self.coord is None:
            self.coord = config["coord"]

    def abstract(self):
        des = {
            "name": self.name,
            "currently": self.scratch.currently,
            "tile": self.maze.tile_at(self.coord).abstract(),
            "status": self.status,
            "concepts": {c.node_id: c.abstract() for c in self.concepts},
            "chats": self.chats,
            "action": self.action.abstract(),
            "associate": self.associate.abstract(),
        }
        if self.schedule.scheduled():
            des["schedule"] = self.schedule.abstract()
        if self.llm_available():
            des["llm"] = self._llm.get_summary()
        # if self.plan.get("path"):
        #     des["path"] = "-".join(
        #         ["{},{}".format(c[0], c[1]) for c in self.plan["path"]]
        #     )
        return des

    def __str__(self):
        return utils.dump_dict(self.abstract())

    def reset(self, keys):
        if self.think_config["mode"] == "llm" and not self._llm:
            llm_cfg = dict(self.think_config["llm"])
            extra_cfg = {k: llm_cfg.pop(k) for k in ("temperature", "timeout") if k in llm_cfg}
            extra_cfg.update({
                "metrics_path": self.metrics_path,
                "agent_name": self.name,
            })
            if self.cheap:
                extra_cfg["cheap_mode"] = True
            self._llm = create_llm_model(**llm_cfg, keys=keys, config=extra_cfg)

    def completion(self, func_hint, *args, **kwargs):
        assert hasattr(
            self.scratch, "prompt_" + func_hint
        ), "Can not find func prompt_{} from scratch".format(func_hint)
        func = getattr(self.scratch, "prompt_" + func_hint)
        prompt = func(*args, **kwargs)
        title, msg = "{}.{}".format(self.name, func_hint), {}
        if self.llm_available():
            self.logger.info("{} -> {}".format(self.name, func_hint))
            output = self._llm.completion(**prompt, caller=func_hint)
            responses = self._llm.meta_responses
            msg = {"<PROMPT>": "\n" + prompt["prompt"] + "\n"}
            msg.update(
                {
                    "<RESPONSE[{}/{}]>".format(idx+1, len(responses)): "\n" + r + "\n"
                    for idx, r in enumerate(responses)
                }
            )
        else:
            output = prompt.get("failsafe")
        if func_hint in ("custom_survey", "custom_survey_dyadic", "custom_survey_cache",
                         "daily_survey_employee", "daily_survey_leader") and isinstance(output, dict):
            output = copy.deepcopy(output)
            if func_hint.startswith("daily_survey") and "_quality" not in output:
                output = {key: None for key in output if key != "reason"}
                output["reason"] = L("未获得有效回答", "no valid answer")
                output["_quality"] = {"version": 2, "status": "invalid", "source": "fallback"}
            if not self.llm_available():
                output.setdefault("_quality", {}).update({"status": "invalid", "source": "offline"})
        msg["<OUTPUT>"] = "\n" + str(output) + "\n"
        self.logger.debug(utils.block_msg(title, msg))
        return output

    def think(self, status, agents):
        self._psych_drift()
        events = self.move(status["coord"], status.get("path"))
        plan, _ = self.make_schedule()

        going_to_sleep = (plan["describe"] == "sleeping" or "睡" in plan["describe"]) if not lang.is_en() \
            else bool(re.search(r"\bsleep|\basleep", plan["describe"].lower()))
        if going_to_sleep and self.is_awake():
            self.logger.info("{} is going to sleep...".format(self.name))
            address = self.spatial.find_address(L("睡觉", "sleep"), as_list=True)
            if not self.maze.navigation:
                tiles = self.maze.get_address_tiles(address)
                coord = random.choice(list(tiles))
                events = self.move(coord)
            # New worlds route to sleep locations below; never teleport into a bed.
            self.action = memory.Action(
                memory.Event(self.name, L("正在", "is"), L("睡觉", "sleeping"), address=address, emoji="😴"),
                memory.Event(
                    address[-1],
                    L("被占用", "is occupied by"),
                    self.name,
                    address=address,
                    emoji="🛌",
                ),
                duration=plan["duration"],
                start=utils.get_timer().daily_time(plan["start"]),
            )
        if self.is_awake():
            if not self._percept_ready:
                self.percept()
            # V24: concepts perceived at the end of the previous step are used once.
            self._percept_ready = False
            self._psych_appraise()
            self.make_plan(agents)
            self.reflect()
        else:
            # Asleep: the news stays in memory, but there is no decision to make now.
            self._handled_injections.update(
                p["intervention_id"] for p in self._pending_reactions if p.get("intervention_id"))
            self._pending_reactions = []
            if self.action.finished():
                self.action = self._determine_action()

        emojis = {}
        if self.action:
            emojis[self.name] = {"emoji": self.get_event().emoji, "coord": self.coord}
        for eve, coord in events.items():
            if eve.subject in agents:
                continue
            emojis[":".join(eve.address)] = {"emoji": eve.emoji, "coord": coord}
        path = self.find_path(agents)
        self.plan = {
            "name": self.name,
            "path": path,
            "emojis": emojis,
        }
        # V24: where this agent will stand for the rest of the step, so others
        # approaching it this step aim at its destination, not where it started.
        self.next_coord = tuple(path[-1]) if path else (tuple(self.coord) if self.coord else None)
        return self.plan

    def arrive(self, coord):
        """V24: take up this step's destination before anyone perceives (end of step)."""
        self.move(coord)
        self.next_coord = tuple(coord)

    def perceive_end_of_step(self):
        """V24: perceive the shared end-of-step snapshot; the next think reuses it."""
        if not self.is_awake():
            self._percept_ready = False
            return False
        self.percept()
        self._percept_ready = True
        return True

    def notify_injection(self, kind, text, intervention_id=None):
        """V24: queue an injected event / setting / thought for a decision at the next think."""
        text = (text or "").strip()
        if not text:
            return
        if intervention_id and (intervention_id in self._handled_injections or any(
                p["intervention_id"] == intervention_id for p in self._pending_reactions)):
            return
        self._pending_reactions.append({"kind": kind, "text": text, "intervention_id": intervention_id})

    def _reaction_areas(self):
        base = self.get_tile().get_address("sector")
        if not base or len(base) < 2:
            base = self._workstation_address()[:2]
        try:
            return list(base), list(self.spatial.get_leaves(base) or [])
        except Exception:  # noqa: BLE001 - unknown sector in this agent's spatial memory
            return list(base), []

    def _reaction_address(self, area, describe):
        base, areas = self._reaction_areas()
        if area and area in areas:
            address = base + [area]
            try:
                objs = self.spatial.get_leaves(address) or []
            except Exception:  # noqa: BLE001
                objs = []
            if len(objs) == 1:
                address.append(objs[0])
            elif objs:
                address.append(self._choose_object(objs, [describe], address))
            return address
        return self._office_redirect_address([describe]) or self._workstation_address() \
            or self.get_tile().get_address()

    def _react_to_injection(self, pending):
        """V24: one decision after learning of researcher injections: keep or switch.

        Mirrors how the original architecture inserts a conversation into the day
        (revise_schedule): a switch becomes the current action and the rest of the
        current hour is re-planned around it.
        """
        texts = [p["text"] for p in pending]
        ids = [p["intervention_id"] for p in pending if p.get("intervention_id")]
        try:
            nodes = self.associate.retrieve_focus(texts, 8)
            memories = [n.describe for n in nodes if n.describe not in texts]
        except Exception:  # noqa: BLE001 - empty index early in a run
            memories = []
        _, areas = self._reaction_areas()
        result = self.completion(
            "react_to_injection", self, [(p["kind"], p["text"]) for p in pending], memories, areas
        ) or {"continue": True}
        before = self.get_event().get_describe(False) if self.action else ""
        record = {"intervention_ids": ids, "news": texts, "before": before,
                  "changed": not result.get("continue", True)}
        if result.get("continue", True):
            self._monitor_buffer.append(("injection_reaction", json.dumps(record, ensure_ascii=False), 0))
            return False
        describe = result["activity"]
        if not describe.startswith(self.name):
            describe = self.name + describe
        address = self._reaction_address(result.get("area"), describe)
        event = self.make_event(self.name, describe, address)
        event.intervention_id = ids[0] if ids else None
        event.emoji = "❗"
        self.revise_schedule(event, utils.get_timer().get_date(), result["minutes"])
        self.action.obj_event = self.make_event(address[-1], describe, address)
        self.path = []
        record.update({"activity": describe, "address": ":".join(address), "minutes": result["minutes"]})
        self._monitor_buffer.append(("injection_reaction", json.dumps(record, ensure_ascii=False), 0))
        self.logger.info("{} reacts to injection: {}".format(self.name, describe))
        return True

    def approach_tiles(self, target_coord, radius=2):
        """V24: free tiles next to target_coord that lie in the target's own area.

        V23 used the four neighbours of the target's starting tile, which could be
        on the other side of an area boundary (e.g. a dorm tile beside the leader
        office), so people in the room never perceived the action.
        """
        target_tile = self.maze.tile_at(target_coord)
        arena = target_tile.get_address("arena")
        x0, y0 = target_coord[0], target_coord[1]
        for r in range(1, radius + 1):
            ring = []
            for x in range(x0 - r, x0 + r + 1):
                for y in range(y0 - r, y0 + r + 1):
                    if max(abs(x - x0), abs(y - y0)) != r:
                        continue
                    if not (0 <= x < self.maze.maze_width and 0 <= y < self.maze.maze_height):
                        continue
                    tile = self.maze.tile_at((x, y))
                    if tile.collision or tile.get_address("arena") != arena:
                        continue
                    if self.maze.navigation and not self.maze.walkable((x, y)):
                        continue
                    ring.append((x, y))
            # Orthogonal neighbours first, as in the original get_around.
            ring.sort(key=lambda c: abs(c[0] - x0) + abs(c[1] - y0))
            if ring:
                return ring
        return []

    def move(self, coord, path=None):
        events = {}

        def _update_tile(coord):
            tile = self.maze.tile_at(coord)
            if not self.action:
                return {}
            if not tile.update_events(self.get_event()):
                tile.add_event(self.get_event())
            obj_event = self.get_event(False)
            if obj_event:
                self.maze.update_obj(coord, obj_event)
            return {e: coord for e in tile.get_events()}

        if self.coord and self.coord != coord:
            tile = self.get_tile()
            tile.remove_events(subject=self.name)
            if tile.has_address("game_object"):
                addr = tile.get_address("game_object")
                self.maze.update_obj(
                    self.coord, memory.Event(addr[-1], address=addr)
                )
            events.update({e: self.coord for e in tile.get_events()})
        if not path:
            events.update(_update_tile(coord))
        self.coord = coord
        self.path = path or []

        return events

    def make_schedule(self):
        if not self.schedule.scheduled():
            self.logger.info("{} is making schedule...".format(self.name))
            # update currently
            if self.associate.index.nodes_num > 0:
                self.associate.cleanup_index()
                focus = L([
                    f"{self.name} 在 {utils.get_timer().daily_format_cn()} 的计划。",
                    f"在 {self.name} 的生活中，重要的近期事件。",
                ], [
                    f"{self.name}'s plan for {utils.get_timer().daily_format_cn()}.",
                    f"Important recent events in {self.name}'s life.",
                ])
                retrieved = self.associate.retrieve_focus(focus)
                self.logger.info(
                    "{} retrieved {} concepts".format(self.name, len(retrieved))
                )
                if retrieved:
                    plan = self.completion("retrieve_plan", retrieved)
                    thought = self.completion("retrieve_thought", retrieved)
                    # V23 semantic layer: keep yesterday's reflection as that day's summary
                    # (no extra model call); surveys on later days read it instead of raw events.
                    yesterday = (utils.get_timer().get_date() - datetime.timedelta(days=1)).strftime("%Y%m%d")
                    if thought and self.llm_available():
                        self.scratch.config.setdefault("day_summaries", {})[yesterday] = str(thought)
                    self.scratch.currently = self.completion(
                        "retrieve_currently", plan, thought
                    )
            # V23 fix: start a fresh daily schedule. V22 appended each new day's plans after
            # the previous days' (start minute 1440, 2880, ...), while current_plan() compares
            # minute-of-day, so from day 2 on agents kept following day 1's plan.
            self.schedule.daily_schedule = []
            # make init schedule
            self.schedule.create = utils.get_timer().get_date()
            wake_up = self.completion("wake_up")
            init_schedule = self.completion("schedule_init", wake_up)
            # make daily schedule
            hours = [f"{i}:00" for i in range(24)]
            # seed = [(h, "sleeping") for h in hours[:wake_up]]
            seed = [(h, L("睡觉", "sleeping")) for h in hours[:wake_up]]
            seed += [(h, "") for h in hours[wake_up:]]
            schedule = {}
            for _ in range(self.schedule.max_try):
                schedule = {h: s for h, s in seed[:wake_up]}
                schedule.update(
                    self.completion("schedule_daily", wake_up, init_schedule)
                )
                schedule = self.normalize_office_schedule(schedule)
                if len(set(schedule.values())) >= self.schedule.diversity:
                    break

            def _to_duration(date_str):
                return utils.daily_duration(utils.to_date(date_str, "%H:%M"))

            schedule = {_to_duration(k): v for k, v in schedule.items()}
            starts = list(sorted(schedule.keys()))
            for idx, start in enumerate(starts):
                end = starts[idx + 1] if idx + 1 < len(starts) else 24 * 60
                self.schedule.add_plan(schedule[start], end - start)
            schedule_time = utils.get_timer().time_format_cn(self.schedule.create)
            thought = L("这是 {} 在 {} 的计划：{}", "This is {}'s plan for {}: {}").format(
                self.name, schedule_time, L("；", "; ").join(init_schedule)
            )
            event = memory.Event(
                self.name,
                L("计划", "plan"),
                schedule_time,
                describe=thought,
                address=self.get_tile().get_address(),
            )
            self._add_concept(
                "thought",
                event,
                expire=self.schedule.create + datetime.timedelta(days=30),
            )
        # decompose current plan (cheap mode H4: skipped when a step lasts an hour or more)
        plan, _ = self.schedule.current_plan()
        if self.schedule.decompose(plan) and not (self.cheap and self.cheap.get("skip_decompose_effective")):
            decompose_schedule = self.completion(
                "schedule_decompose", plan, self.schedule
            )
            decompose, start = [], plan["start"]
            for describe, duration in decompose_schedule:
                decompose.append(
                    {
                        "idx": len(decompose),
                        "describe": describe,
                        "start": start,
                        "duration": duration,
                    }
                )
                start += duration
            plan["decompose"] = decompose
        return self.schedule.current_plan()

    def normalize_office_schedule(self, schedule):
        normalized = {}
        for stamp, describe in schedule.items():
            hour = self._hour_from_stamp(stamp)
            normalized[stamp] = self._normalize_office_activity(describe, hour)
        return self._apply_office_rhythm(normalized)

    def _hour_from_stamp(self, stamp):
        try:
            return int(str(stamp).split(":", 1)[0])
        except (TypeError, ValueError):
            return None

    def _normalize_office_activity(self, describe, hour=None):
        text = (describe or "").strip()
        if not text:
            return text
        if self._has_office_keyword(text, "sleep"):
            if lang.is_en():
                ready = bool(re.search(r"\bready|\bprepar|\bbefore bed", text.lower()))
            else:
                ready = "准备" in text or "睡前" in text
            return act("bed_ready") if ready else act("bed")
        if self._has_office_keyword(text, "dorm"):
            return text  # evening life in the dorm area keeps the agent's own wording
        if self._has_office_keyword(text, "meal"):
            return act("meal_or_rest")
        if self._has_office_keyword(text, "outside"):
            if hour is not None and (hour >= 20 or hour < 8):
                return act("dorm_rest")
            if hour is not None and 11 <= hour <= 13:
                return act("meal_or_rest")
            return act("keep_working")
        return text

    def _apply_office_rhythm(self, schedule):
        """V25: only the anchors the world rules state (lunch; the Monday 10:00 team meeting) plus a
        bedtime fallback when the plan never sleeps. V24 also forced a daily 15:00 visit to the
        leader's office and 18:00 in the tea area, with old research-lab wording."""
        if getattr(self, "office_rhythm", "legacy_v24") == "legacy_v24":
            for stamp, describe in self._office_rhythm().items():
                if stamp not in schedule:
                    continue
                hour = self._hour_from_stamp(stamp)
                if self._has_office_keyword(schedule.get(stamp, ""), "sleep") and (
                    hour is None or hour >= 21 or hour < 8
                ):
                    continue
                schedule[stamp] = describe
            return schedule
        for stamp, describe in self._office_rhythm().items():
            if stamp in schedule:
                schedule[stamp] = describe
        night = [s for s in schedule if (self._hour_from_stamp(s) or 0) >= 21]
        if night and not any(self._has_office_keyword(schedule[s], "sleep") for s in night):
            last = max(night, key=lambda s: self._hour_from_stamp(s) or 0)
            schedule[last] = act("bed_ready")
        return schedule

    def _office_rhythm(self):
        if getattr(self, "office_rhythm", "legacy_v24") == "legacy_v24":
            if self._is_office_leader():
                return {
                    "10:00": act("leader_check"),
                    "12:00": act("meal_or_rest"),
                    "15:00": act("leader_feedback"),
                    "18:00": act("leader_break"),
                    "22:00": act("bed_ready"),
                }
            return {
                "10:00": act("sync"),
                "12:00": act("meal_or_rest"),
                "15:00": act("report"),
                "18:00": act("wrap_up"),
                "22:00": act("bed_ready"),
            }
        rhythm = {"12:00": act("lunch")}
        try:
            monday = utils.get_timer().get_date().weekday() == 0
        except Exception:  # noqa: BLE001
            monday = False
        if monday:
            rhythm["10:00"] = act("lead_meeting") if self._is_office_leader() else act("join_meeting")
        return rhythm

    def _has_office_keyword(self, text, group):
        if lang.is_en():
            return _en_match(text, OFFICE_KEYWORDS_EN[group])
        return any(keyword in text for keyword in OFFICE_KEYWORDS[group])

    def revise_schedule(self, event, start, duration):
        self.action = memory.Action(event, start=start, duration=duration)
        plan, _ = self.schedule.current_plan()
        if len(plan["decompose"]) > 0:
            plan["decompose"] = self.completion(
                "schedule_revise", self.action, self.schedule
            )

    def percept(self):
        scope = self.maze.get_scope(self.coord, self.percept_config)
        # add spatial memory
        for tile in scope:
            if tile.has_address("game_object"):
                self.spatial.add_leaf(tile.address)
        events, arena = {}, self.get_tile().get_address("arena")
        # gather events in scope
        for tile in scope:
            if not tile.events or tile.get_address("arena") != arena:
                continue
            dist = math.dist(tile.coord, self.coord)
            for event in tile.get_events():
                if dist < events.get(event, float("inf")):
                    events[event] = dist
        events = list(sorted(events.keys(), key=lambda k: events[k]))
        # V24: an injected world event seen on site counts as learning of it.
        for event in events:
            if getattr(event, "notify_on_sight", False):
                self.notify_injection("world_event", event.get_describe(),
                                      getattr(event, "intervention_id", None))
        # get concepts
        self.concepts, valid_num = [], 0
        scores = self._batch_poignancy(events[: self.percept_config["att_bandwidth"]]) \
            if self.cheap and self.cheap.get("poignancy_batch") else {}
        for idx, event in enumerate(events[: self.percept_config["att_bandwidth"]]):
            recent_nodes = (
                self.associate.retrieve_events() + self.associate.retrieve_chats()
            )
            recent_nodes = set(n.describe for n in recent_nodes)
            if event.get_describe() not in recent_nodes:
                if event.object == "idle" or event.object == "空闲":
                    node = Concept.from_event(
                        "idle_" + str(idx), "event", event, poignancy=1
                    )
                else:
                    valid_num += 1
                    node_type = "chat" if event.fit(self.name, chat_predicate()) else "event"
                    node = self._add_concept(node_type, event, poignancy=scores.get(idx))
                    self.status["poignancy"] += node.poignancy
                self.concepts.append(node)
        self.concepts = [c for c in self.concepts if c.event.subject != self.name]
        self.logger.info(
            "{} percept {}/{} concepts".format(self.name, valid_num, len(self.concepts))
        )

    def _batch_poignancy(self, events):
        """Cheap mode H3: rate the new perceived events of this step in one call.

        Returns {index: score}; indices missing from the result (one event only, or a
        failed batch) are rated one by one as in the main mode."""
        recent = set(n.describe for n in self.associate.retrieve_events() + self.associate.retrieve_chats())
        todo, seen = [], set()
        for idx, event in enumerate(events):
            describe = event.get_describe()
            if describe in recent or describe in seen:
                continue
            if event.object in ("idle", "空闲") or event.fit(None, "is", "idle") or event.fit(None, "此时", "空闲"):
                continue
            seen.add(describe)
            todo.append((idx, "chat" if event.fit(self.name, chat_predicate()) else "event", describe))
        if len(todo) < 2 or not self.llm_available():
            return {}
        values = self.completion("poignancy_batch", [(kind, text) for _, kind, text in todo])
        if not values:
            return {}
        return {idx: value for (idx, _, _), value in zip(todo, values)}

    def make_plan(self, agents):
        # A researcher-specified behavior owns exactly this decision boundary.
        # The agent still perceives the world first, but reactions and its
        # ordinary schedule may not replace the manipulation in the same step.
        if self._forced_intervention_id:
            self.logger.info("{} executes researcher-specified behavior {}".format(
                self.name, self._forced_intervention_id
            ))
            self._forced_intervention_id = None
            self._pending_reactions = []
            return
        if self._pending_reactions:
            pending, self._pending_reactions = self._pending_reactions, []
            self._handled_injections.update(p["intervention_id"] for p in pending if p.get("intervention_id"))
            if self.injection_reaction and self._react_to_injection(pending):
                return
        if self._reaction(agents):
            return
        if self.path:
            return
        if self.action.finished():
            self.action = self._determine_action()

    # create action && object events
    def make_event(self, subject, describe, address):
        # emoji = self.completion("describe_emoji", describe)
        # return self.completion(
        #     "describe_event", subject, subject + describe, address, emoji
        # )

        e_describe = describe.replace("(", "").replace(")", "").replace("<", "").replace(">", "")
        now_word = L("此时", " is ")
        if e_describe.startswith(subject + now_word):
            e_describe = e_describe[len(subject + now_word):]
        if e_describe.startswith(subject):
            e_describe = e_describe[len(subject):]
        if lang.is_en():
            e_describe = e_describe.strip()
        event = memory.Event(
            subject, L("此时", "is"), e_describe, describe=describe, address=address
        )
        return event

    def reflect(self):
        def _add_thought(thought, evidence=None):
            # event = self.completion(
            #     "describe_event",
            #     self.name,
            #     thought,
            #     address=self.get_tile().get_address(),
            # )
            event = self.make_event(self.name, thought, self.get_tile().get_address())
            return self._add_concept("thought", event, filling=evidence)

        if self.status["poignancy"] < self.think_config["poignancy_max"]:
            return
        nodes = self.associate.retrieve_events() + self.associate.retrieve_thoughts()
        if not nodes:
            return
        self.logger.info(
            "{} reflect(P{}/{}) with {} concepts...".format(
                self.name,
                self.status["poignancy"],
                self.think_config["poignancy_max"],
                len(nodes),
            )
        )
        nodes = sorted(nodes, key=lambda n: n.access, reverse=True)[
            : self.associate.max_importance
        ]
        # summary thought
        focus = self.completion("reflect_focus", nodes, 3)
        retrieved = self.associate.retrieve_focus(focus, reduce_all=False)
        for r_nodes in retrieved.values():
            if not r_nodes:
                continue
            thoughts = self.completion("reflect_insights", r_nodes, 5)
            for thought, evidence in thoughts:
                _add_thought(thought, evidence)
        # summary chats
        if self.chats:
            recorded, evidence = set(), []
            for name, _ in self.chats:
                if name == self.name or name in recorded:
                    continue
                res = self.associate.retrieve_chats(name)
                if res and len(res) > 0:
                    node = res[-1]
                    evidence.append(node.node_id)
            thought = self.completion("reflect_chat_planing", self.chats)
            _add_thought(L(f"对于 {self.name} 的计划：{thought}", f"For {self.name}'s planning: {thought}"), evidence)
            thought = self.completion("reflect_chat_memory", self.chats)
            _add_thought(f"{self.name} {thought}", evidence)
        self.status["poignancy"] = 0
        self.chats = []

    INTERPERSONAL_VERBS = (
        "鼓励", "讨论", "汇报", "沟通", "询问", "交流", "请教", "反馈",
        "分享", "安慰", "指导", "商量", "会面", "帮助", "协助", "慰问",
    )
    INTERPERSONAL_VERBS_EN = (
        r"\bencourag", r"\bdiscuss", r"\breport", r"\bcommunicat", r"\bask", r"\bchat", r"\bconsult",
        r"\bfeedback", r"\bshare", r"\bsharing", r"\bcomfort", r"\bguid", r"\bcoach", r"\bmentor",
        r"\btalk", r"\bmeet\b", r"\bmeet with", r"\bhelp", r"\bassist", r"\bcheck on", r"\bconsol",
    )

    def _maybe_seek_target(self, agents):
        """人际意图落地为趋近行为：当前行为提到他人且含人际动词、对方不在近旁时，
        返回应走向的目标agent名；否则返回None。同一行为只寻人一次（节流）。"""
        if not self.action or not self.is_awake():
            return None
        describe = self.get_event().get_describe(False) or ""
        if lang.is_en():
            if not _en_match(describe, self.INTERPERSONAL_VERBS_EN):
                return None
        elif not any(v in describe for v in self.INTERPERSONAL_VERBS):
            return None
        target = None
        for other in agents:
            if other != self.name and other in describe:
                target = other
                break
        if target is None:
            return None
        other_agent = agents[target]
        if not other_agent.is_awake():
            return None
        # 已经在近旁（切比雪夫距离 <= 感知半径的一半）则无需寻人
        vision = max(2, int(self.percept_config.get("vision_r", 8)) // 2)
        dx = abs(self.coord[0] - other_agent.coord[0])
        dy = abs(self.coord[1] - other_agent.coord[1])
        if max(dx, dy) <= vision:
            return None
        key = (getattr(self.action, "start", None), describe)
        if self._last_seek_key == key:
            return None  # 这个行为已寻过一次，对方走了就不再追
        self._last_seek_key = key
        self.logger.info(
            "{} seeks {} for interpersonal action: {}".format(self.name, target, describe)
        )
        return target

    def find_path(self, agents):
        address = self.get_event().address
        self._approach_target = None
        if self.path:
            if self.maze.navigation and not self.maze.validate_path(self.coord, self.path):
                self.path = []
            else:
                return self.path
        seek_name = self._maybe_seek_target(agents)
        if seek_name:
            address = ["<persona>", seek_name]
        # V24: remembered so the end-of-step pass can follow a target that moved.
        self._approach_target = address[1] if address and address[0] == "<persona>" else None
        if address == self.get_tile().get_address():
            return []
        if address[0] == "<waiting>":
            return []
        if address[0] == "<persona>":
            other = agents[address[1]]
            if self.perception_policy == "step_end_v24":
                target_coord = other.next_coord or other.coord
                target_tiles = self.approach_tiles(target_coord) or self.maze.get_around(target_coord)
            else:
                target_tiles = self.maze.get_around(other.coord)
        else:
            target_tiles = self.maze.get_address_tiles(address)
        if tuple(self.coord) in target_tiles:
            return []

        # filter tile with self event
        def _ignore_target(t_coord):
            if self.maze.navigation and not self.maze.walkable(t_coord):
                return True
            if list(t_coord) == list(self.coord):
                return True
            events = self.maze.tile_at(t_coord).get_events()
            if any(e.subject in agents for e in events):
                return True
            return False

        target_tiles = [t for t in target_tiles if not _ignore_target(t)]
        if not target_tiles:
            return []
        if len(target_tiles) >= 4 and not self.maze.navigation:
            target_tiles = random.sample(target_tiles, 4)
        pathes = {}
        for t in target_tiles:
            path = self.maze.find_path(self.coord, t)
            if path and tuple(path[-1]) == tuple(t) and len(path) > 1:
                pathes[t] = path
        if not pathes:
            return []
        target = min(pathes, key=lambda p: len(pathes[p]))
        return pathes[target][1:]

    def _determine_action(self):
        self.logger.info("{} is determining action...".format(self.name))
        plan, de_plan = self.schedule.current_plan()
        describes = [plan["describe"], de_plan["describe"]]
        address = self._office_redirect_address(describes)
        if not address:
            address = self.spatial.find_address(describes[0], as_list=True)
        if not address:
            tile = self.get_tile()
            kwargs = {
                "describes": describes,
                "spatial": self.spatial,
                "address": tile.get_address("world", as_list=True),
            }
            kwargs["address"].append(
                self.completion("determine_sector", **kwargs, tile=tile)
            )
            arenas = self.spatial.get_leaves(kwargs["address"])
            if len(arenas) == 1:
                kwargs["address"].append(arenas[0])
            else:
                kwargs["address"].append(self.completion("determine_arena", **kwargs))
            objs = self.spatial.get_leaves(kwargs["address"])
            if len(objs) == 1:
                kwargs["address"].append(objs[0])
            elif len(objs) > 1:
                kwargs["address"].append(self._choose_object(objs, describes, kwargs["address"]))
            address = kwargs["address"]

        event = self.make_event(self.name, describes[-1], address)
        obj_describe = describes[-1]
        obj_event = self.make_event(address[-1], obj_describe, address)

        event.emoji = f"{de_plan['describe']}"

        return memory.Action(
            event,
            obj_event,
            duration=de_plan["duration"],
            start=utils.get_timer().daily_time(de_plan["start"]),
        )

    def _office_redirect_address(self, describes):
        text = " ".join([d for d in describes if d])
        minute = utils.get_timer().daily_duration()
        hour = int(minute / 60)
        target_key = None

        if self._has_office_keyword(text, "sleep"):
            target_key = "bed"
        elif self._has_office_keyword(text, "dorm"):
            target_key = "bed"
        elif self._has_office_keyword(text, "meal"):
            target_key = "sofa"
        elif self._has_office_keyword(text, "outside"):
            if hour >= 20 or hour < 8:
                target_key = "bed"
            elif 11 <= hour <= 13:
                target_key = "sofa"
            else:
                return self._workstation_address()
        elif self._has_office_keyword(text, "leader"):
            target_key = "leader_desk"
        elif self._has_office_keyword(text, "meeting"):
            target_key = "meeting_table"
        elif self._has_office_keyword(text, "print"):
            target_key = "printer"
        elif self._has_office_keyword(text, "break"):
            target_key = "water_dispenser"
        elif self._has_office_keyword(text, "work"):
            return self._workstation_address()

        if not target_key:
            return []
        return self._office_address(target_key)

    def _office_address(self, key):
        address = office_address(key)
        if ":".join(address) in self.maze.address_tiles:
            return list(address)
        return []

    def _address_of_object(self, obj_name):
        """按物品名在地图中反查完整地址（任意名单/任意地图通用）。"""
        if not obj_name:
            return []
        suffix = ":" + obj_name
        for full in self.maze.address_tiles:
            if full.endswith(suffix):
                return full.split(":")
        return []

    def _workstation_address(self):
        """本人工位地址：workstation字段优先，其次默认名单映射，最后公共办公桌。"""
        addr = self._address_of_object(self.workstation)
        if addr:
            return addr
        key = OFFICE_AGENT_WORKSTATIONS.get(self.name, "public_desk")
        return self._office_address(key) or self._office_address("public_desk")

    def _is_office_leader(self):
        """是否办公室领导角色：以拥有领导办公桌为准，而非名字。"""
        return self.workstation in ("领导办公桌", "team lead desk") or (
            not self.workstation and self.name in ("克劳斯", "Klaus"))

    def _choose_object(self, objs, describes, address):
        text = " ".join(describes)
        personal_targets = [
            self.workstation,
            f"{self.name}工位",
            f"{self.name}办公桌",
            lang.loc("领导办公桌") if self._is_office_leader() else "",
        ]
        for target in personal_targets:
            if target and target in objs:
                return target

        keyword_priorities = [
            (["会议", "讨论", "汇报"], ["会议桌", "白板", "书柜"]),
            (["打印", "复印"], ["打印机"]),
            (["喝水", "茶水", "咖啡", "休息", "交流"], ["饮水机", "沙发", "休息沙发"]),
            (["睡", "宿舍", "晚餐"], ["床", "休息沙发"]),
            (["阅读", "资料", "论文", "图书"], ["书柜", "公共办公桌"]),
            (["管理", "反馈", "检查"], ["领导办公桌", "公共办公桌"]),
        ]
        keywords_en = [
            [r"\bmeeting", r"\bdiscuss", r"\breport(?:ing|s)? (?:to|back)\b"],
            [r"\bprint", r"\bphotocop", r"\bmake copies"],
            [r"\bdrink", r"\bwater\b", r"\btea\b", r"\bcoffee", r"\brest\b", r"\bresting\b", r"\bchat"],
            [r"\bsleep", r"\bdorm", r"\bdinner"],
            [r"\bread", r"\bmaterial", r"\bpaper", r"\bbook"],
            [r"\bmanag", r"\bfeedback", r"\bcheck"],
        ]
        for index, (keywords, candidates) in enumerate(keyword_priorities):
            hit = _en_match(text, keywords_en[index]) if lang.is_en() else any(keyword in text for keyword in keywords)
            if hit:
                for candidate in candidates:
                    candidate = lang.loc(candidate)
                    if candidate in objs:
                        return candidate

        if address and len(address) >= 3 and address[-1] == lang.loc("开放办公区"):
            for candidate in ["公共办公桌", "1号工位", "2号工位", "3号工位"]:
                candidate = lang.loc(candidate)
                if candidate in objs:
                    return candidate
        return objs[0]

    def _reaction(self, agents=None, ignore_words=None):
        focus = None
        ignore_words = ignore_words or [L("空闲", "idle")]

        def _focus(concept):
            return concept.event.subject in agents

        def _ignore(concept):
            return any(i in concept.describe for i in ignore_words)

        if agents:
            priority = [i for i in self.concepts if _focus(i)]
            if priority:
                focus = random.choice(priority)
        if not focus:
            priority = [i for i in self.concepts if not _ignore(i)]
            if priority:
                focus = random.choice(priority)
        if not focus or focus.event.subject not in agents:
            return
        other, focus = agents[focus.event.subject], self.associate.get_relation(focus)

        if self._chat_with(other, focus):
            return True
        if self._wait_other(other, focus):
            return True
        return False

    def _skip_react(self, other):
        def _skip(event):
            if not event.address or "sleeping" in event.get_describe(False) or "睡觉" in event.get_describe(False):
                return True
            if event.predicate == "待开始":
                return True
            return False

        if utils.get_timer().daily_duration(mode="hour") >= 23:
            return True
        if _skip(self.get_event()) or _skip(other.get_event()):
            return True
        return False

    def _chat_with(self, other, focus):
        if len(self.schedule.daily_schedule) < 1 or len(other.schedule.daily_schedule) < 1:
            # initializing
            return False
        if self._skip_react(other):
            return False
        if other.path:
            return False
        if self.get_event().fit(predicate=chat_predicate()) or other.get_event().fit(predicate=chat_predicate()):
            return False

        chats = self.associate.retrieve_chats(other.name)
        if chats:
            delta = utils.get_timer().get_delta(chats[0].create)
            self.logger.info(
                "retrieved chat between {} and {}({} min):\n{}".format(
                    self.name, other.name, delta, chats[0]
                )
            )
            if delta < 60:
                return False

        if not self.completion("decide_chat", self, other, focus, chats):
            return False

        self.logger.info("{} decides chat with {}".format(self.name, other.name))
        start, chats = utils.get_timer().get_date(), []
        relations = [
            self.completion("summarize_relation", self, other.name),
            other.completion("summarize_relation", other, self.name),
        ]

        # V23: mirrors agent_chat_v2 in the original Stanford converse.py: up to
        # chat_iter rounds (8 by default there), each speaker may end the chat
        # in the same call that produces the utterance.
        ended = False
        for i in range(self.chat_iter):
            text, end = self.completion(
                "generate_chat", self, other, relations[0], chats
            )
            chats.append((self.name, text))
            if end:
                ended = True
                break
            text, end = other.completion(
                "generate_chat", other, self, relations[1], chats
            )
            chats.append((other.name, text))
            if end:
                ended = True
                break
        self.last_chat_meta = {"partner": other.name, "rounds": (len(chats) + 1) // 2,
                               "utterances": len(chats), "ended_by_speaker": ended,
                               "hit_cap": not ended, "cap": self.chat_iter}
        self._monitor_buffer.append(("chat_meta", json.dumps(self.last_chat_meta, ensure_ascii=False), 0))
        for agent, relation, partner in ((self, relations[0], other.name), (other, relations[1], self.name)):
            agent.scratch.config.setdefault("relations", {})[partner] = {
                "text": relation, "time": utils.get_timer().get_date("%Y%m%d-%H:%M")}

        key = utils.get_timer().get_date("%Y%m%d-%H:%M")
        if key not in self.conversation.keys():
            self.conversation[key] = []
        self.conversation[key].append({f"{self.name} -> {other.name} @ {L('，', ', ').join(self.get_event().address)}": chats})

        self.logger.info(
            "{} and {} has chats\n  {}".format(
                self.name,
                other.name,
                "\n  ".join(["{}: {}".format(n, c) for n, c in chats]),
            )
        )
        chat_summary = self.completion("summarize_chats", chats)
        # Chinese: about 240 characters per minute of conversation. English text runs about
        # 3.3 times as many characters for the same content, so 800 keeps durations comparable.
        duration = int(sum([len(c[1]) for c in chats]) / L(240, 800))
        self.schedule_chat(
            chats, chat_summary, start, duration, other
        )
        other.schedule_chat(chats, chat_summary, start, duration, self)
        return True

    def _wait_other(self, other, focus):
        if self._skip_react(other):
            return False
        if not self.path:
            return False
        if self.get_event().address != other.get_tile().get_address():
            return False
        if not self.completion("decide_wait", self, other, focus):
            return False
        self.logger.info("{} decides wait to {}".format(self.name, other.name))
        start = utils.get_timer().get_date()
        # duration = other.action.end - start
        t = other.action.end - start
        duration = int(t.total_seconds() / 60)
        event = memory.Event(
            self.name,
            "waiting to start",
            self.get_event().get_describe(False),
            # address=["<waiting>"] + self.get_event().address,
            address=self.get_event().address,
            emoji=f"⌛",
        )
        self.revise_schedule(event, start, duration)

    def schedule_chat(self, chats, chats_summary, start, duration, other, address=None):
        self.chats.extend(chats)
        event = memory.Event(
            self.name,
            chat_predicate(),
            other.name,
            describe=chats_summary,
            address=address or self.get_tile().get_address(),
            emoji=f"💬",
        )
        self.revise_schedule(event, start, duration)

    def survey_budget_tokens(self):
        budget = int((getattr(self, "_resolved_config", {}).get("survey_context") or {}).get("budget_tokens", 8000))
        if self.cheap and self.cheap.get("short_context"):
            budget = min(budget, int(self.cheap.get("short_context_tokens", 3000)))
        return budget

    def cheap_survey_layout(self):
        """Cheap mode H1/H5 apply to passive three-layer measurement only."""
        return bool(self.cheap and (self.cheap.get("cache_order") or self.cheap.get("survey_merge"))
                    and self.measurement_policy != "legacy_reactive"
                    and self.survey_context_version() == "three_layer_v1")

    def _snapshot_cached(self, schemas, ratee=None):
        from modules import survey_context
        shared, earlier, meta = survey_context.build_cached(
            self, schemas, ratee=ratee, budget_tokens=self.survey_budget_tokens())
        return {"layout": "cache", "context_text": shared, "earlier": earlier,
                "ratee_context": shared, "self_context": "",
                "address": copy.deepcopy(self.get_tile().get_address()),
                "now": utils.get_timer().get_date(),
                "survey_time": utils.get_timer().get_date("%Y%m%d-%H:%M"),
                "context_meta": meta}

    def snapshot_survey_bundle(self, schemas, ratee=None):
        """Cheap mode H5: one frozen context for several questionnaires answered together."""
        return self._snapshot_cached(list(schemas), ratee=ratee)

    def complete_survey_bundle(self, schemas, ratee, condition, run_id, survey_date, snapshot):
        """Cheap mode H5: answer several questionnaires in one call; any questionnaire whose
        answer is unusable is asked again on its own. Returns [(survey_id, row)] in order."""
        from modules import survey as survey_engine
        survey_time = snapshot["survey_time"]
        asked_list = []
        for schema in schemas:
            asked_list.append(survey_engine.ordered_for_asking(
                schema, "|".join(map(str, (run_id, self.name, ratee or "", schema.get("id"), survey_time)))))
        merged = {}
        if len(schemas) > 1 and self.llm_available():
            merged = self.completion("custom_survey_merged", [a for a, _ in asked_list], survey_time,
                                     snapshot["context_text"], snapshot["earlier"], ratee) or {}
        rows = []
        for index, (schema, (asked, order)) in enumerate(zip(schemas, asked_list)):
            if index in merged:
                answers = copy.deepcopy(merged[index])
                how = "merged"
            else:
                answers = self.completion("custom_survey_cache", asked, survey_time,
                                          snapshot["context_text"], snapshot["earlier"], ratee)
                how = "single"
            row = {
                "survey_id": schema.get("id"),
                "run_id": run_id,
                "condition": condition,
                "survey_date": survey_date,
                "survey_time": survey_time,
                "agent": self.name,
            }
            if ratee:
                row["ratee"] = ratee
            row.update(answers)
            if order:
                row["_item_order"] = order
            row["_measurement_policy"] = self.measurement_policy
            meta = dict(snapshot.get("context_meta") or {})
            meta["cheap_mode"] = {"call": how, "bundle": [s.get("id") for s in schemas]}
            row["_context"] = meta
            rows.append((schema.get("id"), row))
        return rows

    def snapshot_dyadic_survey(self, ratee, schema=None):
        if self.measurement_policy == "legacy_reactive":
            return self._snapshot_dyadic_survey(ratee)
        if self.cheap_survey_layout():
            return self._snapshot_cached(schema, ratee=ratee)
        if self.survey_context_version() == "three_layer_v1":
            from modules import survey_context
            text, meta = survey_context.build(self, schema, ratee=ratee,
                                              budget_tokens=self.survey_budget_tokens())
            return {"ratee_context": text, "self_context": "",
                    "survey_time": utils.get_timer().get_date("%Y%m%d-%H:%M"),
                    "context_meta": meta}
        # Retrieval updates access timestamps; passive measurements restore them.
        docs = self.associate.index._index.docstore.docs
        accesses = {key: node.metadata.get("access") for key, node in docs.items()}
        retrieve_config = copy.deepcopy(self.associate._retrieve_config)
        strict_before = getattr(self.associate.index, "strict_retrieval", False)
        self.associate.index.strict_retrieval = True
        self.associate._retrieve_config["read_only"] = True
        try:
            return self._snapshot_dyadic_survey(ratee)
        finally:
            for key, access in accesses.items():
                if key in docs:
                    docs[key].metadata["access"] = access
            self.associate._retrieve_config = retrieve_config
            self.associate.index.strict_retrieval = strict_before

    def _snapshot_dyadic_survey(self, ratee):
        """Freeze the rater's context before any parallel survey request starts."""
        # 关于被评者的记忆：相关事件/想法（语义检索） + 与其的对话
        pieces = []
        try:
            retrieved = self.associate.retrieve_focus([ratee], retrieve_max=12)
            for node in retrieved or []:
                desc = getattr(node, "describe", None) or str(node)
                pieces.append("- " + desc)
        except Exception:  # noqa: BLE001
            if self.measurement_policy != "legacy_reactive":
                raise
        try:
            chats = self.associate.retrieve_chats(ratee) or []
            for node in chats[-6:]:
                desc = getattr(node, "describe", None) or str(node)
                pieces.append(L("- [对话] ", "- [conversation] ") + desc)
        except Exception:  # noqa: BLE001
            if self.measurement_policy != "legacy_reactive":
                raise
        ratee_context = "\n".join(pieces) if pieces else L("（今天与TA没有明确的互动记录）", "(no clear record of interaction with this person today)")

        self_context = json.dumps({
            "currently": self.scratch.currently,
            "psych": self.psych.describe(),
            "recent_memory": self.associate.abstract(),
        }, ensure_ascii=False, indent=1)

        return {
            "ratee_context": ratee_context,
            "self_context": self_context,
            "survey_time": utils.get_timer().get_date("%Y%m%d-%H:%M"),
        }

    def complete_dyadic_survey(
        self, schema, ratee, condition, run_id, survey_date, snapshot=None
    ):
        """互评问卷：以第一人称、基于关于被评者的冻结记忆评价 ratee。"""
        snapshot = snapshot or self.snapshot_dyadic_survey(ratee, schema)
        ratee_context = snapshot["ratee_context"]
        self_context = snapshot["self_context"]
        survey_time = snapshot["survey_time"]

        from modules import survey as survey_engine
        asked, order = survey_engine.ordered_for_asking(
            schema, "|".join(map(str, (run_id, self.name, ratee, schema.get("id"), survey_time))))
        if snapshot.get("layout") == "cache":
            answers = self.completion("custom_survey_cache", asked, survey_time,
                                      snapshot["context_text"], snapshot["earlier"], ratee)
        else:
            answers = self.completion(
                "custom_survey_dyadic", asked, ratee, survey_time, ratee_context, self_context
            )
        row = {
            "survey_id": schema.get("id"),
            "run_id": run_id,
            "condition": condition,
            "survey_date": survey_date,
            "survey_time": survey_time,
            "agent": self.name,
            "ratee": ratee,
        }
        row.update(answers)
        if order:
            row["_item_order"] = order
        row["_measurement_policy"] = self.measurement_policy
        if snapshot.get("context_meta"):
            row["_context"] = snapshot["context_meta"]
        return row

    def survey_context_version(self):
        return (getattr(self, "_resolved_config", {}).get("survey_context") or {}).get("version", "three_layer_v1")

    def snapshot_survey_context(self, schema=None):
        """Serialize one immutable end-of-step context for a self-report survey."""
        if self.cheap_survey_layout():
            return self._snapshot_cached(schema)
        if self.measurement_policy != "legacy_reactive" and self.survey_context_version() == "three_layer_v1":
            from modules import survey_context
            text, meta = survey_context.build(self, schema, budget_tokens=self.survey_budget_tokens())
            return {
                "context_text": text,
                "address": copy.deepcopy(self.get_tile().get_address()),
                "now": utils.get_timer().get_date(),
                "survey_time": utils.get_timer().get_date("%Y%m%d-%H:%M"),
                "context_meta": meta,
            }
        context = {
            "agent": self.name,
            "currently": self.scratch.currently,
            "current_location": self.get_tile().get_address(),
            "current_action": self.action.to_dict() if self.action else {},
            "status": self.status,
            "schedule": self.schedule.to_dict() if self.schedule.scheduled() else {},
            "recent_memory": self.associate.abstract(),
            "recent_chats": self.chats,
        }
        address = copy.deepcopy(self.get_tile().get_address())
        now = utils.get_timer().get_date()
        return {
            "context_text": json.dumps(context, ensure_ascii=False, indent=2),
            "address": address,
            "now": now,
            "survey_time": utils.get_timer().get_date("%Y%m%d-%H:%M"),
        }

    def complete_custom_survey(
        self, schema, condition, run_id, survey_date, snapshot=None
    ):
        """按研究者自定义的问卷schema作答（通用问卷引擎）。"""
        snapshot = snapshot or self.snapshot_survey_context(schema)
        context_text = snapshot["context_text"]
        survey_time = snapshot["survey_time"]
        from modules import survey as survey_engine
        asked, order = survey_engine.ordered_for_asking(
            schema, "|".join(map(str, (run_id, self.name, "", schema.get("id"), survey_time))))
        if snapshot.get("layout") == "cache":
            answers = self.completion("custom_survey_cache", asked, survey_time,
                                      context_text, snapshot["earlier"], None)
        else:
            answers = self.completion("custom_survey", asked, survey_time, context_text)

        # 在记忆中留下"填写了问卷"的痕迹（低显著性，避免问卷本身成为重大事件）
        event = memory.Event(
            self.name,
            L("反思", "reflect on"),
            L("研究问卷", "research survey"),
            describe=L(f"{self.name} 填写了研究问卷《{schema.get('title', schema.get('id'))}》。",
                       f"{self.name} filled in the research survey \"{schema.get('title', schema.get('id'))}\"."),
            address=snapshot["address"],
        )
        if self.measurement_policy == "legacy_reactive":
            self.associate.add_node(
            "thought",
            event,
            poignancy=3,
            expire=snapshot["now"] + datetime.timedelta(days=30),
            )
        row = {
            "survey_id": schema.get("id"),
            "run_id": run_id,
            "condition": condition,
            "survey_date": survey_date,
            "survey_time": survey_time,
            "agent": self.name,
        }
        row.update(answers)
        if order:
            row["_item_order"] = order
        row["_measurement_policy"] = self.measurement_policy
        if snapshot.get("context_meta"):
            row["_context"] = snapshot["context_meta"]
        return row

    def complete_daily_survey(
        self, role, condition, run_id, survey_date, snapshot=None
    ):
        snapshot = snapshot or self.snapshot_survey_context()
        context_text = snapshot["context_text"]
        if role == "leader":
            row = self.completion(
                "daily_survey_leader", condition, run_id, survey_date, context_text
            )
            memory_text = L(
                f"{self.name} 在睡前领导自评问卷中报告：管理严厉度为 "
                f"{row['self_rated_leader_strictness']}，压力为 {row['stress']}，"
                f"对团队信任为 {row['team_trust']}，管理投入为 {row['management_engagement']}，"
                f"心理资源恢复为 {row['psychological_resource_recovery']}，"
                f"情绪耗竭为 {row['emotional_exhaustion']}。原因：{row['reason']}",
                f"In the bedtime self-report survey for leaders, {self.name} reported: strictness of management "
                f"{row['self_rated_leader_strictness']}, stress {row['stress']}, "
                f"trust in the team {row['team_trust']}, engagement in managing {row['management_engagement']}, "
                f"recovery of psychological resources {row['psychological_resource_recovery']}, "
                f"emotional exhaustion {row['emotional_exhaustion']}. Reason: {row['reason']}"
            )
        else:
            row = self.completion(
                "daily_survey_employee", condition, run_id, survey_date, context_text
            )
            memory_text = L(
                f"{self.name} 在睡前员工问卷中报告：感知领导严厉度为 "
                f"{row['perceived_leader_strictness']}，压力为 {row['stress']}，"
                f"心理安全感为 {row['psychological_safety']}，对领导信任为 {row['leader_trust']}，"
                f"工作投入为 {row['work_engagement']}，离职意愿为 {row['turnover_intention']}。"
                f"原因：{row['reason']}",
                f"In the bedtime employee survey, {self.name} reported: perceived strictness of the team lead "
                f"{row['perceived_leader_strictness']}, stress {row['stress']}, "
                f"psychological safety {row['psychological_safety']}, trust in the team lead {row['leader_trust']}, "
                f"work engagement {row['work_engagement']}, intention to leave {row['turnover_intention']}. "
                f"Reason: {row['reason']}"
            )

        event = memory.Event(
            self.name,
            L("反思", "reflect on"),
            L("睡前问卷", "bedtime survey"),
            describe=memory_text,
            address=snapshot["address"],
        )
        if self.measurement_policy == "legacy_reactive":
            self.associate.add_node(
            "thought",
            event,
            poignancy=5,
            expire=snapshot["now"] + datetime.timedelta(days=30),
            )
        row.update(
            {
                "agent": self.name,
                "role": role,
                "condition": condition,
                "run_id": run_id,
                "survey_date": survey_date,
                "survey_time": snapshot["survey_time"],
                "_measurement_policy": self.measurement_policy,
            }
        )
        return row

    def _add_concept(
        self,
        e_type,
        event,
        create=None,
        expire=None,
        filling=None,
        poignancy=None,
    ):
        if event.fit(None, "is", "idle"):
            poignancy = 1
        elif event.fit(None, "此时", "空闲"):
            poignancy = 1
        elif poignancy is not None:
            pass   # cheap mode H3: rated together with the other events of this step
        elif e_type == "chat":
            poignancy = self.completion("poignancy_chat", event)
        else:
            poignancy = self.completion("poignancy_event", event)
        self.logger.debug("{} add associate {}".format(self.name, event))
        concept = self.associate.add_node(
            e_type,
            event,
            poignancy,
            create=create,
            expire=expire,
            filling=filling,
        )
        if poignancy and poignancy > 1:
            self._psych_buffer.append((event.get_describe(), poignancy))
        self._monitor_buffer.append((e_type, event.get_describe(), poignancy or 0))
        if concept is None:
            node_id = "transient_{}_{}".format(e_type, utils.get_timer().get_date("%Y%m%d%H%M%S"))
            return Concept.from_event(node_id, e_type, event, poignancy)
        return concept

    # ------------------------------------------------------------------
    # 结构化心理状态（阶段四）
    # ------------------------------------------------------------------
    def _psych_drift(self):
        now = utils.get_timer().get_date()
        elapsed = (now - self._psych_last_drift).total_seconds() / 60.0
        self._psych_last_drift = now
        if elapsed <= 0:
            return
        sleeping = not self.is_awake()
        if not sleeping and self.action:
            describe = self.get_event().get_describe() or ""
            sleeping = ("睡" in describe) if not lang.is_en() else bool(re.search(r"\bsleep|\basleep", describe.lower()))
        self.psych.drift(elapsed, sleeping=sleeping)
        self.scratch.psych_text = self.psych.describe()

    def _psych_appraise(self):
        if not self._psych_buffer:
            return
        total = sum(p for _, p in self._psych_buffer)
        if total < psych_mod.APPRAISAL_POIGNANCY_THRESHOLD:
            return
        now = utils.get_timer().get_date()
        if self._psych_last_appraisal is not None:
            gap = (now - self._psych_last_appraisal).total_seconds() / 60.0
            if gap < psych_mod.APPRAISAL_COOLDOWN_MINUTES:
                return
        self._psych_last_appraisal = now
        events_text = "\n".join(
            L("- {}（显著性{}）", "- {} (importance {})").format(d, p) for d, p in self._psych_buffer[-10:]
        )
        self._psych_buffer = []
        deltas = self.completion(
            "psych_appraisal", events_text, self.psych.describe(), total
        )
        applied = self.psych.apply_deltas(deltas)
        if applied:
            self.logger.info(
                "{} psych appraisal -> {} | now {}".format(
                    self.name, applied, self.psych.snapshot()
                )
            )
            delta_text = L("，", ", ").join(
                "{}{}{:+.1f}".format(L(psych_mod.VAR_LABELS, psych_mod.VAR_LABELS_EN).get(k, k), L("", " "), v)
                for k, v in applied.items()
            )
            self._monitor_buffer.append(
                ("psych", L("心理状态变化：{}（现状：{}）", "Change in state of mind: {} (now: {})").format(delta_text, self.psych.describe()), 0)
            )
        self.scratch.psych_text = self.psych.describe()

    def drain_monitor(self):
        """取走并清空时间线监控缓冲。"""
        buf, self._monitor_buffer = self._monitor_buffer, []
        return buf

    def set_psych(self, values):
        """研究者直接设定心理状态（干预）。values: {var: 1-10}"""
        applied = self.psych.set_values(values)
        self.scratch.psych_text = self.psych.describe()
        return applied

    def inject_forced_action(
        self,
        text,
        address,
        duration=30,
        event_id=None,
        intervention_id=None,
    ):
        """Make a researcher-specified action the agent's next real action.

        ``address`` may be a normal map address or ``["<persona>", name]``.
        The latter uses the existing pathfinder to approach the target agent.
        """
        clean_text = (text or "").strip()
        if not clean_text:
            raise ValueError("指定行为内容不能为空")
        try:
            duration = max(1, int(duration or 30))
        except (TypeError, ValueError):
            duration = 30
        event = memory.Event(
            self.name,
            L("执行", "carry out"),
            clean_text,
            describe=clean_text,
            address=list(address or self.get_tile().get_address()),
            event_id=event_id,
            intervention_id=intervention_id,
            researcher_injected=True,
        )
        self.action = memory.Action(event, duration=duration)
        self.path = []
        self._last_seek_key = None
        self._forced_intervention_id = intervention_id or event_id or "researcher"
        self._monitor_buffer.append(("specified_action", clean_text, 0))
        return event

    def get_tile(self):
        return self.maze.tile_at(self.coord)

    def get_event(self, as_act=True):
        return self.action.event if as_act else self.action.obj_event

    def is_awake(self):
        if not self.action:
            return True
        if self.get_event().fit(self.name, "is", "sleeping"):
            return False
        if self.get_event().fit(self.name, "正在", "睡觉"):
            return False
        return True

    def llm_available(self):
        if not self._llm:
            return False
        return self._llm.is_available()

    def to_dict(self, with_action=True):
        info = {
            **self._resolved_config,
            "status": self.status,
            "schedule": self.schedule.to_dict(),
            "associate": self.associate.to_dict(),
            "chats": self.chats,
            "currently": self.scratch.currently,
            "psych": self.psych.to_dict(),
            "coord": list(self.coord),
            "_cognitive_coord": list(self.coord),
            "plan": copy.deepcopy(self.plan),
            "_psych_buffer": copy.deepcopy(self._psych_buffer),
            "_psych_last_drift": self._psych_last_drift.strftime("%Y%m%d-%H:%M:%S"),
            "_psych_last_appraisal": self._psych_last_appraisal.strftime("%Y%m%d-%H:%M:%S") if self._psych_last_appraisal else None,
            "_last_seek_key": [self._last_seek_key[0].strftime("%Y%m%d-%H:%M:%S")
                              if isinstance(self._last_seek_key[0], datetime.datetime) else self._last_seek_key[0],
                              self._last_seek_key[1]] if self._last_seek_key else None,
            "measurement_policy": self.measurement_policy,
            "office_rhythm": self.office_rhythm,
            "scratch": copy.deepcopy(self.scratch.config),
            "spatial": {"tree": copy.deepcopy(self.spatial.tree), "address": copy.deepcopy(self.spatial.address)},
            "last_record": self.last_record,
            "workstation": self.workstation,
        }
        if with_action:
            info.update({"action": self.action.to_dict()})
        return info
