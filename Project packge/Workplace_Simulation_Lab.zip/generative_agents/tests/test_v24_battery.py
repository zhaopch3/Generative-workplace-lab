# -*- coding: utf-8 -*-
"""V24: replication battery in the persona-manipulation templates."""
import json
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

from modules import survey as survey_engine  # noqa: E402
import build_v24_battery as battery  # noqa: E402


def load(name):
    return json.loads((ROOT / "data" / "world_presets" / (name + ".json")).read_text(encoding="utf-8"))


class BatteryTemplateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.high = load("人设操纵-高辱虐组")
        cls.low = load("人设操纵-低辱虐组")
        cls.battery = json.loads((ROOT / battery.BATTERY_PATH).read_text(encoding="utf-8"))

    def test_both_persona_templates_carry_the_same_battery(self):
        high = [s for s in self.high["custom_surveys"] if s["id"].startswith("b_")]
        low = [s for s in self.low["custom_surveys"] if s["id"].startswith("b_")]
        self.assertGreater(len(high), 200)
        self.assertEqual(high, low)
        self.assertEqual([s["id"] for s in high], [e["survey"]["id"] for e in self.battery["surveys"]])

    def test_event_templates_untouched(self):
        for name in ("事件操纵-高辱虐组", "事件操纵-低辱虐组"):
            self.assertFalse(any(s["id"].startswith("b_") for s in load(name)["custom_surveys"]))

    def test_v23_surveys_kept(self):
        ids = [s["id"] for s in self.high["custom_surveys"]]
        for sid in ("big5_check", "abusive_self", "coworker_today", "leader_abuse_self", "power_sense"):
            self.assertIn(sid, ids)

    def test_every_survey_validates_and_keeps_instructions(self):
        ids = set()
        for s in self.high["custom_surveys"]:
            out = survey_engine.validate_schema(s)
            self.assertNotIn(out["id"], ids)
            ids.add(out["id"])
            if s["id"].startswith("b_"):
                self.assertEqual(out["instructions"], s["instructions"])
                self.assertTrue(out["randomize_items"])
                self.assertFalse(out["include_reason"])
                self.assertIn(out["display_title"], ("员工日记问卷", "管理者日记问卷"))

    def test_respondents_are_sim_roles(self):
        emp, leader = set(battery.EMP), {battery.LEADER}
        for e in self.battery["surveys"]:
            s = e["survey"]
            if s["mode"] == "self":
                self.assertIn(set(s["targets"]), (emp, leader))
            else:
                self.assertTrue(set(s["raters"]) <= emp | leader)
                self.assertTrue(set(s["ratees"]) <= emp)
        self.assertEqual(self.battery["skipped"], [])

    def test_scope_matches_the_decisions(self):
        keys = [(x["paper_id"], x["study_id"], x["var_id"]) for e in self.battery["surveys"] for x in e["sources"]]
        self.assertEqual(len(keys), len(set(keys)))
        self.assertEqual(len(keys), 291)
        papers = {k[0] for k in keys}
        self.assertEqual(len(papers), 53)
        self.assertFalse(papers & {"P211", "P282", "P038"})
        self.assertNotIn(("P056", "S1", "V1"), keys)  # manager abuse: only in the excluded H1, H3
        excluded = {(x["paper_id"], x["h_id"]) for x in self.battery["excluded_hypotheses"]}
        self.assertIn(("P056", "H1"), excluded)
        self.assertFalse(self.battery["include_pending"])
        for e in self.battery["surveys"]:
            for x in e["sources"]:
                self.assertTrue(x["hypotheses"])

    def test_prompt_shows_instructions_and_scale_once(self):
        s = survey_engine.validate_schema(next(x for x in self.high["custom_surveys"] if x["id"] == "b_p001_s1_v1"))
        text = survey_engine.question_prompt_lines(s)
        self.assertTrue(text.startswith("问卷原文说明：\nInstructions: How often does your supervisor"))
        self.assertIn("Response scale: 5-point, 1 = I cannot remember", text)
        self.assertIn("- i1：Ridicules me 请给出 1 到 5 之间的整数。", text)
        self.assertIn("for another reason", text)
        self.assertEqual(text.count("I cannot remember"), 1)

    def test_hours_become_number_questions(self):
        s = next(x for x in self.high["custom_surveys"] if x["id"] == "b_p302_s1_v3")
        q = s["questions"][0]
        self.assertEqual((q["type"], q["min"], q["max"]), ("number", 0, 24))
        schema = survey_engine.validate_schema(s)
        self.assertIn("请给出 0 到 24 之间的一个数字（单位：小时）", survey_engine.question_prompt_lines(schema))
        ok = survey_engine.parse_answers('{"i1": 1.5}', schema)
        self.assertEqual((ok["i1"], ok["_quality"]["status"]), (1.5, "valid"))
        self.assertIsNone(survey_engine.parse_answers('{"i1": 30}', schema)["i1"])

    def test_world_check_passes(self):
        from modules.research import world_check
        payload = dict(self.high, name="battery-check")
        report, config = world_check.preview_payload(payload)
        self.assertEqual(report["errors"], [])
        self.assertEqual(report["warnings"], [])
        self.assertTrue(any("instructions" in s for s in config["custom_surveys"]))


class BatteryParsingTests(unittest.TestCase):
    def test_parse_scale(self):
        self.assertEqual(battery.parse_scale("5-point, 1 = strongly disagree, 5 = strongly agree"),
                         (1, 5, "strongly disagree", "strongly agree"))
        self.assertEqual(battery.parse_scale("4-point, 0 = never, 1 = seldom, 2 = sometimes, 3 = often"),
                         (0, 3, "never", "often"))
        self.assertEqual(battery.parse_scale("10-point, 1 = never, 10 = frequently, if not always"),
                         (1, 10, "never", "frequently, if not always"))
        self.assertEqual(battery.parse_scale(
            "7-point scale, 1 = extremely unlikely, 7 = extremely likely; middle point unanchored"),
            (1, 7, "extremely unlikely", "extremely likely"))

    def test_window_rewrite(self):
        text = "Instructions: How often has each of the following applied to you? Think about the past month."
        self.assertEqual(battery._rewrite_window(text, final=False)[0],
                         "Instructions: How often has each of the following applied to you? Think about the past few days.")
        self.assertEqual(battery._rewrite_window("In the past few months, how often have you ...", True)[0],
                         "In the past week, how often have you ...")
        self.assertEqual(battery._rewrite_window("Think about the past seven days.", True), ("Think about the past seven days.", False))
        self.assertEqual(battery._rewrite_window("Think about today.", True), ("Think about today.", False))

    def test_timing(self):
        study = [{"测量时点": "T1"}, {"测量时点": "T2 (+6 months)"}, {"测量时点": "T3 (+1 month)"}]
        self.assertEqual(battery.plan_timing(study[0], study)[1:3], ("21:00", [3]))
        self.assertEqual(battery.plan_timing(study[1], study)[2], [4])
        self.assertEqual(battery.plan_timing(study[2], study)[2:], (["last"], True))
        six = [{"测量时点": "T{} (monthly)".format(i)} for i in range(1, 7)]
        self.assertEqual(battery.plan_timing(six[0], six)[1:3], ("08:00", [1]))
        self.assertEqual(battery.plan_timing(six[5], six)[1:3], ("21:00", ["last"]))
        self.assertEqual(battery.plan_timing({"测量时点": "single survey"}, [])[2], ["last"])
        self.assertEqual(battery.plan_timing({"测量时点": "post-manipulation"}, [])[2], ["last"])
        self.assertEqual(battery.plan_timing({"测量时点": "T0"}, [])[1:3], ("08:00", [1]))
        self.assertEqual(battery.plan_timing({"测量时点": "daily afternoon, Day t"}, [])[1:3], ("17:00", []))
        self.assertEqual(battery.plan_timing({"测量时点": "daily noon, Day t"}, [])[1:3], ("12:00", []))
        self.assertEqual(battery.plan_timing({"测量时点": "Day t+1 morning, 11 a.m."}, [])[1:3], ("08:00", [2, 3, 4, "last"]))

    def test_persona_templates_run_five_workdays(self):
        for name in ("人设操纵-高辱虐组", "人设操纵-低辱虐组"):
            payload = load(name)
            self.assertEqual((payload["start_time"], payload["step"], payload["stride"]), ("20240212-08:00", 120, 60))
            self.assertFalse(payload.get("scheduled_events"))


if __name__ == "__main__":
    unittest.main()


class CompactPersonalityTests(unittest.TestCase):
    def test_bfi10_style_is_default_and_short(self):
        from modules import personality
        import server
        payload = load("人设操纵-高辱虐组")
        payload.update(name="v24-bfi10", seed=2)
        cfg = server.build_experiment_config(payload)[2]
        self.assertEqual(cfg["personality"]["style"], "bfi10")
        for name, profile in cfg["personality"]["profiles"].items():
            text = cfg["agents"][name]["scratch"]["innate"]
            self.assertEqual(text, profile["text"])
            self.assertLess(len(text), 90)
            self.assertEqual(text.count("；"), 4)
            self.assertNotIn("既不", text)

    def test_same_respondents_in_both_styles(self):
        from modules import personality
        agents = ["阿伊莎", "克劳斯", "玛丽亚", "沃尔夫冈"]
        a = personality.sample_profiles(agents, 5, style="bfi10")
        b = personality.sample_profiles(agents, 5, style="markers")
        self.assertEqual({k: v["source_row"] for k, v in a.items()}, {k: v["source_row"] for k, v in b.items()})

    def test_bfi10_levels(self):
        from modules import personality
        self.assertEqual(personality.describe_domain_bfi10("extraversion", 9), "极其外向合群、不拘谨")
        self.assertEqual(personality.describe_domain_bfi10("agreeableness", 1), "极其多疑、爱挑剔别人")
        self.assertEqual(personality.describe_domain_bfi10("openness", 5), "想象力和艺术兴趣一般")
        self.assertTrue(personality.describe_domain_bfi10("neuroticism", 3).startswith("比较放松"))


class MarketingSettingTests(unittest.TestCase):
    def test_leadership_style_is_the_only_difference(self):
        from modules.research import world_check
        personas = {}
        for name in ("人设操纵-高辱虐组", "人设操纵-低辱虐组"):
            report, _ = world_check.preview_payload(dict(load(name), seed=3))
            self.assertEqual(report["errors"], [])
            personas[name] = report["personas"]
        high, low = personas["人设操纵-高辱虐组"], personas["人设操纵-低辱虐组"]
        self.assertIn("【领导风格】：克劳斯带组多年，形成了一套固定的说话和做事习惯，对组员一直是这样，并不只在组员出错的时候。", high["克劳斯"])
        self.assertIn("【领导风格】：克劳斯带组多年，形成了一套固定的说话和做事习惯，对组员一直是这样。他对工作标准要求很高", low["克劳斯"])
        for agent in ("阿伊莎", "玛丽亚", "沃尔夫冈"):
            self.assertEqual(high[agent], low[agent])
            self.assertIn("市场运营部", high[agent])
            self.assertNotIn("院长", high[agent])


class WorldRulesTests(unittest.TestCase):
    def test_rules_reach_every_persona_in_both_conditions(self):
        from modules.research import world_check
        rules = load("人设操纵-高辱虐组")["world_rules"]
        self.assertEqual(rules, load("人设操纵-低辱虐组")["world_rules"])
        self.assertTrue(rules.startswith("1. 【工作时间】："))
        report, config = world_check.preview_payload(dict(load("人设操纵-高辱虐组"), seed=2))
        self.assertEqual(report["errors"], [])
        for name, text in report["personas"].items():
            self.assertIn("【世界规则】：\n1. 【工作时间】", text)
            self.assertLess(text.index("【固定背景】"), text.index("【世界规则】"))
            self.assertEqual(config["agents"][name]["scratch"]["world_rules"], rules)
        self.assertLess(report["personas"]["克劳斯"].index("【世界规则】"), report["personas"]["克劳斯"].index("【领导风格】"))

    def test_prompt_fixed_block_matches_preview(self):
        from modules.prompt.scratch import Scratch
        scratch = Scratch("阿伊莎", "", {"background": "甲", "world_rules": "1. 【请假】：可以请假。"})
        self.assertEqual(scratch.fixed_block(), "【固定背景】：甲\n【世界规则】：\n1. 【请假】：可以请假。")

    def test_rules_are_checked_for_banned_words(self):
        from modules.research import world_check
        report, _ = world_check.preview_payload(dict(load("人设操纵-高辱虐组"), world_rules="这是一个模拟世界。"))
        self.assertTrue(any("模拟" in e for e in report["errors"]))
