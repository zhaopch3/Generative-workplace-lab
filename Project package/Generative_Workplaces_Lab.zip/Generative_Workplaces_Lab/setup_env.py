# -*- coding: utf-8 -*-
"""Environment installer for first-time users.

Creates .venv in this folder, installs requirements.txt (optionally from a
mirror in mainland China), checks the imports and, if Ollama is installed,
offers to download the local embedding model.  Never asks for or writes API
keys: those are entered later in the web page (Experiments & archive → API settings).
Messages follow the system language (Chinese or English); SIM_LANG=zh or SIM_LANG=en chooses.

Windows: double-click Install.bat.   macOS / Linux: bash install.sh
Options: --yes (accept defaults, no questions)  --mirror / --no-mirror
         --recreate (delete and rebuild .venv)   --from-launcher
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
REQUIREMENTS = ROOT / "requirements.txt"
MIRROR = "https://pypi.tuna.tsinghua.edu.cn/simple"
OFFICIAL = "https://pypi.org/simple"
CHECK_IMPORTS = ("flask", "openai", "llama_index.core", "numpy", "pandas", "scipy",
                 "statsmodels", "openpyxl", "PIL", "dotenv", "requests")
EMBED_MODEL = "bge-m3"
SUPPORTED = ((3, 10), (3, 13))
WINDOWS = os.name == "nt"


def _console_is_zh():
    """Chinese console messages on a Chinese system, English otherwise (V27.2)."""
    choice = os.environ.get("SIM_LANG", "").strip().lower()
    if choice in ("zh", "en"):
        return choice == "zh"
    if WINDOWS:
        try:
            import ctypes
            return (ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF) == 0x04
        except Exception:
            return False
    for key in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        if os.environ.get(key):
            return os.environ[key].lower().startswith("zh")
    return False


ZH = _console_is_zh()


def T(zh, en):
    return zh if ZH else en


def say(text=""):
    print(text, flush=True)


def step(n, text):
    say()
    say("[%d/5] %s" % (n, text))


def ask(question, default, assume_yes):
    """Yes/no question; Enter takes the default."""
    if assume_yes or not sys.stdin or not sys.stdin.isatty():
        return default
    hint = "[Y/n]" if default else "[y/N]"
    try:
        answer = input("%s %s " % (question, hint)).strip().lower()
    except EOFError:
        return default
    if not answer:
        return default
    return answer in ("y", "yes", "是", "好", "要")


def venv_python():
    return VENV / ("Scripts/python.exe" if WINDOWS else "bin/python")


def run(cmd, **kw):
    say("  > " + " ".join(str(c) for c in cmd))
    return subprocess.call([str(c) for c in cmd], **kw)


def pypi_is_slow():
    """True when pypi.org is unreachable or slow (common in mainland China)."""
    start = time.time()
    try:
        urllib.request.urlopen(OFFICIAL + "/pip/", timeout=4).read(2048)
    except Exception:
        return True
    return time.time() - start > 2.5


def check_python():
    version = sys.version_info[:2]
    say(T("Python %d.%d：%s", "Python %d.%d: %s") % (version[0], version[1], sys.executable))
    if version < SUPPORTED[0]:
        say(T("这个 Python 太旧，需要 3.10–3.12（推荐 3.11）。请先安装新版 Python 再运行本程序。",
              "This Python is too old: 3.10–3.12 is needed (3.11 recommended). Install a newer Python and run this again."))
        return False
    if version > SUPPORTED[1]:
        say(T("提示：这个 Python 比测试过的版本新（推荐 3.11），安装可能失败；失败时请改装 Python 3.11。",
              "Note: this Python is newer than the tested versions (3.11 recommended). If installation fails, install Python 3.11."))
    return True


def make_venv(recreate):
    py = venv_python()
    if recreate and VENV.exists():
        say(T("删除旧的 .venv ……", "Deleting the old .venv ..."))
        shutil.rmtree(VENV, ignore_errors=True)
    if py.exists():
        ok = subprocess.call([str(py), "-c", "import sys; sys.exit(0 if sys.version_info[:2] >= (3, 10) else 1)"]) == 0
        if ok:
            say(T("已有虚拟环境 .venv，直接使用。", "Using the existing virtual environment .venv."))
            return True
        say(T("已有的 .venv 不可用（Python 版本过旧或已损坏），重新创建。", "The existing .venv is unusable (old Python or damaged); recreating it."))
        shutil.rmtree(VENV, ignore_errors=True)
    say(T("创建虚拟环境 .venv（只在本文件夹内，不影响电脑上的其他 Python）……",
          "Creating the virtual environment .venv (inside this folder only; other Python installations are not touched) ..."))
    if run([sys.executable, "-m", "venv", VENV]) != 0 or not py.exists():
        say(T("创建失败。", "Could not create it."))
        if not WINDOWS:
            say(T("Debian/Ubuntu 请先运行：sudo apt install python3-venv（或 python3.11-venv），再重新运行 bash install.sh。",
                  "On Debian/Ubuntu run  sudo apt install python3-venv  (or python3.11-venv) first, then run bash install.sh again."))
        return False
    return True


def pip_install(use_mirror):
    py = venv_python()
    order = [MIRROR, OFFICIAL] if use_mirror else [OFFICIAL, MIRROR]
    for index in order:
        say(T("使用软件源：%s", "Package index: %s") % index)
        base = [py, "-m", "pip", "install", "--disable-pip-version-check", "-i", index]
        if index == MIRROR:
            base += ["--trusted-host", "pypi.tuna.tsinghua.edu.cn"]
        run(base + ["--upgrade", "pip"])
        if run(base + ["-r", REQUIREMENTS]) == 0:
            return True
        say(T("这个软件源安装失败，换另一个再试一次……", "Installation from this index failed; trying the other one ..."))
    return False


def verify():
    code = ("import importlib, sys\n"
            "bad = []\n"
            "for n in %r:\n"
            "    try: importlib.import_module(n)\n"
            "    except Exception as e: bad.append('%%s (%%s)' %% (n, e))\n"
            "print('\\n'.join(bad)); sys.exit(1 if bad else 0)\n") % (CHECK_IMPORTS,)
    result = subprocess.run([str(venv_python()), "-c", code], capture_output=True, text=True)
    if result.returncode == 0:
        say(T("全部依赖可以正常导入。", "All dependencies import correctly."))
        return True
    say(T("以下依赖无法导入：", "These dependencies cannot be imported:"))
    say(result.stdout.strip() or result.stderr.strip())
    return False


def ollama_models():
    """List of local Ollama model names, or None when Ollama is not running."""
    try:
        with urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=2) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return [m.get("name", "") for m in data.get("models", [])]
    except Exception:
        return None


def check_ollama(assume_yes):
    say(T("记忆嵌入模型可以用云端服务（填 API key 即可），也可以用本地 Ollama（免费、不联网）。这一步是可选的。",
          "The memory embedding model can be a cloud service (just enter an API key) or local Ollama (free, offline). This step is optional."))
    models = ollama_models()
    exe = shutil.which("ollama")
    if models is None and not exe:
        say(T("没有检测到 Ollama。想用本地嵌入时，从 https://ollama.com/download 安装，然后在命令行运行：ollama pull %s",
              "Ollama not found. For local embeddings, install it from https://ollama.com/download and run: ollama pull %s") % EMBED_MODEL)
        return
    if models is not None and any(m.split(":")[0] == EMBED_MODEL for m in models):
        say(T("Ollama 已有本地嵌入模型 %s:latest。在 API 设置里选“本地 Ollama”即可。",
              "Ollama already has the local embedding model %s:latest. Choose local Ollama in the API settings.") % EMBED_MODEL)
        return
    if not exe:
        say(T("Ollama 正在运行，但没有找到 ollama 命令。请在命令行运行：ollama pull %s",
              "Ollama is running but the ollama command was not found. Run: ollama pull %s") % EMBED_MODEL)
        return
    if ask(T("Ollama 已安装，但还没有本地嵌入模型 %s（约 1.2 GB）。现在下载吗？",
             "Ollama is installed but has no local embedding model %s (about 1.2 GB). Download it now?") % EMBED_MODEL, False, assume_yes):
        if run([exe, "pull", EMBED_MODEL]) != 0:
            say(T("下载失败。可以之后在命令行运行：ollama pull %s", "Download failed. You can run it later: ollama pull %s") % EMBED_MODEL)
    else:
        say(T("跳过。需要时在命令行运行：ollama pull %s", "Skipped. When needed, run: ollama pull %s") % EMBED_MODEL)


def main():
    parser = argparse.ArgumentParser(description=T("安装运行环境", "Install the runtime environment"))
    parser.add_argument("--yes", action="store_true", help=T("全部采用默认选项，不提问", "accept all defaults without asking"))
    parser.add_argument("--mirror", action="store_true", help=T("使用清华镜像", "use the Tsinghua mirror"))
    parser.add_argument("--no-mirror", action="store_true", help=T("使用官方源", "use the official index"))
    parser.add_argument("--recreate", action="store_true", help=T("删除并重建 .venv", "delete and rebuild .venv"))
    parser.add_argument("--from-launcher", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()

    say("=" * 60)
    say(T("职场模拟实验室：安装运行环境", "Workplace Simulation Lab: installing the environment"))
    say(T("安装位置：%s", "Location: %s") % ROOT)
    say(T("所有内容只装在本文件夹的 .venv 中；删除这个文件夹即可完全卸载。",
          "Everything goes into .venv inside this folder; deleting the folder uninstalls it completely."))
    say("=" * 60)

    step(1, T("检查 Python", "Checking Python"))
    if not check_python():
        return 1
    if not REQUIREMENTS.exists():
        say(T("找不到 requirements.txt，请确认本文件在项目根目录（能看到 launch.py 的那一层）。",
              "requirements.txt not found. Make sure this file is in the project root (next to launch.py)."))
        return 1

    step(2, T("创建虚拟环境", "Creating the virtual environment"))
    if not make_venv(args.recreate):
        return 1

    step(3, T("安装依赖（第一次约需 3–10 分钟，取决于网速）", "Installing dependencies (3–10 minutes the first time, depending on the network)"))
    if args.mirror or args.no_mirror:
        use_mirror = args.mirror
    else:
        slow = pypi_is_slow()
        if slow:
            say(T("连接官方软件源 pypi.org 较慢或不通（在中国大陆常见）。", "The official index pypi.org is slow or unreachable (common in mainland China)."))
        use_mirror = ask(T("使用清华大学镜像下载（中国大陆推荐）？", "Download from the Tsinghua University mirror (recommended in mainland China)?"), slow, args.yes)
    if not pip_install(use_mirror):
        say(T("依赖安装失败。请检查网络后重新运行本程序；如使用代理，请先在系统中打开代理。",
              "Dependency installation failed. Check the network and run this again; if you use a proxy, turn it on in the system first."))
        return 1

    step(4, T("检查依赖", "Checking dependencies"))
    if not verify():
        say(T("可以加 --recreate 重新运行，删除并重建虚拟环境。", "Run again with --recreate to delete and rebuild the virtual environment."))
        return 1

    step(5, T("本地嵌入模型（可选）", "Local embedding model (optional)"))
    check_ollama(args.yes)

    say()
    say("=" * 60)
    say(T("安装完成。", "Installation complete."))
    if args.from_launcher:
        say(T("接下来会自动启动程序。", "The program starts next."))
    elif WINDOWS:
        say(T("以后双击 Start.bat 启动。", "From now on, double-click Start.bat to start."))
    else:
        say(T("以后运行  .venv/bin/python launch.py  启动。", "From now on, run  .venv/bin/python launch.py  to start."))
    say(T("第一次打开网页后，在“实验与存档 → ⚙ API 设置”中填写 API key（只保存在本机的 .env 文件中）。",
          "When the page first opens, enter your API key under Experiments & archive → ⚙ API settings (it is kept only in the local .env file)."))
    say("=" * 60)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        say(T("\n已取消。", "\nCancelled."))
        sys.exit(1)
