# Ollama: local models

## Install

Download Ollama from https://ollama.com/ and install it with the default options.

## Download models

Pull the models from a terminal. The embedding model used for memories in this project is `bge-m3`. A local chat model can be pulled the same way, for example `qwen3:8b-q4_K_M`:

```
ollama pull bge-m3:latest
ollama pull qwen3:8b-q4_K_M
```

*An 8B chat model needs an Apple-silicon Mac with at least 16 GB of memory, or an NVIDIA RTX 30/40-series card with at least 12 GB of video memory. With 24 GB or more, larger quantized models can be used.*

## Run

Start the service by opening the Ollama app, or from the command line:

```
ollama serve
```

*The service listens on port 11434 by default.*

## Configure

### Allow API access

On Windows, set these system environment variables before starting the service, otherwise API calls return error 403:

```
OLLAMA_HOST=0.0.0.0
OLLAMA_ORIGINS=*
```

To set them: right-click “This PC” → Properties → Advanced system settings → Environment Variables → System variables → New. Enter `OLLAMA_HOST` as the variable name and `0.0.0.0` as the value, and do the same for the other variable.

On macOS:

```
launchctl setenv OLLAMA_HOST "0.0.0.0"
launchctl setenv OLLAMA_ORIGINS "*"
```

## Other useful settings

1. Allow access from other machines:
   ```
   OLLAMA_HOST=0.0.0.0
   ```
2. Store models somewhere other than drive C on Windows:
   ```
   OLLAMA_MODELS=E:\OllamaModels
   ```
3. Keep a model in memory for 2 hours (the default is 5 minutes before it is unloaded):
   ```
   OLLAMA_KEEP_ALIVE=2h
   ```
4. Change the port:
   ```
   OLLAMA_HOST=0.0.0.0:11434
   ```
5. Serve several requests at once:
   ```
   OLLAMA_NUM_PARALLEL=2
   ```
6. Keep several models loaded at once:
   ```
   OLLAMA_MAX_LOADED_MODELS=2
   ```
