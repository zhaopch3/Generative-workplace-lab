# -*- coding: utf-8 -*-
"""面向研究者的一键导出。

原始 JSONL 仍是系统内部的审计数据；本模块把不同产出整理为稳定、可直接进入
SPSS/R/Python 的分析表。问卷主表采用类似 Qualtrics 的宽表：同一智能体在同一
时间点填写的多份问卷合并为一行，题目列以 ``问卷ID__题目ID`` 命名。
"""
import csv
import io
import json
import os
import zipfile


RESULTS_ROOT = "results"
RESPONSE_META = (
    "batch_id", "run_id", "group", "condition", "replicate",
    "survey_date", "survey_time", "agent", "role", "ratee", "survey_ids",
)
PRIMARY_TABLES = (
    "responses.csv", "psych_timeseries.csv", "behavior_agent_daily.csv",
    "behavior_dyad_daily.csv", "interventions.csv", "experiment_manifest.csv",
    "codebook.csv", "personality.csv", "conversations.csv",
)


def _read_jsonl(path):
    rows = []
    if not os.path.exists(path):
        return rows
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                # 保留其余有效数据；损坏行仍可在原始JSONL中排查。
                continue
    return rows


def _scalar(value):
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return value


def csv_bytes(rows, first_fields=()):
    """把字典行输出为带 UTF-8 BOM 的 CSV，保证 Excel 直接打开中文正常。"""
    rows = list(rows or [])
    fields = list(first_fields)
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    buf = io.StringIO(newline="")
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({k: _scalar(v) for k, v in row.items()})
    return ("\ufeff" + buf.getvalue()).encode("utf-8")


def _survey_files(run_id):
    folder = os.path.join(RESULTS_ROOT, "surveys", run_id)
    if not os.path.isdir(folder):
        return []
    return [
        os.path.join(folder, fn)
        for fn in sorted(os.listdir(folder))
        if fn.endswith(".jsonl")
    ]


def build_responses(run_metas):
    """生成问卷宽表；run_metas 是含 name/condition 等字段的列表。"""
    grouped = {}
    meta_by_name = {r["name"]: r for r in run_metas}
    fixed = {
        "survey_id", "run_id", "condition", "survey_date", "survey_time",
        "agent", "role", "ratee", "rater",
    }
    for run in run_metas:
        run_id = run["name"]
        for path in _survey_files(run_id):
            fallback_sid = os.path.basename(path)
            if fallback_sid == "daily_survey.jsonl":
                fallback_sid = "daily_survey"
            elif fallback_sid.startswith("custom_"):
                fallback_sid = fallback_sid[len("custom_"):-len(".jsonl")]
            else:
                fallback_sid = fallback_sid[:-len(".jsonl")]
            for raw in _read_jsonl(path):
                sid = str(raw.get("survey_id") or fallback_sid)
                agent = raw.get("agent") or raw.get("rater") or ""
                ratee = raw.get("ratee") or ""
                condition = raw.get("condition") or run.get("condition") or ""
                if str(condition).lower() in ("unknown", "none", "无"):
                    condition = run.get("condition") or condition
                key = (
                    run_id, raw.get("survey_date", ""), raw.get("survey_time", ""),
                    agent, ratee,
                )
                row = grouped.setdefault(key, {
                    "batch_id": run.get("batch_id", ""),
                    "run_id": run_id,
                    "group": run.get("group", ""),
                    "condition": condition,
                    "replicate": run.get("replicate", ""),
                    "survey_date": raw.get("survey_date", ""),
                    "survey_time": raw.get("survey_time", ""),
                    "agent": agent,
                    "role": raw.get("role", ""),
                    "ratee": ratee,
                    "_survey_ids": [],
                })
                if sid not in row["_survey_ids"]:
                    row["_survey_ids"].append(sid)
                if not row.get("role") and raw.get("role"):
                    row["role"] = raw["role"]
                for field, value in raw.items():
                    if field in fixed:
                        continue
                    row[f"{sid}__{field}"] = value
    rows = []
    for row in grouped.values():
        row["survey_ids"] = "|".join(row.pop("_survey_ids"))
        rows.append(row)
    rows.sort(key=lambda r: (
        r.get("run_id", ""), r.get("survey_time", ""),
        r.get("agent", ""), r.get("ratee", ""),
    ))
    return rows


def _latest_checkpoint(run_id):
    folder = os.path.join(RESULTS_ROOT, "checkpoints", run_id)
    if not os.path.isdir(folder):
        return {}
    files = sorted(
        fn for fn in os.listdir(folder)
        if fn.startswith("simulate-") and fn.endswith(".json")
    )
    if not files:
        return {}
    try:
        with open(os.path.join(folder, files[-1]), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def build_codebook(run_metas):
    seen = set()
    rows = []
    for run in run_metas:
        cfg = _latest_checkpoint(run["name"])
        for schema in cfg.get("custom_surveys") or []:
            sid = schema.get("id", "")
            for question in schema.get("questions") or []:
                qid = question.get("id", "")
                column = f"{sid}__{qid}"
                if column in seen:
                    continue
                seen.add(column)
                rows.append({
                    "column": column,
                    "survey_id": sid,
                    "survey_title": schema.get("title", sid),
                    "question_id": qid,
                    "question_text": question.get("text", ""),
                    "type": question.get("type", ""),
                    "min": question.get("min", ""),
                    "max": question.get("max", ""),
                    "options": "|".join(question.get("options") or []),
                })
    return rows


def _rows_with_run_meta(kind, filename, run_metas):
    rows = []
    for run in run_metas:
        path = os.path.join(RESULTS_ROOT, kind, run["name"], filename)
        for row in _read_jsonl(path):
            out = {
                "batch_id": run.get("batch_id", ""),
                "run_id": run["name"],
                "group": run.get("group", ""),
                "condition": run.get("condition", ""),
                "replicate": run.get("replicate", ""),
            }
            out.update(row)
            rows.append(out)
    return rows


def build_behavior(run_metas):
    from modules import behavior
    daily_rows, dyad_rows = [], []
    for run in run_metas:
        try:
            daily, dyad, _ = behavior.compute(run["name"])
        except Exception:  # 单个世界行为数据不足不应阻断整个导出
            continue
        prefix = {
            "batch_id": run.get("batch_id", ""),
            "run_id": run["name"],
            "group": run.get("group", ""),
            "condition": run.get("condition", ""),
            "replicate": run.get("replicate", ""),
        }
        for row in daily:
            daily_rows.append(dict(prefix, **row))
        for row in dyad:
            dyad_rows.append(dict(prefix, **row))
    return daily_rows, dyad_rows


def analysis_tables(run_metas):
    daily, dyad = build_behavior(run_metas)
    manifest_rows = []
    for run in run_metas:
        cfg = _latest_checkpoint(run["name"])
        manifest_rows.append({
            "batch_id": run.get("batch_id", ""),
            "run_id": run["name"],
            "group": run.get("group", ""),
            "condition": run.get("condition", ""),
            "replicate": run.get("replicate", ""),
            "step": cfg.get("step", 0),
            "sim_time": cfg.get("time", ""),
            "stride": cfg.get("stride", ""),
            "agents": "|".join((cfg.get("agents") or {}).keys()),
            "base_model": (cfg.get("model_assignment") or {}).get("base", ""),
            "language": cfg.get("language", "zh"),   # V27: simulation language
        })
    return {
        "responses.csv": (build_responses(run_metas), RESPONSE_META),
        "psych_timeseries.csv": (
            _rows_with_run_meta("psych", "psych.jsonl", run_metas),
            ("batch_id", "run_id", "group", "condition", "replicate", "step", "sim_time", "agent"),
        ),
        "behavior_agent_daily.csv": (
            daily, ("batch_id", "run_id", "group", "condition", "replicate"),
        ),
        "behavior_dyad_daily.csv": (
            dyad, ("batch_id", "run_id", "group", "condition", "replicate"),
        ),
        "interventions.csv": (
            _rows_with_run_meta("interventions", "interventions.jsonl", run_metas),
            ("batch_id", "run_id", "group", "condition", "replicate", "step", "sim_time"),
        ),
        "experiment_manifest.csv": (
            manifest_rows, ("batch_id", "run_id", "group", "condition", "replicate"),
        ),
        "codebook.csv": (
            build_codebook(run_metas), ("column", "survey_id", "survey_title", "question_id"),
        ),
        "personality.csv": (
            build_personality(run_metas), ("batch_id", "run_id", "group", "condition", "replicate", "agent"),
        ),
        "conversations.csv": (
            build_conversation_meta(run_metas),
            ("batch_id", "run_id", "group", "condition", "replicate", "step", "sim_time", "agent", "partner"),
        ),
    }


def _run_meta_fields(run):
    return {
        "batch_id": run.get("batch_id", ""), "run_id": run["name"], "group": run.get("group", ""),
        "condition": run.get("condition", ""), "replicate": run.get("replicate", ""),
    }


def build_personality(run_metas):
    """V23: sampled Big Five profile per agent (scores 1-5, percentiles, 9 levels)."""
    rows = []
    for run in run_metas:
        cfg = _latest_checkpoint(run["name"])
        info = cfg.get("personality") or {}
        for agent, profile in sorted((info.get("profiles") or {}).items()):
            row = {**_run_meta_fields(run), "agent": agent,
                   "personality_seed": info.get("seed", ""), "source_row": profile.get("source_row", "")}
            for key, prefix in (("scores_1to5", "score_"), ("percentiles", "pct_"), ("levels_1to9", "level_")):
                for domain, value in (profile.get(key) or {}).items():
                    row[prefix + domain] = value
            rows.append(row)
    return rows


def build_conversation_meta(run_metas):
    """V23: one row per conversation - rounds, who ended it, whether it hit the cap."""
    rows = []
    for run in run_metas:
        path = os.path.join(RESULTS_ROOT, "monitor", run["name"], "chat_meta.jsonl")
        for item in _read_jsonl(path):
            rows.append({**_run_meta_fields(run), **item})
    return rows


def bundle_bytes(run_metas):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for filename, (rows, first_fields) in analysis_tables(run_metas).items():
            zf.writestr(filename, csv_bytes(rows, first_fields))
    buf.seek(0)
    return buf


def write_analysis_tables(out_dir, run_metas):
    os.makedirs(out_dir, exist_ok=True)
    files = []
    for filename, (rows, first_fields) in analysis_tables(run_metas).items():
        path = os.path.join(out_dir, filename)
        with open(path, "wb") as f:
            f.write(csv_bytes(rows, first_fields))
        files.append(filename)
    return files
