# -*- coding: utf-8 -*-
"""通用问卷引擎（阶段三问卷泛化的核心）

研究者用JSON schema定义问卷（李克特/单选/多选/开放题 + 触发时间），
引擎负责：schema校验、提示词题目文本生成、LLM回答解析与值域校验、
离线failsafe（中性默认答案）。

schema 示例：
{
  "id": "daily_wellbeing",
  "title": "每日身心状态问卷",
  "trigger_time": "21:30",
  "targets": [],                       # 空 = 全体
  "enabled": true,
  "include_reason": true,              # 末尾自动附加一道"评分原因"开放题
  "questions": [
    {"id": "stress", "text": "今天你的工作压力有多大？", "type": "likert",
     "min": 1, "max": 7, "min_label": "完全没有压力", "max_label": "压力极大"},
    {"id": "mood", "text": "今天你的整体心情如何？", "type": "single_choice",
     "options": ["很差", "较差", "一般", "较好", "很好"]},
    {"id": "emotions", "text": "今天你经历了哪些情绪？", "type": "multi_choice",
     "options": ["喜悦", "愤怒", "焦虑", "悲伤", "平静", "兴奋"]},
    {"id": "highlight", "text": "今天印象最深的一件事是什么？", "type": "open"}
  ]
}
"""
import json
import re

VALID_TYPES = ("likert", "single_choice", "multi_choice", "open", "number")  # V24: number = a quantity such as hours

_ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,63}$")


class SchemaError(ValueError):
    pass


TIME_FRAMES = ("today", "recent", "week", "general")
MULTI_DAY_FRAMES = ("recent", "week", "general")


def resolve_days(days, last_day):
    """Map a schema's days (ints and "last") to simulation day numbers."""
    return sorted({last_day if str(d) == "last" else int(d) for d in (days or []) if str(d) != "last" or last_day})


def validate_schema(schema):
    """校验并归一化问卷schema，返回新dict；不合法时抛SchemaError。"""
    if not isinstance(schema, dict):
        raise SchemaError("问卷定义必须是JSON对象")
    out = {}
    sid = str(schema.get("id", "")).strip()
    if not _ID_RE.match(sid):
        raise SchemaError("问卷id必须是字母开头的英文标识符（字母/数字/下划线）")
    out["id"] = sid
    out["title"] = str(schema.get("title", sid)).strip() or sid
    trigger = str(schema.get("trigger_time", "22:00")).strip()
    if not re.match(r"^(?:[01]?\d|2[0-3]):[0-5]\d$", trigger):
        raise SchemaError("trigger_time 格式应为 HH:MM，例如 22:00")
    out["trigger_time"] = trigger
    targets = schema.get("targets") or []
    if not isinstance(targets, list):
        raise SchemaError("targets 必须是数组（空数组表示全体）")
    out["targets"] = [str(t) for t in targets]
    out["enabled"] = bool(schema.get("enabled", True))
    out["include_reason"] = bool(schema.get("include_reason", True))
    # V23: neutral title shown to agents (the researcher title stays in exports) and
    # the time frame the items refer to ("today" | "general").
    out["display_title"] = str(schema.get("display_title", "") or "").strip()
    frame = str(schema.get("time_frame", "today") or "today")
    # V24: recent = 这几天, week = 这一周
    if frame not in TIME_FRAMES:
        raise SchemaError("time_frame 只能是 " + "、".join(TIME_FRAMES))
    out["time_frame"] = frame
    if schema.get("source"):
        out["source"] = str(schema.get("source"))
    # V24: instructions and response scale printed above the items, as in the source questionnaire
    if str(schema.get("instructions", "") or "").strip():
        out["instructions"] = str(schema.get("instructions")).strip()
    # V24: present items in a random order per respondent and occasion (recorded in
    # _item_order); answers stay keyed by item id, so analysis is unaffected.
    out["randomize_items"] = bool(schema.get("randomize_items", False))
    days = schema.get("days") or []
    # V24: "last" = the last simulated day on which this survey's trigger time is reached
    try:
        numbers = sorted({int(d) for d in days if str(d) != "last"})
    except (TypeError, ValueError):
        raise SchemaError("days 必须是模拟日编号（正整数）或 last 组成的列表")
    if any(d < 1 for d in numbers):
        raise SchemaError("days 必须是正整数")
    out["days"] = numbers + (["last"] if any(str(d) == "last" for d in days) else [])

    # 评价模式：self=自评（默认）；dyadic=互评（评价者×被评者展开）
    mode = str(schema.get("mode", "self"))
    if mode not in ("self", "dyadic"):
        raise SchemaError("mode 只能是 self 或 dyadic")
    out["mode"] = mode
    if mode == "dyadic":
        raters = schema.get("raters") or []
        ratees = schema.get("ratees") or []
        if not isinstance(raters, list) or not isinstance(ratees, list):
            raise SchemaError("raters/ratees 必须是数组（空数组表示全体）")
        out["raters"] = [str(t) for t in raters]
        out["ratees"] = [str(t) for t in ratees]

    questions = schema.get("questions") or []
    if not questions:
        raise SchemaError("问卷至少需要一道题目")
    seen_ids = set()
    out_questions = []
    for idx, q in enumerate(questions):
        if not isinstance(q, dict):
            raise SchemaError(f"第{idx+1}题必须是对象")
        qid = str(q.get("id", "")).strip()
        if not _ID_RE.match(qid):
            raise SchemaError(f"第{idx+1}题：题目id必须是字母开头的英文标识符")
        if qid in seen_ids or qid == "reason":
            raise SchemaError(f"题目id重复或保留：{qid}")
        seen_ids.add(qid)
        qtype = str(q.get("type", "likert"))
        if qtype not in VALID_TYPES:
            raise SchemaError(f"题目 {qid}：不支持的题型 {qtype}")
        text = str(q.get("text", "")).strip()
        if not text:
            raise SchemaError(f"题目 {qid}：题干不能为空")
        nq = {"id": qid, "type": qtype, "text": text}
        nq["reverse"] = bool(q.get("reverse", False))
        if qtype == "likert":
            try:
                lo, hi = int(q.get("min", 1)), int(q.get("max", 7))
            except (TypeError, ValueError):
                raise SchemaError(f"题目 {qid}：min/max 必须是整数")
            if not (lo < hi and hi - lo <= 100):
                raise SchemaError(f"题目 {qid}：量表范围不合法")
            nq.update({
                "min": lo, "max": hi,
                "min_label": str(q.get("min_label", "")).strip(),
                "max_label": str(q.get("max_label", "")).strip(),
            })
        elif qtype == "number":
            try:
                lo, hi = float(q.get("min", 0)), float(q.get("max", 24))
            except (TypeError, ValueError):
                raise SchemaError(f"题目 {qid}：min/max 必须是数字")
            if not lo < hi:
                raise SchemaError(f"题目 {qid}：数值范围不合法")
            nq.update({"min": lo, "max": hi, "unit": str(q.get("unit", "")).strip()})
        elif qtype in ("single_choice", "multi_choice"):
            options = [str(o).strip() for o in (q.get("options") or []) if str(o).strip()]
            if len(options) < 2:
                raise SchemaError(f"题目 {qid}：选择题至少需要2个选项")
            nq["options"] = options
        out_questions.append(nq)
    out["questions"] = out_questions
    # 运行时状态字段（沿用legacy survey的设计）
    out["completed_dates"] = list(schema.get("completed_dates") or [])
    return out


def ordered_for_asking(schema, key):
    """V24: the schema as shown to one respondent on one occasion.

    With ``randomize_items`` the questions are shuffled with a seed derived from
    ``key`` (world, respondent, ratee, survey, time), so a rerun reproduces it.
    Returns (schema_to_ask, item_order or None).
    """
    if not schema.get("randomize_items") or len(schema.get("questions") or []) < 2:
        return schema, None
    import random
    questions = list(schema["questions"])
    random.Random("items|" + str(key)).shuffle(questions)
    asked = dict(schema)
    asked["questions"] = questions
    return asked, [q["id"] for q in questions]


def _L(zh, en):
    from modules.lang import L
    return L(zh, en)


def _fill_ratee(text, ratee):
    if ratee:
        return text.replace("{对象}", ratee).replace("{ratee}", ratee)
    return text


def question_prompt_lines(schema, ratee=None):
    """生成提示词中的题目说明文本。互评模式下用被评者姓名替换 {对象} 占位符。"""
    from modules.lang import L
    lines = []
    printed_scale = "Response scale" in str(schema.get("instructions", "") or "")
    if str(schema.get("instructions", "") or "").strip():
        lines.append(L("问卷原文说明：", "Original survey instructions:"))
        lines.extend(_fill_ratee(schema["instructions"], ratee).strip().split("\n"))
        lines.append("")
    for q in schema["questions"]:
        if q["type"] == "likert":
            anchor = ""
            if (q.get("min_label") or q.get("max_label")) and not printed_scale:
                anchor = L("（{}={}，{}={}）", " ({} = {}, {} = {})").format(
                    q["min"], q.get("min_label") or L("最低", "lowest"),
                    q["max"], q.get("max_label") or L("最高", "highest"),
                )
            lines.append(
                L("- {}：{} 请给出 {} 到 {} 之间的整数{}。", "- {}: {} Give a whole number from {} to {}{}.").format(
                    q["id"], _fill_ratee(q["text"], ratee), q["min"], q["max"], anchor
                )
            )
        elif q["type"] == "single_choice":
            lines.append(
                L("- {}：{} 请从以下选项中选择恰好一个（输出选项原文）：{}。",
                  "- {}: {} Choose exactly one of these options (write the option as given): {}.").format(
                    q["id"], _fill_ratee(q["text"], ratee), " / ".join(q["options"])
                )
            )
        elif q["type"] == "number":
            lines.append(
                L("- {}：{} 请给出 {:g} 到 {:g} 之间的一个数字{}（可以有小数）。",
                  "- {}: {} Give a number from {:g} to {:g}{} (decimals allowed).").format(
                    q["id"], _fill_ratee(q["text"], ratee), q["min"], q["max"],
                    L("（单位：{}）", " (unit: {})").format(q["unit"]) if q.get("unit") else "")
            )
        elif q["type"] == "multi_choice":
            lines.append(
                L("- {}：{} 请从以下选项中选择零个或多个，输出JSON字符串数组：{}。",
                  "- {}: {} Choose zero or more of these options and output a JSON array of strings: {}.").format(
                    q["id"], _fill_ratee(q["text"], ratee), " / ".join(q["options"])
                )
            )
        else:  # open
            lines.append(L("- {}：{} 请用一两句话作答（字符串）。", "- {}: {} Answer in one or two sentences (a string).").format(
                q["id"], _fill_ratee(q["text"], ratee)))
    if schema.get("include_reason", True):
        lines.append(L("- reason：用一句话说明我整体上为什么这样作答（字符串）。",
                       "- reason: one sentence on why I answered this way overall (a string)."))
    return "\n".join(lines)


def format_example(schema):
    """提示词中的输出格式示例。"""
    example = {}
    for q in schema["questions"]:
        if q["type"] == "likert":
            example[q["id"]] = (q["min"] + q["max"]) // 2
        elif q["type"] == "single_choice":
            example[q["id"]] = q["options"][0]
        elif q["type"] == "number":
            example[q["id"]] = 1
        elif q["type"] == "multi_choice":
            example[q["id"]] = q["options"][:1]
        else:
            example[q["id"]] = _L("……", "...")
    if schema.get("include_reason", True):
        example["reason"] = _L("……", "...")
    return json.dumps(example, ensure_ascii=False)


def failsafe_answers(schema):
    """Missing answers remain missing. Never manufacture research scores."""
    ans = {q["id"]: None for q in schema["questions"]}
    ans["_quality"] = {
        "version": 2, "status": "invalid", "source": "fallback",
        "items": {q["id"]: "missing" for q in schema["questions"]},
    }
    if schema.get("include_reason", True):
        ans["reason"] = _L("未获得有效回答；缺失值不参与研究计分。", "No valid answer; missing values are not scored.")
    return ans


def parse_answers(response, schema):
    """Validate every item; invalid values are missing with explicit provenance."""
    failsafe = failsafe_answers(schema)
    text = (response or "").strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if not match:
            return failsafe
        try:
            data = json.loads(match.group(0))
        except json.JSONDecodeError:
            return failsafe
    if not isinstance(data, dict):
        return failsafe

    out, validity = {}, {}
    for q in schema["questions"]:
        qid = q["id"]
        value = data.get(qid)
        valid = value is not None
        if q["type"] == "likert":
            try:
                numeric = float(value)
                valid = not isinstance(value, bool) and numeric.is_integer() and q["min"] <= numeric <= q["max"]
                value = int(numeric) if valid else None
            except (TypeError, ValueError):
                value, valid = None, False
        elif q["type"] == "number":
            try:
                numeric = float(value)
                valid = not isinstance(value, bool) and q["min"] <= numeric <= q["max"]
                value = (int(numeric) if numeric.is_integer() else numeric) if valid else None
            except (TypeError, ValueError):
                value, valid = None, False
        elif q["type"] == "single_choice":
            valid = isinstance(value, str) and value.strip() in q["options"]
            value = value.strip() if valid else None
        elif q["type"] == "multi_choice":
            valid = isinstance(value, list) and all(isinstance(v, str) and v in q["options"] for v in value)
            value = list(dict.fromkeys(value)) if valid else None
        else:
            valid = isinstance(value, str) and bool(value.strip())
            value = value.strip() if valid else None
        out[qid] = value
        validity[qid] = "valid" if valid else "missing_or_invalid"
    if schema.get("include_reason", True):
        out["reason"] = str(data.get("reason", failsafe.get("reason", "")))
    count = sum(v == "valid" for v in validity.values())
    out["_quality"] = {
        "version": 2, "status": "valid" if count == len(validity) else "partial" if count else "invalid",
        "source": "model", "items": validity,
    }
    return out


def csv_fieldnames(schema):
    """导出CSV的列顺序。自评：每行=一名智能体一次施测；互评：每行=一个评价对（agent=评价者，ratee=被评者）。"""
    meta = ["survey_id", "run_id", "condition", "survey_date", "survey_time", "agent"]
    if schema.get("mode") == "dyadic":
        meta.append("ratee")
    qids = [q["id"] for q in schema["questions"]]
    if schema.get("include_reason", True):
        qids.append("reason")
    return meta + qids + ["_quality", "_measurement_policy", "_context", "_item_order"]


def row_for_csv(row, schema):
    """多选题序列化为 'a|b|c' 便于统计软件处理。"""
    out = dict(row)
    if isinstance(out.get("_item_order"), list):
        out["_item_order"] = "|".join(out["_item_order"])
    for key in ("_quality", "_context"):
        if isinstance(out.get(key), dict):
            out[key] = json.dumps(out[key], ensure_ascii=False)
    for q in schema["questions"]:
        if q["type"] == "multi_choice" and isinstance(out.get(q["id"]), list):
            out[q["id"]] = "|".join(out[q["id"]])
    return out
