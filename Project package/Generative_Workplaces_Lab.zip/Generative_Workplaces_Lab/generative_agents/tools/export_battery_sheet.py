# -*- coding: utf-8 -*-
"""V24: export the installed replication battery as a reviewable workbook.

Run from generative_agents/ after tools/build_v24_battery.py:

    python tools/export_battery_sheet.py <编码总表_无损合并.xlsx> <复现问卷装入清单.xlsx>

One row per installed survey (all source variables listed in that row), plus the
variables that were not installed. The workbook is only read to show which item
texts were mechanically corrected (line-break hyphens, ligatures, a lost bracket).
"""
import json
import os
import re
import sys

sys.path.insert(0, os.getcwd())
sys.path.insert(0, os.path.join(os.getcwd(), "tools"))
import build_v24_battery as battery  # noqa: E402

RESPONDENT = {"阿伊莎": "员工", "玛丽亚": "员工", "沃尔夫冈": "员工", "克劳斯": "组长"}


def when(survey):
    days = survey["days"]
    if not days:
        text = "每天"
    else:
        parts = ["最后一天（第 {} 天）".format(battery.N_DAYS) if d == "last" else "第 {} 天".format(d) for d in days]
        text = "、".join(parts)
    return "{} {}".format(text, survey["trigger_time"])


def who(survey):
    if survey["mode"] == "self":
        roles = sorted({RESPONDENT.get(a, a) for a in survey["targets"]})
        return "、".join(roles) + "自评（{}）".format("、".join(survey["targets"]))
    raters = sorted({RESPONDENT.get(a, a) for a in survey["raters"]})
    return "{}评每名员工（{} → {}）".format("、".join(raters), "、".join(survey["raters"]), "、".join(survey["ratees"]))


def raw_items(rows):
    """(paper, study, var) -> {item number: raw text without options}"""
    out = {}
    for r in rows:
        text = r.get(battery.QUESTIONNAIRE)
        if not text:
            continue
        items = {}
        for line in str(text).split("\n"):
            m = re.match(r"^(\d+)\.\s+(.*)$", line.rstrip())
            if m:
                items[int(m.group(1))] = re.sub(r"\s*\[\[.*\]\]\s*$", "", m.group(2)).rstrip()
        out[(r.get("paper_id"), r.get("study_id"), r.get("var_id"))] = items
    return out


FRAME = {"today": "今天", "recent": "这几天", "week": "这一周", "general": "不限定"}


def main(workbook, out_path):
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    with open(battery.BATTERY_PATH, "r", encoding="utf-8") as handle:
        data = json.load(handle)
    raw = raw_items(battery.load_rows(workbook)[0])

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "装入的问卷"
    head = ["问卷编号", "来源变量（论文 研究 变量：原名）", "涉及假设", "统一构念", "原研究的评价者", "原测量时点",
            "复现用问卷状态", "量表名称", "问卷来源说明", "模拟中由谁填写", "模拟中施测时间", "时间框架", "题数",
            "指导语（原文）", "指导语与量表（模拟中使用）", "题目文字修正", "显示给智能体的标题"]
    ws.append(head)
    for entry in data["surveys"]:
        s, src = entry["survey"], entry["sources"]
        fixes = []
        first = src[0]
        items = raw.get((first["paper_id"], first["study_id"], first["var_id"]), {})
        for q in s["questions"]:
            number = int(q["id"][1:])
            before = items.get(number)
            if before is not None and before != q["text"]:
                fixes.append("第{}题：{} → {}".format(number, before, q["text"]))
        ws.append([
            s["id"],
            "\n".join("{} {} {}：{}".format(x["paper_id"], x["study_id"], x["var_id"], x["variable"]) for x in src),
            "\n".join("{} {}：{}".format(x["paper_id"], x["study_id"], "、".join(x.get("hypotheses") or [])) for x in src),
            "；".join(sorted({str(x["construct"]) for x in src})),
            "；".join(sorted({str(x["rater"]) for x in src})),
            "\n".join("{} {} {}：{}".format(x["paper_id"], x["study_id"], x["var_id"], x["timepoint"] or "未写") for x in src),
            "\n".join("{} {} {}：{}".format(x["paper_id"], x["study_id"], x["var_id"], x["grade"]) for x in src),
            "；".join(sorted({str(x["scale_name"]) for x in src})),
            "\n".join(sorted({str(x.get("questionnaire_source") or "") for x in src})),
            who(s), when(s), FRAME.get(s["time_frame"], s["time_frame"]), len(s["questions"]),
            entry["original_instructions"],
            s["instructions"] + ("\n（回顾时段已压缩）" if entry["window_rewritten"] else ""),
            "\n".join(fixes),
            s["display_title"],
        ])
    widths = [16, 38, 30, 22, 16, 22, 16, 34, 40, 26, 22, 10, 6, 46, 52, 40, 14]
    for i, w in enumerate(widths):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i + 1)].width = w
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="176C5B")
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    ws.freeze_panes = "B2"

    ws2 = wb.create_sheet("不纳入的假设")
    ws2.append(["论文", "研究", "假设", "原因"])
    for x in data.get("excluded_hypotheses") or []:
        ws2.append([x["paper_id"], x["study_id"], x["h_id"], x["reason"]])
    if not data.get("include_pending"):
        ws2.append(["", "", "实施决定为“待定”的 12 条", "工作—家庭类假设，暂不纳入（P038 因此整篇不在模拟中）"])
    for x in data["skipped"]:
        ws2.append([x["paper_id"], x["study_id"], x["var_id"], "变量未装入：" + x["reason"]])
    for cell in ws2[1]:
        cell.font = Font(bold=True)
    ws2.column_dimensions["C"].width = 30
    ws2.column_dimensions["D"].width = 60

    ws3 = wb.create_sheet("说明")
    papers = sorted({x["paper_id"] for e in data["surveys"] for x in e["sources"]})
    n_vars = sum(len(e["sources"]) for e in data["surveys"])
    notes = [
        "本表由项目中的 tools/export_battery_sheet.py 根据 data/scale_battery/battery_v1.json 生成；问卷由 tools/build_v24_battery.py 从编码总表“变量”表的“复现用问卷（本变量，直接使用）”列装入。",
        "装入范围（2026-10-27 决定）：“假设”表实施决定为“纳入”的假设，去掉 P211、P282 全部假设和 P056 的 H1、H3（需要部门经理，模拟中没有）；待定的 12 条工作—家庭假设不纳入。结果为 {} 篇论文、{} 个问卷变量（合并为 {} 份问卷）。由实验操纵或行为记录实现的变量不需要问卷，不在本表。".format(len(papers), n_vars, len(data["surveys"])),
        "编码总表更新后，在项目里依次重新运行这两个脚本即可重新装入并更新本表。",
        "模拟设计：5 个工作日（周一 08:00 至周五晚）。多波次研究：2 波在第 3、5 天；3 波在第 3、4、5 天；4 波在第 2–5 天；5 波在第 1–5 天晚上；6 波再加第 1 天早上。单次调查、实验操纵后测量、未写时点的在最后一天晚上；日记研究每天按原研究时段施测（报告前一晚活动的，从第 2 天起早上 08:00）。",
        "文字改动只有一类：指导语中的长回顾时段（past month、past year 等）改为 the past few days（最后一波之前）或 the past week（最后一波）。题目和刻度照抄。“以小时计”的题目按 0–24 的数字作答。",
        "题目在模拟中按人按次随机排序；不加“原因”题；智能体看到的标题只有“员工日记问卷”或“管理者日记问卷”。",
    ]
    for n in notes:
        ws3.append([n])
    ws3.column_dimensions["A"].width = 120
    for row in ws3.iter_rows():
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(out_path)
    print("surveys", len(data["surveys"]), "skipped", len(data["skipped"]), "->", out_path)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
