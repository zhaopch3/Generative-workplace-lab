"""Self-contained, verifiable end-of-step state packs for V21."""
import copy
import json
import os
import random
import shutil
import tempfile
import zipfile
from pathlib import Path
from .common import atomic_json, digest

FORMAT = 2


def tuples(value):
    return tuple(tuples(v) for v in value) if isinstance(value, list) else value


def restore_random(config):
    if config.get("_random_state"):
        random.setstate(tuples(config["_random_state"]))


def write_checkpoint(server, checkpoint_path, phase="end_of_step_after_measurement"):
    from start import sanitize_config_for_save
    # Freeze all agents after the entire ordered step, including interactions in
    # which a later actor has modified an earlier actor.
    for name, agent in server.game.agents.items():
        server.config["agents"][name].update(agent.to_dict())
        server.config["agents"][name]["coord"] = list(server.agent_status[name]["coord"])
    server.config["_random_state"] = random.getstate()
    server.config["_maze_config"] = server.game.maze.resolved_config
    server.config["_tile_events"] = [
        {"coord": list(tile.coord), "count": tile.event_cnt,
         "events": {key: event.to_dict() for key, event in tile.events.items()}}
        for row in server.game.maze.tiles for tile in row if tile.events or tile.event_cnt
    ]
    server.config["_engine"] = "v22.0"
    root = Path(server.checkpoints_folder)
    packs = root / "statepacks"
    packs.mkdir(exist_ok=True)
    stamp = Path(checkpoint_path).stem
    filename = stamp + ".zip"
    fd, temporary = tempfile.mkstemp(prefix=stamp, suffix=".tmp", dir=packs)
    os.close(fd)
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=3) as archive:
            for path in sorted((root / "storage").rglob("*")):
                if path.is_file():
                    archive.write(path, str(path.relative_to(root)).replace("\\", "/"))
            archive.writestr("conversation.json", json.dumps(server.game.conversation, ensure_ascii=False))
            # Freeze the resolved map and persona assets as scientific context.
            archive.writestr("world.json", json.dumps({
                "format": FORMAT, "time": server.config["time"],
                "step": server.config["step"], "phase": phase,
            }, ensure_ascii=False))
        destination = packs / filename
        os.replace(temporary, destination)
        server.config["_snapshot"] = {
            "format": FORMAT, "phase": phase,
            "pack": "statepacks/" + filename, "sha256": digest(destination),
        }
        atomic_json(checkpoint_path, sanitize_config_for_save(server.config))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def pack_path(checkpoint_path, config):
    spec = config.get("_snapshot") or {}
    if spec.get("format") != FORMAT:
        return None
    root = Path(checkpoint_path).resolve().parent
    path = (root / spec.get("pack", "")).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise ValueError("完整状态包缺失或路径无效")
    if digest(path) != spec.get("sha256"):
        raise ValueError("完整状态包校验失败")
    return path


def extract_pack(pack, destination):
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(pack) as archive:
        for info in archive.infolist():
            target = (destination / info.filename).resolve()
            if not target.is_relative_to(destination):
                raise ValueError("状态包包含非法路径")
            if info.filename != "conversation.json" and info.filename != "world.json" and not info.filename.startswith("storage/"):
                raise ValueError("状态包包含非状态文件")
        archive.extractall(destination)


def isolate_state(checkpoint_path, config, destination):
    """Rebuild a fresh frame, never reuse a previous frame's mutated index."""
    destination = Path(destination).resolve()
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    pack = pack_path(checkpoint_path, config)
    if pack:
        extract_pack(pack, destination)
        with open(destination / "conversation.json", encoding="utf-8") as handle:
            conversation = json.load(handle)
        return conversation, "verified"
    source = Path(checkpoint_path).resolve().parent / "storage"
    if not source.is_dir():
        raise ValueError("历史世界缺少记忆存储")
    shutil.copytree(source, destination / "storage")
    # Legacy conversation.json is cumulative and cannot safely be used as the
    # dialogue state at an earlier checkpoint.
    return {}, "legacy_partial"
