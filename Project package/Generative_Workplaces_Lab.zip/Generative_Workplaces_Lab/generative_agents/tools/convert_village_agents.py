# -*- coding: utf-8 -*-
"""Turn the Stanford village characters into neutral office staff (V23; run from generative_agents/).

Keeps each character's name, age and sprite; replaces location, schedule and
persona with the same neutral structure as the core team.  The original
village persona is kept under "village_persona_v22" for reference only (never
read by the simulation).  The four core agents are left untouched.
"""
import json
import os

ROOT = os.path.join("frontend", "static", "assets", "village", "agents")
CORE = {"克劳斯", "阿伊莎", "玛丽亚", "沃尔夫冈"}
OFFICE = "公司办公室"
TREE = {"the Ville": {OFFICE: {
    "开放办公区": ["1号工位", "2号工位", "3号工位", "公共办公桌"],
    "领导办公室": ["领导办公桌", "领导椅", "文件柜"],
    "会议区": ["会议桌", "白板", "书柜"],
    "茶水休息区": ["沙发", "饮水机", "打印机"],
    "休息宿舍区": ["床", "休息沙发"]}}}


def free_desk_tiles():
    with open(os.path.join("frontend", "static", "assets", "village", "maze.json"), encoding="utf-8") as f:
        maze = json.load(f)
    return [t["coord"] for t in maze["tiles"]
            if not t.get("collision") and (t.get("address") or [""])[-1] == "公共办公桌"]


def main():
    tiles = free_desk_tiles()
    changed = []
    names = sorted(n for n in os.listdir(ROOT) if os.path.exists(os.path.join(ROOT, n, "agent.json")))
    slot = 0
    for name in names:
        if name in CORE:
            continue
        path = os.path.join(ROOT, name, "agent.json")
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
        scratch = cfg.get("scratch") or {}
        if "village_persona_v22" not in cfg and OFFICE not in json.dumps(cfg.get("spatial", {}), ensure_ascii=False):
            cfg["village_persona_v22"] = {"currently": cfg.get("currently", ""), "scratch": dict(scratch),
                                         "coord": cfg.get("coord")}
        cfg["currently"] = "{}今天像往常一样开始一天的工作。".format(name)
        cfg["scratch"] = {
            "age": scratch.get("age", 30),
            "innate": "性格各方面都处于常人的中等水平。",
            "learned": "{}是团队的员工，负责推进研究课题，对这个课题有一般程度的兴趣。".format(name),
            "lifestyle": "{}通常早上醒来后进入办公室工作，白天在工位、会议区和茶水休息区之间活动，晚上10点左右在办公室休息宿舍区休息。".format(name),
            "daily_plan": "{}白天在公司办公室工作，主要在公共办公桌完成负责的工作，并会去会议区、茶水休息区与同事交流。".format(name),
            "background": "{}是奥克山学院一个企业管理研究团队的员工，团队正在完成一项研究课题：怎样更好地促进人类与人工智能的协作。".format(name),
            "conduct": "",
        }
        cfg["spatial"] = {"address": {
            "living_area": ["the Ville", OFFICE, "休息宿舍区"],
            "睡觉": ["the Ville", OFFICE, "休息宿舍区", "床"],
            "工作": ["the Ville", OFFICE, "开放办公区", "公共办公桌"]}, "tree": TREE}
        cfg["workstation"] = "公共办公桌"
        cfg["coord"] = tiles[slot % len(tiles)]
        slot += 1
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        changed.append(name)
    print("converted", len(changed), "：", "、".join(changed))


if __name__ == "__main__":
    main()
