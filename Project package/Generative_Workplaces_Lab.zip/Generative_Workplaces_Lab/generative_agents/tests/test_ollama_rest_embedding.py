import os
import sys
import unittest
from unittest.mock import Mock, patch


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from modules.storage.index import OllamaRESTEmbedding


class OllamaRESTEmbeddingTests(unittest.TestCase):
    @patch("modules.storage.index.requests.post")
    def test_uses_native_ollama_embed_endpoint_and_preserves_vector(self, post):
        response = Mock()
        response.json.return_value = {"embeddings": [[0.25, -0.5, 0.75]]}
        post.return_value = response

        embedding = OllamaRESTEmbedding(
            model_name="bge-m3:latest",
            base_url="http://127.0.0.1:11434/",
        )
        vector = embedding.get_query_embedding("启动测试")

        self.assertEqual(vector, [0.25, -0.5, 0.75])
        post.assert_called_once_with(
            url="http://127.0.0.1:11434/api/embed",
            json={
                "model": "bge-m3:latest",
                "input": "启动测试",
                "options": {"mirostat": 0},
            },
            timeout=60.0,
        )
        response.raise_for_status.assert_called_once_with()

    @patch("modules.storage.index.requests.post")
    def test_rejects_missing_embedding_vector(self, post):
        response = Mock()
        response.json.return_value = {"embeddings": []}
        post.return_value = response

        embedding = OllamaRESTEmbedding(model_name="bge-m3:latest")
        with self.assertRaisesRegex(ValueError, "no embedding vector"):
            embedding.get_text_embedding("启动测试")


if __name__ == "__main__":
    unittest.main()
