# -*- coding: utf-8 -*-
"""Within-person (day-level) check of the diary hypotheses on one downloaded batch.

Run from generative_agents/:

    python tools/check_within.py <编码总表_无损合并.xlsx> <整批下载.zip 或解压后的目录> [输出.csv] [--boot 2000]

check_hypotheses.py averages every variable over its administrations, so a diary hypothesis
("on days when the supervisor is more abusive, the employee needs more recovery that evening")
is tested there as a between-person relation over the whole week. This tool tests it at the level
the original studies used:

- applies to hypotheses whose X and Y are both measured on several days (diary / ESM designs);
- each administration is scored on its own (items rescaled to 0-1, reverse-keyed items as in
  check_hypotheses.py); a chain X -> M ... -> Y is built from each X administration by taking,
  for every later variable, the first administration at or after the previous one and no more
  than 30 hours after X (same session, later that day, or the next morning);
- when X and Y come from different respondents (employees rating the leader's behaviour), the
  world-day mean is used instead of the person-day; an outcome the statement calls "subsequent"
  or "next-day" must come from a later session than the previous variable;
- every variable is centred on the person's own mean (person fixed effects), so only day-to-day
  changes within a person are used;
- the effect (slope, or product of mediation paths) is judged by a cluster bootstrap that
  resamples whole worlds, as in check_hypotheses.py --boot; supported = 95% interval excludes 0
  in the predicted sign.
Also reported: the share of X's variance that lies within persons (day-to-day), since a stable
persona may leave little daily variation to work with.
"""
import collections
import csv
import datetime as dt
import json
import os
import re
import sys

import numpy as np

sys.path.insert(0, os.getcwd())
sys.path.insert(0, os.path.join(os.getcwd(), "tools"))
import build_v24_battery as battery  # noqa: E402
import check_hypotheses as ch  # noqa: E402

MAX_LAG = dt.timedelta(hours=30)


def when(text):
    return dt.datetime.strptime(text, "%Y%m%d-%H:%M")


def admin_scores(export, scorer, survey):
    """(condition, replicate, person) -> sorted [(time, score)] for every administration."""
    sid = survey["id"]
    rev = scorer.reverse_ids(survey)
    cols = [c for c in export.codebook[sid] if c["type"] in ("likert", "number")]
    acc = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in export.responses:
        if sid not in r["survey_ids"].split("|"):
            continue
        vals = []
        for c in cols:
            v = r.get(c["column"], "")
            if v == "":
                continue
            lo, hi = float(c["min"]), float(c["max"])
            x = (float(v) - lo) / (hi - lo) if hi > lo else float(v)
            vals.append(1 - x if c["question_id"] in rev else x)
        if vals:
            person = r["ratee"] if survey.get("mode") == "dyadic" and r["ratee"] else r["agent"]
            acc[(r["condition"], r["replicate"], person)][when(r["survey_time"])].append(sum(vals) / len(vals))
    return {k: sorted((t, float(np.mean(v))) for t, v in d.items()) for k, d in acc.items()}


def chains(series, later_last=False):
    """series: one [(time, score)] list per variable, X first -> rows of aligned scores.
    later_last: the outcome must come after (not in the same session as) the previous variable."""
    rows = []
    for t0, x in series[0]:
        row, prev = [x], t0
        for j, s in enumerate(series[1:], 1):
            strict = later_last and j == len(series) - 1
            nxt = next(((t, v) for t, v in s if (t > prev if strict else t >= prev)), None)
            if nxt is None or nxt[0] - t0 > MAX_LAG:
                row = None
                break
            row.append(nxt[1])
            prev = nxt[0]
        if row is not None:
            rows.append(row)
    return rows


def outcome_is_later(h):
    """True when the statement says the outcome itself is "subsequent" / "next-day" (e.g. leaders'
    subsequent consideration behaviour), as opposed to an earlier step of the chain."""
    text = str(h.get("假设陈述") or "").lower()
    words = [w for w in re.findall(r"[a-z]+", str(h.get("Y名称") or "").lower()) if len(w) > 3]
    if not words:
        return False
    for m in re.finditer(r"subsequent|next[- ]day|following day", text):
        if words[0] in text[m.end():m.end() + 60]:
            return True
    return False


def main(workbook, export_path, out_csv=None, boot=2000):
    corrections = json.load(open(ch.CORRECTIONS, encoding="utf-8"))
    overrides = {(c["paper_id"], c["study_id"], c["h_id"]): c["prediction"] for c in corrections["prediction_overrides"]}
    data = json.load(open(battery.BATTERY_PATH, encoding="utf-8"))
    var_survey = {(s["paper_id"], s["study_id"], s["var_id"]): e["survey"] for e in data["surveys"] for s in e["sources"]}
    _, hyp_rows = battery.load_rows(workbook)
    decision = "实施决定（2026-10-25）"
    hyps = [h for h in hyp_rows if str(h.get(decision) or "").startswith("纳入")
            and h["paper_id"] not in battery.EXCLUDED_PAPERS
            and (h["paper_id"], h["study_id"], str(h["h_id"]).split("_")[0]) not in battery.EXCLUDED_HYPOTHESES]
    export = ch.Export(export_path)
    scorer = ch.Scorer(export, corrections)
    cache = {}

    def scores(survey):
        if survey["id"] not in cache:
            cache[survey["id"]] = admin_scores(export, scorer, survey)
        return cache[survey["id"]]

    def repeated(survey):
        return survey.get("days") == [] or len(survey.get("days") or []) > 1

    results = []
    for h in hyps:
        key = (h["paper_id"], h["study_id"], str(h["h_id"]))
        ids = [h["X编号"]] + ch.id_list(h["M编号"]) + [h["Y编号"]]
        surveys = [var_survey.get((h["paper_id"], h["study_id"], v)) for v in ids]
        if any(s is None for s in surveys) or not (repeated(surveys[0]) and repeated(surveys[-1])):
            continue
        pred = overrides.get(key, h["预测形式"])
        row = {"paper": key[0], "study": key[1], "h": key[2], "prediction": pred,
               "X": h["X名称"], "M": h["M名称"], "Y": h["Y名称"], "status": "", "detail": "",
               "persons": 0, "person_days": 0, "x_within_share": ""}
        results.append(row)
        if pred not in ("positive", "negative", "no_effect"):
            row["status"] = "无法检验"; row["detail"] = "预测形式 " + str(pred); continue
        per = [scores(s) for s in surveys]
        persons = sorted(set.intersection(*[set(p) for p in per]))
        level = "个体内"
        if not persons:
            # different respondents (e.g. employees rate the leader's behaviour): use the world-day
            # mean of each variable, centred on the world's own mean
            level = "世界内"
            world = []
            for p in per:
                acc = collections.defaultdict(lambda: collections.defaultdict(list))
                for u, series in p.items():
                    for t, v in series:
                        acc[(u[0], u[1], "")][t].append(v)
                world.append({k: sorted((t, float(np.mean(v))) for t, v in d.items()) for k, d in acc.items()})
            per = world
            persons = sorted(set.intersection(*[set(p) for p in per]))
        later_last = outcome_is_later(h)
        data_rows, clusters = [], []
        for u in persons:
            rows = chains([p[u] for p in per], later_last)
            if len(rows) < 2:
                continue
            arr = np.array(rows, dtype=float)
            if np.std(arr[:, 0]) == 0:
                continue
            raw_x = arr[:, 0].copy()
            arr = arr - arr.mean(axis=0)
            data_rows.append((arr, raw_x))
            clusters += ["{}|{}".format(u[0], u[1])] * len(arr)
        if not data_rows:
            row["status"] = "无法检验"; row["detail"] = "X 在个人内没有逐日变化"; continue
        arr = np.vstack([a for a, _ in data_rows])
        all_x = np.concatenate([x for _, x in data_rows])
        row["persons"] = len(data_rows); row["person_days"] = len(arr)
        row["x_within_share"] = round(float(np.var(arr[:, 0]) / np.var(all_x)) if np.var(all_x) > 0 else 0.0, 3)
        clusters = np.array(clusters)
        n_m = len(ids) - 2
        lo, hi, est = ch.cluster_boot(arr, clusters, n_m, boot)
        if lo is None:
            row["status"] = "无法检验"; row["detail"] = "抽样后没有变异"; continue
        excludes = lo > 0 or hi < 0
        sign = 1 if pred == "positive" else -1
        ok = (not excludes) if pred == "no_effect" else (excludes and np.sign(est) == sign)
        row["status"] = "支持" if ok else "不支持"
        row["detail"] = "{} 人日={} 人={} 世界={} {}={:+.3f} 95%CI[{:+.3f},{:+.3f}]".format(
            level, len(arr), len(data_rows), len(set(clusters)), "间接效应" if n_m else "b", est, lo, hi)
    counts = collections.Counter(r["status"] for r in results)
    print("日记类假设 {} 条（个体内检验）：{}".format(len(results), dict(counts)))
    if out_csv:
        with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(results[0]))
            w.writeheader()
            w.writerows(results)
        print("->", out_csv)
    return results


if __name__ == "__main__":
    argv = sys.argv[1:]
    boot = 2000
    if "--boot" in argv:
        i = argv.index("--boot")
        boot = int(argv[i + 1])
        argv = argv[:i] + argv[i + 2:]
    if len(argv) not in (2, 3):
        sys.exit(__doc__)
    main(*argv, boot=boot)
