"""Provider usage is measured, never guessed from character counts."""
from collections import defaultdict
from pathlib import Path
from .common import jsonl
def summarize(worlds):
    groups = defaultdict(lambda: {"calls":0,"attempts":0,"failures":0,"retries":0,"latency_ms":0,
                                 "input_chars":0,"output_chars":0,"prompt_tokens":0,"completion_tokens":0,
                                 "usage_reported_calls":0,"latencies":[]})
    for world in worlds:
        for _,row,error in jsonl(Path("results/monitor")/world["name"]/"model_calls.jsonl"):
            if error:
                continue
            key = (row.get("model",""),row.get("caller") or row.get("kind","unknown"))
            group = groups[key]
            group["calls"] += 1
            group["attempts"] += row.get("attempts",1)
            group["failures"] += int(not row.get("success",True))
            for field in ("retries","latency_ms","input_chars","output_chars"):
                group[field] += row.get(field,0) or 0
            group["latencies"].append(row.get("latency_ms",0) or 0)
            if row.get("usage") is not None:
                group["usage_reported_calls"] += 1
                for field in ("prompt_tokens","completion_tokens"):
                    group[field] += row["usage"].get(field,0) or 0
    rows=[]
    for (model,caller),group in groups.items():
        values=sorted(group.pop("latencies"))
        rows.append({"model":model,"caller":caller,**group,
                     "mean_ms":group["latency_ms"]/group["calls"],
                     "p95_ms":values[min(len(values)-1,int(len(values)*.95))]})
    rows.sort(key=lambda r:r["latency_ms"],reverse=True)
    return {"calls":rows,"notes":["调用耗时是请求累计等待时间，不等于并行实验的墙钟耗时。",
            "字符数不是Token数。仅展示供应商返回的Token用量；旧记录无此字段。",
            "实际费用以供应商账单为准；此页面不使用未经确认的模型价格。"]}

