# -*- coding: utf-8 -*-
"""V24: install the replication battery into the two persona-manipulation templates.

Run from generative_agents/:

    python tools/build_v24_battery.py <编码总表_无损合并.xlsx>

Scope (V24, 2026-10-27): hypotheses whose 实施决定 begins with 纳入 in sheet 假设,
minus the exclusions below; every questionnaire variable those hypotheses need is
installed, one survey per variable. Item wording, response scales and instructions
are copied from 复现用问卷（本变量，直接使用） in sheet 变量; the only text change is the
time window in the instructions (see _rewrite_window), and the original is kept in
the battery file. Variables realised by the manipulation or by behaviour records
have no questionnaire and are skipped.

Writes
    data/scale_battery/battery_v1.json   every survey with its source variables
    data/world_presets/Persona-manipulation-high-abuse_CN.json / Persona-manipulation-low-abuse_CN.json
        (battery surveys have ids starting with "b_"; the V23 surveys are kept;
        rerunning replaces the previous battery)

Compressed design: five working days (Monday 08:00 to Friday night):
    baseline   day 1 08:00   T0, and the non-daily surveys of diary studies
    waves      21:00         a k-wave study uses WAVE_SLOTS[k]; the last wave is "last"
    single     21:00 "last"  cross-sectional, experiments, unknown timing
    diary      every day     at the time of day the study used
"""
import collections
import copy
import json
import os
import re
import sys

EMP = ["阿伊莎", "玛丽亚", "沃尔夫冈"]
LEADER = "克劳斯"
TEMPLATES = ["Persona-manipulation-high-abuse_CN", "Persona-manipulation-low-abuse_CN"]
QUESTIONNAIRE = "复现用问卷（本变量，直接使用）"
INCLUDE_PENDING = False  # 待定 hypotheses (work-family) are not installed
# Decided 2026-10-27: these need a department manager, who is not in the simulation.
EXCLUDED_PAPERS = {"P211": "经理评组长（模拟中没有经理）", "P282": "经理辱虐组长为自变量（模拟中没有经理）"}
EXCLUDED_HYPOTHESES = {("P056", "S1", "H1"): "经理辱虐组长为自变量（模拟中没有经理）",
                       ("P056", "S1", "H3"): "经理辱虐组长为自变量（模拟中没有经理）"}
BATTERY_PATH = os.path.join("data", "scale_battery", "battery_v1.json")

# Who answers. self: targets; dyadic: raters x ratees.
RATERS = {
    "员工自评": ("self", EMP, None),
    "员工评领导": ("self", EMP, None),
    "同事自评": ("self", EMP, None),
    "团队成员自评": ("self", EMP, None),
    "同事评团队": ("self", EMP, None),
    "同事（旁观者）评领导": ("self", EMP, None),
    "领导自评": ("self", [LEADER], None),
    "领导评团队": ("self", [LEADER], None),
    "领导评员工": ("dyadic", [LEADER], EMP),
    "同事评员工": ("dyadic", EMP, EMP),
    "同事评被关联的同事（情境实验参与者）": ("dyadic", EMP, EMP),
}
# Longer labels that carry a note in brackets: matched by prefix.
RATER_PREFIXES = [
    ("员工评领导", ("self", EMP, None)),
    ("情境实验参与者评领导", ("self", EMP, None)),
    ("情境实验参与者（扮演主管）", ("self", [LEADER], None)),
    ("同事评被关联的同事", ("dyadic", EMP, EMP)),
]
EXCLUDED_RATERS = ("家人评员工", "家人自评", "经理评领导", "经理评团队", "领导评经理")


def map_rater(rater):
    if rater in RATERS:
        return RATERS[rater]
    for prefix, target in RATER_PREFIXES:
        if rater.startswith(prefix):
            return target
    return None

# Five working days (Monday 08:00 to Friday night). Measurement slots for a k-wave
# study as (trigger time, day); the last wave is always on the last day ("last").
WAVE_SLOTS = {
    1: [("21:00", "last")],
    2: [("21:00", 3), ("21:00", "last")],
    3: [("21:00", 3), ("21:00", 4), ("21:00", "last")],
    4: [("21:00", 2), ("21:00", 3), ("21:00", 4), ("21:00", "last")],
    5: [("21:00", 1), ("21:00", 2), ("21:00", 3), ("21:00", 4), ("21:00", "last")],
    # more waves than evenings: the first wave moves to the morning of day 1
    6: [("08:00", 1), ("21:00", 1), ("21:00", 2), ("21:00", 3), ("21:00", 4), ("21:00", "last")],
}
N_DAYS = 5
DIARY_DAYS_MORNING = [2, 3, 4, "last"]  # previous-night reports need a simulated night

# PDF line-break hyphens and ligatures in item text (listed in 问卷版本待处理清单.xlsx,
# sheet 英文题项文本问题). Only these exact strings are joined; nothing else is reworded.
TEXT_FIXES = {
    "an- other": "another", "tech- niques": "techniques", "oppor- tunity": "opportunity",
    "im- plementation": "implementation", "Jit- tery": "Jittery", "relation- ship": "relationship",
    "hard-to- \ufb01nd": "hard-to-find", "\ufb01": "fi", "\ufb02": "fl",
}

_WINDOW = re.compile(
    r"(?:the\s+)?(?:past|last)\s+(?:few\s+|six\s+|two\s+|\d+\s+)?(?:months?|years?|weeks)\b", re.I)
_KEEP_WINDOW = re.compile(r"last week|past seven days|since last survey", re.I)


def _wave_no(label):
    label = str(label or "")
    m = re.search(r"\b(?:T|Wave\s*)(\d)\b", label)
    return int(m.group(1)) if m else None


def _is_diary(label):
    return bool(re.search(r"\bdaily\b|\bDay t\b", str(label or ""), re.I))


def _is_experiment(label):
    return bool(re.search(r"manipulation|after round|post-interaction", str(label or ""), re.I))


def _diary_trigger(label):
    text = str(label or "").lower()
    if "morning" in text:
        return "08:00", DIARY_DAYS_MORNING, "recent"
    if "4:30" in text or "afternoon" in text or "5 p.m." in text or "end of workday" in text:
        return "17:00", [], "today"
    if "noon" in text:
        return "12:00", [], "today"
    return "21:00", [], "today"


def parse_questionnaire(text):
    """-> (instruction lines, scale line, [(number, item text, options or None)])"""
    instr, scale, items = [], "", []
    for raw in str(text).split("\n"):
        line = raw.rstrip()
        if not line.strip():
            continue
        m = re.match(r"^(\d+)\.\s+(.*)$", line)
        if m:
            body, options = m.group(2), None
            om = re.search(r"\s*(\[\[.*\]\])\s*$", body)
            if om:
                options = json.loads(om.group(1))[0]
                body = body[:om.start()].rstrip()
            for bad, good in TEXT_FIXES.items():
                body = body.replace(bad, good)
            if body.count("[") > body.count("]"):
                body += "]"  # bracketed placeholder whose closing bracket was lost in extraction
            items.append((int(m.group(1)), body, options))
        elif line.startswith("Response scale:"):
            scale = line[len("Response scale:"):].strip()
        elif not items:
            instr.append(line)
    return instr, scale, items


def parse_scale(scale):
    """Numeric range and endpoint labels from a printed response scale."""
    marks = list(re.finditer(r"(?<![\w.])(\d+)\s*=\s*", scale))
    if len(marks) < 2:
        raise ValueError("response scale without two anchors: " + scale)
    anchors = {}
    for i, mk in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(scale)
        label = scale[mk.end():end].strip()
        label = re.split(r";\s*(?:same scale|middle point|increments)", label)[0]
        anchors[int(mk.group(1))] = label.strip(" ,;.")
    lo, hi = min(anchors), max(anchors)
    return lo, hi, anchors[lo], anchors[hi]


def _rewrite_window(instr, final):
    """Map a long reference period onto the compressed week. Returns (text, changed)."""
    if _KEEP_WINDOW.search(instr):
        return instr, False
    new = _WINDOW.sub("the past week" if final else "the past few days", instr)
    return new, new != instr


def _time_frame(instr, rewritten, final, baseline):
    low = instr.lower()
    if baseline:
        return "general"
    if "today" in low:
        return "today"
    if rewritten or _KEEP_WINDOW.search(instr):
        return "week" if final else "recent"
    return "general"


def load_rows(path):
    """-> (variable rows, hypothesis rows) from the master workbook."""
    import openpyxl
    wb = openpyxl.load_workbook(path, read_only=True)

    def sheet(name):
        rows = list(wb[name].iter_rows(values_only=True))
        return [dict(zip(rows[0], r)) for r in rows[1:]]
    return sheet("变量"), sheet("假设")


def select_scope(var_rows, hyp_rows):
    """-> ({variable key: [hypothesis ids]}, [excluded hypotheses with reasons])"""
    needed, excluded = collections.defaultdict(list), []
    for h in hyp_rows:
        decision = str(h.get("实施决定（2026-10-25）") or "")
        if not (decision.startswith("纳入") or (INCLUDE_PENDING and decision.startswith("待定"))):
            continue
        hid = (h["paper_id"], h["study_id"], h["h_id"])
        why = EXCLUDED_PAPERS.get(h["paper_id"]) or EXCLUDED_HYPOTHESES.get(hid)
        if why:
            excluded.append((hid, why))
            continue
        for var in [x.strip() for x in str(h.get("测量核对：所需变量") or "").split(",") if x.strip()]:
            needed[(h["paper_id"], h["study_id"], var)].append(h["h_id"])
    return needed, excluded


def plan_timing(row, study_rows):
    """-> (kind, trigger_time, days, final_wave)"""
    label = row.get("测量时点")
    if _is_diary(label):
        trigger, days, _ = _diary_trigger(label)
        return "diary", trigger, days, False
    diary_study = any(_is_diary(r.get("测量时点")) for r in study_rows)
    wave = _wave_no(label)
    if wave == 0 or (diary_study and not _is_experiment(label)):
        return "baseline", "08:00", [1], False
    if _is_experiment(label) or wave is None:
        return "single", "21:00", ["last"], True
    waves = sorted({w for w in (_wave_no(r.get("测量时点")) for r in study_rows) if w})
    k = max(waves)
    if k > max(WAVE_SLOTS):
        raise ValueError("too many waves: {} {}".format(row["paper_id"], row["study_id"]))
    trigger, day = WAVE_SLOTS[k][wave - 1]
    return "wave", trigger, [day], day == "last"


def build_surveys(rows, hyp_rows):
    by_study = collections.defaultdict(list)
    for r in rows:
        by_study[(r.get("paper_id"), r.get("study_id"))].append(r)
    needed, excluded = select_scope(rows, hyp_rows)
    surveys, skipped, merged = [], [], {}
    for r in rows:
        key3 = (r.get("paper_id"), r.get("study_id"), r.get("var_id"))
        if key3 not in needed or not str(r.get(QUESTIONNAIRE) or "").strip():
            continue  # out of scope, or realised by the manipulation / behaviour records
        rater = str(r.get("评价者（谁来答）") or "").strip()
        target = map_rater(rater)
        if rater in EXCLUDED_RATERS or target is None:
            skipped.append((r, "作答人在模拟中没有对应角色：" + rater))
            continue
        mode, who, ratees = target
        kind, trigger, days, final = plan_timing(r, by_study[(r["paper_id"], r["study_id"])])
        instr_lines, scale, items = parse_questionnaire(r[QUESTIONNAIRE])
        original = "\n".join(instr_lines)
        instr, changed = _rewrite_window(original, final) if kind != "baseline" else (original, False)
        frame = _time_frame(instr, changed, final, kind == "baseline")
        if kind == "diary":
            frame = _diary_trigger(r.get("测量时点"))[2]
        questions = []
        lo = hi = lo_label = hi_label = None
        hours = scale.lower().startswith("number of hours")
        if any(opt is None for _, _, opt in items) and not hours:
            lo, hi, lo_label, hi_label = parse_scale(scale)
        for number, text, options in items:
            if hours:
                questions.append({"id": "i{}".format(number), "type": "number", "text": text,
                                  "min": 0, "max": 24, "unit": "小时"})
            elif options:
                questions.append({"id": "i{}".format(number), "type": "single_choice",
                                  "text": text, "options": options})
            else:
                questions.append({"id": "i{}".format(number), "type": "likert", "text": text,
                                  "min": lo, "max": hi, "min_label": lo_label, "max_label": hi_label})
        prompt_instr = instr + ("\nResponse scale: " + scale if scale else "")
        key = json.dumps([mode, who, ratees, trigger, days, frame, prompt_instr, questions],
                         ensure_ascii=False, sort_keys=True)
        source = {"paper_id": r["paper_id"], "study_id": r["study_id"], "var_id": r["var_id"],
                  "variable": r.get("变量原名"), "construct": r.get("统一构念"), "rater": rater,
                  "timepoint": r.get("测量时点"), "grade": r.get("复现用问卷状态"),
                  "scale_name": r.get("量表名称"), "questionnaire_source": r.get("复现用问卷来源说明"),
                  "hypotheses": sorted(set(needed[key3]))}
        if key in merged:
            merged[key]["sources"].append(source)
            continue
        sid = "b_{}_{}_{}".format(r["paper_id"], r["study_id"], r["var_id"]).lower()
        survey = {
            "id": re.sub(r"[^a-z0-9_]", "_", sid),
            "title": "{} {} {} {}（{}，{}）".format(r["paper_id"], r["study_id"], r["var_id"],
                                                 r.get("变量原名"), rater, r.get("测量时点") or "单次"),
            "time_frame": frame, "trigger_time": trigger, "days": days, "mode": mode,
            "include_reason": False, "randomize_items": True,
            "instructions": prompt_instr,
            "source": "{} | {}".format(r.get("量表名称") or "", r.get("复现用问卷状态") or ""),
            "questions": questions,
        }
        if mode == "self":
            survey["targets"] = list(who)
        else:
            survey["raters"], survey["ratees"] = list(who), list(ratees)
        entry = {"survey": survey, "sources": [source], "kind": kind,
                 "original_instructions": original, "window_rewritten": changed}
        merged[key] = entry
        surveys.append(entry)
    # unique ids; neutral titles
    seen = collections.Counter()
    for entry in surveys:
        s = entry["survey"]
        seen[s["id"]] += 1
        if seen[s["id"]] > 1:
            s["id"] = "{}_{}".format(s["id"], seen[s["id"]])
        leader = (s.get("targets") or s.get("raters")) == [LEADER]
        # neutral and identical within a group: the agent sees one questionnaire per call
        s["display_title"] = "管理者日记问卷" if leader else "员工日记问卷"
    return surveys, skipped, excluded


def load_summary(surveys, n_days=N_DAYS):
    days = {}
    for d in range(1, n_days + 1):
        calls = items = count = 0
        for entry in surveys:
            s = entry["survey"]
            on = (not s["days"]) or d in s["days"] or ("last" in s["days"] and d == n_days)
            if not on:
                continue
            per = len(s["targets"]) if s["mode"] == "self" else \
                sum(1 for a in s["raters"] for b in s["ratees"] if a != b)
            count += 1
            calls += per
            items += per * len(s["questions"])
        days[d] = (count, calls, items)
    return days


def main(path):
    from modules import survey as survey_engine
    rows, hyp_rows = load_rows(path)
    surveys, skipped, excluded = build_surveys(rows, hyp_rows)
    for entry in surveys:
        survey_engine.validate_schema(entry["survey"])
    os.makedirs(os.path.dirname(BATTERY_PATH), exist_ok=True)
    with open(BATTERY_PATH, "w", encoding="utf-8") as handle:
        json.dump({"version": "battery_v1", "source_workbook": os.path.basename(path),
                   "surveys": surveys,
                   "skipped": [{"paper_id": r["paper_id"], "study_id": r["study_id"],
                                "var_id": r["var_id"], "rater": r.get("评价者（谁来答）"), "reason": why}
                               for r, why in skipped],
                   "excluded_hypotheses": [{"paper_id": p, "study_id": st, "h_id": h, "reason": why}
                                           for (p, st, h), why in excluded],
                   "include_pending": INCLUDE_PENDING},
                  handle, ensure_ascii=False, indent=1)
    for name in TEMPLATES:
        tpath = os.path.join("data", "world_presets", name + ".json")
        with open(tpath, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        kept = [s for s in payload.get("custom_surveys") or [] if not str(s.get("id", "")).startswith("b_")]
        payload["custom_surveys"] = kept + [copy.deepcopy(e["survey"]) for e in surveys]
        with open(tpath, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    kinds = collections.Counter(e["kind"] for e in surveys)
    n_sources = sum(len(e["sources"]) for e in surveys)
    papers = {x["paper_id"] for e in surveys for x in e["sources"]}
    print("papers: {}  variables used: {}  surveys: {}  skipped: {}  hypotheses excluded: {}".format(
        len(papers), n_sources, len(surveys), len(skipped), len(excluded)))
    print("by timing:", dict(kinds))
    print("day  surveys  answer-calls  item-answers (battery only)")
    for d, (count, calls, items) in load_summary(surveys).items():
        print("{:>3}  {:>7}  {:>12}  {:>12}".format(d, count, calls, items))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    sys.path.insert(0, os.getcwd())
    main(sys.argv[1])
