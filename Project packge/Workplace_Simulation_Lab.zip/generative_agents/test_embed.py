import logging
import requests
from llama_index.embeddings.ollama import OllamaEmbedding

# 启用详细日志
logging.basicConfig(level=logging.DEBUG)

print("=== 测试LlamaIndex Ollama集成 ===\n")

# 测试1：不同的base_url格式
urls = [
    "http://localhost:11434",
    "http://127.0.0.1:11434",
    "http://localhost:11434/",
    "http://localhost:11434/api",
]

for url in urls:
    print(f"\n测试 base_url: {url}")
    try:
        embedding = OllamaEmbedding(
            model_name="mxbai-embed-large:latest",
            base_url=url,
            request_timeout=30.0
        )
        result = embedding.get_text_embedding("test")
        print(f"✓ 成功！向量长度: {len(result)}")
    except Exception as e:
        print(f"✗ 失败: {e}")

# 测试2：使用不同的参数
print("\n\n=== 测试不同参数配置 ===")
try:
    # 尝试添加更多参数
    embedding = OllamaEmbedding(
        model_name="mxbai-embed-large:latest",
        base_url="http://localhost:11434",
        request_timeout=60.0,
        additional_kwargs={"temperature": 0}
    )
    result = embedding.get_text_embedding("test")
    print(f"✓ 成功！向量长度: {len(result)}")
except Exception as e:
    print(f"✗ 失败: {e}")