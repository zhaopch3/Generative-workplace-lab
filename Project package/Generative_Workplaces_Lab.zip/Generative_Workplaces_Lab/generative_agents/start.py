import os
import copy
import json
import argparse
import datetime
import random
import csv
from concurrent.futures import ThreadPoolExecutor

from dotenv import load_dotenv, find_dotenv

from modules.game import create_game, get_game
from modules import utils
from modules import cheap_mode
from modules import lang

personas = [
    "阿伊莎", "克劳斯", "玛丽亚", "沃尔夫冈",  # 学生
]

DAILY_SURVEY_FIELDS = [
    "condition",
    "run_id",
    "survey_date",
    "survey_time",
    "agent",
    "role",
    "perceived_leader_strictness",
    "stress",
    "psychological_safety",
    "leader_trust",
    "work_engagement",
    "turnover_intention",
    "self_rated_leader_strictness",
    "team_trust",
    "management_engagement",
    "psychological_resource_recovery",
    "emotional_exhaustion",
    "reason",
    "_quality",
    "_measurement_policy",
]


class SimulateServer:
    def __init__(self, name, static_root, checkpoints_folder, config, start_step=0, verbose="info", log_file="", on_step=None, control=None):
        self.name = name
        self.static_root = static_root
        self.checkpoints_folder = checkpoints_folder

        # 历史存档数据（用于断点恢复）
        self.config = config
        # V27: the simulation language of this world (worlds saved before V27 are Chinese).
        lang.set_language(config.get("language", "zh"))
        if not config.get("_random_state"):
            random.seed(config.get("seed", 0))

        os.makedirs(checkpoints_folder, exist_ok=True)

        # 载入历史对话数据（用于断点恢复）
        self.conversation_log = f"{checkpoints_folder}/conversation.json"
        if os.path.exists(self.conversation_log):
            with open(self.conversation_log, "r", encoding="utf-8") as f:
                conversation = json.load(f)
        else:
            conversation = {}

        if len(log_file) > 0:
            self.logger = utils.create_file_logger(f"{checkpoints_folder}/{log_file}", verbose)
        else:
            self.logger = utils.create_io_logger(verbose)

        # 创建游戏
        game = create_game(name, static_root, config, conversation, logger=self.logger)
        game.reset_game(keys=config["api_keys"])

        self.game = get_game()
        from modules.research.snapshots import restore_random
        restore_random(config)
        self.tile_size = self.game.maze.tile_size
        self.agent_status = {}
        if "agent_base" in config:
            agent_base = config["agent_base"]
        else:
            agent_base = {}
        for agent_name, agent in config["agents"].items():
            agent_config = copy.deepcopy(agent_base)
            agent_config = utils.update_dict(agent_config, self.load_static(agent["config_path"]))
            agent_config = utils.update_dict(agent_config, copy.deepcopy(agent))
            self.agent_status[agent_name] = {
                "coord": agent_config["coord"],
                "path": [],
            }
        self.think_interval = max(
            a.think_config["interval"] for a in self.game.agents.values()
        )
        self.start_step = start_step
        self.daily_survey_rows = self.load_daily_survey_rows()
        # 实时模式钩子：on_step(payload) 在每个step后被调用；control 提供 pause/stop 事件
        self.on_step = on_step
        self.control = control or {}
        self._last_action_text = {}  # 时间线：记录每个agent上次的行为描述，避免重复行
        self._transient_world_events = []
        # V24: worlds created by V24 perceive at the end of each step; older worlds
        # (no key in their saved config) keep the V23 behaviour when resumed.
        self.perception_policy = config.get("perception_policy", "legacy")
        for agent in self.game.agents.values():
            agent.perception_policy = self.perception_policy
        # V24: agents get one decision after learning of an injection (new worlds only).
        self.injection_reaction = bool(config.get("injection_reaction", False))
        for agent in self.game.agents.values():
            agent.injection_reaction = self.injection_reaction

    def simulate(self, step, stride=0):
        timer = utils.get_timer()
        # V24: time of this run's final step, so surveys set to the "last" day can find it.
        step_minutes = stride or int(self.config.get("stride", 0) or 0)
        self._final_step_time = timer.get_date() + datetime.timedelta(minutes=step_minutes * max(0, step - 1))
        for i in range(self.start_step, self.start_step + step):
            # 实时控制：暂停 / 停止
            pause_event = self.control.get("pause")
            stop_event = self.control.get("stop")
            if pause_event is not None:
                while pause_event.is_set():
                    if stop_event is not None and stop_event.is_set():
                        break
                    import time as _time
                    _time.sleep(0.2)
            if stop_event is not None and stop_event.is_set():
                self.logger.info("Simulation stopped by control signal.")
                break

            # 应用研究者干预（在step间隙、模拟线程内执行，避免与think()竞争）
            applied_interventions = self.apply_pending_interventions(i + 1)
            from modules.research.scenario import apply_due_events, observe_tasks
            applied_interventions.extend(apply_due_events(self, i + 1))

            title = "Simulate Step[{}/{}, time: {}]".format(i+1, self.start_step + step, timer.get_date())
            self.logger.info("\n" + utils.split_line(title, "="))
            step_agents = {}
            timeline_delta = []
            sim_time_now = utils.get_timer().get_date("%Y%m%d-%H:%M")
            for rec in applied_interventions:
                timeline_targets = rec.get("targets") or (
                    [rec.get("actor")] if rec.get("actor") else [lang.L("世界事件", "world event")]
                )
                for t in timeline_targets:
                    text = rec.get("text") or ""
                    if rec.get("psych"):
                        text += ("" if not text else " ") + lang.L("[心理设定:{}]", "[state set: {}]").format(rec["psych"])
                    timeline_delta.append({
                        "step": i + 1, "sim_time": sim_time_now, "agent": t,
                        "type": "intervention", "text": text, "poignancy": rec.get("poignancy", 0),
                        "intervention_id": rec.get("intervention_id"),
                        "event_id": rec.get("event_id"),
                        "intervention_kind": rec.get("kind"),
                        "researcher_injected": True,
                        "status": rec.get("status", "applied"),
                    })
            chat_meta_rows = []
            think_order = list(self.agent_status.keys())
            if self.config.get("shuffle_think_order", False):
                random.shuffle(think_order)  # 每步随机思考顺序，消除固定先手偏差
            for name in think_order:
                status = self.agent_status[name]
                think_result = self.game.agent_think(name, status)
                plan, info = think_result["plan"], think_result.get("info", {})
                agent = self.game.get_agent(name)
                if name not in self.config["agents"]:
                    self.config["agents"][name] = {}
                self.config["agents"][name].update(agent.to_dict())
                prev_coord = list(status["coord"])
                if self.game.maze.navigation and not self.game.maze.validate_path(prev_coord, plan.get("path") or []):
                    raise ValueError("Invalid movement path for {}: refusing to record a wall crossing".format(name))
                if plan.get("path"):
                    status["coord"], status["path"] = plan["path"][-1], []
                self.config["agents"][name].update(
                    # {"coord": status["coord"], "path": plan["path"]}
                    {"coord": status["coord"]}
                )
                emoji = ""
                emojis = plan.get("emojis") or {}
                if name in emojis:
                    emoji = emojis[name].get("emoji", "")
                action_info = info.get("action", {}) or {}
                action_text = ""
                if isinstance(action_info, dict):
                    action_text = action_info.get("event", "") or action_info.get("describe", "")
                if action_text and self._last_action_text.get(name) != action_text:
                    self._last_action_text[name] = action_text
                    timeline_delta.append({
                        "step": i + 1, "sim_time": sim_time_now, "agent": name,
                        "type": "action", "text": action_text, "poignancy": 0,
                        "researcher_injected": bool(action_info.get("researcher_injected")),
                        "intervention_id": action_info.get("intervention_id"),
                        "event_id": action_info.get("event_id"),
                    })
                self._drain_monitor(name, i + 1, sim_time_now, timeline_delta, chat_meta_rows)
                step_agents[name] = {
                    "psych": agent.psych.snapshot(),
                    "coord": list(status["coord"]),
                    "prev_coord": prev_coord,
                    "navigation_policy": self.config.get("navigation_policy", "legacy"),
                    "path": [list(c) for c in (plan.get("path") or [])],
                    "emoji": emoji,
                    "currently": info.get("currently", ""),
                    "action": info.get("action", {}),
                    "address": info.get("address", ""),
                    "chats": info.get("chats", []),
                    "schedule": info.get("schedule", {}),
                }

            if self.perception_policy == "step_end_v24":
                self._end_of_step_perception(step_agents)
                for name in think_order:
                    self._drain_monitor(name, i + 1, sim_time_now, timeline_delta, chat_meta_rows)

            if chat_meta_rows:
                with open(os.path.join(os.path.dirname(self.timeline_log_path()), "chat_meta.jsonl"),
                          "a", encoding="utf-8") as f:
                    for row in chat_meta_rows:
                        f.write(json.dumps(row, ensure_ascii=False) + "\n")
            if timeline_delta:
                with open(self.timeline_log_path(), "a", encoding="utf-8") as f:
                    for row in timeline_delta:
                        f.write(json.dumps(row, ensure_ascii=False) + "\n")
            self.log_psych_states(i + 1)
            observe_tasks(self, i + 1, stride, step_agents)
            self.maybe_complete_daily_survey()
            self.maybe_complete_custom_surveys()

            sim_time = timer.get_date("%Y%m%d-%H:%M")
            self.config.update(
                {
                    "time": sim_time,
                    "step": i + 1,
                }
            )
            # 保存Agent活动数据
            from modules.research.snapshots import write_checkpoint
            write_checkpoint(self, f"{self.checkpoints_folder}/simulate-{sim_time.replace(':', '')}.json")
            # 保存对话数据
            with open(f"{self.checkpoints_folder}/conversation.json", "w", encoding="utf-8") as f:
                f.write(json.dumps(self.game.conversation, indent=2, ensure_ascii=False))

            # 实时推送：把本step的世界状态交给回调（SSE广播）
            if self.on_step is not None:
                try:
                    survey_cfg = self.config.get("daily_survey", {})
                    payload = {
                        "type": "step",
                        "step": i + 1,
                        "total_steps": self.start_step + step,
                        "time": sim_time,
                        "stride": self.config.get("stride", stride),
                        "agents": step_agents,
                        "conversation": self.game.conversation,
                        "survey_rows": len(self.daily_survey_rows),
                        "custom_survey_rows": {
                            k: len(v) for k, v in getattr(self, "custom_survey_rows", {}).items()
                        },
                        "interventions": applied_interventions,
                        "timeline": timeline_delta,
                        "think_order": think_order,
                    }
                    self.on_step(payload)
                except Exception as e:
                    self.logger.warning("on_step callback failed: {}".format(e))

            if stride > 0:
                timer.forward(stride)

    def load_static(self, path):
        return utils.load_dict(os.path.join(self.static_root, path))

    def _drain_monitor(self, name, step, sim_time, timeline_delta, chat_meta_rows):
        agent = self.game.get_agent(name)
        for m_type, m_text, m_poig in agent.drain_monitor():
            if m_type == "injection_reaction":
                # V24: what an agent decided after learning of an injection.
                data = json.loads(m_text)
                with open(os.path.join(os.path.dirname(self.timeline_log_path()), "injection_reactions.jsonl"),
                          "a", encoding="utf-8") as f:
                    f.write(json.dumps({"step": step, "sim_time": sim_time, "agent": name, **data},
                                       ensure_ascii=False) + "\n")
                text = (lang.L("改做：", "switched to: ") + data["activity"]) if data.get("changed") else lang.L("继续原安排", "kept the plan")
                timeline_delta.append({
                    "step": step, "sim_time": sim_time, "agent": name, "type": m_type,
                    "text": text, "poignancy": 0,
                    "intervention_id": (data.get("intervention_ids") or [None])[0],
                })
                continue
            if m_type == "chat_meta":
                # V23: conversation-length metadata is data, not a timeline event.
                chat_meta_rows.append({"step": step, "sim_time": sim_time, "agent": name,
                                       **json.loads(m_text)})
                continue
            timeline_delta.append({
                "step": step, "sim_time": sim_time, "agent": name,
                "type": m_type, "text": m_text, "poignancy": m_poig,
            })

    # ------------------------------------------------------------------
    # V24：步末统一感知
    # ------------------------------------------------------------------
    def _end_of_step_perception(self, step_agents):
        """Everyone takes up this step's destination, then everyone perceives.

        V23 perceived at the start of each agent's own think, from the position
        reached in the previous step, so with 60-minute steps what a bystander saw
        lagged a full step and depended on whether the actor had thought yet.
        Here all actions of the step are on the map before anybody looks, and the
        concepts are kept for the agent's next think (reactions, appraisal).
        """
        agents = self.game.agents
        for name, agent in agents.items():
            target = getattr(agent, "_approach_target", None)
            if target and target in agents and target != name:
                self._reresolve_approach(name, target, step_agents)
        for name, agent in agents.items():
            agent.arrive(self.agent_status[name]["coord"])
        for agent in agents.values():
            agent.perceive_end_of_step()

    def _reresolve_approach(self, name, target, step_agents):
        """Keep an approach action next to where its target ended up this step.

        The target may think after the actor and walk elsewhere; the actor then
        re-plans its walk (from this step's starting tile) to a free tile in the
        target's area beside the target's destination.
        """
        maze = self.game.maze
        agent = self.game.get_agent(name)
        goal = tuple(self.agent_status[target]["coord"])
        dest = tuple(self.agent_status[name]["coord"])
        same_area = maze.tile_at(dest).get_address("arena") == maze.tile_at(goal).get_address("arena")
        if same_area and dest != goal and max(abs(dest[0] - goal[0]), abs(dest[1] - goal[1])) <= 2:
            return
        start = tuple(agent.coord)
        occupied = {tuple(s["coord"]) for n, s in self.agent_status.items() if n != name}
        best = None
        for tile in agent.approach_tiles(goal):
            if tile in occupied:
                continue
            if tile == start:
                best = []
                break
            path = maze.find_path(start, tile)
            if not path or tuple(path[-1]) != tuple(tile) or len(path) < 2:
                continue
            path = [list(c) for c in path[1:]]
            if maze.navigation and not maze.validate_path(list(start), path):
                continue
            if best is None or len(path) < len(best):
                best = path
        if best is None:
            return
        new_coord = list(best[-1]) if best else list(start)
        self.agent_status[name]["coord"] = new_coord
        self.config["agents"].setdefault(name, {})["coord"] = new_coord
        if name in step_agents:
            step_agents[name]["coord"] = new_coord
            step_agents[name]["path"] = best
        agent.next_coord = tuple(new_coord)
        self.logger.info("{} re-approaches {} at {}".format(name, target, new_coord))

    # ------------------------------------------------------------------
    # 研究者干预（自变量操纵）
    # ------------------------------------------------------------------
    def timeline_log_path(self):
        folder = os.path.join("results", "monitor", self.name)
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, "timeline.jsonl")

    def psych_log_path(self):
        folder = os.path.join("results", "psych", self.name)
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, "psych.jsonl")

    def log_psych_states(self, step):
        sim_time = utils.get_timer().get_date("%Y%m%d-%H:%M")
        with open(self.psych_log_path(), "a", encoding="utf-8") as f:
            for name in self.game.agents:
                agent = self.game.get_agent(name)
                row = {"step": step, "sim_time": sim_time, "agent": name}
                row.update(agent.psych.snapshot())
                f.write(json.dumps(row, ensure_ascii=False) + "\n")

    def interventions_log_path(self):
        folder = os.path.join("results", "interventions", self.name)
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, "interventions.jsonl")

    def apply_pending_interventions(self, step):
        """Apply due interventions and retain future requests for later steps."""
        self._expire_world_events(step)
        q = self.control.get("interventions")
        if q is None:
            return []
        applied, deferred = [], []
        while True:
            try:
                item = q.get_nowait()
            except Exception:
                break
            try:
                if not self._intervention_due(item):
                    deferred.append(item)
                    continue
                record = self.apply_intervention(item, step)
                if record:
                    applied.append(record)
            except Exception as e:  # noqa: BLE001
                self.logger.warning("intervention failed: {}".format(e))
                failed = self._base_intervention_record(item, step, "failed")
                failed["error"] = str(e)
                self._append_intervention_record(failed)
                applied.append(failed)
            finally:
                if item not in deferred:
                    self._finish_pending_request(item)
        for item in deferred:
            q.put(item)
        return applied

    def _intervention_due(self, item):
        stamp = (item.get("scheduled_time") or "").strip()
        if not stamp:
            return True
        for pattern in ("%Y%m%d-%H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M"):
            try:
                target = datetime.datetime.strptime(stamp, pattern)
                return utils.get_timer().get_date() >= target
            except ValueError:
                continue
        raise ValueError("计划生效时间格式无效")

    def _expire_world_events(self, step):
        keep = []
        for state in self._transient_world_events:
            if state["expires_after_step"] < step:
                self.game.maze.tile_at(state["coord"]).remove_events(event=state["event"])
            else:
                keep.append(state)
        self._transient_world_events = keep

    def _resolve_intervention_location(self, location=None, fallback_agent=None):
        if isinstance(location, list):
            address = list(location)
            key = ":".join(address)
        else:
            value = (location or "").strip()
            key, address = value, value.split(":") if value else []
        if not key and fallback_agent in self.game.agents:
            agent = self.game.get_agent(fallback_agent)
            return list(agent.get_tile().get_address()), list(agent.coord)
        if key not in self.game.maze.address_tiles:
            matches = [k for k in self.game.maze.address_tiles if k.endswith(":" + key)]
            if len(matches) == 1:
                key, address = matches[0], matches[0].split(":")
            elif not matches:
                raise ValueError("找不到指定地点：{}".format(key or "（空）"))
            else:
                raise ValueError("地点名称不唯一，请选择完整地点")
        tiles = sorted(self.game.maze.get_address_tiles(address))
        if not tiles:
            raise ValueError("指定地点没有可用位置")
        return address, list(tiles[0])

    def _preintervention_checkpoint(self, item, step):
        from modules.research.snapshots import write_checkpoint
        safe_id = "".join(c for c in item.get("intervention_id", "") if c.isalnum())[:20]
        filename = "preintervention-step{:04d}-{}.json".format(step, safe_id or "unknown")
        path = os.path.join(self.checkpoints_folder, filename)
        # Before the first normal step, the initial config has not acquired the
        # ordinary end-of-step fields yet. Freeze its true current clock and
        # completed-step count explicitly.
        self.config["time"] = utils.get_timer().get_date("%Y%m%d-%H:%M")
        self.config["step"] = max(0, step - 1)
        write_checkpoint(self, path, phase="pre_intervention_before_step")
        return path, (self.config.get("_snapshot") or {}).get("sha256")

    def _base_intervention_record(self, item, step, status):
        return {
            "intervention_id": item.get("intervention_id"),
            "event_id": item.get("event_id"),
            "kind": item.get("kind", "world_event"),
            "created_at": item.get("created_at"),
            "scheduled_time": item.get("scheduled_time") or None,
            "applied_time": utils.get_timer().get_date("%Y%m%d-%H:%M"),
            "step": step,
            "sim_time": utils.get_timer().get_date("%Y%m%d-%H:%M"),
            "actor": item.get("actor"),
            "object": item.get("object"),
            "targets": list(item.get("targets") or []),
            "scope": item.get("scope"),
            "location": item.get("location"),
            "text": item.get("text", ""),
            "researcher_injected": True,
            "status": status,
            "source": item.get("source", "live_console"),
        }

    def _append_intervention_record(self, record):
        with open(self.interventions_log_path(), "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def _finish_pending_request(self, item):
        path = item.get("_pending_path")
        if path and os.path.isfile(path):
            try:
                os.remove(path)
            except OSError as exc:
                self.logger.warning("pending intervention cleanup failed: {}".format(exc))

    def apply_intervention(self, item, step):
        """Apply a researcher intervention.

        Kinds: world_event, thought, specified_action (V22); world_setting and
        revoke (V24). With ``react`` (default on) the agents who learn of an event,
        setting or thought get one decision at their next think (V24).
        """
        text = (item.get("text") or "").strip()
        psych_values = item.get("psych") or {}
        kind = item.get("kind", "world_event")
        if kind == "revoke":
            return self._apply_revoke(item, step)
        if not text and not psych_values:
            return None
        targets = list(item.get("targets") or [])
        try:
            poignancy = max(1, min(10, int(item.get("poignancy", 8))))
        except (TypeError, ValueError):
            poignancy = 8
        source_checkpoint, source_checkpoint_sha256 = self._preintervention_checkpoint(item, step)
        applied_to, event_location = [], None
        react = bool(item.get("react", True)) and bool(text)
        iid = item.get("intervention_id")
        expires = self._intervention_expiry(item)

        if kind == "world_event":
            scope = item.get("scope", "all")
            fallback = targets[0] if targets else next(iter(self.game.agents), None)
            address, coord = self._resolve_intervention_location(item.get("location"), fallback)
            event_location = ":".join(address)
            event = self.game.get_agent(fallback).make_event(lang.L("环境事件", "Environment"), text, address)
            event.predicate = lang.L("发生", "happens")
            event.event_id = item.get("event_id")
            event.intervention_id = item.get("intervention_id")
            event.researcher_injected = True
            # V24: whoever sees it on site also gets to decide what to do about it.
            event.notify_on_sight = react
            self.game.maze.tile_at(coord).add_event(event)
            self._transient_world_events.append({
                "coord": coord, "event": event, "expires_after_step": step,
            })
            if scope == "all":
                recipients = list(self.game.agents)
            elif scope == "selected":
                recipients = targets
            elif scope == "local":
                recipients = []  # Normal perception decides who notices it.
            else:
                raise ValueError("事件知情范围无效")
            for agent_name in recipients:
                agent = self.game.get_agent(agent_name)
                agent.associate.add_node("event", event, poignancy)
                agent.status["poignancy"] = agent.status.get("poignancy", 0) + poignancy
                agent._psych_buffer.append((event.get_describe(), poignancy))
                agent._monitor_buffer.append(("event", event.get_describe(), poignancy))
                if psych_values:
                    agent.set_psych(psych_values)
                if react:
                    agent.notify_injection("world_event", event.get_describe(), iid)
                applied_to.append(agent_name)
        elif kind == "world_setting":
            # V24: a standing fact about the world, written into the fixed layer of
            # every prompt of the agents it applies to until it expires or is revoked.
            if not text:
                raise ValueError("世界设定必须填写内容")
            scope = item.get("scope") or ("selected" if targets else "all")
            recipients = list(self.game.agents) if scope == "all" else targets
            if not recipients:
                raise ValueError("世界设定至少要对一个智能体生效")
            now = utils.get_timer().get_date("%Y%m%d-%H:%M")
            for agent_name in recipients:
                agent = self.game.get_agent(agent_name)
                agent.scratch.config.setdefault("world_facts", []).append({
                    "text": text, "from": now, "expires": expires,
                    "intervention_id": iid, "source": item.get("source", "live_console"),
                })
                setting = agent.make_event(lang.L("环境事件", "Environment"), text, agent.get_tile().get_address())
                setting.predicate = lang.L("发生", "happens")
                setting.intervention_id = iid
                setting.researcher_injected = True
                agent.associate.add_node("event", setting, poignancy)
                agent.status["poignancy"] = agent.status.get("poignancy", 0) + poignancy
                agent._psych_buffer.append((text, poignancy))
                agent._monitor_buffer.append(("world_setting", text, poignancy))
                if psych_values:
                    agent.set_psych(psych_values)
                if react:
                    agent.notify_injection("world_setting", text, iid)
                applied_to.append(agent_name)
        elif kind == "thought":
            if not targets:
                raise ValueError("想法或意图必须选择至少一个智能体")
            for agent_name in targets:
                agent = self.game.get_agent(agent_name)
                thought = agent.make_event(agent.name, text, agent.get_tile().get_address())
                thought.predicate = lang.L("想到", "thinks")
                thought.intervention_id = item.get("intervention_id")
                thought.researcher_injected = True
                agent.associate.add_node("thought", thought, poignancy)
                agent.status["poignancy"] = agent.status.get("poignancy", 0) + poignancy
                if item.get("persistent") or item.get("update_currently"):
                    # V23: persistent intents live outside `currently`, which the
                    # daily update rewrites; they last until `expires` (or the run ends).
                    agent.scratch.config.setdefault("intents", []).append({
                        "text": text, "created": utils.get_timer().get_date("%Y%m%d-%H:%M"),
                        "expires": expires, "intervention_id": item.get("intervention_id"),
                    })
                if psych_values:
                    agent.set_psych(psych_values)
                agent._monitor_buffer.append(("thought", text, poignancy))
                if react:
                    agent.notify_injection("thought", text, iid)
                applied_to.append(agent_name)
        elif kind == "specified_action":
            actor = item.get("actor")
            if actor not in self.game.agents:
                raise ValueError("指定行为必须选择有效行为者")
            if item.get("location"):
                address, _ = self._resolve_intervention_location(item.get("location"), actor)
                event_location = ":".join(address)
            elif item.get("object") in self.game.agents:
                address = ["<persona>", item["object"]]
            else:
                address = list(self.game.get_agent(actor).get_tile().get_address())
                event_location = ":".join(address)
            forced = self.game.get_agent(actor).inject_forced_action(
                text, address, duration=item.get("duration", 30),
                event_id=item.get("event_id"),
                intervention_id=item.get("intervention_id"),
            )
            if psych_values:
                self.game.get_agent(actor).set_psych(psych_values)
            applied_to = [actor]
            # V23: the actor remembers what he did, and named targets (e.g. the person
            # addressed) know it happened; bystanders still perceive it only through
            # ordinary perception of the action on the map.
            if item.get("remember", True):
                self.game.get_agent(actor).associate.add_node("event", forced, poignancy)
            for agent_name in targets:
                if agent_name == actor or agent_name not in self.game.agents:
                    continue
                agent = self.game.get_agent(agent_name)
                agent.associate.add_node("event", forced, poignancy)
                agent.status["poignancy"] = agent.status.get("poignancy", 0) + poignancy
                agent._psych_buffer.append((forced.get_describe(), poignancy))
                agent._monitor_buffer.append(("event", forced.get_describe(), poignancy))
                applied_to.append(agent_name)
        else:
            raise ValueError("未知干预类型")

        record = self._base_intervention_record(item, step, "applied")
        record.update({
            "targets": applied_to,
            "location": event_location or item.get("location"),
            "poignancy": poignancy,
            "persistent": bool(item.get("persistent") or item.get("update_currently")) or kind == "world_setting",
            "expires": expires if (kind == "world_setting" or item.get("persistent")
                                   or item.get("update_currently")) else None,
            "react": react,
            "psych": {k: v for k, v in psych_values.items() if v not in (None, "")},
            "source_checkpoint": source_checkpoint,
            "source_checkpoint_sha256": source_checkpoint_sha256,
        })
        self._append_intervention_record(record)
        self.logger.info("[intervention:{}] {} -> {}".format(kind, text, applied_to))
        return record

    @staticmethod
    def _intervention_expiry(item):
        expires = (item.get("expires_time") or "").strip() or None
        if expires:
            for pattern in ("%Y%m%d-%H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M"):
                try:
                    return datetime.datetime.strptime(expires, pattern).strftime("%Y%m%d-%H:%M")
                except ValueError:
                    continue
            raise ValueError("到期时间格式无效")
        if item.get("persist_days"):
            return (utils.get_timer().get_date() + datetime.timedelta(
                days=float(item["persist_days"]))).strftime("%Y%m%d-%H:%M")
        return None

    def _apply_revoke(self, item, step):
        """V24: withdraw a world setting or persistent intent from now on."""
        revoke_id = (item.get("revoke_id") or "").strip()
        if not revoke_id:
            raise ValueError("撤销需要指定要撤销的干预编号")
        now = utils.get_timer().get_date("%Y%m%d-%H:%M")
        applied_to, texts = [], set()
        for name, agent in self.game.agents.items():
            hit = False
            for key in ("world_facts", "intents"):
                for entry in agent.scratch.config.get(key) or []:
                    if entry.get("intervention_id") == revoke_id and not entry.get("revoked"):
                        entry["revoked"] = now
                        texts.add(entry.get("text", ""))
                        hit = True
            if hit:
                applied_to.append(name)
                agent._monitor_buffer.append(("revoke", lang.L("不再生效：", "no longer applies: ") + lang.L("；", "; ").join(sorted(texts)), 0))
        if not applied_to:
            raise ValueError("没有找到仍在生效的设定或持续打算：{}".format(revoke_id))
        record = self._base_intervention_record(item, step, "applied")
        record.update({"targets": applied_to, "revoke_id": revoke_id,
                       "text": item.get("text") or (lang.L("撤销：", "revoked: ") + lang.L("；", "; ").join(sorted(texts))),
                       "persistent": False, "psych": {}})
        self._append_intervention_record(record)
        self.logger.info("[intervention:revoke] {} -> {}".format(revoke_id, applied_to))
        return record

    def daily_survey_paths(self):
        folder = os.path.join("results", "surveys", self.name)
        return (
            os.path.join(folder, "daily_survey.jsonl"),
            os.path.join(folder, "daily_survey.csv"),
        )

    def load_daily_survey_rows(self):
        jsonl_path, _ = self.daily_survey_paths()
        rows = []
        if not os.path.exists(jsonl_path):
            return rows
        with open(jsonl_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
        return rows

    def write_daily_survey_rows(self):
        jsonl_path, csv_path = self.daily_survey_paths()
        os.makedirs(os.path.dirname(jsonl_path), exist_ok=True)
        with open(jsonl_path, "w", encoding="utf-8") as f:
            for row in self.daily_survey_rows:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=DAILY_SURVEY_FIELDS)
            writer.writeheader()
            for row in self.daily_survey_rows:
                writer.writerow({field: json.dumps(row[field], ensure_ascii=False) if isinstance(row.get(field), dict)
                                 else row.get(field, "") for field in DAILY_SURVEY_FIELDS})

    def _run_survey_jobs(self, jobs):
        """Run different agents concurrently while preserving each agent's job order."""
        if not jobs:
            return []
        lanes = {}
        for index, (agent_name, job) in enumerate(jobs):
            lanes.setdefault(agent_name, []).append((index, job))
        configured = self.config.get("performance", {}).get("survey_parallel", 2)
        try:
            workers = max(1, min(4, int(configured)))
        except (TypeError, ValueError):
            workers = 2
        results = [None] * len(jobs)

        def run_lane(lane):
            return [(index, job()) for index, job in lane]

        with ThreadPoolExecutor(max_workers=min(workers, len(lanes))) as executor:
            futures = [executor.submit(run_lane, lane) for lane in lanes.values()]
            for future in futures:
                for index, result in future.result():
                    results[index] = result
        return results

    def maybe_complete_daily_survey(self):
        survey_config = self.config.setdefault("daily_survey", default_daily_survey_config())
        if not survey_config.get("enabled", True):
            return

        timer = utils.get_timer()
        current_minutes = timer.daily_duration()
        trigger_minutes = utils.daily_duration(
            utils.to_date(survey_config.get("trigger_time", "22:00"), "%H:%M")
        )
        survey_date = timer.get_date("%Y%m%d")
        completed_dates = survey_config.setdefault("completed_dates", [])
        if current_minutes < trigger_minutes or survey_date in completed_dates:
            return

        condition = self.config.get("experiment", {}).get("condition", "unknown")
        run_id = self.name
        roles = survey_config.get("roles", {})
        self.logger.info(f"Daily survey triggered for {survey_date} at {timer.get_date('%H:%M')}")
        jobs, surveyed_agents = [], []
        for agent_name in survey_config.get("agents", []):
            if agent_name not in self.game.agents:
                continue
            agent = self.game.get_agent(agent_name)
            role = roles.get(agent_name, "employee")
            snapshot = agent.snapshot_survey_context()
            surveyed_agents.append(agent_name)
            jobs.append((agent_name, lambda agent=agent, role=role, snapshot=snapshot:
                agent.complete_daily_survey(
                    role, condition, run_id, survey_date, snapshot=snapshot
                )))

        for agent_name, row in zip(surveyed_agents, self._run_survey_jobs(jobs)):
            self.daily_survey_rows.append(row)
            agent = self.game.get_agent(agent_name)
            self.config["agents"][agent_name].update(agent.to_dict())

        completed_dates.append(survey_date)
        survey_config["latest_rows"] = (
            self.daily_survey_rows[-len(surveyed_agents):] if surveyed_agents else []
        )
        self.write_daily_survey_rows()

    # ------------------------------------------------------------------
    # 自定义问卷（通用问卷引擎，schema由研究者在配置器中定义）
    # ------------------------------------------------------------------
    def custom_survey_paths(self, survey_id):
        folder = os.path.join("results", "surveys", self.name)
        os.makedirs(folder, exist_ok=True)
        return (
            os.path.join(folder, f"custom_{survey_id}.jsonl"),
            os.path.join(folder, f"custom_{survey_id}.csv"),
        )

    def load_custom_survey_rows(self, survey_id):
        jsonl_path, _ = self.custom_survey_paths(survey_id)
        rows = []
        if os.path.exists(jsonl_path):
            with open(jsonl_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        rows.append(json.loads(line))
        return rows

    def write_custom_survey_rows(self, schema, rows):
        from modules import survey as survey_engine
        jsonl_path, csv_path = self.custom_survey_paths(schema["id"])
        with open(jsonl_path, "w", encoding="utf-8") as f:
            for row in rows:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        fieldnames = survey_engine.csv_fieldnames(schema)
        with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow(survey_engine.row_for_csv(row, schema))

    def _last_survey_day(self, schema, origin_date):
        """Day number of the last day whose trigger time falls within this run (V24)."""
        final = getattr(self, "_final_step_time", None)
        if final is None:
            return None
        trigger = datetime.datetime.strptime(schema.get("trigger_time", "22:00"), "%H:%M").time()
        last_date = final.date() if final.time() >= trigger else final.date() - datetime.timedelta(days=1)
        return (last_date - origin_date).days + 1

    def _cheap_survey_jobs(self, triggered, condition, survey_date, cheap):
        """Cheap mode: survey jobs with H2 (identical questionnaires answered once) and
        H5 (several questionnaires per call for the same person and rated colleague).
        Returns (jobs, affected_agents, copies) where copies maps a survey id to the ids
        of identical questionnaires that receive a copy of its answers."""
        primaries, copies = [], {}
        if cheap.get("survey_dedupe"):
            first = {}
            for schema in triggered:
                signature = cheap_mode.survey_signature(schema)
                if signature in first:
                    copies.setdefault(first[signature], []).append(schema["id"])
                    self.logger.info("Cheap mode: survey '{}' is identical to '{}'; answers are copied".format(
                        schema["id"], first[signature]))
                else:
                    first[signature] = schema["id"]
                    primaries.append(schema)
        else:
            primaries = list(triggered)

        # (respondent, rated colleague or None) -> questionnaires in their original order
        lanes, all_agents = {}, list(self.game.agents.keys())
        for schema in primaries:
            if schema.get("mode") == "dyadic":
                raters = [a for a in (schema.get("raters") or all_agents) if a in self.game.agents]
                ratees = [a for a in (schema.get("ratees") or all_agents) if a in self.game.agents]
                pairs = [(r, e) for r in raters for e in ratees if r != e]
            else:
                targets = schema.get("targets") or all_agents
                pairs = [(a, None) for a in targets if a in self.game.agents]
            for pair in pairs:
                lanes.setdefault(pair, []).append(schema)

        jobs, affected_agents = [], []
        for (agent_name, ratee), schemas in lanes.items():
            agent = self.game.get_agent(agent_name)
            if agent_name not in affected_agents:
                affected_agents.append(agent_name)
            if cheap.get("survey_merge") and agent.cheap_survey_layout():
                for chunk in cheap_mode.chunk_surveys(schemas, cheap.get("merge_max_surveys", 5),
                                                      cheap.get("merge_max_items", 40)):
                    snapshot = agent.snapshot_survey_bundle(chunk, ratee)
                    jobs.append((agent_name, lambda agent=agent, chunk=chunk, ratee=ratee, snapshot=snapshot:
                        agent.complete_survey_bundle(chunk, ratee, condition, self.name, survey_date, snapshot)))
                continue
            for schema in schemas:
                sid = schema["id"]
                if ratee:
                    snapshot = agent.snapshot_dyadic_survey(ratee, schema)
                    jobs.append((agent_name, lambda agent=agent, ratee=ratee, snapshot=snapshot, schema=schema, sid=sid:
                        (sid, agent.complete_dyadic_survey(schema, ratee, condition, self.name, survey_date,
                                                           snapshot=snapshot))))
                else:
                    snapshot = agent.snapshot_survey_context(schema)
                    jobs.append((agent_name, lambda agent=agent, snapshot=snapshot, schema=schema, sid=sid:
                        (sid, agent.complete_custom_survey(schema, condition, self.name, survey_date,
                                                           snapshot=snapshot))))
        return jobs, affected_agents, copies

    def maybe_complete_custom_surveys(self):
        schemas = self.config.get("custom_surveys") or []
        if not schemas:
            return
        timer = utils.get_timer()
        current_minutes = timer.daily_duration()
        survey_date = timer.get_date("%Y%m%d")
        condition = self.config.get("experiment", {}).get("condition", "none")
        if not hasattr(self, "custom_survey_rows"):
            self.custom_survey_rows = {}

        # 先为本步所有到期问卷冻结上下文，再开始任何模型请求。
        # jobs 仍按 schema/target 原始顺序排列；_run_survey_jobs 只跨人物并行，
        # 同一人物的多份问卷和多个评价对象保持串行。
        triggered, jobs, affected_agents = [], [], []
        for schema in schemas:
            if not schema.get("enabled", True):
                continue
            trigger_minutes = utils.daily_duration(
                utils.to_date(schema.get("trigger_time", "22:00"), "%H:%M")
            )
            completed_dates = schema.setdefault("completed_dates", [])
            if current_minutes < trigger_minutes or survey_date in completed_dates:
                continue
            if schema.get("days"):
                # V23: surveys limited to given simulation days (e.g. the day-1 personality check);
                # V24: "last" = the last day on which this survey's trigger time is reached.
                origin = self.config.get("simulation_start") or (self.config.get("setup_payload") or {}).get("start_time")
                if origin:
                    from modules import survey as survey_engine
                    origin_date = datetime.datetime.strptime(origin, "%Y%m%d-%H:%M").date()
                    day_no = (timer.get_date().date() - origin_date).days + 1
                    if day_no not in survey_engine.resolve_days(schema["days"], self._last_survey_day(schema, origin_date)):
                        continue
            sid = schema["id"]
            if sid not in self.custom_survey_rows:
                self.custom_survey_rows[sid] = self.load_custom_survey_rows(sid)
            triggered.append(schema)
            self.logger.info(
                "Custom survey '{}' (mode={}) triggered for {} at {}".format(
                    sid, schema.get("mode", "self"), survey_date, timer.get_date("%H:%M")
                )
            )
        cheap = cheap_mode.settings(self.config)
        if cheap:
            jobs, affected_agents, copies = self._cheap_survey_jobs(triggered, condition, survey_date, cheap)
        else:
            copies = {}
            for schema in triggered:
                sid = schema["id"]
                if schema.get("mode") == "dyadic":
                    all_agents = list(self.game.agents.keys())
                    raters = [a for a in (schema.get("raters") or all_agents) if a in self.game.agents]
                    ratees = [a for a in (schema.get("ratees") or all_agents) if a in self.game.agents]
                    pairs = [(r, e) for r in raters for e in ratees if r != e]
                    if len(pairs) > 200:
                        self.logger.warning(
                            "Dyadic survey '{}' has {} pairs; consider narrowing raters/ratees.".format(sid, len(pairs))
                        )
                    for rater, ratee in pairs:
                        agent = self.game.get_agent(rater)
                        snapshot = agent.snapshot_dyadic_survey(ratee, schema)
                        if rater not in affected_agents:
                            affected_agents.append(rater)
                        jobs.append((rater, lambda agent=agent, ratee=ratee,
                                    snapshot=snapshot, schema=schema, sid=sid:
                            (sid, agent.complete_dyadic_survey(
                                schema, ratee, condition, self.name, survey_date,
                                snapshot=snapshot,
                            ))))
                else:
                    targets = schema.get("targets") or list(self.game.agents.keys())
                    for agent_name in targets:
                        if agent_name not in self.game.agents:
                            continue
                        agent = self.game.get_agent(agent_name)
                        snapshot = agent.snapshot_survey_context(schema)
                        if agent_name not in affected_agents:
                            affected_agents.append(agent_name)
                        jobs.append((agent_name, lambda agent=agent, snapshot=snapshot,
                                    schema=schema, sid=sid:
                            (sid, agent.complete_custom_survey(
                                schema, condition, self.name, survey_date,
                                snapshot=snapshot,
                            ))))

        for result in self._run_survey_jobs(jobs):
            # cheap mode H5: a merged job returns several (survey_id, row) pairs
            for sid, row in (result if isinstance(result, list) else [result]):
                self.custom_survey_rows[sid].append(row)
                for copy_sid in copies.get(sid, []):
                    # cheap mode H2: an identical questionnaire due at the same time
                    copied = copy.deepcopy(row)
                    copied["survey_id"] = copy_sid
                    copied["_context"] = dict(copied.get("_context") or {}, copied_from=sid)
                    self.custom_survey_rows[copy_sid].append(copied)
        for agent_name in affected_agents:
            self.config["agents"][agent_name].update(
                self.game.get_agent(agent_name).to_dict()
            )
        for schema in triggered:
            sid = schema["id"]
            completed_dates = schema.setdefault("completed_dates", [])
            completed_dates.append(survey_date)
            self.write_custom_survey_rows(schema, self.custom_survey_rows[sid])


# 从存档数据中载入配置，用于断点恢复
def get_config_from_log(checkpoints_folder):
    files = sorted(os.listdir(checkpoints_folder))

    json_files = list()
    for file_name in files:
        if file_name.startswith("simulate-") and file_name.endswith(".json"):
            json_files.append(os.path.join(checkpoints_folder, file_name))

    if len(json_files) < 1:
        return None

    with open(json_files[-1], "r", encoding="utf-8") as f:
        config = json.load(f)

    assets_root = os.path.join("assets", "village")

    start_time = datetime.datetime.strptime(config["time"], "%Y%m%d-%H:%M")
    start_time += datetime.timedelta(minutes=config["stride"])
    config["time"] = {"start": start_time.strftime("%Y%m%d-%H:%M")}
    agents = config["agents"]
    for a in agents:
        config["agents"][a]["config_path"] = os.path.join(assets_root, "agents", a.replace(" ", "_"), "agent.json")
    config.setdefault("daily_survey", default_daily_survey_config())

    return config


def apply_env_overrides(config):
    keys = config.setdefault("api_keys", {})
    for key in [
        "OPENAI_API_KEY",
        "OPENROUTER_API_KEY",
        "DEEPSEEK_API_KEY",
        "GEMINI_API_KEY",
        "ANTHROPIC_API_KEY",
        "DASHSCOPE_API_KEY",
        "EMBEDDING_API_KEY",
        "OPENROUTER_SITE_URL",
        "OPENROUTER_APP_NAME",
        "QIANFAN_AK",
        "QIANFAN_SK",
        "SPARK_APPID",
        "SPARK_API_SECRET",
        "SPARK_API_KEY",
        "ZHIPUAI_API_KEY",
    ]:
        value = os.getenv(key)
        if value:
            keys[key] = value
    return config


def default_daily_survey_config(enabled=True):
    return {
        "enabled": enabled,
        "trigger_time": "22:00",
        "agents": ["阿伊莎", "玛丽亚", "沃尔夫冈", "克劳斯"],
        "roles": {
            "阿伊莎": "employee",
            "玛丽亚": "employee",
            "沃尔夫冈": "employee",
            "克劳斯": "leader",
        },
        "completed_dates": [],
        "latest_rows": [],
    }


def apply_experiment_condition(config, condition):
    if not condition:
        return config
    path = os.path.join("data", "experiment_conditions.json")
    with open(path, "r", encoding="utf-8") as f:
        conditions = json.load(f)
    if condition not in conditions:
        raise ValueError(f"Unknown condition '{condition}'. Choose one of: {', '.join(conditions)}")
    experiment = conditions[condition]
    if config.get("language", "zh") != "zh":
        # V27: an English world uses the condition's English text (same condition name).
        translated = (experiment.get("translations") or {}).get(config["language"])
        if not translated:
            raise ValueError(f"Condition '{condition}' has no {config['language']} text")
        experiment = {**experiment, **translated}
    agent_overrides = copy.deepcopy(experiment.get("agent_overrides", {}))
    leader = experiment.get("leader")
    if leader and experiment.get("leader_overrides"):
        agent_overrides[leader] = utils.update_dict(
            agent_overrides.get(leader, {}),
            copy.deepcopy(experiment["leader_overrides"]),
        )
    for agent_name, overrides in agent_overrides.items():
        if agent_name not in config["agents"]:
            raise ValueError(f"Experiment agent '{agent_name}' is not in this simulation")
        config["agents"][agent_name] = utils.update_dict(config["agents"][agent_name], overrides)
    config["experiment"] = {
        "condition": condition,
        "description": experiment["description"],
        "leader": leader,
        "agent_overrides": list(agent_overrides.keys()),
    }
    return config


def sanitize_config_for_save(config):
    def redact(value):
        if isinstance(value, dict):
            clean = {}
            for key, item in value.items():
                lowered = key.lower()
                if "api_key" in lowered or lowered in ("authorization", "access_token", "password"):
                    clean[key] = {k: "" for k in item} if isinstance(item, dict) else [] if isinstance(item, list) else ""
                else:
                    clean[key] = redact(item)
            return clean
        if isinstance(value, list):
            return [redact(item) for item in value]
        return copy.deepcopy(value)
    return redact(config)


# 为新游戏创建配置
def get_config(start_time="20240213-09:30", stride=15, agents=None, condition=None, daily_survey_enabled=True):
    with open("data/config.json", "r", encoding="utf-8") as f:
        json_data = json.load(f)
        agent_config = json_data["agent"]

    assets_root = os.path.join("assets", "village")
    config = {
        "stride": stride,
        "time": {"start": start_time},
        "maze": {"path": os.path.join(assets_root, "maze.json")},
        "navigation_policy": "office-solid-v1",
        "perception_policy": "step_end_v24",
        "injection_reaction": True,
        "agent_base": dict(agent_config, office_rhythm="rules_v25"),
        "agents": {},
        "api_keys": json_data["api_keys"],
        "daily_survey": default_daily_survey_config(enabled=daily_survey_enabled),
    }
    for a in agents:
        config["agents"][a] = {
            "config_path": os.path.join(
                assets_root, "agents", a.replace(" ", "_"), "agent.json"
            ),
        }
    config = apply_experiment_condition(config, condition)
    return apply_env_overrides(config)


load_dotenv(find_dotenv())

def _build_parser():
    parser = argparse.ArgumentParser(description="console for village")
    parser.add_argument("--name", type=str, default="", help="The simulation name")
    parser.add_argument("--start", type=str, default="20240213-09:30", help="The starting time of the simulated ville")
    parser.add_argument("--resume", action="store_true", help="Resume running the simulation")
    parser.add_argument("--step", type=int, default=10, help="The simulate step")
    parser.add_argument("--stride", type=int, default=10, help="The step stride in minute")
    parser.add_argument("--verbose", type=str, default="debug", help="The verbose level")
    parser.add_argument("--log", type=str, default="", help="Name of the log file")
    parser.add_argument("--condition", type=str, default="", help="Experimental condition (a key in data/experiment_conditions.json)")
    parser.add_argument("--seed", type=int, default=0, help="Random seed for local simulation choices")
    parser.add_argument("--disable-daily-survey", action="store_true", help="Disable the in-simulation 22:00 daily survey")
    return parser


if __name__ == "__main__":
    args = _build_parser().parse_args()
    if args.seed:
        random.seed(args.seed)

    checkpoints_path = "results/checkpoints"

    name = args.name
    if len(name) < 1:
        name = input("Please enter a simulation name (e.g. sim-test): ")

    resume = args.resume
    if resume:
        while not os.path.exists(f"{checkpoints_path}/{name}"):
            name = input(f"'{name}' doesn't exists, please re-enter the simulation name: ")
    else:
        while os.path.exists(f"{checkpoints_path}/{name}"):
            name = input(f"The name '{name}' already exists, please enter a new name: ")

    checkpoints_folder = f"{checkpoints_path}/{name}"

    start_time = args.start
    if resume:
        sim_config = get_config_from_log(checkpoints_folder)
        if sim_config is None:
            print("No checkpoint file found to resume running.")
            exit(0)
        sim_config = apply_env_overrides(sim_config)
        start_step = sim_config["step"]
    else:
        sim_config = get_config(start_time, args.stride, personas, args.condition, not args.disable_daily_survey)
        start_step = 0

    static_root = "frontend/static"

    server = SimulateServer(name, static_root, checkpoints_folder, sim_config, start_step, args.verbose, args.log)
    server.simulate(args.step, args.stride)
