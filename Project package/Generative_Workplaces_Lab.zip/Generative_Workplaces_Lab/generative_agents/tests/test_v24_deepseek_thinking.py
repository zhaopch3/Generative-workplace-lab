# -*- coding: utf-8 -*-
"""V24: the official DeepSeek API is called with thinking disabled unless configured."""
import os
import unittest
from types import SimpleNamespace
from unittest import mock

from modules.model import llm_model


class FakeCompletions:
    def __init__(self):
        self.kwargs = None

    def create(self, **kwargs):
        self.kwargs = kwargs
        message = SimpleNamespace(content="OK")
        usage = SimpleNamespace(prompt_tokens=5, completion_tokens=1, total_tokens=6)
        return SimpleNamespace(choices=[SimpleNamespace(message=message)], usage=usage)


def fake_model(base_url, config=None):
    model = llm_model.OpenAILLMModel.__new__(llm_model.OpenAILLMModel)
    model._base_url = base_url
    model._config = config or {}
    model._model = "deepseek-flash"
    model._timeout = 60
    model._call_usage = None
    completions = FakeCompletions()
    model._handle = SimpleNamespace(base_url=base_url, chat=SimpleNamespace(completions=completions))
    return model, completions


class DeepSeekThinkingTests(unittest.TestCase):
    def setUp(self):
        self.env = mock.patch.dict(os.environ, {}, clear=False)
        self.env.start()
        os.environ.pop("DEEPSEEK_THINKING", None)

    def tearDown(self):
        self.env.stop()

    def test_deepseek_default_disables_thinking(self):
        model, calls = fake_model("https://api.deepseek.com/v1")
        self.assertEqual(model._completion("hi"), "OK")
        self.assertEqual(calls.kwargs["extra_body"], {"thinking": {"type": "disabled"}})

    def test_config_or_env_can_enable(self):
        model, calls = fake_model("https://api.deepseek.com/v1", {"thinking": "enabled"})
        model._completion("hi")
        self.assertEqual(calls.kwargs["extra_body"]["thinking"], {"type": "enabled"})
        os.environ["DEEPSEEK_THINKING"] = "disabled"
        model._completion("hi")
        self.assertEqual(calls.kwargs["extra_body"]["thinking"], {"type": "disabled"})

    def test_other_endpoints_untouched(self):
        model, calls = fake_model("https://openrouter.ai/api/v1")
        model._completion("hi")
        self.assertNotIn("thinking", calls.kwargs.get("extra_body", {}))
        self.assertEqual(llm_model.deepseek_thinking("https://api.openai.com/v1"), "")


if __name__ == "__main__":
    unittest.main()
