# -*- coding: utf-8 -*-
"""V25.1 cheap mode: off by default and absent from main-mode configs; settings, grouping,
prompt parsing, merged surveys with single fallback, batched importance, skipped decomposition."""
import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import server  # noqa: E402
from modules import cheap_mode, survey, utils  # noqa: E402
from modules.prompt.scratch import Scratch  # noqa: E402


def load(name):
    with open(ROOT / "data" / "world_presets" / (name + ".json"), encoding="utf-8") as f:
        return json.load(f)


def scratch():
    s = Scratch("阿伊莎", "", {"age": 28, "innate": "", "learned": "", "lifestyle": "", "daily_plan": ""})
    s.template_path = str(ROOT / "data" / "prompts")
    return s


class SettingsTests(unittest.TestCase):
    def test_off_means_none(self):
        for raw in (None, {}, {"enabled": False}, False, ""):
            self.assertIsNone(cheap_mode.normalize(raw))

    def test_defaults_and_stride(self):
        s = cheap_mode.normalize({"enabled": True}, stride=60)
        self.assertTrue(s["survey_merge"] and s["cache_order"] and s["poignancy_batch"])
        self.assertFalse(s["short_context"])
        self.assertTrue(s["skip_decompose_effective"])
        self.assertFalse(cheap_mode.normalize({"enabled": True}, stride=10)["skip_decompose_effective"])
        s = cheap_mode.normalize({"enabled": True, "merge_max_surveys": 99, "survey_merge": False})
        self.assertEqual(s["merge_max_surveys"], 10)
        self.assertFalse(s["survey_merge"])

    def test_main_mode_config_has_no_cheap_keys(self):
        payload = load("人设操纵-高辱虐组")
        payload.update(name="v251-main", offline=True)
        _, _, cfg = server.build_experiment_config(payload)
        self.assertNotIn("cheap_mode", cfg)
        self.assertNotIn("cheap_mode", cfg["agent_base"])

    def test_cheap_config(self):
        payload = load("人设操纵-高辱虐组")
        payload.update(name="v251-cheap", offline=True, cheap_mode={"enabled": True})
        _, _, cfg = server.build_experiment_config(payload)
        self.assertTrue(cfg["cheap_mode"]["enabled"])
        self.assertEqual(cfg["agent_base"]["cheap_mode"]["version"], cheap_mode.VERSION)

    def test_comparison_signature_separates_modes(self):
        world = load("人设操纵-高辱虐组")
        cheap = dict(world, cheap_mode={"enabled": True})
        self.assertNotEqual(server.comparison_signature(world), server.comparison_signature(cheap))
        self.assertTrue(server.comparison_summary(cheap)["cheap_mode"])
        self.assertFalse(server.comparison_summary(world)["cheap_mode"])


class SurveyHelperTests(unittest.TestCase):
    def schema(self, sid, n=3, **extra):
        return survey.validate_schema(dict({"id": sid, "questions": [
            {"id": "i%d" % i, "text": "题%d" % i, "min": 1, "max": 5} for i in range(1, n + 1)]}, **extra))

    def test_signature(self):
        a, b = self.schema("a"), self.schema("b")
        self.assertEqual(cheap_mode.survey_signature(a), cheap_mode.survey_signature(b))
        c = self.schema("c", time_frame="general")
        self.assertNotEqual(cheap_mode.survey_signature(a), cheap_mode.survey_signature(c))

    def test_chunks(self):
        schemas = [self.schema("s%d" % i, n) for i, n in enumerate([10, 10, 10, 15, 50, 2])]
        chunks = cheap_mode.chunk_surveys(schemas, 5, 30)
        self.assertEqual([[s["id"] for s in c] for c in chunks], [["s0", "s1", "s2"], ["s3"], ["s4"], ["s5"]])

    def test_merged_prompt_and_partial_parse(self):
        utils.set_timer("20240214-21:00")
        a, b = self.schema("a", 2), self.schema("b", 2)
        p = scratch().prompt_custom_survey_merged([a, b], "20240214-21:00", "共同经历", "更早的事")
        text = p["prompt"]
        self.assertLess(text.index("共同经历"), text.index("【问卷 S1】"))
        self.assertIn("更早的事", text)
        out = p["callback"]('{"S1": {"i1": 2, "i2": 3}, "S2": {"i1": 4, "i2": 9}}')
        self.assertEqual(sorted(out), [0, 1])
        self.assertEqual(out[0]["_quality"]["status"], "valid")
        self.assertEqual(out[1]["_quality"]["status"], "partial")
        out = p["callback"]('{"S1": {"i1": 2, "i2": 3}, "S2": "x"}')
        self.assertEqual(sorted(out), [0])
        self.assertIsNone(p["callback"]("not json"))

    def test_cache_prompt_puts_title_after_context(self):
        utils.set_timer("20240214-21:00")
        a = self.schema("a", 2, display_title="今日问卷")
        p = scratch().prompt_custom_survey_cache(a, "20240214-21:00", "共同经历", "", ratee="克劳斯")
        text = p["prompt"]
        self.assertLess(text.index("共同经历"), text.index("今日问卷"))
        self.assertIn("关于 克劳斯 的", text)
        self.assertEqual(p["callback"]('{"i1": 1, "i2": 5}')["i2"], 5)

    def test_poignancy_batch_parse(self):
        utils.set_timer("20240214-10:00")
        p = scratch().prompt_poignancy_batch([("event", "克劳斯在骂人"), ("chat", "闲聊")])
        self.assertIn("（对话）闲聊", p["prompt"])
        self.assertEqual(p["callback"]("[7, 2]"), [7, 2])
        self.assertEqual(p["callback"]('评分：["7", 2]'), [7, 2])
        self.assertIsNone(p["callback"]("[7]"))
        self.assertIsNone(p["callback"]("[0, 11]"))
        self.assertIsNone(p["callback"]("[2.5, 3]"))


class FakeLLM:
    """Answers questionnaires from the format example; merged calls drop the last survey
    so that the single-call fallback is exercised."""

    def __init__(self):
        self.calls = []
        self.meta_responses = []

    def is_available(self):
        return True

    def get_summary(self):
        return {}

    def completion(self, prompt, retry=10, callback=None, failsafe=None, caller="", **kwargs):
        self.calls.append(caller)
        if caller == "custom_survey_merged":
            example = json.loads(prompt.rsplit("输出格式示例：", 1)[1].strip())
            example.pop(sorted(example)[-1])
            return callback(json.dumps(example))
        if caller.startswith("custom_survey"):
            return callback(prompt.rsplit("输出格式示例：", 1)[1].strip())
        if caller == "poignancy_batch":
            import re
            n = int(re.search(r"需要评分的 (\d+) 个事件", prompt).group(1))
            return callback(json.dumps([5] * n))
        if caller in ("poignancy_event", "poignancy_chat"):
            return callback("评分：5")
        return failsafe


class WorldTests(unittest.TestCase):
    """One offline day with a fake model: main mode vs cheap mode."""

    def run_day(self, cheap):
        from start import SimulateServer
        origin = Path.cwd()
        payload = load("人设操纵-高辱虐组")
        payload.update(name="v251-" + ("cheap" if cheap else "main"), offline=True, step=15)
        if cheap:
            payload["cheap_mode"] = {"enabled": True}
        _, args, cfg = server.build_experiment_config(payload)
        with tempfile.TemporaryDirectory() as root:
            os.chdir(root)
            try:
                run = SimulateServer(args.name, str(origin / "frontend/static"),
                                     "results/checkpoints/" + args.name, cfg, verbose="error")
                fakes = []
                for agent in run.game.agents.values():
                    agent.scratch.template_path = str(origin / "data/prompts")
                    agent._llm = FakeLLM()
                    fakes.append(agent._llm)
                run.simulate(15, stride=60)
                rows = {}
                folder = "results/surveys/" + args.name
                for f in os.listdir(folder):
                    if f.startswith("custom_") and f.endswith(".jsonl"):
                        with open(os.path.join(folder, f), encoding="utf-8") as fh:
                            rows[f[7:-6]] = [json.loads(x) for x in fh]
                calls = [c for fake in fakes for c in fake.calls]
                ckpt = sorted(os.listdir("results/checkpoints/" + args.name))
                with open(os.path.join("results/checkpoints", args.name,
                                       [c for c in ckpt if c.startswith("simulate-")][-1]), encoding="utf-8") as fh:
                    saved = json.load(fh)
                return rows, calls, saved
            finally:
                os.chdir(origin)

    def test_main_vs_cheap(self):
        main_rows, main_calls, main_saved = self.run_day(False)
        cheap_rows, cheap_calls, cheap_saved = self.run_day(True)
        # same questionnaires, same respondents, every answer usable
        self.assertEqual(sorted(main_rows), sorted(cheap_rows))
        count = lambda rows: sorted((sid, r["agent"], r.get("ratee", "")) for sid, v in rows.items() for r in v)
        self.assertEqual(count(main_rows), count(cheap_rows))
        for rows in (main_rows, cheap_rows):
            self.assertTrue(all(r["_quality"]["status"] == "valid" for v in rows.values() for r in v))
        # main mode never uses the cheap prompts; cheap mode merges and falls back
        self.assertFalse({"custom_survey_merged", "custom_survey_cache", "poignancy_batch"} & set(main_calls))
        self.assertIn("custom_survey_merged", cheap_calls)
        self.assertIn("custom_survey_cache", cheap_calls)
        self.assertNotIn("schedule_decompose", cheap_calls)
        self.assertIn("schedule_decompose", main_calls)
        survey_calls = lambda calls: sum(c.startswith("custom_survey") for c in calls)
        self.assertLess(survey_calls(cheap_calls), survey_calls(main_calls) / 2)
        calls_of = [r["_context"].get("cheap_mode", {}).get("call") for v in cheap_rows.values() for r in v]
        self.assertIn("merged", calls_of)
        self.assertIn("single", calls_of)
        self.assertNotIn("cheap_mode", json.dumps(main_rows, ensure_ascii=False))
        # the setting is saved with the world, so a resumed world stays in its mode
        self.assertNotIn("cheap_mode", main_saved)
        self.assertTrue(cheap_saved["cheap_mode"]["enabled"])
        agent = next(iter(cheap_saved["agents"].values()))
        self.assertTrue(agent["cheap_mode"]["enabled"])


class DedupeTests(unittest.TestCase):
    def test_identical_surveys_copied(self):
        from start import SimulateServer
        agent = SimpleNamespace(cheap_survey_layout=lambda: False,
                                snapshot_survey_context=lambda schema: {},
                                complete_custom_survey=lambda schema, *a, **k: {"survey_id": schema["id"], "x": 1})
        server_obj = SimulateServer.__new__(SimulateServer)
        server_obj.name = "w"
        server_obj.logger = SimpleNamespace(info=lambda *a, **k: None)
        server_obj.game = SimpleNamespace(agents={"甲": agent}, get_agent=lambda n: agent)
        q = [{"id": "i1", "type": "likert", "text": "题", "min": 1, "max": 5}]
        schemas = [{"id": "a", "questions": q, "targets": ["甲"]}, {"id": "b", "questions": copy.deepcopy(q), "targets": ["甲"]},
                   {"id": "c", "questions": q, "targets": ["甲"], "time_frame": "week"}]
        jobs, affected, copies = server_obj._cheap_survey_jobs(
            schemas, "cond", "20240212", {"survey_dedupe": True, "survey_merge": False})
        self.assertEqual(copies, {"a": ["b"]})
        self.assertEqual([job()[0] for _, job in jobs], ["a", "c"])
        self.assertEqual(affected, ["甲"])


if __name__ == "__main__":
    unittest.main()
