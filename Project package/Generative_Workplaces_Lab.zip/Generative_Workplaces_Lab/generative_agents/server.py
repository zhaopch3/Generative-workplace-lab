# -*- coding: utf-8 -*-
"""实时模拟服务器 + 研究者控制台

两种启动方式：

1. 配置模式（推荐）：先在网页上配置实验（人设/智能体数量/问卷/条件），再启动
       python server.py
   打开 http://127.0.0.1:5001/setup 完成配置并点击"启动实验"。

2. 直接启动（与旧版CLI一致）：
       python server.py --name live-001 --step 100 --stride 10 --condition high_abuse
       python server.py --name offline-test --step 20 --offline
       python server.py --name live-001 --resume --step 50

页面：
    /setup    实验配置器（问卷设计、人设编辑、智能体选择）
    /         实时地图
    /console  研究者控制台（干预、数据、导出）
"""
import argparse
import copy
import hashlib
import json
import secrets
import os
import queue
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import types
import uuid

from dotenv import load_dotenv, find_dotenv
from flask import Flask, Response, jsonify, redirect, render_template, request, send_file

import start as sim
from start import (
    SimulateServer,
    apply_env_overrides,
    apply_experiment_condition,
    get_config,
    get_config_from_log,
    personas,
)
from modules import survey as survey_engine
from modules import exporter
from modules import posthoc
from modules import utils

load_dotenv(find_dotenv())

STATIC_ROOT = "frontend/static"
CHECKPOINTS_PATH = "results/checkpoints"
AGENTS_ROOT = os.path.join(STATIC_ROOT, "assets", "village", "agents")
OFFICE_KEYWORD = "公司办公室"  # 用于判断智能体是否与当前办公室地图兼容

_NAME_RE = re.compile(r"^[\w\-\u4e00-\u9fff]{1,40}$")
RUNTIME_FILE = "runtime.json"
BATCH_MANIFEST = "batch_manifest.json"
BATCH_DELETE_MARKER = ".deleting"


def active_persistent_interventions(history, sim_time=""):
    """V24: applied world settings / persistent intents not yet expired or revoked."""
    revoked = {rec.get("revoke_id") for rec in history
               if rec.get("kind") == "revoke" and rec.get("status") == "applied"}
    out = []
    for rec in history:
        if rec.get("status") != "applied" or rec.get("intervention_id") in revoked:
            continue
        if not (rec.get("kind") == "world_setting" or (rec.get("kind") == "thought" and rec.get("persistent"))):
            continue
        expires = rec.get("expires")
        if expires and sim_time and expires <= sim_time:
            continue
        out.append({key: rec.get(key) for key in (
            "intervention_id", "kind", "text", "targets", "applied_time", "expires", "source")})
    return out


def _atomic_json(path, data, retries=8):
    """原子写JSON；Windows短暂占用目标文件时退避重试。"""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temp = "{}.{}.{}.tmp".format(path, os.getpid(), threading.get_ident())
    for attempt in range(max(1, int(retries))):
        try:
            with open(temp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(temp, path)
            return
        except OSError as exc:
            retryable = (
                isinstance(exc, PermissionError)
                or getattr(exc, "winerror", None) in (5, 32)
            )
            if not retryable or attempt + 1 >= max(1, int(retries)):
                raise
            try:
                os.remove(temp)
            except OSError:
                pass
            time.sleep(min(0.4, 0.025 * (2 ** attempt)))


def runtime_path(name):
    return os.path.join(CHECKPOINTS_PATH, name, RUNTIME_FILE)


def write_runtime_registry(name, port, host="127.0.0.1", status="starting"):
    """把子世界的可发现地址持久化；主服务重启后仍能重新探活。"""
    data = {
        "name": name,
        "port": int(port),
        "host": host or "127.0.0.1",
        "pid": os.getpid(),
        "project_root": os.path.dirname(os.path.abspath(__file__)),
        "status": status,
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    _atomic_json(runtime_path(name), data)
    return data


def probe_runtime(name, timeout=0.6):
    """读取运行注册并真实探活。只把仍可控制的世界暴露为live。"""
    path = runtime_path(name)
    try:
        with open(path, "r", encoding="utf-8") as f:
            reg = json.load(f)
        # Copied V20 registrations must never connect V21 controls to a V20 world.
        if os.path.normcase(reg.get("project_root", "")) != os.path.normcase(os.path.dirname(os.path.abspath(__file__))):
            return None
        # 子世界正常结束、停止或报错时会先把最终状态写入注册文件，再退出
        # Web 服务。此时再逐一等待 HTTP 超时既没有意义，也会让拥有大量历史
        # 世界的实验管理页线性变慢（例如 80 个世界约需等待 48 秒）。
        # 只有可能仍在运行的注册项才需要做真实探活。
        registered_status = str(reg.get("status") or "").strip().lower()
        if registered_status in ("finished", "completed", "stopped", "error", "failed"):
            return None
        port = int(reg.get("port", 0))
        if not (1 <= port <= 65535):
            return None
        import urllib.request
        with urllib.request.urlopen(
                "http://127.0.0.1:{}/api/state".format(port), timeout=timeout) as resp:
            state = json.loads(resp.read())
        if state.get("name") != name:
            return None
        status = state.get("status", "")
        if status not in ("initializing", "running", "paused"):
            return None
        return {
            "status": status,
            "port": port,
            "step": int(state.get("step", 0) or 0),
            "cockpit_url": "/cockpit",
        }
    except (OSError, ValueError, json.JSONDecodeError):
        return None


# ---------------------------------------------------------------------------
# 事件总线：模拟线程 -> 多个浏览器客户端（SSE）
# ---------------------------------------------------------------------------
class EventBus:
    def __init__(self, history_limit=500):
        self._clients = []
        self._lock = threading.Lock()
        self.history = []
        self.history_limit = history_limit

    def subscribe(self):
        q = queue.Queue(maxsize=1000)
        with self._lock:
            self._clients.append(q)
        return q

    def unsubscribe(self, q):
        with self._lock:
            if q in self._clients:
                self._clients.remove(q)

    def publish(self, event):
        if event.get("type") == "step":
            self.history.append(event)
            if len(self.history) > self.history_limit:
                self.history = self.history[-self.history_limit:]
        with self._lock:
            clients = list(self._clients)
        for q in clients:
            try:
                q.put_nowait(event)
            except queue.Full:
                pass


# ---------------------------------------------------------------------------
# 智能体资源辅助
# ---------------------------------------------------------------------------
_MANGLED_RE = re.compile(r"#U([0-9a-fA-F]{4})")


def repair_mangled_asset_names():
    """修复Windows解压中文文件名产生的 #Uxxxx 乱码目录/文件名。

    某些解压工具会把 UTF-8 文件名转成 '#U963f#U4f0a#U838e' 这种转义形式，
    导致智能体资源目录找不到、模拟启动时报 JSONDecodeError。
    服务启动时自动扫描并改回正确的中文名。
    """
    fixed = []
    for base in (AGENTS_ROOT, os.path.join(STATIC_ROOT, "assets")):
        if not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base, topdown=False):
            for n in files + dirs:
                if "#U" in n:
                    new_name = _MANGLED_RE.sub(lambda m: chr(int(m.group(1), 16)), n)
                    if new_name != n:
                        src_p = os.path.join(root, n)
                        dst_p = os.path.join(root, new_name)
                        if not os.path.exists(dst_p):
                            os.rename(src_p, dst_p)
                            fixed.append(new_name)
    if fixed:
        print("[自动修复] 已还原 {} 个乱码文件/目录名（Windows解压中文名问题），例如：{}".format(
            len(fixed), "、".join(fixed[:5])))
    return fixed


def scan_experiments():
    """扫描 results/checkpoints 下的所有历史实验，返回元信息列表。"""
    out = []
    if not os.path.isdir(CHECKPOINTS_PATH):
        return out
    for name in sorted(os.listdir(CHECKPOINTS_PATH)):
        folder = os.path.join(CHECKPOINTS_PATH, name)
        if not os.path.isdir(folder):
            continue
        meta = {"name": name, "step": 0, "time": "", "condition": "",
                "agents": [], "files": [], "batch": None, "live": None}
        try:
            json_files = sorted(
                f for f in os.listdir(folder)
                if f.startswith("simulate-") and f.endswith(".json")
            )
            if json_files:
                with open(os.path.join(folder, json_files[-1]), "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                meta["step"] = cfg.get("step", 0)
                t = cfg.get("time", "")
                meta["time"] = t if isinstance(t, str) else t.get("start", "")
                meta["condition"] = (cfg.get("experiment") or {}).get("condition", "") or "无"
                meta["agents"] = list((cfg.get("agents") or {}).keys())
                if cfg.get("batch"):
                    meta["batch"] = cfg["batch"]
        except (json.JSONDecodeError, OSError):
            meta["condition"] = "（存档读取失败）"
        meta["live"] = probe_runtime(name)
        # 可下载的数据文件
        for sub, label in (("surveys", "问卷"), ("psych", "心理"),
                           ("monitor", "监控"), ("interventions", "干预")):
            d = os.path.join("results", sub, name)
            if os.path.isdir(d):
                for fn in sorted(os.listdir(d)):
                    meta["files"].append({"sub": sub, "file": fn, "label": label})
        out.append(meta)
    return out


_SAFE_PART = re.compile(r"^[\w\-.\u4e00-\u9fff]+$")


def validate_personas(agent_names):
    """启动前校验智能体资源完整性，给出明确的中文错误而不是JSONDecodeError。"""
    problems = []
    for name in agent_names:
        cfg = os.path.join(AGENTS_ROOT, name, "agent.json")
        if not os.path.exists(cfg):
            problems.append(f"缺少 {cfg}")
            continue
        try:
            with open(cfg, "r", encoding="utf-8") as f:
                json.load(f)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            problems.append(f"{cfg} 不是有效JSON（{e}）")
    if problems:
        raise SystemExit(
            "智能体资源校验失败：\n  - " + "\n  - ".join(problems) +
            "\n请确认 frontend/static/assets/village/agents/ 下的中文目录完整。"
            "\n（若目录名是 #Uxxxx 乱码，重启本服务会自动修复；也可从原始包重新解压，"
            "Windows建议用 7-Zip 解压以正确处理中文文件名。）"
        )


def list_available_agents():
    """扫描资源目录，返回可用智能体及其是否兼容办公室地图。"""
    agents = []
    if not os.path.isdir(AGENTS_ROOT):
        return agents
    for name in sorted(os.listdir(AGENTS_ROOT)):
        folder = os.path.join(AGENTS_ROOT, name)
        cfg_path = os.path.join(folder, "agent.json")
        if not os.path.isdir(folder) or not os.path.exists(cfg_path):
            continue
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue
        spatial_text = json.dumps(cfg.get("spatial", {}), ensure_ascii=False)
        office = OFFICE_KEYWORD in spatial_text or "company office" in spatial_text   # V27 English agents
        agents.append({
            "name": name,
            "office_compatible": office,
            "portrait": "/static/assets/village/agents/{}/portrait.png".format(name),
        })
    # 办公室兼容的排在前面；V27.3：英文智能体排在中文之前，四名团队成员各自排在本语言最前
    team = ("Klaus", "Ayesha", "Maria", "Wolfgang", "克劳斯", "阿伊莎", "玛丽亚", "沃尔夫冈")
    agents.sort(key=lambda a: (not a["office_compatible"], bool(re.search(r"[\u4e00-\u9fff]", a["name"])),
                               a["name"] not in team, team.index(a["name"]) if a["name"] in team else 0, a["name"]))
    return agents


def load_agent_persona(name):
    cfg_path = os.path.join(AGENTS_ROOT, name, "agent.json")
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    scratch = cfg.get("scratch", {})
    return {
        "name": name,
        "currently": cfg.get("currently", ""),
        "age": scratch.get("age", ""),
        "innate": scratch.get("innate", ""),
        "learned": scratch.get("learned", ""),
        "lifestyle": scratch.get("lifestyle", ""),
        "daily_plan": scratch.get("daily_plan", ""),
        "coord": cfg.get("coord", [1, 1]),
    }


def clone_agent(source, new_name, appearance=None, workstation=None):
    """克隆一个智能体资源目录，用于扩充智能体数量。
    appearance: 借用其他角色（含村民）的贴图外观（portrait/texture）；
    workstation: 克隆体工位归属（默认公共办公桌，"__source__"=跟随源人物）。"""
    if not _NAME_RE.match(new_name or ""):
        raise ValueError("新名称只能包含中文、字母、数字、下划线或连字符（≤40字符）")
    src_folder = os.path.join(AGENTS_ROOT, source)
    dst_folder = os.path.join(AGENTS_ROOT, new_name)
    if not os.path.isdir(src_folder):
        raise ValueError(f"源智能体不存在：{source}")
    if os.path.exists(dst_folder):
        raise ValueError(f"名称已存在：{new_name}")
    shutil.copytree(src_folder, dst_folder)
    cfg_path = os.path.join(dst_folder, "agent.json")
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    cfg["name"] = new_name
    cfg["portrait"] = "assets/village/agents/{}/portrait.png".format(new_name)
    # V23：随机外观——从人类贴图中随机取一个底版，按发色/上衣/下装重新配色
    if appearance == "__random__":
        from modules import appearance as appearance_mod
        cfg["appearance"] = appearance_mod.generate(
            dst_folder, seed="{}-{}".format(new_name, secrets.token_hex(3)), root=AGENTS_ROOT)
    # 外观借用：覆盖贴图文件（帧定义全局共享、贴图布局一致，即插即用）
    elif appearance and appearance != source:
        ap_folder = os.path.join(AGENTS_ROOT, appearance)
        if not os.path.isdir(ap_folder):
            raise ValueError(f"外观来源不存在：{appearance}")
        for fn in ("portrait.png", "texture.png"):
            ap_file = os.path.join(ap_folder, fn)
            if os.path.exists(ap_file):
                shutil.copy(ap_file, os.path.join(dst_folder, fn))
    # 工位归属：默认公共办公桌（大办公区自由落座）
    if workstation != "__source__":
        cfg["workstation"] = workstation or "公共办公桌"
    # 人设字段替换名字，避免克隆体自称源人物
    for key in ("currently",):
        if isinstance(cfg.get(key), str):
            cfg[key] = cfg[key].replace(source, new_name)
    scratch = cfg.get("scratch", {})
    for key in ("learned", "lifestyle", "daily_plan", "innate"):
        if isinstance(scratch.get(key), str):
            scratch[key] = scratch[key].replace(source, new_name)
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=4)
    return cfg


# ---------------------------------------------------------------------------
# 模拟运行器
# ---------------------------------------------------------------------------
class SimulationRunner:
    def __init__(self, args, prepared_config=None, start_step=0):
        self.args = args
        self.bus = EventBus()
        self.pause_event = threading.Event()
        self.stop_event = threading.Event()
        self.interventions_queue = queue.Queue()
        self.intervention_history = []
        self.state = {
            "status": "initializing",
            "name": args.name,
            "step": 0,
            "total_steps": args.step,
            "time": "",
            "condition": args.condition or "none",
            "agents": {},
            "error": "",
        }
        self.server = None
        self.thread = None
        self.step_records = []  # 回看：每step的世界快照（持久化于 results/monitor/<name>/steps.jsonl）
        if prepared_config is not None:
            self.config = prepared_config
            self.start_step = start_step
            self.checkpoints_folder = f"{CHECKPOINTS_PATH}/{args.name}"
            self.name = args.name
        else:
            self._init_meta()
        self._load_step_records()
        self._load_intervention_state()

    def steps_log_path(self):
        folder = os.path.join("results", "monitor", self.args.name)
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, "steps.jsonl")

    def _load_step_records(self):
        p = self.steps_log_path()
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            self.step_records.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass

    def interventions_folder(self):
        path = os.path.join("results", "interventions", self.name)
        os.makedirs(path, exist_ok=True)
        return path

    def _load_intervention_state(self):
        """Restore audit history and not-yet-applied requests after restart."""
        history_path = os.path.join(self.interventions_folder(), "interventions.jsonl")
        if os.path.isfile(history_path):
            with open(history_path, encoding="utf-8") as handle:
                for line in handle:
                    try:
                        self.intervention_history.append(json.loads(line))
                    except (json.JSONDecodeError, TypeError):
                        continue
        pending_dir = os.path.join(self.interventions_folder(), "pending")
        if not os.path.isdir(pending_dir):
            return
        for filename in sorted(os.listdir(pending_dir)):
            if not filename.endswith(".json"):
                continue
            path = os.path.join(pending_dir, filename)
            try:
                with open(path, encoding="utf-8") as handle:
                    item = json.load(handle)
                item["_pending_path"] = path
                self.interventions_queue.put(item)
            except (OSError, json.JSONDecodeError, TypeError):
                continue

    # -- 初始化配置（与 start.py 主流程一致，CLI直接启动路径） --
    def _init_meta(self):
        args = self.args
        name = args.name
        checkpoints_folder = f"{CHECKPOINTS_PATH}/{name}"

        if args.resume:
            if not os.path.exists(checkpoints_folder):
                raise SystemExit(f"找不到存档目录：{checkpoints_folder}")
            config = get_config_from_log(checkpoints_folder)
            if config is None:
                raise SystemExit("存档目录中没有可恢复的checkpoint。")
            config = apply_env_overrides(config)
            self.start_step = config["step"]
        else:
            if os.path.exists(checkpoints_folder):
                raise SystemExit(
                    f"模拟名称 '{name}' 已存在，请换一个名称或使用 --resume 恢复。"
                )
            validate_personas(personas)
            config = get_config(
                args.start, args.stride, personas, args.condition or None,
                not args.disable_daily_survey,
            )
            self.start_step = 0

        if args.offline:
            apply_offline_overrides(config)

        self.config = config
        self.checkpoints_folder = checkpoints_folder
        self.name = name

    def build(self):
        control = {
            "pause": self.pause_event,
            "stop": self.stop_event,
            "interventions": self.interventions_queue,
        }
        self.server = SimulateServer(
            self.name,
            STATIC_ROOT,
            self.checkpoints_folder,
            self.config,
            start_step=self.start_step,
            verbose=self.args.verbose,
            log_file=self.args.log,
            on_step=self._on_step,
            control=control,
        )

    def _on_step(self, payload):
        self.state["step"] = payload["step"]
        self.state["total_steps"] = payload["total_steps"]
        self.state["time"] = payload["time"]
        self.state["agents"] = payload["agents"]
        if not self.pause_event.is_set():
            self.state["status"] = "running"
        conv = payload.pop("conversation", {}) or {}
        recent_keys = sorted(conv.keys())[-3:]
        payload["conversation_recent"] = {k: conv[k] for k in recent_keys}
        for rec in payload.get("interventions") or []:
            self.intervention_history.append(rec)
        # 回看快照（精简）：坐标/emoji/行为/位置/心理/最后一句对话
        snap_agents = {}
        for name, a in (payload.get("agents") or {}).items():
            action = a.get("action") or {}
            action_text = ""
            if isinstance(action, dict):
                action_text = action.get("event", "") or action.get("describe", "")
            last_chat = ""
            chats = a.get("chats") or []
            if chats:
                last = chats[-1]
                last_chat = last.get("chat", "") if isinstance(last, dict) else str(last)
            snap_agents[name] = {
                "coord": a.get("coord"),
                # V23: replay needs the start cell and policy to animate the recorded path;
                # without them every frame was treated as a legacy record and teleported.
                "prev_coord": a.get("prev_coord"),
                "navigation_policy": a.get("navigation_policy", "legacy"),
                "path": a.get("path") or [],
                "emoji": a.get("emoji", ""),
                "action": action_text,
                "address": a.get("address", ""),
                "psych": a.get("psych", {}),
                "chat": last_chat,
            }
        record = {"step": payload["step"], "time": payload["time"], "agents": snap_agents,
                  "think_order": payload.get("think_order", [])}
        self.step_records.append(record)
        try:
            with open(self.steps_log_path(), "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except OSError:
            pass
        self.bus.publish(payload)

    def initial_positions(self):
        positions = {}
        for agent_name, agent_cfg in self.config.get("agents", {}).items():
            coord = agent_cfg.get("coord")
            if coord is None:
                config_path = agent_cfg.get("config_path", "")
                full = os.path.join(STATIC_ROOT, config_path)
                if os.path.exists(full):
                    with open(full, "r", encoding="utf-8") as f:
                        coord = json.load(f).get("coord")
            positions[agent_name] = coord or [1, 1]
        return positions

    def run(self):
        def _target():
            try:
                self.build()
                self.state["status"] = "running"
                self.bus.publish({"type": "status", "status": "running"})
                self.server.simulate(self.args.step, self.args.stride)
                if self.stop_event.is_set():
                    self.state["status"] = "stopped"
                else:
                    self.state["status"] = "finished"
                self.bus.publish({"type": "status", "status": self.state["status"]})
            except Exception as e:  # noqa: BLE001
                import traceback
                traceback.print_exc()
                self.state["status"] = "error"
                self.state["error"] = str(e)
                self.bus.publish({"type": "status", "status": "error", "error": str(e)})

        self.thread = threading.Thread(target=_target, daemon=True)
        self.thread.start()

    def queue_intervention(self, item):
        psych_values = {}
        from modules import psych as psych_mod
        for k, v in (item.get("psych") or {}).items():
            if k in psych_mod.VARS and v not in (None, ""):
                psych_values[k] = v
        legacy_type = item.get("memory_type")
        kind = item.get("kind") or ("thought" if legacy_type == "thought" else "world_event")
        if kind == "action":
            kind = "specified_action"
        raw_targets = item.get("targets") or []
        if isinstance(raw_targets, str):
            raw_targets = [raw_targets]
        clean = {
            "intervention_id": "iv_" + uuid.uuid4().hex[:16],
            "event_id": "evt_" + uuid.uuid4().hex[:16] if kind in ("world_event", "specified_action") else None,
            "kind": kind,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "scheduled_time": (item.get("scheduled_time") or "").strip(),
            "targets": raw_targets,
            "actor": (item.get("actor") or "").strip() or None,
            "object": (item.get("object") or "").strip() or None,
            "scope": item.get("scope") or ("selected" if item.get("targets") else "all"),
            "location": item.get("location") or "",
            "text": (item.get("text") or "").strip(),
            "poignancy": item.get("poignancy", 8),
            "persistent": bool(item.get("persistent") or item.get("update_currently")),
            "duration": item.get("duration", 30),
            "psych": psych_values,
            "source": item.get("source", "live_console"),
            # V24: decide-on-injection, expiry of settings/intents, withdrawal.
            "react": bool(item.get("react", True)),
            "expires_time": (item.get("expires_time") or "").strip(),
            "persist_days": item.get("persist_days") or None,
            "revoke_id": (item.get("revoke_id") or "").strip(),
        }
        if clean["kind"] == "revoke":
            if not clean["revoke_id"]:
                raise ValueError("撤销需要指定要撤销的设定")
            clean["event_id"] = None
        elif not clean["text"] and not psych_values:
            return None
        known = set(self.config.get("agents", {}).keys())
        clean["targets"] = [t for t in clean["targets"] if t in known]
        if clean["kind"] not in ("world_event", "thought", "specified_action", "world_setting", "revoke"):
            raise ValueError("未知干预类型")
        if clean["kind"] == "world_setting":
            if not clean["text"]:
                raise ValueError("世界设定必须填写内容")
            if clean["scope"] not in ("all", "selected"):
                raise ValueError("世界设定只能对全体或指定的人生效")
            if clean["scope"] == "selected" and not clean["targets"]:
                raise ValueError("选择生效对象时至少勾选一个智能体")
        if clean["kind"] == "world_event":
            if not clean["text"]:
                raise ValueError("发生事件必须填写事件内容")
            if clean["scope"] not in ("all", "selected", "local"):
                raise ValueError("事件知情范围无效")
            if clean["scope"] == "selected" and not clean["targets"]:
                raise ValueError("选择知情人时至少勾选一个智能体")
            if clean["scope"] == "local" and not clean["location"]:
                raise ValueError("按现场感知传播的事件必须选择发生地点")
        elif clean["kind"] == "thought" and not clean["targets"]:
            raise ValueError("想法或意图必须选择至少一个智能体")
        elif clean["kind"] == "specified_action":
            if not clean["text"]:
                raise ValueError("指定行为必须填写行为内容")
            if clean["actor"] not in known:
                raise ValueError("指定行为必须选择有效行为者")
            if clean["object"] and clean["object"] not in known:
                raise ValueError("行为对象不在当前世界中")
            if clean["object"] == clean["actor"]:
                raise ValueError("行为者与行为对象不能是同一人物")
            clean["targets"] = [clean["actor"]]
        if clean["scheduled_time"]:
            valid = False
            import datetime as _datetime
            for pattern in ("%Y%m%d-%H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M"):
                try:
                    parsed = _datetime.datetime.strptime(clean["scheduled_time"], pattern)
                    clean["scheduled_time"] = parsed.strftime("%Y%m%d-%H:%M")
                    valid = True
                    break
                except ValueError:
                    continue
            if not valid:
                raise ValueError("计划生效时间格式无效")
        pending_dir = os.path.join(self.interventions_folder(), "pending")
        os.makedirs(pending_dir, exist_ok=True)
        pending_path = os.path.join(pending_dir, clean["intervention_id"] + ".json")
        _atomic_json(pending_path, clean)
        clean["_pending_path"] = pending_path
        self.interventions_queue.put(clean)
        public = {k: v for k, v in clean.items() if not k.startswith("_")}
        self.bus.publish({"type": "intervention_queued", "item": public})
        return public

    def control(self, command):
        if self.state["status"] in ("finished", "stopped", "error") and command in ("pause", "resume"):
            return True  # 幂等接受但不改状态
        if command == "pause":
            self.pause_event.set()
            self.state["status"] = "paused"
        elif command == "resume":
            self.pause_event.clear()
            self.state["status"] = "running"
        elif command == "stop":
            self.stop_event.set()
            self.pause_event.clear()
        else:
            return False
        self.bus.publish({"type": "status", "status": self.state["status"]})
        return True

    # -- 问卷数据访问 --
    def survey_index(self):
        """返回所有问卷（legacy + custom）的清单与行数。"""
        out = []
        if self.server is not None:
            if self.config.get("daily_survey", {}).get("enabled", False):
                out.append({
                    "id": "legacy",
                    "title": "每日领导力问卷（内置）",
                    "rows": len(self.server.daily_survey_rows),
                })
            for schema in self.config.get("custom_surveys") or []:
                rows = getattr(self.server, "custom_survey_rows", {}).get(schema["id"])
                if rows is None:
                    rows = self.server.load_custom_survey_rows(schema["id"])
                out.append({
                    "id": schema["id"],
                    "title": schema.get("title", schema["id"]),
                    "rows": len(rows),
                })
        return out

    def survey_rows(self, survey_id):
        if self.server is None:
            return None, []
        if survey_id in ("", "legacy"):
            return None, list(self.server.daily_survey_rows)
        for schema in self.config.get("custom_surveys") or []:
            if schema["id"] == survey_id:
                rows = getattr(self.server, "custom_survey_rows", {}).get(survey_id)
                if rows is None:
                    rows = self.server.load_custom_survey_rows(survey_id)
                return schema, list(rows)
        return None, []


def apply_offline_overrides(config):
    """离线模式：LLM走failsafe，embedding走mock，零外部调用。"""
    agent_base = config.setdefault("agent_base", {})
    think = agent_base.setdefault("think", {})
    think["mode"] = "offline"
    assoc = agent_base.setdefault("associate", {})
    assoc["embedding"] = {"type": "mock"}
    return config


def build_experiment_config(payload, check=True):
    """根据配置器提交的payload构建模拟config。返回 (name, args_namespace, config)。

    V27: ``payload["language"]`` ("zh" default, or "en") is the simulation language of the
    world; the config is built in that language (personality wording, condition text)."""
    from modules import lang as lang_mod
    language = lang_mod.normalize((payload or {}).get("language"))
    with lang_mod.using(language):
        return _build_experiment_config(payload, check, language)


def _build_experiment_config(payload, check, language):
    name = str(payload.get("name", "")).strip()
    if not _NAME_RE.match(name):
        raise ValueError("实验名称只能包含中文、字母、数字、下划线或连字符（≤40字符）")
    if os.path.exists(f"{CHECKPOINTS_PATH}/{name}"):
        existing = os.listdir(f"{CHECKPOINTS_PATH}/{name}")
        has_checkpoint = any(
            f.startswith("simulate-") and f.endswith(".json") for f in existing
        )
        # 批量子世界可能在首个step前失败，但已留下runtime/log/storage目录；
        # 这种情况下允许原配置原地重试。已有正式checkpoint则必须走resume。
        if has_checkpoint or not isinstance(payload.get("_batch"), dict):
            raise ValueError(f"实验名称 '{name}' 已存在，请换一个名称")

    agents = payload.get("agents") or []
    if not (1 <= len(agents) <= 30):
        raise ValueError("智能体数量必须在 1-30 之间")
    for a in agents:
        cfg = os.path.join(AGENTS_ROOT, a, "agent.json")
        if not os.path.exists(cfg):
            raise ValueError(f"智能体不存在：{a}（缺少 {cfg}）")
        try:
            with open(cfg, "r", encoding="utf-8") as f:
                json.load(f)
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ValueError(f"智能体 {a} 的 agent.json 损坏或编码异常")

    start_time = str(payload.get("start_time", "20240213-09:30")).strip()
    try:
        utils.to_date(start_time, "%Y%m%d-%H:%M")
    except Exception:
        raise ValueError("起始时间格式应为 YYYYMMDD-HH:MM")
    try:
        step = max(1, min(100000, int(payload.get("step", 144))))
        stride = max(1, min(720, int(payload.get("stride", 10))))
    except (TypeError, ValueError):
        raise ValueError("步数/步长必须是整数")

    condition = str(payload.get("condition", "")).strip()
    legacy_survey = bool(payload.get("legacy_survey", False))

    config = get_config(start_time, stride, agents, None, legacy_survey)
    if language != "zh":
        config["language"] = language   # Chinese worlds keep the pre-V27 config (no key)

    # 基座模型（全局默认）与对话轮数
    base_model = str(payload.get("base_model", "")).strip()
    if base_model:
        config["agent_base"].setdefault("think", {}).setdefault("llm", {})["model"] = base_model
    chat_iter = payload.get("chat_iter")
    if chat_iter not in (None, ""):
        try:
            config["agent_base"]["chat_iter"] = max(1, min(8, int(chat_iter)))
        except (TypeError, ValueError):
            pass
    api_base_url = str(payload.get("api_base_url", "") or "").strip()
    if api_base_url.startswith("http"):
        config["agent_base"].setdefault("think", {}).setdefault("llm", {})["base_url"] = api_base_url
    # 每次实验可独立锁定记忆嵌入通道。留空时继承 data/config.json 的全局设置；
    # 显式选择会随世界模板和 checkpoint 保存，避免同一批实验混用向量空间。
    embedding_type = str(payload.get("embedding_type", "") or "").strip()
    embedding_presets = {
        "ollama": {
            "type": "ollama", "base_url": "http://127.0.0.1:11434",
            "model": "bge-m3:latest",
        },
        "openrouter": {
            "type": "openrouter", "base_url": "https://openrouter.ai/api/v1",
            "model": "openai/text-embedding-3-small",
        },
        "dashscope": dict(DASHSCOPE_EMBEDDING),
    }
    if embedding_type:
        if embedding_type not in embedding_presets:
            raise ValueError("记忆 Embedding 只能选择本地 BGE-M3、OpenRouter text-embedding-3-small 或阿里云百炼 text-embedding-v4")
        config["agent_base"].setdefault("associate", {})["embedding"] = copy.deepcopy(
            embedding_presets[embedding_type]
        )
    temperature = payload.get("temperature")
    if temperature not in (None, ""):
        try:
            config["agent_base"].setdefault("think", {}).setdefault("llm", {})["temperature"] =                 max(0.0, min(2.0, float(temperature)))
        except (TypeError, ValueError):
            pass
    # 思考顺序随机化（默认开）：写入配置随存档留痕
    config["shuffle_think_order"] = bool(payload.get("shuffle_think_order", True))
    config["seed"] = int(payload.get("seed", 0))
    config["simulation_start"] = start_time
    config["measurement_policy"] = str(payload.get("measurement_policy", "passive"))
    if config["measurement_policy"] not in ("passive", "legacy_reactive"):
        raise ValueError("测量方式必须是 passive 或 legacy_reactive")
    config["agent_base"]["measurement_policy"] = config["measurement_policy"]
    # V25: daily anchors follow the world rules only; event-manipulation templates keep the V24 rhythm
    # (team in the meeting area at 10:00 and the leader's office at 15:00, where their scheduled events happen).
    config["office_rhythm"] = str(payload.get("office_rhythm") or "rules_v25")
    if config["office_rhythm"] not in ("rules_v25", "legacy_v24"):
        raise ValueError("office_rhythm 必须是 rules_v25 或 legacy_v24")
    config["agent_base"]["office_rhythm"] = config["office_rhythm"]
    # V25.1: optional cheap mode. Off = no key at all, so main-mode worlds are unchanged.
    from modules import cheap_mode
    cheap = cheap_mode.normalize(payload.get("cheap_mode"), stride=stride)
    if cheap:
        config["cheap_mode"] = cheap
        config["agent_base"]["cheap_mode"] = copy.deepcopy(cheap)
    config["scheduled_events"] = copy.deepcopy(payload.get("scheduled_events") or [])
    config["work_tasks"] = copy.deepcopy(payload.get("work_tasks") or [])
    from modules.research.scenario import validate_scenario
    validate_scenario({**payload, "agents": agents})
    config["research_design"] = copy.deepcopy(payload.get("research_design") or {})
    # 保存原始setup配置（供"历史实验另存为世界模板"）
    config["setup_payload"] = copy.deepcopy(payload)
    # 批次身份随checkpoint持久化，聚合不再依赖实验名称猜测。
    if isinstance(payload.get("_batch"), dict):
        config["batch"] = copy.deepcopy(payload["_batch"])
    # 实验条件（条件中引用的智能体必须在所选名单内才应用）
    if condition:
        try:
            config = apply_experiment_condition(config, condition)
        except ValueError as e:
            raise ValueError(f"实验条件应用失败：{e}")
    # V27.3: in an English world the built-in daily survey names the agents in English too
    # (it is not part of the comparison signature, so grouping is unchanged)
    if config.get("language") == "en":
        from modules import lang as _lang
        ds = config.get("daily_survey") or {}
        ds["agents"] = [_lang.NAMES.get(a, a) for a in ds.get("agents", [])]
        ds["roles"] = {_lang.NAMES.get(a, a): r for a, r in (ds.get("roles") or {}).items()}
    # legacy问卷的目标与角色按所选智能体收敛
    if legacy_survey:
        ds = config.get("daily_survey", {})
        ds["agents"] = [a for a in ds.get("agents", []) if a in agents] or list(agents)
        ds["roles"] = {a: r for a, r in ds.get("roles", {}).items() if a in agents}

    # 人设覆盖（与experiment_conditions相同的合并机制）
    overrides = payload.get("persona_overrides") or {}
    shared_context = str(payload.get("shared_context", "")).strip()
    # V24: world rules shared by every agent (work hours, channels, what is allowed),
    # written into the fixed layer of every prompt as 【世界规则】.
    world_rules = str(payload.get("world_rules", "") or "").strip()
    for agent_name in agents:
        ov = overrides.get(agent_name) or {}
        agent_cfg = config["agents"][agent_name]
        scratch = {}
        for key in ("innate", "learned", "lifestyle", "daily_plan", "background", "conduct"):
            value = str(ov.get(key, "")).strip()
            if value:
                scratch[key] = value
        age = ov.get("age", "")
        if str(age).strip():
            try:
                scratch["age"] = int(age)
            except (TypeError, ValueError):
                pass
        currently = str(ov.get("currently", "")).strip()
        if currently:
            # 手动编辑的currently优先级最高（替换实验条件与默认值）
            agent_cfg["currently"] = currently
        if world_rules:
            scratch["world_rules"] = world_rules
        if shared_context:
            # V24: the shared context is a standing world fact in the fixed layer of every
            # prompt. V23 appended it to `currently`, which the daily update rewrites, so
            # it could disappear after day 1.
            facts = list((agent_cfg.get("scratch") or {}).get("world_facts") or [])
            facts.append({"text": shared_context, "from": None, "expires": None,
                          "intervention_id": "shared_context", "source": "setup"})
            scratch["world_facts"] = facts
        if scratch:
            # V23: merge instead of replace, so a template override of one field no
            # longer silently drops the fields an experimental condition set.
            agent_cfg["scratch"] = {**(agent_cfg.get("scratch") or {}), **scratch}
        model = str(ov.get("model", "")).strip()
        if model:
            agent_cfg.setdefault("think", {}).setdefault("llm", {})["model"] = model

    # V23 人格抽样：每个世界用自己的种子从真人大五数据中抽取，配对世界种子相同→人格相同
    personality = payload.get("personality") or {}
    if personality.get("enabled"):
        from modules import personality as personality_mod
        personality_mod.apply_to_config(config, agents, config["seed"], personality)
    # V23 问卷上下文：三层记忆 + 上限
    survey_ctx = {"version": "three_layer_v1", "budget_tokens": 8000}
    survey_ctx.update(payload.get("survey_context") or {})
    config["agent_base"]["survey_context"] = survey_ctx

    # 自定义问卷
    schemas = []
    seen = set()
    for raw in payload.get("custom_surveys") or []:
        schema = survey_engine.validate_schema(raw)
        if schema["id"] in seen:
            raise ValueError(f"问卷id重复：{schema['id']}")
        seen.add(schema["id"])
        schema["targets"] = [t for t in schema["targets"] if t in agents]
        if schema.get("mode") == "dyadic":
            schema["raters"] = [t for t in schema.get("raters", []) if t in agents]
            schema["ratees"] = [t for t in schema.get("ratees", []) if t in agents]
        schemas.append(schema)
    if schemas:
        config["custom_surveys"] = schemas

    # 模型分配清单（写入存档，保证数据可追溯）
    if config.get("research_design", {}).get("condition_code"):
        condition = config["research_design"]["condition_code"]
        config.setdefault("experiment", {})["condition"] = condition
    effective_base = (config["agent_base"].get("think", {}).get("llm", {}) or {}).get("model", "")
    config["model_assignment"] = {
        "base": effective_base,
        "embedding": copy.deepcopy(
            (config["agent_base"].get("associate", {}) or {}).get("embedding", {})
        ),
        "per_agent": {
            n: config["agents"][n]["think"]["llm"]["model"]
            for n in agents
            if (config["agents"][n].get("think", {}).get("llm", {}) or {}).get("model")
        },
    }

    if bool(payload.get("offline")):
        apply_offline_overrides(config)

    # V23 模板核对：条件与人设冲突、构念词泄露 → 直接拦下
    if check:
        from modules.research import world_check
        result = world_check.check_world(payload, config)
        if result["errors"]:
            raise ValueError("模板核对未通过：" + "；".join(result["errors"]))
        config["world_check"] = {"warnings": result["warnings"]}

    args = types.SimpleNamespace(
        name=name, start=start_time, resume=False, step=step, stride=stride,
        verbose="info", log="server.log", condition=condition,
        disable_daily_survey=not legacy_survey, offline=bool(payload.get("offline")),
        port=0, host="",
    )
    return name, args, config


# ---------------------------------------------------------------------------
# Flask 应用
# ---------------------------------------------------------------------------
# 出厂默认API Key（应用户要求内置的低额度兜底key）：仅当环境中没有对应key时启用；
# 用户在API设置面板保存过的自有key始终优先。可随时在下方删除本默认值。
DEFAULT_API_KEYS = {}  # Credentials are supplied only by the local settings or environment.


def apply_default_api_keys():
    for var, val in DEFAULT_API_KEYS.items():
        os.environ.setdefault(var, val)


FACTORY_PRESET_BASE = {
    "start_time": "20240213-09:30", "step": 144, "stride": 10,
    "base_model": "", "chat_iter": 2, "temperature": 1, "shuffle_think_order": True,
    "offline": False, "legacy_survey": True,
    "agents": ["阿伊莎", "克劳斯", "玛丽亚", "沃尔夫冈"],
    "shared_context": "", "world_rules": "", "persona_overrides": {}, "custom_surveys": [],
}


def ensure_factory_presets():
    """创建出厂模板 strict/lenient（分组=模板统一体系）。每个安装只发一次：
    用标记文件记录已发过，之后用户删改模板都被尊重、不会复活。"""
    d = os.path.join("data", "world_presets")
    marker = os.path.join(d, ".factory_v1")
    if os.path.exists(marker):
        return
    os.makedirs(d, exist_ok=True)
    created = []
    for cond in ():  # V23: no auto-created demo templates (old strict/lenient leaked condition names)
        p = os.path.join(d, cond + ".json")
        if not os.path.exists(p):
            payload = dict(FACTORY_PRESET_BASE)
            payload["condition"] = cond
            with open(p, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
            created.append(cond)
    with open(marker, "w", encoding="utf-8") as f:
        f.write("factory presets delivered\n")
    if created:
        print("[初始化] 已创建出厂世界模板:", " / ".join(created))


# V26: persona-manipulation versions tried during the 2026-10-28/29 pilots. The habit version became
# 人设操纵-高/低辱虐组; the others are retired. Overwriting an installation never deletes files,
# so remove these factory templates once (only these exact names; user templates are untouched).
RETIRED_PRESETS = ("人设操纵详细版-高辱虐组", "人设操纵详细版-低辱虐组", "人设操纵简略稳定版-高辱虐组",
                   "人设操纵习惯版-高辱虐组", "人设操纵习惯版-低辱虐组")


def retire_old_presets():
    d = os.path.join("data", "world_presets")
    marker = os.path.join(d, ".retired_v26")
    if os.path.exists(marker) or not os.path.isdir(d):
        return
    removed = []
    for name in RETIRED_PRESETS:
        p = os.path.join(d, name + ".json")
        if os.path.exists(p):
            os.remove(p)
            removed.append(name)
    with open(marker, "w", encoding="utf-8") as f:
        f.write("retired: " + ", ".join(RETIRED_PRESETS) + "\n")
    if removed:
        print("[初始化] V26 已移除旧的人设操纵模板：" + "、".join(removed))


# V27.4: every factory template name says the language of its world: _EN for English-language
# worlds (no suffix until V27.3), _CN for Chinese-language worlds (Chinese names until V27.3), so that
# readers who do not read Chinese can tell what each one is. The content is unchanged, so worlds
# keep their comparable-group IDs. Old names still work wherever a template is requested by name.
PRESET_RENAMES = {
    "人设操纵-高辱虐组": "Persona-manipulation-high-abuse_CN",
    "人设操纵-低辱虐组": "Persona-manipulation-low-abuse_CN",
    "事件操纵-高辱虐组": "Event-manipulation-high-abuse_CN",
    "事件操纵-低辱虐组": "Event-manipulation-low-abuse_CN",
    "Persona-manipulation-high-abuse": "Persona-manipulation-high-abuse_EN",
    "Persona-manipulation-low-abuse": "Persona-manipulation-low-abuse_EN",
    "Event-manipulation-high-abuse": "Event-manipulation-high-abuse_EN",
    "Event-manipulation-low-abuse": "Event-manipulation-low-abuse_EN",
}


def preset_path(name):
    """File of a world template; a V27.3-or-earlier name finds the renamed file."""
    d = os.path.join("data", "world_presets")
    p = os.path.join(d, name + ".json")
    if not os.path.exists(p) and name in PRESET_RENAMES:
        return os.path.join(d, PRESET_RENAMES[name] + ".json")
    return p


def rename_old_presets():
    """An installation upgraded by overwriting still holds the old-named files: rename each one
    to its new name, or remove it when the new file is already there with the same content.
    A template whose content the user changed is kept under its old name."""
    d = os.path.join("data", "world_presets")
    if not os.path.isdir(d):
        return
    done = []
    for old, new in PRESET_RENAMES.items():
        po, pn = os.path.join(d, old + ".json"), os.path.join(d, new + ".json")
        if not os.path.exists(po):
            continue
        try:
            if not os.path.exists(pn):
                os.replace(po, pn)
                done.append(old + " -> " + new)
                continue
            with open(po, "r", encoding="utf-8") as f1, open(pn, "r", encoding="utf-8") as f2:
                same = json.load(f1) == json.load(f2)
        except (OSError, json.JSONDecodeError):
            continue
        if same:
            os.remove(po)
            done.append(old + " -> " + new)
    if done:
        print("[init] V27.4 renamed templates: " + "; ".join(done))


def ensure_config_exists():
    """用户可变配置缺失时（全新解压）从出厂模板创建；覆盖升级不再重置用户设置。"""
    for live, default in (
        (os.path.join("data", "config.json"), os.path.join("data", "config.default.json")),
        (os.path.join("data", "experiment_conditions.json"),
         os.path.join("data", "experiment_conditions.default.json")),
    ):
        if not os.path.exists(live) and os.path.exists(default):
            shutil.copy(default, live)
            print("[初始化] 已从出厂模板创建", live)


import re as _re


_COMPARISON_IGNORED_KEYS = {"name", "_batch", "batch_id", "replicate"}


def _canonical_comparison_value(value):
    """移除运行身份字段并稳定排序，用完整实验设计生成可比性指纹。"""
    if isinstance(value, dict):
        return {
            key: _canonical_comparison_value(item)
            for key, item in sorted(value.items())
            if key not in _COMPARISON_IGNORED_KEYS
        }
    if isinstance(value, list):
        return [_canonical_comparison_value(item) for item in value]
    return value


def _condition_definition(name, language="zh"):
    """Current text of an experiment condition (V26: part of the comparison fingerprint)."""
    try:
        with open(os.path.join("data", "experiment_conditions.json"), "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    data = data.get("conditions", data) if isinstance(data, dict) else {}
    entry = data.get(name) if isinstance(data, dict) else None
    if not isinstance(entry, dict):
        return entry
    # V27: only the text the world actually uses (the Chinese fingerprint stays as in V26).
    entry = dict(entry)
    translations = entry.pop("translations", None) or {}
    if language != "zh":
        entry.update(translations.get(language) or {})
    return entry


def comparison_signature(payload):
    payload = dict(payload or {})
    condition = str(payload.get("condition") or "")
    if condition:
        # V26: the same condition name has carried different leadership texts over versions
        # (brief in V25, habit in V26); worlds are comparable only when the text is the same.
        payload["_condition_definition"] = _condition_definition(condition, str(payload.get("language") or "zh"))
    canonical = _canonical_comparison_value(payload)
    raw = json.dumps(canonical, ensure_ascii=False, sort_keys=True,
                     separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:12]


def comparison_summary(payload):
    payload = payload or {}
    surveys = payload.get("custom_surveys") or []
    return {
        "step": int(payload.get("step", 0) or 0),
        "stride": int(payload.get("stride", 0) or 0),
        "agent_count": len(payload.get("agents") or []),
        "survey_count": len(surveys),
        "survey_names": [str(s.get("title") or s.get("id") or "未命名问卷") for s in surveys],
        "legacy_survey": bool(payload.get("legacy_survey", False)),
        "base_model": str(payload.get("base_model") or "默认模型"),
        "condition": str(payload.get("condition") or ""),
        "cheap_mode": bool((payload.get("cheap_mode") or {}).get("enabled")) if isinstance(payload.get("cheap_mode"), dict) else False,
        "language": str(payload.get("language") or "zh"),
    }


def _latest_checkpoint_json(name):
    folder = os.path.join(CHECKPOINTS_PATH, name)
    try:
        files = sorted(
            f for f in os.listdir(folder)
            if f.startswith("simulate-") and f.endswith(".json")
        )
        if not files:
            return {}
        with open(os.path.join(folder, files[-1]), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def _comparison_config_for_run(run):
    cfg_path = run.get("cfg_path") or ""
    if cfg_path and os.path.isfile(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                return json.load(f), True
        except (OSError, json.JSONDecodeError):
            pass
    checkpoint = _latest_checkpoint_json(run.get("name", ""))
    setup_payload = checkpoint.get("setup_payload")
    if isinstance(setup_payload, dict) and setup_payload:
        return setup_payload, True
    # 无原始配置的旧世界无法严格验证；至少按原分组隔离，绝不跨组误合并。
    return {
        "legacy_group": run.get("group") or run.get("condition") or run.get("name", ""),
        "step": run.get("total", 0),
        "stride": run.get("stride", 0),
    }, False


def _read_batch_manifest(prefix):
    path = os.path.join("results", "batch", prefix, BATCH_MANIFEST)
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def comparison_groups_for_batch(prefix, manifest=None):
    """返回批次内可安全聚合的配置组；相同指纹才会进入同一组。"""
    manifest = manifest if manifest is not None else _read_batch_manifest(prefix)
    runs = []
    if manifest:
        for saved in manifest.get("runs") or []:
            if os.path.isdir(os.path.join(CHECKPOINTS_PATH, saved.get("name", ""))):
                run = dict(saved)
                run.update({
                    "batch_id": manifest.get("batch_id") or prefix,
                    "group": run.get("group", ""),
                    "condition": run.get("condition", ""),
                    "replicate": run.get("replicate", ""),
                })
                runs.append(run)
    else:
        pattern = _re.compile("^" + _re.escape(prefix) + "-(.+)-([0-9]{2,})$")
        if os.path.isdir(CHECKPOINTS_PATH):
            for name in sorted(os.listdir(CHECKPOINTS_PATH)):
                match = pattern.match(name)
                if not match:
                    continue
                run = export_run_meta(name)
                run.update({
                    "name": name,
                    "batch_id": prefix,
                    "group": run.get("group") or match.group(1),
                    "condition": run.get("condition") or match.group(1),
                    "replicate": run.get("replicate") or int(match.group(2)),
                })
                runs.append(run)

    groups = {}
    for run in runs:
        payload, verified = _comparison_config_for_run(run)
        group_id = run.get("config_id") or comparison_signature(payload)
        label = str(run.get("group") or run.get("condition") or "未命名配置")
        item = groups.setdefault(group_id, {
            "group_id": group_id,
            "label": label,
            "labels": [],
            "verified": True,
            "summary": run.get("config_summary") or comparison_summary(payload),
            "runs": [],
        })
        if label not in item["labels"]:
            item["labels"].append(label)
        item["verified"] = item["verified"] and verified
        item["runs"].append({
            "name": run["name"],
            "batch_id": run.get("batch_id") or prefix,
            "group": run.get("group", ""),
            "condition": run.get("condition", ""),
            "replicate": run.get("replicate", ""),
            "status": run.get("status", ""),
        })
    result = []
    for item in groups.values():
        item["run_count"] = len(item["runs"])
        item["statuses"] = {
            status: sum(1 for run in item["runs"] if run.get("status") == status)
            for status in sorted({run.get("status", "") for run in item["runs"] if run.get("status")})
        }
        if len(item["labels"]) > 1:
            item["label"] = " / ".join(item["labels"])
        result.append(item)
    return sorted(result, key=lambda item: (item["label"], item["group_id"]))


def aggregate_prefix(prefix, group_id=None):
    """按名称前缀聚合历史批量：扫描 checkpoints 中形如 前缀-分组-NN 的实验，
    合并问卷/心理/行为数据到 results/batch/<前缀>/。返回(文件列表, run数)。"""
    prefix = (prefix or "").strip()
    if not prefix:
        raise ValueError("请提供批量前缀")
    groups = comparison_groups_for_batch(prefix)
    if not groups:
        raise ValueError(f"批次「{prefix}」没有可聚合的实验")
    if group_id:
        selected = next((group for group in groups if group["group_id"] == group_id), None)
        if selected is None:
            raise ValueError("该可比配置组不存在或已变化，请刷新页面")
    elif len(groups) == 1:
        selected = groups[0]
    else:
        raise ValueError(
            "该批次包含 {} 个不同配置，不能合并成一份数据；请展开批次后按可比实验组聚合。".format(len(groups))
        )
    runs = selected["runs"]
    out_dir = os.path.join("results", "batch", prefix, "aggregates", selected["group_id"])
    os.makedirs(out_dir, exist_ok=True)
    import batch as batch_mod
    batch_mod.aggregate(prefix, runs, out_dir=out_dir)
    from modules import behavior as behavior_mod
    import csv as _csv
    daily_rows, dyad_rows = [], []
    for r in runs:
        try:
            daily, dyad, _ = behavior_mod.compute(r["name"])
            for row in daily:
                row["run_id"], row["group"], row["condition"] = (
                    r["name"], r.get("group", ""), r.get("condition", "")
                )
                daily_rows.append(row)
            for row in dyad:
                row["run_id"], row["group"], row["condition"] = (
                    r["name"], r.get("group", ""), r.get("condition", "")
                )
                dyad_rows.append(row)
        except Exception:  # noqa: BLE001
            continue
    for fn, rows in (("merged_behavior_daily.csv", daily_rows),
                     ("merged_behavior_dyad.csv", dyad_rows)):
        if rows:
            cols = sorted({k for row in rows for k in row})
            with open(os.path.join(out_dir, fn), "w", encoding="utf-8-sig", newline="") as f:
                w = _csv.DictWriter(f, fieldnames=cols)
                w.writeheader()
                w.writerows(rows)
    # 新的统一研究表：responses.csv 是Qualtrics式问卷宽表，其余表按数据粒度拆分。
    exporter.write_analysis_tables(out_dir, runs)
    files = sorted(f for f in os.listdir(out_dir) if f.endswith(".csv"))
    return files, len(runs), out_dir, selected


def scan_batches():
    """返回按时间折叠展示的批次，以及批次内可安全聚合的配置组。"""
    root = os.path.join("results", "batch")
    out = []
    if not os.path.isdir(root):
        return out
    for entry in os.listdir(root):
        folder = os.path.join(root, entry)
        if not os.path.isdir(folder):
            continue
        # 大批次磁盘清理可能持续数秒；一旦确认删除便立即从历史扫描中隐藏。
        if os.path.exists(os.path.join(folder, BATCH_DELETE_MARKER)):
            continue
        manifest = _read_batch_manifest(entry)
        if manifest:
            runs = manifest.get("runs") or []
            batch_id = manifest.get("batch_id") or entry
            comparison_groups = comparison_groups_for_batch(entry, manifest)
            item = {
                "batch_id": batch_id,
                "prefix": manifest.get("prefix") or entry,
                "label": manifest.get("label") or batch_id,
                "created_at": manifest.get("created_at", ""),
                "updated_at": manifest.get("updated_at", ""),
                "run_count": len(runs),
                "groups": [group["label"] for group in comparison_groups],
                "comparison_groups": comparison_groups,
                "config_group_count": len(comparison_groups),
                "statuses": {s: sum(1 for r in runs if r.get("status") == s)
                             for s in sorted({r.get("status", "") for r in runs})},
                "legacy": False,
                "sort_time": os.path.getmtime(os.path.join(folder, BATCH_MANIFEST)),
            }
            out.append(item)
            continue
        # 旧版批次没有manifest；批次目录名就是此前要求用户手填的prefix。
        pat = _re.compile("^" + _re.escape(entry) + "-(.+)-([0-9]{2,})$")
        names = []
        if os.path.isdir(CHECKPOINTS_PATH):
            for name in os.listdir(CHECKPOINTS_PATH):
                match = pat.match(name)
                if match:
                    names.append(name)
        if names:
            comparison_groups = comparison_groups_for_batch(entry)
            modified = os.path.getmtime(folder)
            out.append({
                "batch_id": entry, "prefix": entry, "label": entry,
                "created_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(modified)),
                "updated_at": "", "run_count": len(names),
                "groups": [group["label"] for group in comparison_groups],
                "comparison_groups": comparison_groups,
                "config_group_count": len(comparison_groups),
                "statuses": {}, "legacy": True, "sort_time": modified,
            })
    out.sort(key=lambda item: item.pop("sort_time", 0), reverse=True)
    return out


def export_run_meta(name):
    """从最新checkpoint提取统一导出所需的实验身份。"""
    folder = os.path.join(CHECKPOINTS_PATH, name)
    cfg = {}
    if os.path.isdir(folder):
        files = sorted(
            f for f in os.listdir(folder)
            if f.startswith("simulate-") and f.endswith(".json")
        )
        if files:
            try:
                with open(os.path.join(folder, files[-1]), "r", encoding="utf-8") as f:
                    cfg = json.load(f)
            except (OSError, json.JSONDecodeError):
                cfg = {}
    batch = cfg.get("batch") or {}
    condition = (cfg.get("experiment") or {}).get("condition", "")
    meta = {
        "name": name,
        "batch_id": batch.get("batch_id", ""),
        "group": batch.get("group", ""),
        "condition": batch.get("condition") or condition,
        "replicate": batch.get("replicate", ""),
        "config_id": batch.get("config_id", ""),
    }
    # 旧批次没有batch字段时，从已有批次目录和标准名称做一次兼容恢复。
    if not meta["batch_id"]:
        root = os.path.join("results", "batch")
        if os.path.isdir(root):
            for prefix in sorted(os.listdir(root), key=len, reverse=True):
                match = _re.match(
                    "^" + _re.escape(prefix) + "-(.+)-([0-9]{2,})$", name
                )
                if match:
                    meta.update({
                        "batch_id": prefix,
                        "group": match.group(1),
                        "condition": meta["condition"] or match.group(1),
                        "replicate": int(match.group(2)),
                    })
                    break
    return meta


def _available_ports(count, start=5002):
    """寻找当前可绑定的端口，避免残留子进程占用固定5002起始段。"""
    ports = []
    candidate = start
    while len(ports) < count and candidate <= 65000:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.bind(("127.0.0.1", candidate))
            ports.append(candidate)
        except OSError:
            pass
        finally:
            sock.close()
        candidate += 1
    if len(ports) != count:
        raise ValueError("没有足够的本地端口用于启动批量世界")
    return ports


def _new_batch_id():
    base = "B" + time.strftime("%Y%m%d-%H%M%S")
    candidate = base
    index = 2
    while os.path.exists(os.path.join("results", "batch", candidate)):
        candidate = "{}-{:02d}".format(base, index)
        index += 1
    return candidate


def _batch_label(value):
    label = str(value or "").strip() or "批量实验"
    if len(label) > 60 or any(ch in label for ch in "\\/\r\n\t"):
        raise ValueError("批次名称最多60字，且不能包含斜杠或换行")
    return label


class BatchManager:
    """网页批量执行器：每个世界=独立子进程+独立端口的完整迷你服务（保留全套实时功能）。"""

    def __init__(self):
        self.lock = threading.Lock()
        self.batch = None          # {prefix, parallel, runs:[{name,condition,port,status,step,total,proc,cfg_path}]}
        self.thread = None
        self.generation = 0

    def _active_unlocked(self):
        return bool(self.batch and any(
            r["status"] in ("排队中", "运行中") for r in self.batch["runs"]
        ))

    @staticmethod
    def _terminal(status):
        return status in ("已完成", "失败", "已停止")

    def active(self):
        with self.lock:
            return self._active_unlocked()

    def _manifest_path_unlocked(self):
        if not self.batch:
            return ""
        return os.path.join("results", "batch", self.batch["prefix"], BATCH_MANIFEST)

    def _save_manifest_unlocked(self):
        if not self.batch:
            return True
        data = {
            "schema_version": 2,
            "batch_id": self.batch["batch_id"],
            "prefix": self.batch["prefix"],
            "label": self.batch.get("label", self.batch["batch_id"]),
            "parallel": self.batch["parallel"],
            "created_at": self.batch["created_at"],
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "aggregated": bool(self.batch.get("aggregated", False)),
            "agg_dir": self.batch.get("agg_dir", ""),
            "runs": [
                {k: r.get(k) for k in (
                    "name", "group", "condition", "replicate", "port",
                    "status", "step", "total", "stride", "offline",
                    "cfg_path", "error", "config_id", "config_summary",
                )}
                for r in self.batch["runs"]
            ],
        }
        try:
            _atomic_json(self._manifest_path_unlocked(), data)
            return True
        except OSError as exc:
            # 清单是监控/恢复元数据；一次磁盘竞争不能杀死整个调度线程。
            print("[批量] !! 清单保存失败，调度继续并将在下一轮重试：{}".format(exc))
            return False

    def snapshot(self):
        with self.lock:
            if not self.batch:
                return {"active": False}
            b = self.batch
            return {"active": self._active_unlocked(), "batch_id": b["batch_id"],
                    "prefix": b["prefix"], "label": b.get("label", b["batch_id"]),
                    "parallel": b["parallel"],
                    "aggregated": b.get("aggregated", False), "agg_dir": b.get("agg_dir", ""),
                    "runs": [dict({k: r.get(k) for k in (
                                      "name", "group", "condition", "replicate",
                                      "port", "status", "step", "total", "live")},
                                  error=r.get("error", "")) for r in b["runs"]]}

    def _start_thread(self):
        generation = self.generation
        self.thread = threading.Thread(target=self._loop, args=(generation,), daemon=True)
        self.thread.start()

    def restore_latest(self):
        """从最新批次清单恢复管理状态；运行中的子世界用持久注册表重新接管。"""
        root = os.path.join("results", "batch")
        candidates = []
        if os.path.isdir(root):
            for entry in os.listdir(root):
                folder = os.path.join(root, entry)
                if os.path.exists(os.path.join(folder, BATCH_DELETE_MARKER)):
                    continue
                path = os.path.join(folder, BATCH_MANIFEST)
                if os.path.isfile(path):
                    candidates.append((os.path.getmtime(path), path))
        manifests = []
        for modified, path in candidates:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if not data.get("runs"):
                    continue
            except (OSError, json.JSONDecodeError):
                continue
            has_active = any(
                r.get("status") in ("排队中", "运行中") for r in data["runs"]
            )
            manifests.append((has_active, modified, path, data))

        # 活动批次优先于更晚创建的已结束批次，确保重启后不会漏接仍在运行的世界。
        for _, _, path, data in sorted(manifests, reverse=True):

            runs = []
            queued = []
            for saved in data["runs"]:
                run = dict(saved)
                run.update({
                    "proc": None,
                    "error": run.get("error", ""),
                    "step": int(run.get("step", 0) or 0),
                    "total": int(run.get("total", 0) or 0),
                    "stride": int(run.get("stride", 10) or 10),
                    "offline": bool(run.get("offline", False)),
                    "_misses": 0,
                    "live": None,
                })
                disk = self._disk_step(run.get("name", ""))
                run["step"] = max(run["step"], disk)
                live = probe_runtime(run.get("name", ""))
                if live:
                    run["status"] = "运行中"
                    run["port"] = live["port"]
                    run["step"] = max(run["step"], live.get("step", 0))
                    run["live"] = live
                elif run["total"] > 0 and disk >= run["total"]:
                    run["status"] = "已完成"
                elif run.get("status") == "排队中":
                    run["resume"] = disk > 0
                    queued.append(run)
                elif run.get("status") == "运行中":
                    # 给刚重启/尚未响应的子世界三次探活机会，再由循环判定失联。
                    run["status"] = "运行中"
                elif not self._terminal(run.get("status")):
                    run["status"] = "失败"
                    run["error"] = "主服务恢复时发现未知任务状态"
                runs.append(run)

            if queued:
                for run, port in zip(queued, _available_ports(len(queued))):
                    run["port"] = port
            prefix = data.get("prefix") or os.path.basename(os.path.dirname(path))
            with self.lock:
                self.generation += 1
                self.batch = {
                    "batch_id": data.get("batch_id") or prefix,
                    "prefix": prefix,
                    "label": data.get("label") or data.get("batch_id") or prefix,
                    "created_at": data.get("created_at") or time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "parallel": max(1, int(data.get("parallel", 1) or 1)),
                    "extra_keys": [],
                    "runs": runs,
                    "aggregated": bool(data.get("aggregated", False)),
                    "agg_dir": data.get("agg_dir", ""),
                }
                active = self._active_unlocked()
                if active:
                    self._save_manifest_unlocked()
            if active:
                self._start_thread()
            print("[批量] 已从清单恢复 {}（{} 个世界，活动中={}）".format(prefix, len(runs), active))
            return True
        return False

    def start(self, payload):
        with self.lock:
            if self.batch and any(r["status"] in ("排队中", "运行中") for r in self.batch["runs"]):
                raise ValueError("已有批量任务在运行，请先停止或等待完成。")
            label = _batch_label(payload.get("batch_label") or payload.get("name_prefix") or payload.get("name"))
            prefix = _new_batch_id()
            replicates = max(1, min(20, int(payload.get("replicates", 1))))
            parallel = max(1, min(10, int(payload.get("parallel", 3))))
            extra_keys = [k.strip() for k in (payload.get("extra_api_keys") or "").splitlines() if k.strip()]
            # 统一体系：每个"分组"就是一个世界模板（或当前页面配置）
            groups = []
            template_names = payload.get("templates") or []
            if "_planned_worlds" in payload:
                raise ValueError("实验设计功能已移除，请使用创建实验页面的世界模板批量运行。")
            if template_names:
                for t in template_names:
                    if t == "__current__":
                        cur = payload.get("current_payload") or {}
                        if not cur.get("agents"):
                            raise ValueError("当前页面配置为空（未选择智能体）")
                        groups.append(("current", dict(cur)))
                    else:
                        p = preset_path(t)
                        if not os.path.exists(p):
                            raise ValueError(f"世界模板不存在：{t}")
                        with open(p, "r", encoding="utf-8") as f:
                            # V27.4: a group requested by an old template name is labelled with the new one
                            groups.append((os.path.basename(p)[:-5], json.load(f)))
            else:
                # 旧接口兼容：conditions × 共享base
                base = {k: v for k, v in payload.items()
                        if k not in ("conditions", "replicates", "parallel", "name_prefix",
                                     "extra_api_keys", "batch_mode", "templates", "current_payload")}
                for cond in (payload.get("conditions") or [""]):
                    world = dict(base)
                    world["condition"] = cond
                    groups.append((cond or "none", world))
            # V23 模板核对：每组先生成一次最终人设；任何错误都在启动前拦下，
            # 并把各组之间的差异（声明的操纵 vs 其他）记入批次清单。
            from modules.research import world_check
            checked = []
            for group_label, world_payload in groups:
                try:
                    result, _cfg = world_check.preview_payload(world_payload)
                except (ValueError, OSError, KeyError) as exc:
                    # The world itself cannot be built here (e.g. missing persona files);
                    # the child process reports the same error for that world.
                    print("[模板核对] 无法预览「{}」：{}".format(group_label, exc))
                    continue
                if result["errors"]:
                    raise ValueError("模板「{}」核对未通过：{}".format(group_label, "；".join(result["errors"])))
                checked.append((group_label, world_payload, result["personas"]))
            comparison = world_check.compare_worlds(checked)
            for line in comparison["manipulated"]:
                print("[模板核对] 操纵差异：" + line)
            for line in comparison["other"]:
                print("[模板核对] 注意，非操纵差异：" + line)
            cfg_dir = os.path.join("results", "batch", prefix, "world-configs")
            os.makedirs(cfg_dir, exist_ok=True)
            with open(os.path.join("results", "batch", prefix, "template_check.json"), "w", encoding="utf-8") as f:
                json.dump({"comparison": comparison,
                           "personas": {label: personas for label, _p, personas in checked}},
                          f, ensure_ascii=False, indent=2)
            run_count = len(groups) * replicates
            ports = iter(_available_ports(run_count))
            runs = []
            for group_index, (group_label, world_payload) in enumerate(groups, start=1):
                group_code = "G{:02d}".format(group_index)
                for i in range(1, replicates + 1):
                    name = "{}-{}-{:02d}".format(prefix, group_code, i)
                    if not _NAME_RE.match(name):
                        raise ValueError("生成的世界名称过长或含非法字符：{}".format(name))
                    if os.path.exists(os.path.join(CHECKPOINTS_PATH, name)):
                        raise ValueError("批量世界已存在：{}；请更换批量名称".format(name))
                    world = dict(world_payload)
                    world["name"] = name
                    world["offline"] = bool(world.get("offline", False) or payload.get("offline", False))
                    # V25.1: cheap mode is chosen on the setup page for the whole batch; it enters the
                    # comparison signature, so cheap-mode worlds never share a group with main-mode ones.
                    from modules import cheap_mode
                    cheap = cheap_mode.normalize(payload.get("cheap_mode"))   # the page decides, not the template
                    world.pop("cheap_mode", None)
                    if cheap:
                        world["cheap_mode"] = {k: v for k, v in cheap.items() if k != "version"}
                    condition = str(world.get("condition", "") or group_label)
                    config_id = comparison_signature(world)
                    config_summary = comparison_summary(world)
                    world["seed"] = int(world_payload.get("seed", 0)) + i
                    research_condition = (world.get("research_design") or {}).get("condition_code")
                    if research_condition:
                        condition = research_condition
                    world["_batch"] = {
                        "batch_id": prefix,
                        "prefix": prefix,
                        "label": label,
                        "group": group_label,
                        "condition": condition,
                        "replicate": i,
                        "config_id": config_id,
                    }
                    cfg_path = os.path.join(cfg_dir, name + ".json")
                    with open(cfg_path, "w", encoding="utf-8") as f:
                        json.dump(world, f, ensure_ascii=False, indent=2)
                    runs.append({"name": name, "group": group_label, "condition": condition,
                                 "replicate": i, "port": next(ports),
                                 "status": "排队中", "step": 0,
                                 "total": int(world.get("step", 0) or 0),
                                 "stride": int(world.get("stride", 10) or 10),
                                 "offline": bool(world.get("offline", False)),
                                 "config_id": config_id, "config_summary": config_summary,
                                 "proc": None, "cfg_path": cfg_path})
            self.batch = {"batch_id": prefix, "prefix": prefix,
                          "label": label,
                          "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                          "parallel": parallel, "extra_keys": extra_keys,
                          "runs": runs, "aggregated": False, "agg_dir": ""}
            self.generation += 1
            self._save_manifest_unlocked()
        self._start_thread()
        return {"count": len(runs), "parallel": parallel,
                "batch_id": prefix, "label": label}

    def _child_env(self, idx):
        env = dict(os.environ)
        keys = self.batch.get("extra_keys") or []
        if keys:
            # 主key + 额外key 轮换（同服务商多key防限流）
            try:
                with open(os.path.join("data", "config.json"), "r", encoding="utf-8") as f:
                    base_url = json.load(f)["agent"]["think"]["llm"].get("base_url", "")
            except (OSError, json.JSONDecodeError, KeyError):
                base_url = ""
            var = LLM_PROVIDERS[_infer_provider(base_url)]["key_var"]
            pool = [os.environ.get(var, "")] + keys
            pool = [k for k in pool if k]
            if pool:
                env[var] = pool[idx % len(pool)]
        return env

    def _poll_child(self, run):
        try:
            import urllib.request
            with urllib.request.urlopen(
                    "http://127.0.0.1:{}/api/state".format(run["port"]), timeout=3) as resp:
                st = json.loads(resp.read())
            run["step"] = int(st.get("step", run["step"]) or run["step"])
            return st.get("status", "")
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _log_tail(log_path, lines=12):
        try:
            with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read().strip().splitlines()
            return "\n".join(content[-lines:]) if content else "(日志为空)"
        except OSError:
            return "(无法读取日志)"

    def _disk_step(self, name):
        """Step of the newest checkpoint on disk.

        V27.1: checkpoint names are simulate-YYYYMMDD-HHMM.json and simulated time only moves
        forward, so the newest file holds the highest step. Reading only that file (and the one
        before it if the newest is unreadable, e.g. half-written) keeps startup fast: a finished
        3-day world has about 170 checkpoints, and reading all of them for a 20-world batch took
        minutes on Windows, longer than the launcher waited."""
        folder = os.path.join("results", "checkpoints", name)
        try:
            cks = sorted(f for f in os.listdir(folder) if f.startswith("simulate-") and f.endswith(".json"))
        except OSError:
            return 0
        for fn in reversed(cks[-2:]):
            try:
                with open(os.path.join(folder, fn), "r", encoding="utf-8") as f:
                    return int(json.load(f).get("step", 0) or 0)
            except (OSError, ValueError, json.JSONDecodeError):
                continue
        return 0

    def _loop(self, generation=None):
        if generation is None:
            generation = self.generation
        idx = 0
        while True:
            # 阶段1：短暂持锁取快照与补位启动
            with self.lock:
                if generation != self.generation or not self.batch:
                    return
                runs = self.batch["runs"]
                parallel = self.batch["parallel"]
                running = [r for r in runs if r["status"] == "运行中"]
                queued = [r for r in runs if r["status"] == "排队中"]
                for r in queued[: max(0, parallel - len(running))]:
                    if r.get("resume"):
                        remaining = max(1, r["total"] - self._disk_step(r["name"]))
                        cmd = [sys.executable, "-u", "server.py",
                               "--name", r["name"], "--resume",
                               "--step", str(remaining), "--stride", str(r.get("stride", 10)),
                               "--exit-on-finish", "--port", str(r["port"])]
                        if r.get("offline"):
                            cmd.append("--offline")
                    else:
                        cmd = [sys.executable, "-u", "server.py",
                               "--config-json", r["cfg_path"], "--exit-on-finish",
                               "--port", str(r["port"])]
                    log = open(os.path.join("results", "batch", self.batch["prefix"],
                                            r["name"] + ".log"), "a", encoding="utf-8")
                    r["proc"] = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT,
                                                 env=self._child_env(idx))
                    r["status"] = "运行中"
                    r["live"] = None
                    r["_misses"] = 0
                    r["log_path"] = log.name
                    print("[批量] 启动世界 {} → 端口 {}（日志 {}）".format(r["name"], r["port"], log.name))
                    idx += 1
                running = [r for r in runs if r["status"] == "运行中"]
                self._save_manifest_unlocked()
            # 阶段2：锁外做慢操作（HTTP轮询子世界、读磁盘），结果快速回写
            updates = []
            for r in list(running):
                child_status = self._poll_child(r)  # 只写r["step"]，单写者无竞争
                proc_exited = r["proc"] is not None and r["proc"].poll() is not None
                if child_status in ("initializing", "running", "paused"):
                    r["_misses"] = 0
                    r["live"] = {"status": child_status, "port": r["port"],
                                 "step": r["step"], "cockpit_url": "/cockpit"}
                    continue
                r["live"] = None
                if child_status == "finished":
                    disk = self._disk_step(r["name"])
                    ok = disk >= r["total"] and r["total"] > 0
                    err = "" if ok else self._log_tail(r.get("log_path", ""))
                    updates.append((r, max(r["step"], disk), "已完成" if ok else "失败", err))
                elif child_status == "error":
                    disk = self._disk_step(r["name"])
                    updates.append((r, max(r["step"], disk), "失败",
                                    self._log_tail(r.get("log_path", ""))))
                elif child_status == "stopped":
                    disk = self._disk_step(r["name"])
                    updates.append((r, max(r["step"], disk), "已停止", "用户停止"))
                else:
                    r["_misses"] = int(r.get("_misses", 0)) + 1
                    if proc_exited or (r["proc"] is None and r["_misses"] >= 3):
                        disk = self._disk_step(r["name"])
                        ok = disk >= r["total"] and r["total"] > 0
                        if ok:
                            updates.append((r, max(r["step"], disk), "已完成", ""))
                        elif r["proc"] is None:
                            # 主服务关闭时，同一控制台下的子进程也可能被Windows一并终止。
                            # 这不是实验失败：从存档自动重排；0步世界则按原配置重新开始。
                            updates.append((r, max(r["step"], disk), "排队中", ""))
                        else:
                            updates.append((r, max(r["step"], disk), "失败",
                                            self._log_tail(r.get("log_path", ""))))
            with self.lock:
                if generation != self.generation or not self.batch:
                    return
                for r, step, status, err in updates:
                    r["step"] = step
                    r["status"] = status
                    r["live"] = None
                    if status == "失败":
                        r["error"] = err
                        print("[批量] !! 世界 {} 失败，日志尾部：\n{}".format(r["name"], err))
                    elif status == "排队中":
                        r["resume"] = step > 0
                        r["error"] = ""
                        r["_misses"] = 0
                        print("[批量] 世界 {} 在主服务重启后失联，已自动重新排队（存档 {} / {} 步）".format(
                            r["name"], step, r["total"]
                        ))
                    elif status == "已停止":
                        r["error"] = "用户停止"
                done = all(self._terminal(x["status"]) for x in self.batch["runs"])
                self._save_manifest_unlocked()
            if done:
                self._aggregate()
                return
            time.sleep(5)

    def _aggregate(self):
        with self.lock:
            prefix = self.batch["prefix"]
        try:
            groups = comparison_groups_for_batch(prefix)
            for group in groups:
                aggregate_prefix(prefix, group["group_id"])
            with self.lock:
                self.batch["aggregated"] = True
                self.batch["agg_dir"] = os.path.join("results", "batch", prefix, "aggregates")
                self._save_manifest_unlocked()
        except Exception as e:  # noqa: BLE001
            print("[批量] 聚合失败:", e)

    def stop(self):
        targets = []
        queued_count = 0
        with self.lock:
            if not self.batch:
                return 0
            for r in self.batch["runs"]:
                if r["status"] == "运行中":
                    targets.append(r)
                elif r["status"] == "排队中":
                    r["status"] = "已停止"
                    r["error"] = "用户停止"
                    queued_count += 1
            self._save_manifest_unlocked()
        for r in targets:
            graceful = self._request_child_stop(r["port"])
            proc = r.get("proc")
            if not graceful and proc is not None and proc.poll() is None:
                proc.terminate()
            with self.lock:
                if r["status"] == "运行中":
                    r["status"] = "已停止"
                    r["error"] = "用户停止"
                    r["live"] = None
        with self.lock:
            self._save_manifest_unlocked()
        return len(targets) + queued_count

    @staticmethod
    def _request_child_stop(port):
        try:
            import urllib.request
            body = json.dumps({"command": "stop"}).encode("utf-8")
            req = urllib.request.Request(
                "http://127.0.0.1:{}/api/control".format(port), data=body,
                headers={"Content-Type": "application/json"}, method="POST"
            )
            with urllib.request.urlopen(req, timeout=3) as resp:
                result = json.loads(resp.read())
            return bool(result.get("ok"))
        except Exception:  # noqa: BLE001
            return False

    def retry_failed(self):
        with self.lock:
            if not self.batch:
                return 0
            n = 0
            retry_runs = []
            for r in self.batch["runs"]:
                if r["status"] in ("失败", "已停止"):
                    disk = self._disk_step(r["name"])
                    if r["total"] > 0 and disk >= r["total"]:
                        r["status"] = "已完成"
                        r["step"] = disk
                        continue
                    r["status"] = "排队中"
                    r["step"] = disk
                    r["resume"] = disk > 0
                    r["error"] = ""
                    r["live"] = None
                    r["_misses"] = 0
                    retry_runs.append(r)
                    n += 1
            if retry_runs:
                for r, port in zip(retry_runs, _available_ports(len(retry_runs))):
                    r["port"] = port
            self._save_manifest_unlocked()
            if n and (self.thread is None or not self.thread.is_alive()):
                self._start_thread()
            return n


BATCH = BatchManager()


SYSTEM_VERSION = "v27.4.0-english-template-names"

LLM_PROVIDERS = {
    "openrouter": {
        "label": "OpenRouter", "base_url": "https://openrouter.ai/api/v1",
        "key_var": "OPENROUTER_API_KEY",
        "embedding": {"type": "openrouter", "base_url": "https://openrouter.ai/api/v1",
                      "model": "openai/text-embedding-3-small"},
    },
    "deepseek": {
        "label": "DeepSeek 官方", "base_url": "https://api.deepseek.com/v1",
        "key_var": "DEEPSEEK_API_KEY", "embedding": None,
    },
    "openai": {
        "label": "OpenAI官方", "base_url": "https://api.openai.com/v1",
        "key_var": "OPENAI_API_KEY",
        "embedding": {"type": "openai", "base_url": "https://api.openai.com/v1",
                      "model": "text-embedding-3-small"},
    },
    # V27.2: Google Gemini and Anthropic Claude official APIs through their OpenAI-compatible endpoints.
    "gemini": {
        "label": "Google Gemini 官方", "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "key_var": "GEMINI_API_KEY", "embedding": None,
    },
    "anthropic": {
        "label": "Anthropic Claude 官方", "base_url": "https://api.anthropic.com/v1",
        "key_var": "ANTHROPIC_API_KEY", "embedding": None,
    },
    "custom": {"label": "自定义兼容端点", "base_url": "", "key_var": "OPENAI_API_KEY",
               "embedding": None},
}


EMB_KEY_VARS = {"openrouter": "OPENROUTER_API_KEY", "openai": "OPENAI_API_KEY",
                "dashscope": "DASHSCOPE_API_KEY", "custom": "EMBEDDING_API_KEY"}
EMB_KEY_LABELS = {"OPENROUTER_API_KEY": "OpenRouter", "OPENAI_API_KEY": "OpenAI",
                  "DASHSCOPE_API_KEY": "阿里云百炼", "EMBEDDING_API_KEY": "自定义嵌入端点"}
DASHSCOPE_EMBEDDING = {"type": "dashscope", "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
                       "model": "text-embedding-v4"}


def _mask_key(k):
    if not k:
        return ""
    return k[:7] + "…" + k[-4:] if len(k) > 14 else "已设置"


def _update_env_file(var, value):
    lines = []
    if os.path.exists(".env"):
        with open(".env", "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    done = False
    for i, line in enumerate(lines):
        if line.strip().startswith(var + "="):
            lines[i] = f"{var}={value}"
            done = True
            break
    if not done:
        lines.append(f"{var}={value}")
    with open(".env", "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    os.environ[var] = value


def _infer_provider(base_url):
    u = base_url or ""
    if "openrouter" in u:
        return "openrouter"
    if "deepseek" in u:
        return "deepseek"
    if "openai.com" in u:
        return "openai"
    if "generativelanguage.googleapis.com" in u:
        return "gemini"
    if "api.anthropic.com" in u:
        return "anthropic"
    return "custom"


def maybe_rebuild_maze():
    """tilemap.json 比 maze.json 新时自动重建地址层（Tiled管线）。"""
    try:
        from modules import mapgen
        if not mapgen.needs_rebuild():
            return
        report = mapgen.build(write=True)
        if report.get("skipped"):
            return
        if report.get("ok"):
            print("[地图管线] {} 校验全部通过。".format(report.get("message", "")))
        else:
            print("[地图管线] !! {}".format(report.get("message", "重建失败")))
            for m in report.get("agent_missing_addresses", []):
                print("[地图管线]    缺失地址:", m)
    except Exception as e:  # noqa: BLE001
        print("[地图管线] 重建异常（继续使用现有maze.json）:", e)


def create_app(holder):
    app = Flask(
        __name__,
        template_folder="frontend/templates",
        static_folder="frontend/static",
        static_url_path="/static",
    )

    def runner():
        return holder.get("runner")

    # 只在实验管理主服务真正访问补测功能时创建。批量子世界也会加载
    # create_app；延迟初始化可避免子世界误把主服务中的运行任务标记为中断。
    posthoc_holder = {}

    def posthoc_manager():
        manager = posthoc_holder.get("manager")
        if manager is None:
            manager = posthoc.TaskManager()
            posthoc_holder["manager"] = manager
        return manager

    def posthoc_group(batch_id, group_id):
        groups = comparison_groups_for_batch(batch_id)
        return next((g for g in groups if g.get("group_id") == group_id), None)

    @app.route("/", methods=["GET"])
    def live():
        r = runner()
        if r is None:
            return redirect("/experiments")
        zoom = float(request.args.get("zoom", 0))
        positions = r.initial_positions()
        return render_template(
            "live.html",
            persona_names=list(positions.keys()),
            persona_init_pos=positions,
            navigation_policy=r.config.get("navigation_policy", "legacy"),
            sim_name=r.name,
            condition=r.state["condition"],
            zoom=zoom,
            embed=request.args.get("embed") == "1",
        )

    @app.route("/console", methods=["GET"])
    def console():
        r = runner()
        if r is None:
            return redirect("/experiments")
        positions = r.initial_positions()
        return render_template(
            "console.html",
            persona_names=list(positions.keys()),
            sim_name=r.name,
            condition=r.state["condition"],
            embed=request.args.get("embed") == "1",
        )

    @app.route("/cockpit", methods=["GET"])
    def cockpit():
        r = runner()
        if r is None:
            return redirect("/experiments")
        return render_template(
            "cockpit.html", sim_name=r.name, condition=r.state["condition"]
        )

    @app.route("/monitor", methods=["GET"])
    def monitor():
        r = runner()
        if r is None:
            return redirect("/experiments")
        positions = r.initial_positions()
        return render_template(
            "monitor.html",
            persona_names=list(positions.keys()),
            sim_name=r.name,
        )

    @app.route("/api/steps/meta")
    def api_steps_meta():
        r = runner()
        if r is None or not r.step_records:
            return jsonify({"min": 0, "max": 0})
        return jsonify({
            "min": r.step_records[0]["step"],
            "max": r.step_records[-1]["step"],
            "latest_time": r.step_records[-1]["time"],
        })

    @app.route("/api/steps")
    def api_steps():
        r = runner()
        if r is None:
            return jsonify({"ok": False, "error": "实验尚未启动"}), 409
        try:
            step = int(request.args.get("step", 0))
        except ValueError:
            return jsonify({"ok": False, "error": "step必须是整数"}), 400
        from modules.research.common import fill_prev_coords
        records = fill_prev_coords(r.step_records)
        for rec in records:
            if rec["step"] == step:
                return jsonify({"ok": True, "record": rec})
        return jsonify({"ok": False, "error": f"step {step} 无记录"}), 404

    @app.route("/api/timeline")
    def api_timeline():
        r = runner()
        if r is None:
            return jsonify({"rows": [], "total": 0})
        jsonl_path = os.path.join("results", "monitor", r.name, "timeline.jsonl")
        rows = []
        if os.path.exists(jsonl_path):
            with open(jsonl_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        rows.append(json.loads(line))
        agent = request.args.get("agent", "")
        types = [t for t in request.args.get("types", "").split(",") if t]
        keyword = request.args.get("q", "").strip()
        if agent:
            rows = [x for x in rows if x.get("agent") == agent]
        if types:
            rows = [x for x in rows if x.get("type") in types]
        if keyword:
            rows = [x for x in rows if keyword in (x.get("text") or "")]
        total = len(rows)
        try:
            offset = max(0, int(request.args.get("offset", 0)))
            limit = min(500, max(1, int(request.args.get("limit", 200))))
        except ValueError:
            offset, limit = 0, 200
        # 最新在前
        rows = list(reversed(rows))[offset: offset + limit]
        return jsonify({"rows": rows, "total": total, "offset": offset})

    # ------------------ 配置器 ------------------
    # ------------------ 实验管理 ------------------
    @app.route("/experiments", methods=["GET"])
    def experiments_page():
        r = runner()
        return render_template(
            "experiments.html",
            active_name=(r.name if r else ""),
            active_status=(r.state["status"] if r else ""),
        )

    @app.route("/posthoc", methods=["GET"])
    def posthoc_page():
        batch_id = (request.args.get("batch_id") or "").strip()
        group_id = (request.args.get("group_id") or "").strip()
        if not (_SAFE_PART.match(batch_id) and _SAFE_PART.match(group_id)):
            return redirect("/experiments")
        return render_template("posthoc.html", batch_id=batch_id, group_id=group_id)

    @app.route("/api/experiments")
    def api_experiments():
        r = runner()
        batches = scan_batches()
        manager = posthoc_manager()
        for batch in batches:
            for group in batch.get("comparison_groups") or []:
                group["posthoc_tasks"] = manager.list_group(
                    batch["batch_id"], group["group_id"]
                )[:3]
        return jsonify({
            "experiments": scan_experiments(),
            "batches": batches,
            "active": {"name": r.name, "status": r.state["status"]} if r else None,
            "busy": runner_busy(),
        })

    @app.route("/api/posthoc/group")
    def api_posthoc_group():
        batch_id = (request.args.get("batch_id") or "").strip()
        group_id = (request.args.get("group_id") or "").strip()
        if not (_SAFE_PART.match(batch_id or "") and _SAFE_PART.match(group_id or "")):
            return jsonify({"ok": False, "error": "批次或配置组标识不合法"}), 400
        group = posthoc_group(batch_id, group_id)
        if group is None:
            return jsonify({"ok": False, "error": "可比配置组不存在或已经变化"}), 404
        try:
            catalog = posthoc.group_catalog(group)
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({
            "ok": True, "batch_id": batch_id, "group_id": group_id,
            "group_label": group.get("label", ""), "summary": group.get("summary") or {},
            "run_count": group.get("run_count", 0), "verified": bool(group.get("verified")),
            "tasks": posthoc_manager().list_group(batch_id, group_id), **catalog,
        })

    def _prepare_posthoc_request(data):
        batch_id = str(data.get("batch_id") or "").strip()
        group_id = str(data.get("group_id") or "").strip()
        if not (_SAFE_PART.match(batch_id or "") and _SAFE_PART.match(group_id or "")):
            raise ValueError("批次或配置组标识不合法")
        group = posthoc_group(batch_id, group_id)
        if group is None:
            raise ValueError("可比配置组不存在或已经变化，请刷新页面")
        live = [run["name"] for run in group.get("runs") or [] if probe_runtime(run["name"])]
        if live:
            raise ValueError("以下世界仍在运行，不能作为历史补测来源：{}".format("、".join(live)))
        return posthoc.prepare_task(
            batch_id, group, data.get("frames") or [], data.get("added_surveys") or []
        )

    @app.route("/api/posthoc/preview", methods=["POST"])
    def api_posthoc_preview():
        data = request.get_json(silent=True) or {}
        try:
            prepared = _prepare_posthoc_request(data)
        except (ValueError, survey_engine.SchemaError) as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "preview": prepared})

    @app.route("/api/posthoc/tasks", methods=["POST"])
    def api_posthoc_tasks_create():
        data = request.get_json(silent=True) or {}
        try:
            prepared = _prepare_posthoc_request(data)
            task = posthoc_manager().create(prepared, data.get("title", ""))
        except (ValueError, survey_engine.SchemaError, OSError) as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "task": task})

    @app.route("/api/posthoc/tasks/<task_id>")
    def api_posthoc_task(task_id):
        if not _SAFE_PART.match(task_id or ""):
            return jsonify({"ok": False, "error": "任务标识不合法"}), 400
        found = posthoc_manager().find(task_id)
        if not found:
            return jsonify({"ok": False, "error": "补测任务不存在"}), 404
        return jsonify({"ok": True, "task": found[2]})

    @app.route("/api/posthoc/tasks/<task_id>/cancel", methods=["POST"])
    def api_posthoc_task_cancel(task_id):
        found = posthoc_manager().find(task_id)
        if not found:
            return jsonify({"ok": False, "error": "补测任务不存在"}), 404
        status = posthoc_manager().cancel(found[0], found[1], task_id)
        return jsonify({"ok": True, "task": status})

    @app.route("/api/posthoc/tasks/<task_id>/retry", methods=["POST"])
    def api_posthoc_task_retry(task_id):
        found = posthoc_manager().find(task_id)
        if not found:
            return jsonify({"ok": False, "error": "补测任务不存在"}), 404
        try:
            task = posthoc_manager().retry(found[0], found[1], task_id)
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 409
        return jsonify({"ok": True, "task": task})

    @app.route("/api/posthoc/tasks/<task_id>/download")
    def api_posthoc_task_download(task_id):
        found = posthoc_manager().find(task_id)
        if not found:
            return jsonify({"ok": False, "error": "补测任务不存在"}), 404
        bundle = posthoc_manager().bundle(found[0], found[1], task_id)
        if bundle is None:
            return jsonify({"ok": False, "error": "补测结果不存在"}), 404
        return send_file(
            bundle, mimetype="application/zip", as_attachment=True,
            download_name="{}-{}-聚合补测数据.zip".format(found[0], task_id),
        )

    @app.route("/api/resume", methods=["POST"])
    def api_resume():
        if runner_busy():
            return jsonify({"ok": False, "error": "当前有实验正在运行，请先停止或等待结束。"}), 409
        data = request.get_json(silent=True) or {}
        name = str(data.get("name", "")).strip()
        if not _SAFE_PART.match(name) or not os.path.isdir(os.path.join(CHECKPOINTS_PATH, name)):
            return jsonify({"ok": False, "error": f"实验不存在：{name}"}), 404
        try:
            steps = max(0, min(100000, int(data.get("steps", 0))))
        except (TypeError, ValueError):
            return jsonify({"ok": False, "error": "步数必须是整数"}), 400
        offline = bool(data.get("offline"))
        args = types.SimpleNamespace(
            name=name, start="", resume=True, step=steps, stride=0,
            verbose="info", log="server.log", condition="",
            disable_daily_survey=False, offline=offline, port=0, host="",
        )
        try:
            new_runner = SimulationRunner(args)
        except SystemExit as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        # 步长：请求未指定时自动沿用存档中的原步长，保证续跑时间粒度一致
        req_stride = data.get("stride")
        if req_stride in (None, "", 0, "0"):
            new_runner.args.stride = int(new_runner.config.get("stride", 10) or 10)
        else:
            try:
                new_runner.args.stride = max(1, min(720, int(req_stride)))
            except (TypeError, ValueError):
                new_runner.args.stride = int(new_runner.config.get("stride", 10) or 10)
        if offline or steps == 0:
            apply_offline_overrides(new_runner.config)
        holder["runner"] = new_runner
        new_runner.run()
        mode = "查看模式（不再推进）" if steps == 0 else f"继续运行 {steps} 步"
        return jsonify({"ok": True, "name": name, "mode": mode, "redirect": "/"})

    @app.route("/api/delete_experiment", methods=["POST"])
    def api_delete_experiment():
        data = request.get_json(silent=True) or {}
        name = str(data.get("name", "")).strip()
        if not _SAFE_PART.match(name):
            return jsonify({"ok": False, "error": "名称不合法"}), 400
        r = runner()
        if r is not None and r.name == name and runner_busy():
            return jsonify({"ok": False, "error": "该实验正在运行，请先停止再删除。"}), 409
        # Windows 下已结束的运行器仍可能短暂持有索引文件句柄；先从应用释放引用再删目录。
        if r is not None and r.name == name:
            holder["runner"] = None
            r = None
            import gc
            gc.collect()
        deleted = []
        failures = []
        for sub in ("checkpoints", "surveys", "psych", "monitor", "interventions"):
            d = os.path.join("results", sub, name)
            if os.path.isdir(d):
                try:
                    shutil.rmtree(d)
                    deleted.append(sub)
                except OSError as exc:
                    failures.append("{}: {}".format(sub, exc))
        if failures:
            return jsonify({
                "ok": False,
                "error": "部分数据仍被系统占用，请稍后重试：" + "；".join(failures),
                "deleted": deleted,
            }), 409
        return jsonify({"ok": True, "deleted": deleted})

    @app.route("/api/delete_batch", methods=["POST"])
    def api_delete_batch():
        data = request.get_json(silent=True) or {}
        batch_id = str(data.get("batch_id", "")).strip()
        if not _SAFE_PART.match(batch_id):
            return jsonify({"ok": False, "error": "批次标识不合法"}), 400
        batch_dir = os.path.join("results", "batch", batch_id)
        manifest = _read_batch_manifest(batch_id)
        if not os.path.isdir(batch_dir) or not manifest:
            return jsonify({"ok": False, "error": "批次不存在或批次清单无法读取"}), 404
        run_names = []
        for saved in manifest.get("runs") or []:
            name = str(saved.get("name", "")).strip()
            if not _SAFE_PART.match(name):
                return jsonify({"ok": False, "error": "批次中包含不合法的世界标识，已拒绝删除"}), 400
            run_names.append(name)

        with BATCH.lock:
            current = BATCH.batch
            is_current = bool(current and (
                current.get("batch_id") == batch_id or current.get("prefix") == batch_id
            ))
            thread_alive = bool(BATCH.thread and BATCH.thread.is_alive())
            if is_current and (BATCH._active_unlocked() or thread_alive):
                return jsonify({
                    "ok": False,
                    "error": "该批次仍在运行或正在收尾，请先停止并等待状态稳定后再删除。",
                }), 409

        r = runner()
        if r is not None and r.name in run_names and runner_busy():
            return jsonify({"ok": False, "error": "该批次中的世界正在运行，请先停止再删除。"}), 409
        if r is not None and r.name in run_names:
            holder["runner"] = None
            r = None
            import gc
            gc.collect()

        posthoc_batch_dir = os.path.join(posthoc.ROOT, batch_id)
        if os.path.isdir(posthoc_batch_dir):
            for group_name in os.listdir(posthoc_batch_dir):
                for task in posthoc_manager().list_group(batch_id, group_name):
                    if task.get("status") in ("queued", "running", "cancelling"):
                        return jsonify({
                            "ok": False,
                            "error": "该批次仍有历史补测任务在运行，请先在补测页面停止任务。",
                        }), 409

        marker = os.path.join(batch_dir, BATCH_DELETE_MARKER)
        try:
            with open(marker, "w", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
        except OSError as exc:
            return jsonify({"ok": False, "error": "无法标记批次删除状态：{}".format(exc)}), 409

        # 标记落盘后立即释放当前批次状态；即使用户此时刷新页面或重启服务，
        # scan_batches() 也不会把正在清理的批次重新显示出来。
        with BATCH.lock:
            current = BATCH.batch
            if current and (current.get("batch_id") == batch_id or current.get("prefix") == batch_id):
                BATCH.batch = None
                BATCH.thread = None
                BATCH.generation += 1

        def restore_history_marker():
            try:
                if os.path.exists(marker):
                    os.remove(marker)
            except OSError:
                pass

        deleted_worlds = []
        failures = []
        for name in run_names:
            world_deleted = False
            for sub in ("checkpoints", "surveys", "psych", "monitor", "interventions"):
                folder = os.path.join("results", sub, name)
                if not os.path.isdir(folder):
                    continue
                try:
                    shutil.rmtree(folder)
                    world_deleted = True
                except OSError as exc:
                    failures.append("{} / {}: {}".format(name, sub, exc))
            if world_deleted:
                deleted_worlds.append(name)
        if failures:
            restore_history_marker()
            return jsonify({
                "ok": False,
                "error": "部分数据仍被系统占用，请稍后重试：" + "；".join(failures),
                "deleted_worlds": len(deleted_worlds),
            }), 409

        try:
            shutil.rmtree(batch_dir)
        except OSError as exc:
            restore_history_marker()
            return jsonify({
                "ok": False,
                "error": "子世界已清理，但批次目录删除失败，请重试：{}".format(exc),
                "deleted_worlds": len(deleted_worlds),
            }), 409

        if os.path.isdir(posthoc_batch_dir):
            try:
                shutil.rmtree(posthoc_batch_dir)
            except OSError as exc:
                return jsonify({
                    "ok": False,
                    "error": "批次实验已删除，但补测结果目录清理失败：{}".format(exc),
                    "deleted_worlds": len(deleted_worlds),
                }), 409

        return jsonify({
            "ok": True,
            "batch_id": batch_id,
            "deleted_worlds": len(run_names),
        })

    @app.route("/api/world_presets", methods=["GET"])
    def api_presets_list():
        d = os.path.join("data", "world_presets")
        names = []
        if os.path.isdir(d):
            names = sorted(f[:-5] for f in os.listdir(d) if f.endswith(".json"))
        return jsonify({"ok": True, "presets": names})

    @app.route("/api/world_presets", methods=["POST"])
    def api_presets_save():
        data = request.get_json(silent=True) or {}
        name = (data.get("name") or "").strip()
        payload = data.get("payload")
        if not _NAME_RE.match(name):
            return jsonify({"ok": False, "error": "模板名只能包含中文、字母、数字、下划线或连字符（≤40字符）"}), 400
        if not isinstance(payload, dict) or not payload.get("agents"):
            return jsonify({"ok": False, "error": "配置为空或缺少智能体名单"}), 400
        d = os.path.join("data", "world_presets")
        os.makedirs(d, exist_ok=True)
        payload = dict(payload)
        payload.pop("name", None)
        with open(os.path.join(d, name + ".json"), "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return jsonify({"ok": True, "message": "世界模板「{}」已保存".format(name)})

    @app.route("/api/world_presets/get")
    def api_presets_get():
        name = (request.args.get("name") or "").strip()
        p = preset_path(name)
        if not os.path.exists(p):
            return jsonify({"ok": False, "error": "模板不存在"}), 404
        with open(p, "r", encoding="utf-8") as f:
            return jsonify({"ok": True, "payload": json.load(f)})

    @app.route("/api/world_presets", methods=["DELETE"])
    def api_presets_delete():
        name = (request.args.get("name") or "").strip()
        p = os.path.join("data", "world_presets", name + ".json")
        if os.path.exists(p):
            os.remove(p)
            return jsonify({"ok": True})
        return jsonify({"ok": False, "error": "模板不存在"}), 404

    @app.route("/api/experiment_payload")
    def api_experiment_payload():
        name = (request.args.get("name") or "").strip()
        folder = os.path.join("results", "checkpoints", name)
        if not os.path.isdir(folder):
            return jsonify({"ok": False, "error": "找不到该实验"}), 404
        cks = sorted(f for f in os.listdir(folder) if f.startswith("simulate-") and f.endswith(".json"))
        for fn in reversed(cks):
            try:
                with open(os.path.join(folder, fn), "r", encoding="utf-8") as f:
                    cfg = json.load(f)
            except (OSError, json.JSONDecodeError):
                continue
            sp = cfg.get("setup_payload")
            if sp:
                return jsonify({"ok": True, "payload": sp})
        return jsonify({"ok": False, "error": "该实验是旧版本运行的，存档中没有原始配置（新实验才支持）"}), 404

    @app.route("/api/version")
    def api_version():
        return jsonify({"version": SYSTEM_VERSION, "project_path": os.path.dirname(os.path.abspath(__file__))})

    @app.route("/api/aggregate", methods=["POST"])
    def api_aggregate():
        data = request.get_json(silent=True) or {}
        prefix = (data.get("batch_id") or data.get("prefix") or "").strip()
        group_id = str(data.get("group_id") or "").strip()
        if not _SAFE_PART.match(prefix or ""):
            return jsonify({"ok": False, "error": "批次标识不合法"}), 400
        if group_id and not _SAFE_PART.match(group_id):
            return jsonify({"ok": False, "error": "配置组标识不合法"}), 400
        try:
            files, n_runs, _, selected = aggregate_prefix(prefix, group_id or None)
        except ValueError as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        except Exception as e:  # noqa: BLE001
            return jsonify({"ok": False, "error": f"聚合失败：{e}"}), 500
        return jsonify({"ok": True, "runs": n_runs, "files": files,
                        "group": selected["label"],
                        "zip_url": "/api/aggregate_zip?prefix={}&group_id={}".format(
                            prefix, selected["group_id"]
                        )})

    @app.route("/api/aggregate_zip")
    def api_aggregate_zip():
        import io
        import zipfile as _zipfile
        prefix = (request.args.get("prefix") or "").strip()
        group_id = (request.args.get("group_id") or "").strip()
        if not _SAFE_PART.match(prefix or ""):
            return jsonify({"ok": False, "error": "批次标识不合法"}), 400
        if not _SAFE_PART.match(group_id or ""):
            return jsonify({"ok": False, "error": "请从可比实验组内下载"}), 400
        groups = comparison_groups_for_batch(prefix)
        selected = next((group for group in groups if group["group_id"] == group_id), None)
        if selected is None:
            return jsonify({"ok": False, "error": "配置组不存在"}), 404
        out_dir = os.path.join("results", "batch", prefix, "aggregates", group_id)
        if not os.path.isdir(out_dir):
            return jsonify({"ok": False, "error": "该配置组尚未聚合"}), 404
        buf = io.BytesIO()
        with _zipfile.ZipFile(buf, "w", _zipfile.ZIP_DEFLATED) as zf:
            primary = list(exporter.PRIMARY_TABLES) + ["summary_by_condition.csv"]
            for fn in primary:
                path = os.path.join(out_dir, fn)
                if not os.path.isfile(path):
                    continue
                zi = _zipfile.ZipInfo(fn)
                zi.flag_bits |= 0x800
                with open(path, "rb") as f:
                    zf.writestr(zi, f.read())
        buf.seek(0)
        return send_file(buf, mimetype="application/zip", as_attachment=True,
                         download_name="{}-{}-合并数据.zip".format(prefix, selected["label"]))

    @app.route("/api/batch_bundle.zip")
    def api_batch_bundle_zip():
        """整批下载，但每个可比配置组保持独立子目录，绝不跨配置混表。"""
        import io
        import zipfile as _zipfile
        prefix = (request.args.get("batch_id") or "").strip()
        if not _SAFE_PART.match(prefix or ""):
            return jsonify({"ok": False, "error": "批次标识不合法"}), 400
        groups = comparison_groups_for_batch(prefix)
        if not groups:
            return jsonify({"ok": False, "error": "批次没有可导出的世界"}), 404
        buf = io.BytesIO()
        with _zipfile.ZipFile(buf, "w", _zipfile.ZIP_DEFLATED) as zf:
            for group in groups:
                aggregate_prefix(prefix, group["group_id"])
                folder = os.path.join("results", "batch", prefix, "aggregates", group["group_id"])
                safe_label = _re.sub(r"[\\/:*?\"<>|]+", "_", group["label"]).strip(" .")
                archive_dir = "{}-{}".format(group["group_id"], safe_label or "配置组")
                for fn in list(exporter.PRIMARY_TABLES) + ["summary_by_condition.csv"]:
                    path = os.path.join(folder, fn)
                    if not os.path.isfile(path):
                        continue
                    zi = _zipfile.ZipInfo(archive_dir + "/" + fn)
                    zi.flag_bits |= 0x800
                    with open(path, "rb") as f:
                        zf.writestr(zi, f.read())
        buf.seek(0)
        return send_file(buf, mimetype="application/zip", as_attachment=True,
                         download_name="{}-按可比组数据包.zip".format(prefix))

    @app.route("/api/batch_start", methods=["POST"])
    def api_batch_start():
        payload = request.get_json(silent=True) or {}
        try:
            info = BATCH.start(payload)
        except ValueError as e:
            return jsonify({"ok": False, "error": str(e)}), 409
        return jsonify({"ok": True, **info, "redirect": "/experiments"})

    @app.route("/api/batch_state")
    def api_batch_state():
        return jsonify(BATCH.snapshot())

    @app.route("/api/batch_stop", methods=["POST"])
    def api_batch_stop():
        return jsonify({"ok": True, "stopped": BATCH.stop()})

    @app.route("/api/batch_retry", methods=["POST"])
    def api_batch_retry():
        return jsonify({"ok": True, "requeued": BATCH.retry_failed()})

    @app.route("/api/batch_download")
    def api_batch_download():
        fn = os.path.basename(request.args.get("f") or "")
        snap = BATCH.snapshot()
        if not snap.get("agg_dir") or not fn:
            return jsonify({"ok": False, "error": "无聚合产出"}), 404
        path_ = os.path.join(snap["agg_dir"], fn)
        if not os.path.exists(path_):
            return jsonify({"ok": False, "error": "文件不存在"}), 404
        return send_file(os.path.abspath(path_), as_attachment=True)

    @app.route("/api/survey_designs")
    def api_survey_designs():
        name = (request.args.get("name") or "").strip()
        if not name:
            return jsonify({"ok": False, "error": "缺少实验名"}), 400
        folder = os.path.join("results", "checkpoints", name)
        if not os.path.isdir(folder):
            return jsonify({"ok": False, "error": "找不到该实验"}), 404
        cks = sorted(f for f in os.listdir(folder) if f.startswith("simulate-") and f.endswith(".json"))
        if not cks:
            return jsonify({"ok": False, "error": "该实验没有存档"}), 404
        try:
            with open(os.path.join(folder, cks[-1]), "r", encoding="utf-8") as f:
                cfg = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            return jsonify({"ok": False, "error": str(e)}), 500
        out = []
        for sc in cfg.get("custom_surveys") or []:
            qs = []
            for q in sc.get("questions") or []:
                item = {"id": q.get("id", ""), "text": q.get("text", ""), "type": q.get("type", "likert"),
                        "min": q.get("min", 1), "max": q.get("max", 7),
                        "min_label": q.get("min_label", ""), "max_label": q.get("max_label", ""),
                        "options": "/".join(q.get("options") or []) if isinstance(q.get("options"), list)
                                   else (q.get("options") or "")}
                qs.append(item)
            out.append({"id": sc.get("id", ""), "title": sc.get("title", ""),
                        "trigger_time": sc.get("trigger_time", "21:30"),
                        "include_reason": bool(sc.get("include_reason", True)),
                        "mode": sc.get("mode", "self"),
                        "targets": sc.get("targets") or [], "raters": sc.get("raters") or [],
                        "ratees": sc.get("ratees") or [], "questions": qs})
        return jsonify({"ok": True, "surveys": out})

    @app.route("/api/llm_settings", methods=["GET"])
    def api_llm_settings_get():
        with open(os.path.join("data", "config.json"), "r", encoding="utf-8") as f:
            cfg = json.load(f)
        llm = cfg["agent"]["think"]["llm"]
        emb = (cfg["agent"].get("associate") or {}).get("embedding", {})
        return jsonify({
            "provider": _infer_provider(llm.get("base_url", "")),
            "base_url": llm.get("base_url", ""),
            "model": llm.get("model", ""),
            "embedding_type": emb.get("type", ""),
            "embedding_model": emb.get("model", ""),
            "embedding_base_url": emb.get("base_url", ""),
            "keys": {v: _mask_key(os.environ.get(v, "")) for v in
                     ("OPENROUTER_API_KEY", "DEEPSEEK_API_KEY", "OPENAI_API_KEY",
                      "GEMINI_API_KEY", "ANTHROPIC_API_KEY",
                      "DASHSCOPE_API_KEY", "EMBEDDING_API_KEY")},
        })

    @app.route("/api/llm_settings", methods=["POST"])
    def api_llm_settings_post():
        data = request.get_json(silent=True) or {}
        provider = str(data.get("provider", "")).strip()
        if provider not in LLM_PROVIDERS:
            return jsonify({"ok": False, "error": "未知的服务商"}), 400
        p = LLM_PROVIDERS[provider]
        base_url = str(data.get("base_url", "")).strip() or p["base_url"]
        if not base_url.startswith("http"):
            return jsonify({"ok": False, "error": "自定义端点需要填写完整的 http(s) 地址"}), 400
        model = str(data.get("model", "")).strip()
        if not model:
            return jsonify({"ok": False, "error": "请填写模型名"}), 400
        api_key = str(data.get("api_key", "")).strip()
        emb_api_key = str(data.get("embedding_api_key", "") or "").strip()
        if not api_key and not os.environ.get(p["key_var"]):
            return jsonify({"ok": False, "error": f"尚未提供 {p['key_var']}，请在“对话模型”里填写 API key"}), 400

        cfg_path = os.path.join("data", "config.json")
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        cfg["agent"]["think"]["llm"]["base_url"] = base_url
        cfg["agent"]["think"]["llm"]["model"] = model
        warnings = []
        emb_type = str(data.get("embedding_type", "") or "").strip()
        emb_model = str(data.get("embedding_model", "") or "").strip()
        if emb_type in ("openrouter", "hugging_face") and ("/" not in emb_model or ":" in emb_model):
            emb_model = ""  # 本地模型名（如 bge-m3:latest）不能用于云端/HF 通道，改用推荐默认
        if emb_type in ("openai", "dashscope") and ("/" in emb_model or ":" in emb_model):
            emb_model = ""
        if emb_type == "ollama" and "/" in emb_model:
            emb_model = ""  # 换到本地 Ollama 时残留的云端模型名，改用默认 bge-m3:latest
        emb_base = str(data.get("embedding_base_url", "") or "").strip()
        if emb_type == "custom" and (not emb_base.startswith("http") or not emb_model):
            return jsonify({"ok": False, "error": "自定义嵌入端点需要填写完整的 http(s) 地址和嵌入模型名"}), 400
        EMB_PRESETS = {
            "openrouter": {"type": "openrouter", "base_url": "https://openrouter.ai/api/v1",
                           "model": emb_model or "openai/text-embedding-3-small"},
            "openai": {"type": "openai", "base_url": "https://api.openai.com/v1",
                       "model": emb_model or "text-embedding-3-small"},
            "hugging_face": {"type": "hugging_face",
                             "model": emb_model or "BAAI/bge-small-zh-v1.5"},
            "ollama": {"type": "ollama", "base_url": "http://127.0.0.1:11434",
                       "model": emb_model or "bge-m3:latest"},
            "dashscope": dict(DASHSCOPE_EMBEDDING, model=emb_model or DASHSCOPE_EMBEDDING["model"]),
            "custom": {"type": "custom", "base_url": emb_base.rstrip("/"), "model": emb_model},
        }
        if emb_type in EMB_PRESETS:
            # 用户显式指定嵌入通道/模型：直接生效
            cfg["agent"].setdefault("associate", {})["embedding"] = EMB_PRESETS[emb_type]
        elif p["embedding"] is not None:
            # 未显式指定时沿用服务商联动默认（openrouter/openai 自动跟随）
            cfg["agent"].setdefault("associate", {})["embedding"] = dict(p["embedding"])
        elif provider == "deepseek":
            # DeepSeek 官方没有嵌入接口：“自动”时走 OpenRouter
            cfg["agent"].setdefault("associate", {})["embedding"] = EMB_PRESETS["openrouter"]
        emb = (cfg["agent"].get("associate") or {}).get("embedding", {})
        emb_key_var = EMB_KEY_VARS.get(emb.get("type", ""))
        if emb_api_key:
            if not emb_key_var:
                return jsonify({"ok": False, "error": "本地嵌入通道不需要 API key，请清空“嵌入 API Key”"}), 400
            if emb_key_var == p["key_var"] and api_key and api_key != emb_api_key:
                return jsonify({"ok": False, "error": "对话和嵌入用的是同一个服务商的 key，两处填写不一致，请只填一处"}), 400
        # 校验通过后再写入两个 key
        if api_key:
            _update_env_file(p["key_var"], api_key)
        if emb_api_key:
            _update_env_file(emb_key_var, emb_api_key)
        if emb.get("type") == "hugging_face":
            warnings.append("本地HuggingFace嵌入需要额外依赖（torch+sentence-transformers，约2GB，一次性）："
                            "在项目根目录命令行执行 .venv\\Scripts\\pip install llama-index-embeddings-huggingface")
        if emb.get("type") == "ollama":
            warnings.append("本地Ollama嵌入需要本机已安装并运行 Ollama，且已拉取所选嵌入模型。")
        if True:
            if emb_key_var and not os.environ.get(emb_key_var):
                warnings.append(
                    "记忆嵌入走 {}，但还没有保存 {}，新实验的记忆检索会失败——"
                    "请在“记忆嵌入模型”里填写这个 key 后再保存一次。".format(
                        EMB_KEY_LABELS.get(emb_key_var, emb_key_var), emb_key_var))
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        return jsonify({"ok": True, "provider": provider, "base_url": base_url,
                        "model": model, "warnings": warnings,
                        "message": "已保存。新启动的实验将使用该设置（进行中的实验不受影响）。"})

    def _explain_conn_error(exc, where):
        """V27.2: plain explanation of common connection failures. The text is Chinese and the English
        interface translates it (en.json); the operating system's own message, which Windows writes in the
        system language, is dropped so that no untranslatable text reaches the page."""
        raw = str(exc)
        low = raw.lower()
        local_ollama = "11434" in raw
        if "10061" in raw or "connection refused" in low or "积极拒绝" in raw or "errno 111" in low:
            if local_ollama:
                return "无法连接本地 Ollama（127.0.0.1:11434）：Ollama 没有运行。请先打开 Ollama，再重新测试。"
            return "无法连接" + where + "：对方拒绝连接。请检查服务地址，以及本机是否开着代理或防火墙。"
        if "10060" in raw or "timed out" in low or "timeout" in low or "超时" in raw:
            return "连接" + where + "超时：网络不通或太慢。请检查网络或代理后重试。"
        if "11001" in raw or "getaddrinfo" in low or "name or service not known" in low or "nodename nor servname" in low:
            return "找不到" + where + "的地址：请检查服务地址是否写对，以及网络是否可用。"
        if local_ollama and ("404" in raw or "not found" in low):
            return "本地 Ollama 没有这个嵌入模型：请在命令行运行 ollama pull bge-m3，再重新测试。"
        # anything else: keep the technical text but drop Windows' localized sentence after [WinError N]
        return re.sub(r"(\[WinError \d+\])[^\]\)\"']*", r"\1", raw)[:300]

    @app.route("/api/llm_test", methods=["POST"])
    def api_llm_test():
        import time as _time
        from openai import OpenAI as _OpenAI
        import requests as _requests

        data = request.get_json(silent=True) or {}
        with open(os.path.join("data", "config.json"), "r", encoding="utf-8") as f:
            cfg = json.load(f)
        llm = cfg["agent"]["think"]["llm"]
        base_url = str(data.get("base_url", "") or "").strip() or llm.get("base_url", "")
        model = str(data.get("model", "") or "").strip() or llm.get("model", "")
        provider = _infer_provider(base_url)
        key = os.environ.get(LLM_PROVIDERS[provider]["key_var"], "")
        chat_result = {"ok": False, "provider": provider, "model": model}
        if not key:
            chat_result["error"] = f"缺少 {LLM_PROVIDERS[provider]['key_var']}"
        else:
            try:
                headers = {}
                if provider == "openrouter":
                    if os.environ.get("OPENROUTER_SITE_URL"):
                        headers["HTTP-Referer"] = os.environ["OPENROUTER_SITE_URL"]
                    if os.environ.get("OPENROUTER_APP_NAME"):
                        headers["X-OpenRouter-Title"] = os.environ["OPENROUTER_APP_NAME"]
                client = _OpenAI(
                    api_key=key, base_url=base_url, timeout=30,
                    **({"default_headers": headers} if headers else {}),
                )
                t0 = _time.time()
                from modules.model.llm_model import deepseek_thinking
                thinking = deepseek_thinking(base_url, llm)
                # Claude 4.7+ rejects temperature below 1 on the compatible endpoint: leave it unset.
                resp = client.chat.completions.create(
                    model=model, max_tokens=8,
                    **({} if provider == "anthropic" else {"temperature": 0}),
                    messages=[{"role": "user", "content": "只回复两个字：OK"}],
                    **({"extra_body": {"thinking": {"type": thinking}}} if thinking else {}))
                chat_result.update({
                    "ok": True,
                    "latency_ms": int((_time.time() - t0) * 1000),
                    "reply": (resp.choices[0].message.content or "").strip()[:20],
                })
            except Exception as e:  # noqa: BLE001
                chat_result["error"] = _explain_conn_error(e, "对话模型服务")

        requested_embedding = str(data.get("embedding_type", "") or "").strip()
        if requested_embedding == "ollama":
            embedding = {"type": "ollama", "base_url": "http://127.0.0.1:11434",
                         "model": "bge-m3:latest"}
        elif requested_embedding == "openrouter":
            embedding = {"type": "openrouter", "base_url": "https://openrouter.ai/api/v1",
                         "model": "openai/text-embedding-3-small"}
        elif requested_embedding == "dashscope":
            embedding = dict(DASHSCOPE_EMBEDDING)
        else:
            embedding = copy.deepcopy((cfg["agent"].get("associate") or {}).get("embedding", {}))
        emb_kind = embedding.get("type", "")
        emb_model = embedding.get("model", "")
        embedding_result = {"ok": False, "type": emb_kind, "model": emb_model}
        try:
            t0 = _time.time()
            if emb_kind == "ollama":
                emb_base = str(embedding.get("base_url", "http://127.0.0.1:11434")).rstrip("/")
                resp = _requests.post(
                    emb_base + "/api/embed",
                    json={"model": emb_model or "bge-m3:latest", "input": "记忆嵌入连接测试"},
                    timeout=30,
                )
                resp.raise_for_status()
                vectors = resp.json().get("embeddings") or []
                vector = vectors[0] if vectors else []
            elif emb_kind in EMB_KEY_VARS:
                key_var = EMB_KEY_VARS[emb_kind]
                emb_key = os.environ.get(key_var, "")
                if not emb_key:
                    raise ValueError(f"缺少 {key_var}")
                emb_headers = {}
                if emb_kind == "openrouter":
                    if os.environ.get("OPENROUTER_SITE_URL"):
                        emb_headers["HTTP-Referer"] = os.environ["OPENROUTER_SITE_URL"]
                    if os.environ.get("OPENROUTER_APP_NAME"):
                        emb_headers["X-OpenRouter-Title"] = os.environ["OPENROUTER_APP_NAME"]
                emb_client = _OpenAI(
                    api_key=emb_key,
                    base_url=embedding.get("base_url"),
                    timeout=30,
                    **({"default_headers": emb_headers} if emb_headers else {}),
                )
                emb_resp = emb_client.embeddings.create(
                    model=emb_model, input="记忆嵌入连接测试"
                )
                vector = emb_resp.data[0].embedding
            else:
                raise ValueError("连接检查目前支持本地 Ollama、OpenRouter、OpenAI、阿里云百炼和自定义兼容端点")
            if not vector:
                raise ValueError("服务返回了空向量")
            embedding_result.update({
                "ok": True,
                "latency_ms": int((_time.time() - t0) * 1000),
                "dimensions": len(vector),
            })
        except Exception as e:  # noqa: BLE001
            embedding_result["error"] = _explain_conn_error(e, "Embedding 服务") if not isinstance(e, ValueError) else str(e)[:300]

        ok = bool(chat_result.get("ok") and embedding_result.get("ok"))
        return jsonify({
            "ok": ok,
            "chat": chat_result,
            "embedding": embedding_result,
            # 保留旧前端曾使用的字段，避免缓存页面报错。
            "latency_ms": chat_result.get("latency_ms"),
            "reply": chat_result.get("reply", ""),
            "model": model,
            "error": "" if ok else "聊天模型或记忆 Embedding 至少有一项未通过",
        })

    @app.route("/api/rebuild_maze", methods=["POST"])
    def api_rebuild_maze():
        if runner_busy():
            return jsonify({"ok": False, "error": "有实验正在运行，请先停止再重建地址层。"}), 409
        from modules import mapgen
        if not mapgen.has_semantic_layers():
            return jsonify({"ok": False, "error": "tilemap.json 中没有语义层。先运行: python -m modules.mapgen export"}), 400
        report = mapgen.build(write=True)
        code = 200 if report.get("ok") else 422
        return jsonify(report), code

    @app.route("/api/export")
    def api_export():
        name = request.args.get("name", "")
        sub = request.args.get("sub", "")
        fn = request.args.get("file", "")
        if sub not in ("surveys", "psych", "monitor", "interventions"):
            return jsonify({"ok": False, "error": "类别不合法"}), 400
        if not (_SAFE_PART.match(name) and _SAFE_PART.match(fn)):
            return jsonify({"ok": False, "error": "参数不合法"}), 400
        fp = os.path.join("results", sub, name, fn)
        if not os.path.exists(fp):
            return jsonify({"ok": False, "error": "文件不存在"}), 404
        return send_file(os.path.abspath(fp), as_attachment=True,
                         download_name=f"{name}_{fn}")

    @app.route("/api/research.csv")
    def api_research_csv():
        """单世界Qualtrics式问卷宽表：一次点击得到一份分析就绪CSV。"""
        r = runner()
        name = (request.args.get("name") or (r.name if r else "")).strip()
        if not _SAFE_PART.match(name or ""):
            return jsonify({"ok": False, "error": "实验名不合法"}), 400
        if not os.path.isdir(os.path.join(CHECKPOINTS_PATH, name)):
            return jsonify({"ok": False, "error": "实验不存在"}), 404
        rows = exporter.build_responses([export_run_meta(name)])
        data = exporter.csv_bytes(rows, exporter.RESPONSE_META)
        import io
        return send_file(
            io.BytesIO(data), mimetype="text/csv; charset=utf-8",
            as_attachment=True, download_name=f"{name}-responses.csv",
        )

    @app.route("/api/research_bundle.zip")
    def api_research_bundle():
        """单世界完整研究数据包；各表保持正确统计粒度。"""
        r = runner()
        name = (request.args.get("name") or (r.name if r else "")).strip()
        if not _SAFE_PART.match(name or ""):
            return jsonify({"ok": False, "error": "实验名不合法"}), 400
        if not os.path.isdir(os.path.join(CHECKPOINTS_PATH, name)):
            return jsonify({"ok": False, "error": "实验不存在"}), 404
        return send_file(
            exporter.bundle_bytes([export_run_meta(name)]),
            mimetype="application/zip", as_attachment=True,
            download_name=f"{name}-研究数据.zip",
        )

    @app.route("/setup", methods=["GET"])
    def setup_page():
        r = runner()
        return render_template("setup.html", started=runner_busy(),
                               sim_name=(r.name if r else ""))

    @app.route("/api/presets/check", methods=["POST"])
    def api_presets_check():
        """V23: final personas + conflicts/label leaks for one or more templates."""
        from modules.research import world_check
        data = request.get_json(silent=True) or {}
        names = data.get("templates") or ([data["name"]] if data.get("name") else [])
        items, reports = [], {}
        try:
            for t in names:
                with open(preset_path(t), "r", encoding="utf-8") as f:
                    payload = json.load(f)
                result, _cfg = world_check.preview_payload(payload)
                reports[t] = result
                items.append((t, payload, result["personas"]))
        except (OSError, ValueError, json.JSONDecodeError) as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        return jsonify({"ok": all(not r["errors"] for r in reports.values()),
                        "reports": reports, "comparison": world_check.compare_worlds(items)})

    @app.route("/api/conditions", methods=["POST"])
    def api_conditions_save():
        data = request.get_json(silent=True) or {}
        name = (data.get("name") or "").strip()
        leader = (data.get("leader") or "").strip()
        desc = (data.get("description") or "").strip()
        overrides = data.get("overrides") or {}
        if not _NAME_RE.match(name):
            return jsonify({"ok": False, "error": "分组名只能包含中文、字母、数字、下划线或连字符（≤40字符）"}), 400
        if not leader:
            return jsonify({"ok": False, "error": "请选择操纵对象"}), 400
        clean = {k: str(v).strip() for k, v in overrides.items()
                 if k in ("currently", "innate", "learned", "daily_plan", "lifestyle") and str(v).strip()}
        if not clean:
            return jsonify({"ok": False, "error": "该智能体没有任何人设修改——请先在人设编辑器中改写它的人设，再存为分组"}), 400
        cond_path = os.path.join("data", "experiment_conditions.json")
        conds = {}
        if os.path.exists(cond_path):
            with open(cond_path, "r", encoding="utf-8") as f:
                conds = json.load(f)
        entry = {"description": desc or f"自定义分组（操纵{leader}）",
                 "leader": leader, "leader_overrides": {"scratch": {}}}
        if "currently" in clean:
            entry["leader_overrides"]["currently"] = clean.pop("currently")
        entry["leader_overrides"]["scratch"] = clean
        existed = name in conds
        conds[name] = entry
        with open(cond_path, "w", encoding="utf-8") as f:
            json.dump(conds, f, ensure_ascii=False, indent=2)
        return jsonify({"ok": True, "message": ("已更新" if existed else "已创建") + f"实验分组「{name}」",
                        "conditions": sorted(conds.keys())})

    @app.route("/api/conditions", methods=["DELETE"])
    def api_conditions_delete():
        name = (request.args.get("name") or "").strip()
        cond_path = os.path.join("data", "experiment_conditions.json")
        if not os.path.exists(cond_path):
            return jsonify({"ok": False, "error": "无条件文件"}), 404
        with open(cond_path, "r", encoding="utf-8") as f:
            conds = json.load(f)
        if name not in conds:
            return jsonify({"ok": False, "error": "分组不存在"}), 404
        del conds[name]
        with open(cond_path, "w", encoding="utf-8") as f:
            json.dump(conds, f, ensure_ascii=False, indent=2)
        return jsonify({"ok": True})

    @app.route("/api/setup_options")
    def api_setup_options():
        conditions = [""]
        condition_info = {"": "不应用任何实验条件，所有智能体使用默认/自定义人设。"}
        condition_overrides = {}
        cond_path = os.path.join("data", "experiment_conditions.json")
        if os.path.exists(cond_path):
            with open(cond_path, "r", encoding="utf-8") as f:
                cond_data = json.load(f)
            for k, v in cond_data.items():
                conditions.append(k)
                desc = v.get("description", "")
                leader = v.get("leader", "")
                condition_info[k] = (f"操纵对象：{leader}。" if leader else "") + desc
                ov = v.get("leader_overrides") or {}
                flat = {}
                if ov.get("currently"):
                    flat["currently"] = ov["currently"]
                for fk, fv in (ov.get("scratch") or {}).items():
                    if fv:
                        flat[fk] = fv
                condition_overrides[k] = {"leader": leader, "fields": flat}
        default_model, default_chat_iter = "", 2
        default_embedding_type, default_embedding_model = "", ""
        try:
            with open(os.path.join("data", "config.json"), "r", encoding="utf-8") as f:
                base_cfg = json.load(f).get("agent", {})
            default_model = (base_cfg.get("think", {}).get("llm", {}) or {}).get("model", "")
            default_chat_iter = int(base_cfg.get("chat_iter", 4))
            default_embedding = (base_cfg.get("associate", {}) or {}).get("embedding", {})
            default_embedding_type = default_embedding.get("type", "")
            default_embedding_model = default_embedding.get("model", "")
        except (OSError, json.JSONDecodeError, ValueError):
            pass
        return jsonify({
            "agents": list_available_agents(),
            "conditions": conditions,
            "condition_info": condition_info,
            "condition_overrides": condition_overrides,
            "default_model": default_model,
            "default_chat_iter": default_chat_iter,
            "default_embedding_type": default_embedding_type,
            "default_embedding_model": default_embedding_model,
            "default_agents": list(personas),
            # V27.2: the English interface starts from the English world (same four people)
            "default_agents_en": [n for n in ("Ayesha", "Klaus", "Maria", "Wolfgang")
                                  if os.path.isdir(os.path.join(AGENTS_ROOT, n))],
            "started": runner() is not None,
        })

    @app.route("/api/models")
    def api_models():
        import time as _time
        import urllib.request as _ur
        cache = getattr(api_models, "_cache", None)
        if cache and _time.time() - cache[0] < 3600:
            return jsonify({"models": cache[1], "source": cache[2]})
        fallback = [
            "google/gemini-2.5-flash-lite", "google/gemini-3.1-flash-lite", "google/gemini-3.5-flash",
            "openai/gpt-5.4-mini", "openai/gpt-5.4", "openai/gpt-5.5",
            "anthropic/claude-fable-5", "anthropic/claude-opus-4.8",
            "deepseek/deepseek-v4-flash", "deepseek/deepseek-v4-pro", "deepseek/deepseek-v3.2",
            "qwen/qwen-2.5-72b-instruct",
        ]
        models, source = fallback, "fallback"
        try:
            req = _ur.Request("https://openrouter.ai/api/v1/models",
                              headers={"User-Agent": "generative-agents-research"})
            with _ur.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            ids = sorted(m["id"] for m in data.get("data", []) if m.get("id"))
            if ids:
                models, source = ids, "live"
        except Exception:  # noqa: BLE001 网络不可用时静默兜底
            pass
        api_models._cache = (_time.time(), models, source)
        return jsonify({"models": models, "source": source})

    @app.route("/api/agent_config")
    def api_agent_config():
        name = request.args.get("name", "")
        if not os.path.exists(os.path.join(AGENTS_ROOT, name, "agent.json")):
            return jsonify({"ok": False, "error": "智能体不存在"}), 404
        return jsonify({"ok": True, "persona": load_agent_persona(name)})

    @app.route("/api/clone_agent", methods=["POST"])
    def api_clone_agent():
        data = request.get_json(silent=True) or {}
        try:
            clone_agent(str(data.get("source", "")), str(data.get("new_name", "")).strip(),
                        appearance=(str(data.get("appearance", "")) or "").strip() or None,
                        workstation=(str(data.get("workstation", "")) or "").strip() or None)
        except ValueError as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        return jsonify({"ok": True, "agents": list_available_agents()})

    def runner_busy():
        r = runner()
        return r is not None and r.state["status"] not in ("finished", "stopped", "error")

    @app.route("/api/start", methods=["POST"])
    def api_start():
        if runner_busy():
            return jsonify({"ok": False, "error": "当前有实验正在运行。请先在控制台停止它，或等它结束。"}), 409
        payload = request.get_json(silent=True) or {}
        try:
            name, args, config = build_experiment_config(payload)
        except ValueError as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        r = SimulationRunner(args, prepared_config=config)
        holder["runner"] = r
        r.run()
        return jsonify({"ok": True, "name": name, "redirect": "/console"})

    # ------------------ 实时流与控制 ------------------
    @app.route("/events")
    def events():
        r = runner()
        if r is None:
            return jsonify({"ok": False, "error": "实验尚未启动"}), 409

        def stream():
            q = r.bus.subscribe()
            try:
                init = {
                    "type": "init",
                    "state": r.state,
                    "history_steps": len(r.bus.history),
                }
                yield f"data: {json.dumps(init, ensure_ascii=False)}\n\n"
                for ev in r.bus.history[-50:]:
                    yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
                while True:
                    try:
                        ev = q.get(timeout=15)
                        yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
                    except queue.Empty:
                        yield ": keepalive\n\n"
            finally:
                r.bus.unsubscribe(q)

        return Response(
            stream(),
            mimetype="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    @app.route("/api/state")
    def api_state():
        r = runner()
        if r is None:
            return jsonify({"status": "not_started"})
        return jsonify(r.state)

    @app.route("/api/control", methods=["POST"])
    def api_control():
        r = runner()
        if r is None:
            return jsonify({"ok": False, "error": "实验尚未启动"}), 409
        data = request.get_json(silent=True) or {}
        command = data.get("command", "")
        if r.control(command):
            return jsonify({"ok": True, "status": r.state["status"]})
        return jsonify({"ok": False, "error": f"unknown command '{command}'"}), 400

    # ------------------ 干预 ------------------
    @app.route("/api/agents")
    def api_agents():
        r = runner()
        if r is None:
            return jsonify({"agents": []})
        return jsonify({"agents": list(r.config.get("agents", {}).keys())})

    @app.route("/api/intervention/options")
    def api_intervention_options():
        r = runner()
        if r is None:
            return jsonify({"agents": [], "locations": [], "sim_time": ""})
        locations = []
        if r.server is not None:
            for key in sorted(r.server.game.maze.address_tiles):
                parts = key.split(":")
                if len(parts) >= 3:
                    locations.append({"value": key, "label": " / ".join(parts[2:])})
        return jsonify({
            "agents": list(r.config.get("agents", {}).keys()),
            "locations": locations,
            "sim_time": r.state.get("time") or "",
        })

    @app.route("/api/intervene", methods=["POST"])
    def api_intervene():
        r = runner()
        if r is None:
            return jsonify({"ok": False, "error": "实验尚未启动"}), 409
        if r.state["status"] in ("finished", "stopped", "error"):
            return jsonify({"ok": False, "error": "模拟已结束，干预无法生效。请用 --resume 增加步数后再注入。"}), 409
        data = request.get_json(silent=True) or {}
        try:
            clean = r.queue_intervention(data)
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        if clean is None:
            return jsonify({"ok": False, "error": "干预文本不能为空"}), 400
        return jsonify({"ok": True, "queued": clean,
                        "note": "干预已入队，将在下一个step开始时生效（暂停中则在恢复后生效）"})

    @app.route("/api/interventions")
    def api_interventions():
        r = runner()
        if r is None:
            return jsonify({"history": []})
        queued = []
        pending_dir = os.path.join(r.interventions_folder(), "pending")
        if os.path.isdir(pending_dir):
            for filename in sorted(os.listdir(pending_dir)):
                if not filename.endswith(".json"):
                    continue
                try:
                    with open(os.path.join(pending_dir, filename), encoding="utf-8") as handle:
                        item = json.load(handle)
                    item.update({"status": "queued", "step": "-", "sim_time": item.get("scheduled_time") or "下一步"})
                    queued.append(item)
                except (OSError, json.JSONDecodeError, TypeError):
                    continue
        return jsonify({"history": r.intervention_history + queued})

    @app.route("/api/interventions/active")
    def api_interventions_active():
        """V24: world settings and persistent intents still in force (for withdrawal)."""
        r = runner()
        if r is None:
            return jsonify({"active": []})
        return jsonify({"active": active_persistent_interventions(
            r.intervention_history, r.state.get("time") or "")})

    # ------------------ 问卷数据 ------------------
    @app.route("/api/surveys")
    def api_surveys():
        r = runner()
        if r is None:
            return jsonify({"surveys": []})
        return jsonify({"surveys": r.survey_index()})

    @app.route("/api/survey")
    def api_survey():
        r = runner()
        if r is None:
            return jsonify({"rows": [], "count": 0})
        survey_id = request.args.get("survey", "legacy")
        _, rows = r.survey_rows(survey_id)
        return jsonify({"rows": rows, "count": len(rows)})

    @app.route("/api/survey.csv")
    def api_survey_csv():
        r = runner()
        if r is None:
            return jsonify({"ok": False, "error": "实验尚未启动"}), 409
        survey_id = request.args.get("survey", "legacy")
        if survey_id in ("", "legacy"):
            csv_path = os.path.join("results", "surveys", r.name, "daily_survey.csv")
        else:
            csv_path = os.path.join("results", "surveys", r.name, f"custom_{survey_id}.csv")
        if not os.path.exists(csv_path):
            return jsonify({"ok": False, "error": "暂无问卷数据"}), 404
        return send_file(os.path.abspath(csv_path), as_attachment=True,
                         download_name=f"{r.name}_{survey_id}.csv")

    @app.route("/api/psych.csv")
    def api_psych_csv():
        r = runner()
        if r is None:
            return jsonify({"ok": False, "error": "实验尚未启动"}), 409
        jsonl_path = os.path.join("results", "psych", r.name, "psych.jsonl")
        if not os.path.exists(jsonl_path):
            return jsonify({"ok": False, "error": "暂无心理状态数据"}), 404
        import csv as _csv
        import io
        rows = []
        with open(jsonl_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
        buf = io.StringIO()
        fields = ["step", "sim_time", "agent", "mood", "stress", "energy", "sociality"]
        writer = _csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
        data = "\ufeff" + buf.getvalue()
        return Response(
            data, mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={r.name}_psych.csv"},
        )

    @app.route("/api/behavior.csv")
    def api_behavior_csv():
        from modules import behavior
        name = request.args.get("name", "") or (runner().name if runner() else "")
        if not _SAFE_PART.match(name or ""):
            return jsonify({"ok": False, "error": "实验名不合法"}), 400
        kind = request.args.get("kind", "daily")
        daily_rows, dyad_rows, _ = behavior.compute(name)
        rows = dyad_rows if kind == "dyad" else daily_rows
        if not rows:
            return jsonify({"ok": False, "error": "该实验暂无可计算的行为数据（需要至少运行过若干step）"}), 404
        return Response(
            behavior.to_csv_text(rows), mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={name}_behavior_{kind}.csv"},
        )

    @app.route("/api/conversations")
    def api_conversations():
        r = runner()
        conv = {}
        if r is not None and r.server is not None:
            conv = r.server.game.conversation or {}
        keys = sorted(conv.keys())[-20:]
        return jsonify({"conversations": {k: conv[k] for k in keys}})

    from modules.research.api import register
    register(app, {"scan_batches": scan_batches, "scan_experiments": scan_experiments,
                   "batch": BATCH, "probe_runtime": probe_runtime,
                   "available_ports": _available_ports, "comparison_summary": comparison_summary})
    return app


def parse_args():
    parser = argparse.ArgumentParser(description="实时模拟服务器与研究者控制台")
    parser.add_argument("--name", type=str, default="", help="模拟名称（留空进入网页配置模式）")
    parser.add_argument("--start", type=str, default="20240213-09:30", help="模拟起始时间")
    parser.add_argument("--resume", action="store_true", help="断点恢复")
    parser.add_argument("--step", type=int, default=100, help="模拟步数")
    parser.add_argument("--stride", type=int, default=10, help="每步推进的分钟数")
    parser.add_argument("--verbose", type=str, default="info", choices=["debug", "info", "warn"], help="日志级别")
    parser.add_argument("--log", type=str, default="", help="日志文件名")
    parser.add_argument("--condition", type=str, default="", help="实验条件（experiment_conditions.json中的任意分组名）")
    parser.add_argument("--disable-daily-survey", action="store_true", help="关闭内置每日问卷")
    parser.add_argument("--offline", action="store_true", help="离线测试模式：不调用任何外部API")
    parser.add_argument("--port", type=int, default=5001, help="Web服务端口")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="监听地址")
    parser.add_argument("--config-json", type=str, default="", help="从JSON文件加载完整实验payload并立即启动（批量子世界用）")
    parser.add_argument("--exit-on-finish", action="store_true", help="模拟结束约30秒后自动退出进程（批量子世界用）")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    ensure_config_exists()
    ensure_factory_presets()
    retire_old_presets()
    rename_old_presets()
    apply_default_api_keys()
    maybe_rebuild_maze()
    repair_mangled_asset_names()
    holder = {"runner": None}
    app = create_app(holder)
    if not args.config_json and not args.name:
        BATCH.restore_latest()
    if args.config_json:
        with open(args.config_json, "r", encoding="utf-8") as _f:
            _payload = json.load(_f)
        _name, _sim_args, _cfg = build_experiment_config(_payload)
        holder["runner"] = SimulationRunner(_sim_args, prepared_config=_cfg)
        holder["runner"].run()
        write_runtime_registry(_name, args.port, args.host, "starting")
        print("[批量子世界] {} 已启动，端口 {}".format(_name, args.port))
    if args.exit_on_finish:
        def _watch_exit():
            while True:
                time.sleep(5)
                _r2 = holder.get("runner")
                if _r2 is not None and _r2.state.get("status") in ("finished", "stopped", "error"):
                    final_status = _r2.state.get("status")
                    write_runtime_registry(
                        _r2.name, args.port, args.host, final_status
                    )
                    # 用户主动停止后尽快释放端口，便于立即重试；正常完成保留短暂回看窗口。
                    time.sleep(2 if final_status == "stopped" else 30)
                    os._exit(0)
        threading.Thread(target=_watch_exit, daemon=True).start()
    print("[系统] 版本 {}，端口 {}".format(SYSTEM_VERSION, args.port))
    if args.name:
        holder["runner"] = SimulationRunner(args)
        holder["runner"].run()
        write_runtime_registry(args.name, args.port, args.host, "starting")
        print(f"\n实时地图: http://{args.host}:{args.port}/")
        print(f"研究者控制台: http://{args.host}:{args.port}/console")
        print(f"行为/想法/对话监控: http://{args.host}:{args.port}/monitor\n")
    else:
        print(f"\n实验管理: http://{args.host}:{args.port}/experiments")
        print(f"新建实验: http://{args.host}:{args.port}/setup\n")
    app.run(host=args.host, port=args.port, threaded=True, debug=False, use_reloader=False)
