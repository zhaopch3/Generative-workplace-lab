#!/usr/bin/env bash
# macOS / Linux installer: bash install.sh   (options: --yes --mirror --no-mirror --recreate)
cd "$(dirname "$0")" || exit 1
PY=""
for c in python3.11 python3.12 python3.10 python3.13 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if (3,10)<=sys.version_info[:2]<=(3,13) else 1)' 2>/dev/null; then
    PY="$c"; break
  fi
done
if [ -z "$PY" ]; then
  case "${SIM_LANG:-${LC_ALL:-${LANG:-}}}" in
    zh*)
      echo "没有找到可用的 Python（需要 3.10-3.12，推荐 3.11）。"
      echo "  macOS:          brew install python@3.11   （或从 https://www.python.org/downloads/ 下载）"
      echo "  Ubuntu/Debian:  sudo apt install python3.11 python3.11-venv"
      echo "装好后重新运行：bash install.sh" ;;
    *)
      echo "No usable Python found: 3.10-3.12 is needed, 3.11 recommended."
      echo "  macOS:          brew install python@3.11   (or download from https://www.python.org/downloads/)"
      echo "  Ubuntu/Debian:  sudo apt install python3.11 python3.11-venv"
      echo "Then run again: bash install.sh" ;;
  esac
  exit 1
fi
exec "$PY" -X utf8 setup_env.py "$@"
