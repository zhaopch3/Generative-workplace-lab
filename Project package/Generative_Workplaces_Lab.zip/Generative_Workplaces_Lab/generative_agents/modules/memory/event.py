"""generative_agents.memory.event"""

from modules import lang

_NOT_GERUNDS = {"morning", "evening", "something", "nothing", "everything", "anything", "during",
                "thing", "things", "string", "king", "spring", "ceiling"}


def _starts_with_gerund(text):
    first = str(text or "").strip().split(" ", 1)[0].lower()
    return len(first) > 4 and first.endswith("ing") and first not in _NOT_GERUNDS


class Event:
    def __init__(
        self,
        subject,
        predicate=None,
        object=None,
        address=None,
        describe=None,
        emoji=None,
        event_id=None,
        intervention_id=None,
        researcher_injected=False,
    ):
        self.subject = subject
        # self.predicate = predicate or "is"
        # self.object = object or "idle"
        self.predicate = predicate or lang.L("此时", "is")
        self.object = object or lang.L("空闲", "idle")
        self._describe = describe or ""
        self.address = address or []
        self.emoji = emoji or ""
        # Research provenance travels with the world event and every memory
        # derived from it.  It is deliberately metadata, not part of the text
        # shown to the agent or used to decide whether two events are equal.
        self.event_id = event_id
        self.intervention_id = intervention_id
        self.researcher_injected = bool(researcher_injected)

    def __str__(self):
        if self._describe:
            des = "{}".format(self._describe)
        else:
            des = "{} {} {}".format(self.subject, self.predicate, self.object)
        # if self.emoji:
        #     des += "[{}]".format(self.emoji)
        if self.address:
            des += " @ " + ":".join(self.address)
        return des

    def __hash__(self):
        return hash(
            (
                self.subject,
                self.predicate,
                self.object,
                self._describe,
                ":".join(self.address),
                self.event_id,
            )
        )

    def __eq__(self, other):
        if isinstance(other, Event):
            return hash(self) == hash(other)
        return False

    def update(self, predicate=None, object=None, describe=None):
        # self.predicate = predicate or "is"
        # self.object = object or "idle"
        self.predicate = predicate or lang.L("此时", "is")
        self.object = object or lang.L("空闲", "idle")
        self._describe = describe or self._describe

    def to_id(self):
        return self.subject, self.predicate, self.object, self._describe

    def fit(self, subject=None, predicate=None, object=None):
        if subject and self.subject != subject:
            return False
        if predicate and self.predicate != predicate:
            return False
        if object and self.object != object:
            return False
        return True

    def to_dict(self):
        data = {
            "subject": self.subject,
            "predicate": self.predicate,
            "object": self.object,
            "describe": self._describe,
            "address": self.address,
            "emoji": self.emoji,
        }
        if self.event_id:
            data["event_id"] = self.event_id
        if self.intervention_id:
            data["intervention_id"] = self.intervention_id
        if self.researcher_injected:
            data["researcher_injected"] = True
        return data

    def get_describe(self, with_subject=True):
        describe = self._describe or "{} {}".format(self.predicate, self.object)
        subject = ""
        if with_subject:
            if self.subject not in describe:
                subject = self.subject + " "
                if lang.is_en() and _starts_with_gerund(describe):
                    subject += "is "   # V27: "Ayesha is reviewing the draft"
        else:
            if describe.startswith(self.subject + " "):
                describe = describe[len(self.subject) + 1:]
        return "{}{}".format(subject, describe)

    @classmethod
    def from_dict(cls, config):
        return cls(**config)

    @classmethod
    def from_list(cls, event):
        if len(event) == 3:
            return cls(event[0], event[1], event[2])
        return cls(event[0], event[1], event[2], event[3])
