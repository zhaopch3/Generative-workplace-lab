# -*- coding: utf-8 -*-
"""V27.2: Google Gemini and Anthropic Claude official APIs (OpenAI-compatible endpoints)."""
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import server  # noqa: E402
from modules.model.llm_model import OpenAILLMModel  # noqa: E402


class FakeCompletions:
    def __init__(self):
        self.kwargs = None

    def create(self, **kwargs):
        self.kwargs = kwargs
        msg = SimpleNamespace(content="OK")
        return SimpleNamespace(choices=[SimpleNamespace(message=msg)], usage=None)


class ProviderTests(unittest.TestCase):
    def test_provider_table_and_inference(self):
        self.assertEqual(server._infer_provider(server.LLM_PROVIDERS["gemini"]["base_url"]), "gemini")
        self.assertEqual(server._infer_provider(server.LLM_PROVIDERS["anthropic"]["base_url"]), "anthropic")
        self.assertEqual(server.LLM_PROVIDERS["gemini"]["key_var"], "GEMINI_API_KEY")
        self.assertEqual(server.LLM_PROVIDERS["anthropic"]["key_var"], "ANTHROPIC_API_KEY")
        self.assertEqual(server._infer_provider("https://api.deepseek.com/v1"), "deepseek")
        self.assertEqual(server._infer_provider("https://example.org/v1"), "custom")

    def make(self, base_url, keys):
        model = OpenAILLMModel.__new__(OpenAILLMModel)
        model._base_url = base_url
        model._timeout = 30
        model._config = {}
        model._model = "m"
        model._call_usage = None
        model._handle = model.setup(keys, {})
        fake = FakeCompletions()
        model._handle = SimpleNamespace(base_url=base_url, chat=SimpleNamespace(completions=fake))
        return model, fake

    def test_keys_are_routed_by_endpoint(self):
        model, _ = self.make(server.LLM_PROVIDERS["gemini"]["base_url"], {"GEMINI_API_KEY": "g-key"})
        model, _ = self.make(server.LLM_PROVIDERS["anthropic"]["base_url"], {"ANTHROPIC_API_KEY": "a-key"})
        with self.assertRaises(ValueError):   # a Gemini endpoint never falls back to another provider's key
            self.make(server.LLM_PROVIDERS["gemini"]["base_url"], {"OPENAI_API_KEY": "o-key"})

    def test_claude_omits_temperature_others_keep_it(self):
        model, fake = self.make(server.LLM_PROVIDERS["anthropic"]["base_url"], {"ANTHROPIC_API_KEY": "a"})
        self.assertEqual(model._completion("hi", temperature=0.5), "OK")
        self.assertNotIn("temperature", fake.kwargs)
        model, fake = self.make(server.LLM_PROVIDERS["gemini"]["base_url"], {"GEMINI_API_KEY": "g"})
        model._completion("hi", temperature=0.5)
        self.assertEqual(fake.kwargs["temperature"], 0.5)
        model, fake = self.make("https://api.deepseek.com/v1", {"DEEPSEEK_API_KEY": "d"})
        model._completion("hi", temperature=0.7)
        self.assertEqual(fake.kwargs["temperature"], 0.7)


if __name__ == "__main__":
    unittest.main()
