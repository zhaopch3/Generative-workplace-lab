from llama_index.embeddings.ollama import OllamaEmbedding

emb = OllamaEmbedding(
    model_name="mxbai-embed-large:latest",
    base_url="http://127.0.0.1:11434"
)
print(emb.get_query_embedding("你好")[:10])  # 只打印前 10 维
