"""Thread-safe, content-free performance telemetry for model calls."""

import datetime
import json
import os
import threading


_LOCKS = {}
_LOCKS_GUARD = threading.Lock()


def _path_lock(path):
    normalized = os.path.abspath(path)
    with _LOCKS_GUARD:
        lock = _LOCKS.get(normalized)
        if lock is None:
            lock = threading.Lock()
            _LOCKS[normalized] = lock
    return lock


def write_metric(path, record):
    """Append one JSONL metric without storing prompts, responses, or API keys."""
    if not path:
        return
    try:
        row = dict(record)
        row.setdefault(
            "recorded_at",
            datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="milliseconds"),
        )
        folder = os.path.dirname(os.path.abspath(path))
        os.makedirs(folder, exist_ok=True)
        line = json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n"
        with _path_lock(path):
            with open(path, "a", encoding="utf-8") as stream:
                stream.write(line)
    except (OSError, TypeError, ValueError):
        # Telemetry must never change or stop the simulation it observes.
        return
