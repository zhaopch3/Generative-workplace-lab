"""Read-only research catalog and item-level data audit."""
from collections import Counter
from pathlib import Path
import math
from .common import fingerprint, jsonl, read_json, safe_id

ROOT = Path("results")


def latest_config(name):
    files = sorted((ROOT / "checkpoints" / safe_id(name)).glob("simulate-*.json"))
    return read_json(files[-1], {}) if files else {}


def schema_version(schema):
    return fingerprint({k: v for k, v in schema.items() if k not in ("completed_dates", "latest_rows")})[:16]


def catalog(batches, experiments):
    identities = {}
    for batch in batches:
        for group in batch.get("comparison_groups", []):
            for run in group["runs"]:
                identities[run["name"]] = {
                    "batch_id": batch["batch_id"], "group_id": group["group_id"],
                    "group_label": group["label"], "batch_label": batch["label"],
                }
    surveys, worlds = {}, []
    for experiment in experiments:
        name = experiment["name"]
        config = latest_config(name)
        item = {**experiment, **identities.get(name, {}), "seed": config.get("seed"),
                "snapshot_format": (config.get("_snapshot") or {}).get("format", 0),
                "measurement_policy": config.get("measurement_policy", "legacy_reactive"),
                "parent": config.get("branch_parent"), "surveys": [], "survey_versions": {}}
        for schema in config.get("custom_surveys", []):
            sid = schema["id"]
            version = schema_version(schema)
            surveys.setdefault(sid, {"id": sid, "title": schema.get("title", sid),
                                     "mode": schema.get("mode", "self"), "versions": {},
                                     "questions": schema.get("questions", [])})
            surveys[sid]["versions"][version] = schema
            item["surveys"].append(sid)
            item["survey_versions"][sid] = version
        item.pop("files", None)
        worlds.append(item)
    return {"worlds": worlds, "surveys": list(surveys.values()), "batches": batches}


def records(worlds):
    from collections import defaultdict
    labels = defaultdict(set)
    for world in worlds:
        labels[world.get("group_label") or world.get("condition") or "未分组"].add(world.get("group_id", ""))
    for world in worlds:
        name = safe_id(world["name"])
        config = latest_config(name)
        schemas = {s["id"]: s for s in config.get("custom_surveys", [])}
        for path in sorted((ROOT / "surveys" / name).glob("*.jsonl")):
            sid_default = path.stem.removeprefix("custom_")
            for line, row, error in jsonl(path):
                provenance = {"file": str(path), "line": line, "run_id": name,
                              "cluster_id": (config.get("branch_parent") or {}).get("cluster_id", name),
                              "batch_id": world.get("batch_id", ""),
                              "config_group_id": world.get("group_id", ""),
                              "measurement_policy": config.get("measurement_policy", "legacy_reactive"),
                              "group": world.get("group_label") or world.get("condition") or "未分组"}
                if len(labels[provenance["group"]]) > 1:
                    provenance["group"] += " [" + world.get("group_id", "unknown") + "]"
                if error:
                    yield {"provenance": provenance, "error": error, "row": {}, "schema": {}}
                    continue
                sid = row.get("survey_id") or sid_default
                schema = schemas.get(sid, {})
                yield {"provenance": provenance, "row": row, "survey_id": sid, "schema": schema}


def assess(record):
    row, schema = record.get("row", {}), record.get("schema", {})
    if record.get("error"):
        return "invalid", {"_row": record["error"]}
    quality = row.get("_quality") or {}
    legacy = not quality
    bad_reason = any(word in str(row.get("reason", "")) for word in ("解析失败", "中性默认", "离线模式"))
    source = quality.get("source")
    if source in ("offline", "fallback") or quality.get("status") == "invalid" or bad_reason:
        return "invalid", {"_row": "离线、解析失败或默认答案"}
    items = {}
    for q in schema.get("questions", []):
        value = row.get(q["id"])
        reported = quality.get("items", {}).get(q["id"])
        valid = value is not None and reported in (None, "valid")
        if q["type"] == "likert":
            try:
                number = float(value)
                valid = valid and not isinstance(value, bool) and math.isfinite(number) and number.is_integer() and q["min"] <= number <= q["max"]
            except (TypeError, ValueError):
                valid = False
        items[q["id"]] = "valid" if valid else "missing_or_invalid"
    if not schema:
        return ("legacy_unverified" if legacy else quality.get("status", "invalid")), items
    if any(v != "valid" for v in items.values()):
        return "partial", items
    return ("legacy_unverified" if legacy else "valid"), items


def quality_report(worlds):
    counts, issues, per_world = Counter(), [], {}
    seen = set()
    for record in records(worlds):
        status, items = assess(record)
        counts[status] += 1
        name = record["provenance"]["run_id"]
        wc = per_world.setdefault(name, Counter())
        wc[status] += 1
        row = record["row"]
        key = (name, record.get("survey_id"), row.get("agent"), row.get("ratee"),
               row.get("survey_date"), row.get("survey_time"))
        if key in seen:
            counts["duplicates"] += 1
            issues.append({**record["provenance"], "survey_id": record.get("survey_id"), "status": "duplicate", "detail": "同一测量键重复"})
        seen.add(key)
        if status in ("partial", "invalid"):
            issues.append({**record["provenance"], "survey_id": record.get("survey_id"),
                           "agent": row.get("agent"), "status": status, "detail": items})
    formats = Counter(w.get("snapshot_format", 0) for w in worlds)
    return {"counts": dict(counts), "worlds": [{"run_id": k, **v} for k, v in per_world.items()],
            "issues": issues, "snapshot_formats": dict(formats),
            "notes": [
                "检查范围：所选世界已保存的原始问卷记录；不包含独立补测任务，不检查未生成的测量次数。",
                "旧记录缺少逐题校验标记时列为“无法完整核验”，不直接判为有效或无效。",
                "本工具检查记录格式、题项值和重复测量键，不评估量表效度，不修改或删除文件。",
            ]}
