"""
手动测试存储封装 LlamaIndex.retrieve(...)
"""

from modules.storage.index import LlamaIndex

embedding_cfg = {
    "type":      "ollama",                    # <- 一定要有
    "base_url":  "http://127.0.0.1:11434",
    "model":     "bge-m3:latest",
}

# 1) 初始化
idx = LlamaIndex(**embedding_cfg)

# 2) 尝试检索
try:
    docs = idx.retrieve("测试查询")          # 内容随便写
    print("✅ 检索结果：", docs)
except Exception as e:
    print("❌ 检索出错：", e)
