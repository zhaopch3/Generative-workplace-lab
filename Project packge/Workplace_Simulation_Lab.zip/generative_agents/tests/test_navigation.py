import copy
import json
import os
import tempfile
import unittest
from pathlib import Path

from modules.maze import Maze
from modules.navigation import build_navigation, POLICY

ROOT = Path(__file__).resolve().parents[1]
STATIC = ROOT / "frontend/static"


class NavigationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = json.loads((STATIC / "assets/village/maze.json").read_text(encoding="utf-8"))
        cls.config = build_navigation(cls.original, STATIC)
        cls.maze = Maze(copy.deepcopy(cls.config), None)

    def test_all_pairs_are_connected_and_cardinal(self):
        m = self.maze
        free = [(x,y) for y in range(m.maze_height) for x in range(m.maze_width) if m.walkable((x,y))]
        self.assertGreater(len(free), 80)
        for src in free:
            for dst in free:
                path = m.find_path(src, dst)
                self.assertEqual(path[0], src)
                self.assertEqual(path[-1], dst)
                self.assertTrue(m.validate_path(src, path[1:]))

    def test_no_segments_intersect_imported_geometry_or_furniture(self):
        m = self.maze
        geometry = json.loads((STATIC / "assets/village/navigation.json").read_text(encoding="utf-8"))
        tilemap = json.loads((STATIC / "assets/village/tilemap/tilemap.json").read_text(encoding="utf-8"))
        for layer in tilemap["layers"]:
            if layer["name"] in ("furniture", "objects", "props"):
                for i, gid in enumerate(layer["data"]):
                    if gid: self.assertFalse(m.walkable((i%m.maze_width,i//m.maze_width)))
        rx, ry = geometry["footprint_half_size"]
        for y in range(m.maze_height):
            for x in range(m.maze_width):
                a = (x,y)
                if not m.walkable(a): continue
                for b in [a] + [b for b in m.get_around(a) if m.can_step(a,b)]:
                    bounds = (min(x,b[0])*48+24-rx,min(y,b[1])*48+24-ry,
                              max(x,b[0])*48+24+rx,max(y,b[1])*48+24+ry)
                    for r in geometry["rectangles"]:
                        self.assertFalse(bounds[0]<r["x"]+r["width"] and bounds[2]>r["x"] and
                                         bounds[1]<r["y"]+r["height"] and bounds[3]>r["y"])

    def test_approach_points_spawns_and_no_map_mutation(self):
        m = self.maze
        for address in m.address_tiles:
            targets = m.get_address_tiles(address.split(":"))
            self.assertTrue(targets, address)
            self.assertTrue(all(m.walkable(t) for t in targets))
        self.assertEqual(m.get_address_tiles(["nonexistent"]), set())
        for coord in ([5,6],[8,10],[11,6],[14,15]):
            self.assertTrue(m.walkable(m.nearest_walkable(coord)))
        self.assertNotIn("navigation", self.original)
        self.assertEqual(self.original, json.loads((STATIC/"assets/village/maze.json").read_text(encoding="utf-8")))

    def test_bounds_bad_paths_and_snapshot_graph(self):
        m = self.maze
        for target in ([-1,0],[999,0],[0,0]): self.assertFalse(m.find_path([5,6],target))
        self.assertFalse(m.validate_path([5,6],[[6,7]]))
        self.assertFalse(m.validate_path([5,6],[[10,6]]))
        clone = Maze(copy.deepcopy(m.resolved_config), None)
        self.assertEqual(clone.blocked_edges, m.blocked_edges)
        self.assertEqual(clone.navigation, m.navigation)
        self.assertEqual(len(m.get_around([0,0],False)),2)

    def test_offline_evening_records_no_sleep_teleports(self):
        import server
        from start import SimulateServer
        origin = Path.cwd()
        preset = json.loads((ROOT/"data/world_presets/人设操纵-低辱虐组.json").read_text(encoding="utf-8"))
        preset.update(name="navigation-offline-test",offline=True,step=6,start_time="20240213-20:00",
                      stride=60,custom_surveys=[],legacy_survey=False)
        _, args, cfg = server.build_experiment_config(preset)
        self.assertEqual(cfg["navigation_policy"],POLICY)
        records=[]
        with tempfile.TemporaryDirectory() as directory:
            os.chdir(directory)
            try:
                runner = SimulateServer(args.name,str(STATIC),"results/checkpoints/"+args.name,
                                        cfg,verbose="error",on_step=records.append)
                for a in runner.game.agents.values():
                    a.scratch.template_path=str(ROOT/"data/prompts")
                    self.assertFalse(a.llm_available())
                runner.simulate(6,stride=60)
                self.assertEqual(len(records),6)
                previous={}
                for rec in records:
                    for name,a in rec["agents"].items():
                        self.assertEqual(a["navigation_policy"],POLICY)
                        self.assertTrue(runner.game.maze.validate_path(a["prev_coord"],a["path"]))
                        self.assertEqual(a["coord"], a["path"][-1] if a["path"] else a["prev_coord"])
                        if name in previous:self.assertEqual(a["prev_coord"],previous[name])
                        previous[name]=a["coord"]
                saved=json.loads(sorted(Path(runner.checkpoints_folder).glob("simulate-*.json"))[-1].read_text(encoding="utf-8"))
                self.assertEqual(saved["_maze_config"]["navigation"]["version"],POLICY)
            finally:
                os.chdir(origin)


if __name__ == "__main__": unittest.main()
