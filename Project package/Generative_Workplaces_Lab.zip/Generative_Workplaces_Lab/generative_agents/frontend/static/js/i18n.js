/* Interface language switch (中文 / English), V27. English is the default since V27.2.
 *
 * Chinese is the source language of every page. In English mode this script
 * translates what the user sees (text nodes and the attributes placeholder,
 * title, aria-label, alt, and the label of input buttons) by exact match
 * against /static/i18n/en.json, plus entries with placeholders for text
 * built at run time: {x} matches text without Chinese characters (numbers,
 * ids, times), {s} matches any text (names, messages). It never changes
 * data: option values, input values, textareas, editable areas and anything inside [data-i18n-skip]
 * (world content such as personas, transcripts, logs and answers) are left
 * untouched, and nothing is sent to the server in another language.
 */
(function () {
  "use strict";
  var KEY = "ui_lang";
  var HAN = /[一-鿿]/;
  var ATTRS = ["placeholder", "title", "aria-label", "alt"];
  var SKIP_TAGS = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, NOSCRIPT: 1, CODE: 1, PRE: 1 };

  function readLang() {
    var v = null;
    try { v = window.localStorage.getItem(KEY); } catch (e) { v = null; }
    if (!v) {
      var m = /(?:^|;\s*)ui_lang=(zh|en)/.exec(document.cookie || "");
      v = m ? m[1] : null;
    }
    return v === "zh" ? "zh" : "en";   // V27.2: English unless the user chose 中文
  }

  function setLang(lang) {
    lang = lang === "en" ? "en" : "zh";
    try { window.localStorage.setItem(KEY, lang); } catch (e) { /* storage blocked */ }
    try { document.cookie = "ui_lang=" + lang + "; path=/; max-age=31536000; SameSite=Lax"; } catch (e) { /* ignore */ }
    window.location.reload();
  }

  var lang = readLang();
  var exact = Object.create(null);   // normalized zh -> en
  var templ = Object.create(null);   // zh with {x} for numbers -> en (fast path)
  var patterns = [];                 // [{re, en}] for entries with {x}/{s} placeholders
  var cache = Object.create(null);
  var ready = false;

  function norm(s) { return String(s).replace(/\s+/g, " ").trim(); }
  function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

  function fill(en, args) {
    var i = 0;
    return en.replace(/\{(x|s|\d)\}/g, function (_, k) {
      var v = (k === "x" || k === "s") ? args[i++] : args[Number(k) - 1];
      return v === undefined ? "" : v;
    });
  }

  function load(dict) {
    Object.keys(dict).forEach(function (zh) {
      if (zh === "_note") return;
      var en = dict[zh];
      var key = norm(zh);
      if (!/\{[xs]\}/.test(key)) { exact[key] = en; return; }
      if (key.indexOf("{s}") < 0) templ[key] = en;
      var src = "^", m;
      var ph = /\{([xs])\}/g, last = 0;
      while ((m = ph.exec(key))) {
        src += escRe(key.slice(last, m.index)) + (m[1] === "x" ? "([^\\u4e00-\\u9fff]+?)" : "([\\s\\S]+?)");
        last = ph.lastIndex;
      }
      src += escRe(key.slice(last)) + "$";
      patterns.push({ re: new RegExp(src), en: en, len: key.replace(/\{[xs]\}/g, "").length });
    });
    patterns.sort(function (a, b) { return b.len - a.len; });
  }

  // Translate one string; returns the English text, or null when unknown.
  function lookup(s) {
    var key = norm(s);
    if (!key || !HAN.test(key)) return null;
    if (key in cache) return cache[key];
    var out = null;
    if (key in exact) out = exact[key];
    if (out === null) {
      var nums = [];
      var t = key.replace(/-?\d+(?:[.,:]\d+)*%?/g, function (m) { nums.push(m); return "{x}"; });
      if (nums.length && t in templ) out = fill(templ[t], nums);
    }
    if (out === null) {
      for (var i = 0; i < patterns.length; i++) {
        var m = patterns[i].re.exec(key);
        if (m) {
          var args = m.slice(1).map(function (a) { var r = lookup(a); return r === null ? a : r; });
          out = fill(patterns[i].en, args);
          break;
        }
      }
    }
    if (out === null && key.indexOf("\n") < 0 && /[。；]/.test(key) && key.length < 400) {
      // several sentences in one node: translate sentence by sentence when every piece is known
      var pieces = key.match(/[^。；]+[。；]?/g) || [];
      if (pieces.length > 1) {
        var done = pieces.map(function (p) { return lookup(p); });
        if (done.every(function (d) { return d !== null; })) out = done.join(" ");
      }
    }
    cache[key] = out;
    return out;
  }

  function t(s) {
    if (lang !== "en" || s === null || s === undefined) return s;
    var str = String(s);
    if (!HAN.test(str)) return str;
    var r = lookup(str);
    if (r !== null) {
      var lead = /^\s*/.exec(str)[0], tail = /\s*$/.exec(str)[0];
      return lead + r + tail;
    }
    if (str.indexOf("\n") >= 0) {
      return str.split("\n").map(function (line) {
        var x = HAN.test(line) ? lookup(line) : null;
        return x === null ? line : x;
      }).join("\n");
    }
    return str;
  }

  function skipped(el) {
    for (var e = el; e && e.nodeType === 1; e = e.parentNode) {
      if (SKIP_TAGS[e.tagName]) return true;
      if (e.hasAttribute("data-i18n-skip")) return true;
      if (e.isContentEditable) return true;
    }
    return false;
  }

  function doText(node) {
    var v = node.nodeValue;
    if (!v || !HAN.test(v)) return;
    var p = node.parentNode;
    if (!p || p.nodeType !== 1 || skipped(p)) return;
    var r = t(v);
    if (r === v) return;
    // Chinese needs no spaces around inline elements such as <b>; English does.
    // Neighbours may still be Chinese at this point (translated a moment later), so Chinese
    // characters count as word characters too.
    var prev = node.previousSibling, next = node.nextSibling;
    var pt = prev ? (prev.textContent || "") : "", nt = next ? (next.textContent || "") : "";
    if (pt && /^[A-Za-z0-9(“]/.test(r) && /[A-Za-z0-9.,;:)”\u4e00-\u9fff]$/.test(pt)) r = " " + r;
    if (nt && /[A-Za-z0-9.,;:)”]$/.test(r) && /^[A-Za-z0-9(“\u4e00-\u9fff]/.test(nt)) r = r + " ";
    node.nodeValue = r;
  }

  function doAttrs(el) {
    // a textarea's text is data, but its placeholder and title are interface text
    if (el.tagName === "TEXTAREA" ? skipped(el.parentNode) : skipped(el)) return;
    for (var i = 0; i < ATTRS.length; i++) {
      var a = el.getAttribute(ATTRS[i]);
      if (a && HAN.test(a)) {
        var r = t(a);
        if (r !== a) el.setAttribute(ATTRS[i], r);
      }
    }
    if (el.tagName === "INPUT" && /^(button|submit|reset)$/i.test(el.type || "") && HAN.test(el.value || "")) {
      var rv = t(el.value);
      if (rv !== el.value) el.value = rv;
    }
  }

  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { doText(root); return; }
    if (root.nodeType !== 1 && root.nodeType !== 9 && root.nodeType !== 11) return;
    if (root.nodeType === 1) {
      if (root.tagName === "TEXTAREA") { doAttrs(root); return; }
      if (SKIP_TAGS[root.tagName] || root.hasAttribute("data-i18n-skip")) return;
      doAttrs(root);
    }
    var tw = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        if (n.nodeType === 1 && (SKIP_TAGS[n.tagName] || n.hasAttribute("data-i18n-skip"))) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    var n;
    while ((n = tw.nextNode())) {
      if (n.nodeType === 3) doText(n); else doAttrs(n);
    }
    if (root.querySelectorAll) {
      var areas = root.querySelectorAll("textarea[placeholder], textarea[title]");
      for (var i = 0; i < areas.length; i++) doAttrs(areas[i]);
    }
    if (root.tagName === "TEXTAREA") doAttrs(root);
  }

  function translateTitle() {
    if (document.title && HAN.test(document.title)) document.title = t(document.title);
  }

  function observe() {
    var mo = new MutationObserver(function (list) {
      for (var i = 0; i < list.length; i++) {
        var m = list[i];
        if (m.type === "childList") {
          for (var j = 0; j < m.addedNodes.length; j++) walk(m.addedNodes[j]);
        } else if (m.type === "characterData") {
          doText(m.target);
        } else if (m.type === "attributes") {
          doAttrs(m.target);
        }
      }
      translateTitle();
    });
    mo.observe(document.documentElement, {
      childList: true, subtree: true, characterData: true,
      attributes: true, attributeFilter: ATTRS.concat(["value"])
    });
  }

  function wrapDialogs() {
    var A = window.alert, C = window.confirm, P = window.prompt;
    window.alert = function (msg) { return A.call(window, t(msg)); };
    window.confirm = function (msg) { return C.call(window, t(msg)); };
    window.prompt = function (msg, def) { return P.call(window, t(msg), def); };
  }

  function addToggle() {
    var header = document.querySelector(".studio-header");
    if (!header || header.querySelector(".lang-toggle")) return;
    var box = document.createElement("span");
    box.className = "lang-toggle";
    box.setAttribute("data-i18n-skip", "");
    box.innerHTML = '<a href="#" data-lang="zh">中</a><i>/</i><a href="#" data-lang="en">EN</a>';
    box.querySelector('[data-lang="' + lang + '"]').className = "active";
    box.addEventListener("click", function (ev) {
      var a = ev.target.closest ? ev.target.closest("a[data-lang]") : null;
      if (!a) return;
      ev.preventDefault();
      if (a.getAttribute("data-lang") !== lang) setLang(a.getAttribute("data-lang"));
    });
    header.appendChild(box);
  }

  function reveal() { document.documentElement.classList.remove("i18n-pending"); }

  window.I18N = {
    lang: lang,
    t: t,
    set: setLang,
    isReady: function () { return ready; }
  };

  function start() {
    addToggle();
    if (lang !== "en") return;
    walk(document.body);
    translateTitle();
    observe();
    reveal();
  }

  if (lang === "en") {
    document.documentElement.lang = "en";
    document.documentElement.classList.add("i18n-pending");
    wrapDialogs();
    var fallback = setTimeout(reveal, 2000);
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/static/i18n/en.json", true);
    xhr.onload = function () {
      try { load(JSON.parse(xhr.responseText)); } catch (e) { /* keep Chinese */ }
      ready = true;
      clearTimeout(fallback);
      if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
      else start();
    };
    xhr.onerror = function () { ready = true; reveal(); addToggleWhenReady(); };
    xhr.send();
  } else {
    ready = true;
    addToggleWhenReady();
  }

  function addToggleWhenReady() {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", addToggle);
    else addToggle();
  }
})();
