"""generative_agents.storage.index"""

import os
import requests
import json
import threading
from collections import OrderedDict
from pydantic import PrivateAttr

# 禁用代理，防止与本地Ollama服务冲突
os.environ['NO_PROXY'] = 'localhost,127.0.0.1,::1'
os.environ['no_proxy'] = 'localhost,127.0.0.1,::1'
# 清除可能存在的HTTP代理设置
if 'HTTP_PROXY' in os.environ:
    del os.environ['HTTP_PROXY']
if 'HTTPS_PROXY' in os.environ:
    del os.environ['HTTPS_PROXY']
if 'http_proxy' in os.environ:
    del os.environ['http_proxy']
if 'https_proxy' in os.environ:
    del os.environ['https_proxy']

import time
from llama_index.core.indices.vector_store.retrievers import VectorIndexRetriever
from llama_index.core.schema import TextNode
from llama_index import core as index_core
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core import Settings
from llama_index.core.embeddings import BaseEmbedding
from modules import utils
from modules.model.telemetry import write_metric


_EMBEDDING_CACHE = OrderedDict()
_EMBEDDING_CACHE_LOCK = threading.Lock()
_EMBEDDING_KEY_LOCKS = {}
_EMBEDDING_CACHE_MAX = 2048


def _key_lock(key):
    with _EMBEDDING_CACHE_LOCK:
        lock = _EMBEDDING_KEY_LOCKS.get(key)
        if lock is None:
            lock = threading.Lock()
            _EMBEDDING_KEY_LOCKS[key] = lock
        return lock


class ExactCachedEmbedding(BaseEmbedding):
    """Cache embeddings only when provider, model, endpoint and full text match."""

    _inner = PrivateAttr()
    _namespace = PrivateAttr()
    _metrics_path = PrivateAttr()
    _agent_name = PrivateAttr()

    def __init__(self, inner, namespace, metrics_path="", agent_name=""):
        super().__init__(model_name=getattr(inner, "model_name", "embedding"))
        self._inner = inner
        self._namespace = namespace
        self._metrics_path = metrics_path
        self._agent_name = agent_name

    def _cached(self, text, caller, producer):
        started = time.perf_counter()
        key = (self._namespace, text)
        with _EMBEDDING_CACHE_LOCK:
            cached = _EMBEDDING_CACHE.get(key)
            if cached is not None:
                _EMBEDDING_CACHE.move_to_end(key)
        if cached is not None:
            self._record(caller, text, started, True, True, "")
            return list(cached)

        lock = _key_lock(key)
        with lock:
            with _EMBEDDING_CACHE_LOCK:
                cached = _EMBEDDING_CACHE.get(key)
                if cached is not None:
                    _EMBEDDING_CACHE.move_to_end(key)
            if cached is not None:
                self._record(caller, text, started, True, True, "")
                return list(cached)
            try:
                vector = producer()
            except Exception as exc:
                self._record(caller, text, started, False, False, type(exc).__name__)
                raise
            frozen = tuple(vector)
            with _EMBEDDING_CACHE_LOCK:
                _EMBEDDING_CACHE[key] = frozen
                _EMBEDDING_CACHE.move_to_end(key)
                while len(_EMBEDDING_CACHE) > _EMBEDDING_CACHE_MAX:
                    old_key, _ = _EMBEDDING_CACHE.popitem(last=False)
                    _EMBEDDING_KEY_LOCKS.pop(old_key, None)
            self._record(caller, text, started, False, True, "")
            return list(frozen)

    def _record(self, caller, text, started, cache_hit, success, error_type):
        write_metric(self._metrics_path, {
            "kind": "embedding",
            "agent": self._agent_name,
            "caller": caller,
            "model": self.model_name,
            "success": bool(success),
            "cache_hit": bool(cache_hit),
            "attempts": 0 if cache_hit else 1,
            "retries": 0,
            "failed_attempts": 0 if success else 1,
            "latency_ms": round((time.perf_counter() - started) * 1000, 3),
            "input_chars": len(text or ""),
            "output_chars": 0,
            "error_type": error_type or "",
        })

    def _get_query_embedding(self, query):
        return self._cached(
            query, "embedding_query", lambda: self._inner.get_query_embedding(query)
        )

    def _get_text_embedding(self, text):
        return self._cached(
            text, "embedding_text", lambda: self._inner.get_text_embedding(text)
        )

    async def _aget_query_embedding(self, query):
        return self._get_query_embedding(query)


class OpenRouterEmbedding(BaseEmbedding):
    api_base: str
    api_key: str
    default_headers: dict = {}

    def _get_embedding(self, text):
        # 网络抖动（代理断线、SSL 中断、限流、服务端 5xx）时退避重试，约 1 分钟内共 6 次，
        # 避免一次断线就丢掉一条记忆或让问卷检索失败。
        delays = [1, 2, 4, 8, 16]
        for attempt in range(len(delays) + 1):
            try:
                response = requests.post(
                    url=f"{self.api_base.rstrip('/')}/embeddings",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                        **self.default_headers,
                    },
                    json={"model": self.model_name, "input": text},
                    timeout=60,
                )
                response.raise_for_status()
                data = response.json()
                return data["data"][0]["embedding"]
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout,
                    requests.exceptions.SSLError) as exc:
                error = exc
            except requests.exceptions.HTTPError as exc:
                code = getattr(exc.response, "status_code", 0) or 0
                if code != 429 and code < 500:
                    raise
                error = exc
            if attempt < len(delays):
                print("嵌入请求失败，{} 秒后重试（{}/{}）：{}".format(delays[attempt], attempt + 1, len(delays), error))
                time.sleep(delays[attempt])
        raise error

    def _get_query_embedding(self, query):
        return self._get_embedding(query)

    async def _aget_query_embedding(self, query):
        return self._get_query_embedding(query)

    def _get_text_embedding(self, text):
        return self._get_embedding(text)


class OllamaRESTEmbedding(BaseEmbedding):
    """Ollama embedding adapter that does not require an optional LlamaIndex plugin."""

    base_url: str = "http://127.0.0.1:11434"
    request_timeout: float = 60.0

    def _get_embedding(self, text):
        base_url = self.base_url.rstrip("/")
        response = requests.post(
            url=f"{base_url}/api/embed",
            json={
                "model": self.model_name,
                "input": text,
                "options": {"mirostat": 0},
            },
            timeout=self.request_timeout,
        )
        response.raise_for_status()
        data = response.json()
        embeddings = data.get("embeddings")
        if not embeddings or not isinstance(embeddings[0], list):
            raise ValueError("Ollama /api/embed response contains no embedding vector")
        return embeddings[0]

    def _get_query_embedding(self, query):
        return self._get_embedding(query)

    async def _aget_query_embedding(self, query):
        return self._get_query_embedding(query)

    def _get_text_embedding(self, text):
        return self._get_embedding(text)

    async def _aget_text_embedding(self, text):
        return self._get_text_embedding(text)


class LlamaIndex:
    def __init__(self, embedding, path=None, metrics_path="", agent_name=""):
        self._config = {"max_nodes": 0}
        if embedding["type"] == "hugging_face":
            from llama_index.embeddings.huggingface import HuggingFaceEmbedding
            embed_model = HuggingFaceEmbedding(model_name=embedding["model"])
        elif embedding["type"] == "ollama":
            embed_model = OllamaRESTEmbedding(
                model_name=embedding["model"],
                base_url=embedding["base_url"],
            )
        elif embedding["type"] == "openai":
            api_key = os.getenv("OPENAI_API_KEY") or embedding.get("api_key")
            if not api_key:
                raise ValueError("OPENAI_API_KEY is required for OpenAI embeddings")
            embed_model = OpenRouterEmbedding(
                api_base=embedding.get("base_url", "https://api.openai.com/v1"),
                api_key=api_key,
                model_name=embedding.get("model", "text-embedding-3-small"),
            )
        elif embedding["type"] == "openrouter":
            api_key = os.getenv("OPENROUTER_API_KEY") or embedding.get("api_key")
            if not api_key:
                raise ValueError("OPENROUTER_API_KEY is required for OpenRouter embeddings")
            default_headers = {}
            site_url = os.getenv("OPENROUTER_SITE_URL") or embedding.get("site_url")
            app_name = os.getenv("OPENROUTER_APP_NAME") or embedding.get("app_name")
            if site_url:
                default_headers["HTTP-Referer"] = site_url
            if app_name:
                default_headers["X-OpenRouter-Title"] = app_name
            embed_model = OpenRouterEmbedding(
                model_name=embedding["model"],
                api_base=embedding["base_url"],
                api_key=api_key,
                default_headers=default_headers,
            )
        elif embedding["type"] in ("dashscope", "custom"):
            # 国内阿里云百炼，或任意 OpenAI 兼容的 /embeddings 端点（硅基流动、智谱等）
            key_var = "DASHSCOPE_API_KEY" if embedding["type"] == "dashscope" else "EMBEDDING_API_KEY"
            api_key = os.getenv(key_var)
            if not api_key:
                raise ValueError("{} is required for {} embeddings".format(key_var, embedding["type"]))
            if not embedding.get("base_url") or not embedding.get("model"):
                raise ValueError("custom embeddings need base_url and model")
            embed_model = OpenRouterEmbedding(
                model_name=embedding["model"],
                api_base=embedding["base_url"],
                api_key=api_key,
            )
        elif embedding["type"] == "mock":
            # 离线测试用：确定性伪向量，不发起任何网络请求
            from llama_index.core.embeddings import BaseEmbedding

            class MockEmbedding(BaseEmbedding):
                dim: int = 64

                def _hash_vec(self, text):
                    import hashlib
                    h = hashlib.sha256((text or "").encode("utf-8")).digest()
                    vals = []
                    while len(vals) < self.dim:
                        h = hashlib.sha256(h).digest()
                        vals.extend([b / 255.0 - 0.5 for b in h])
                    return vals[: self.dim]

                def _get_query_embedding(self, query):
                    return self._hash_vec(query)

                def _get_text_embedding(self, text):
                    return self._hash_vec(text)

                async def _aget_query_embedding(self, query):
                    return self._hash_vec(query)

                async def _aget_text_embedding(self, text):
                    return self._hash_vec(text)

            embed_model = MockEmbedding()
        else:
            raise NotImplementedError(
                "embedding type {} is not supported".format(embedding["type"])
            )

        namespace = json.dumps({
            "type": embedding.get("type", ""),
            "base_url": embedding.get("base_url", ""),
            "model": embedding.get("model", ""),
        }, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        embed_model = ExactCachedEmbedding(
            embed_model,
            namespace=namespace,
            metrics_path=metrics_path,
            agent_name=agent_name,
        )

        Settings.embed_model = embed_model
        Settings.node_parser = SentenceSplitter(chunk_size=512, chunk_overlap=64)
        Settings.num_output = 1024
        Settings.context_window = 4096
        if path and os.path.exists(path):
            self._index = index_core.load_index_from_storage(
                index_core.StorageContext.from_defaults(persist_dir=path),
                show_progress=True,
            )
            self._config = utils.load_dict(os.path.join(path, "index_config.json"))
        else:
            self._index = index_core.VectorStoreIndex([], show_progress=True)
        self._path = path

    def add_node(
        self,
        text,
        metadata=None,
        exclude_llm_keys=None,
        exclude_embedding_keys=None,
        id=None,
    ):
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                metadata = metadata or {}
                exclude_llm_keys = exclude_llm_keys or list(metadata.keys())
                exclude_embedding_keys = exclude_embedding_keys or list(metadata.keys())
                id = id or "node_" + str(self._config["max_nodes"])
                self._config["max_nodes"] += 1
                node = TextNode(
                    text=text,
                    id_=id,
                    metadata=metadata,
                    excluded_llm_metadata_keys=exclude_llm_keys,
                    excluded_embed_metadata_keys=exclude_embedding_keys,
                )
                self._index.insert_nodes([node])
                return node
            except Exception as e:
                retry_count += 1
                if retry_count >= max_retries:
                    print(f"LlamaIndex.add_node() failed after {max_retries} attempts: {e}")
                    return None
                print(f"LlamaIndex.add_node() retry {retry_count}/{max_retries}: {e}")
                time.sleep(2)

    def has_node(self, node_id):
        return node_id in self._index.docstore.docs

    def find_node(self, node_id):
        return self._index.docstore.docs[node_id]

    def get_nodes(self, filter=None):
        def _check(node):
            if not filter:
                return True
            return filter(node)

        return [n for n in self._index.docstore.docs.values() if _check(n)]

    def remove_nodes(self, node_ids, delete_from_docstore=True):
        self._index.delete_nodes(node_ids, delete_from_docstore=delete_from_docstore)

    def cleanup(self):
        now, remove_ids = utils.get_timer().get_date(), []
        for node_id, node in self._index.docstore.docs.items():
            create = utils.to_date(node.metadata["create"])
            expire = utils.to_date(node.metadata["expire"])
            if create > now or expire < now:
                remove_ids.append(node_id)
        self.remove_nodes(remove_ids)
        return remove_ids

    def retrieve(
        self,
        text,
        similarity_top_k=5,
        filters=None,
        node_ids=None,
        retriever_creator=None,
    ):
        try:
            # 如果索引为空，直接返回空列表
            if self.nodes_num == 0:
                return []
                
            retriever_creator = retriever_creator or VectorIndexRetriever
            return retriever_creator(
                self._index,
                similarity_top_k=similarity_top_k,
                filters=filters,
                node_ids=node_ids,
            ).retrieve(text)
        except Exception as e:
            # 对于空向量库错误，直接返回空结果
            if getattr(self, "strict_retrieval", False):
                raise
            if "should return at least one" in str(e) or "empty index" in str(e).lower():
                return []
            # 其他错误打印一次并返回空结果
            print(f"LlamaIndex.retrieve() warning: {e}")
            return []

    def query(
        self,
        text,
        similarity_top_k=5,
        text_qa_template=None,
        refine_template=None,
        filters=None,
        query_creator=None,
    ):
        kwargs = {
            "similarity_top_k": similarity_top_k,
            "text_qa_template": text_qa_template,
            "refine_template": refine_template,
            "filters": filters,
        }
        try:
            # 如果索引为空，返回一个空响应
            if self.nodes_num == 0:
                from llama_index.core.schema import Response
                return Response(response="", source_nodes=[])
                
            if query_creator:
                query_engine = query_creator(retriever=self._index.as_retriever(**kwargs))
            else:
                query_engine = self._index.as_query_engine(**kwargs)
            return query_engine.query(text)
        except Exception as e:
            print(f"LlamaIndex.query() warning: {e}")
            from llama_index.core.schema import Response
            return Response(response="", source_nodes=[])

    def save(self, path=None):
        path = path or self._path
        self._index.storage_context.persist(path)
        utils.save_dict(self._config, os.path.join(path, "index_config.json"))

    @property
    def nodes_num(self):
        return len(self._index.docstore.docs)
