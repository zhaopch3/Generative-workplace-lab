# quick_ollama_sdk.py
from ollama import Client
client = Client(host='http://127.0.0.1:11434')

data = client.embeddings(
    model='mxbai-embed-large:latest',
    prompt='你好'
)
print(data["data"][0]["embedding"][:10])   # 打印前 10 维
