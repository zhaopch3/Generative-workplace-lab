# -*- coding: utf-8 -*-
"""V24: end-of-step perception and same-area approach.

V23 perceived at the start of each agent's own think (one step late, and
dependent on think order), and "walk up to someone" could stop on a tile of the
neighbouring area, so bystanders in the room did not perceive the leader's
scheduled behaviour toward 阿伊莎.
"""
import json
import os
import tempfile
import unittest
from pathlib import Path

import server
from start import get_config

ROOT = Path(__file__).resolve().parents[1]
PRESETS = ROOT / "data" / "world_presets"
ABUSE = {"d2_high_1": "方案很愚蠢", "d2_high_2": "一塌糊涂"}


def load(name):
    return json.loads((PRESETS / (name + ".json")).read_text(encoding="utf-8"))


def run_world(name, steps, **extra):
    from start import SimulateServer
    payload = load("事件操纵-高辱虐组")
    payload.update(name=name, offline=True, step=steps, **extra)
    _, args, cfg = server.build_experiment_config(payload)
    origin = Path.cwd()
    root = tempfile.mkdtemp()
    os.chdir(root)
    try:
        run = SimulateServer(args.name, str(origin / "frontend/static"),
                             "results/checkpoints/" + args.name, cfg, verbose="error")
        for agent in run.game.agents.values():
            agent.scratch.template_path = str(origin / "data/prompts")
        run.simulate(steps, stride=60)
        return run, root
    finally:
        os.chdir(origin)


def remembered(agent, needle):
    out = []
    for node_id in agent.associate.memory["event"]:
        concept = agent.associate.find_concept(node_id)
        if needle in concept.describe:
            out.append(concept.create.strftime("%Y%m%d-%H:%M"))
    return sorted(set(out))


class PerceptionPolicyTests(unittest.TestCase):
    def test_new_worlds_use_step_end_perception(self):
        cfg = get_config("20240213-08:00", 60, ["阿伊莎"])
        self.assertEqual(cfg["perception_policy"], "step_end_v24")
        _, _, built = server.build_experiment_config(dict(load("事件操纵-低辱虐组"), name="v24-policy"))
        self.assertEqual(built["perception_policy"], "step_end_v24")


class BystanderTests(unittest.TestCase):
    """Day 2, 10:00 (meeting area) and 15:00 (leader office): the whole team is present."""

    @classmethod
    def setUpClass(cls):
        # 32 steps from 02-13 08:00 reach the 15:00 step of day 2.
        cls.world, _ = run_world("v24-bystander", 32, shuffle_think_order=False)

    def test_bystanders_perceive_both_events_when_they_happen(self):
        for name in ("玛丽亚", "沃尔夫冈"):
            agent = self.world.game.get_agent(name)
            self.assertEqual(remembered(agent, ABUSE["d2_high_1"]), ["20240214-10:00"], name)
            self.assertEqual(remembered(agent, ABUSE["d2_high_2"]), ["20240214-15:00"], name)

    def test_leader_stands_in_target_area(self):
        maze = self.world.game.maze
        leader = self.world.agent_status["克劳斯"]["coord"]
        target = self.world.agent_status["阿伊莎"]["coord"]
        self.assertEqual(maze.tile_at(leader).get_address("arena"), maze.tile_at(target).get_address("arena"))
        self.assertLessEqual(max(abs(leader[0] - target[0]), abs(leader[1] - target[1])), 2)


class ThinkOrderTests(unittest.TestCase):
    def test_shuffled_think_order_gives_same_witnesses(self):
        run, _ = run_world("v24-shuffle", 32, shuffle_think_order=True)
        for name in ("玛丽亚", "沃尔夫冈"):
            agent = run.game.get_agent(name)
            self.assertEqual(remembered(agent, ABUSE["d2_high_1"]), ["20240214-10:00"], name)
            self.assertEqual(remembered(agent, ABUSE["d2_high_2"]), ["20240214-15:00"], name)


class ApproachTilesTests(unittest.TestCase):
    def test_tiles_stay_in_target_area(self):
        run, _ = run_world("v24-approach", 1)
        agent = run.game.get_agent("克劳斯")
        maze = run.game.maze
        for coord in ([10, 17], [16, 9], [6, 10]):
            arena = maze.tile_at(coord).get_address("arena")
            tiles = agent.approach_tiles(coord)
            self.assertTrue(tiles)
            for tile in tiles:
                self.assertEqual(maze.tile_at(tile).get_address("arena"), arena)
                self.assertNotEqual(tuple(tile), tuple(coord))


class LegacyWorldTests(unittest.TestCase):
    def test_world_without_policy_keeps_v23_perception(self):
        from start import SimulateServer
        payload = dict(load("事件操纵-高辱虐组"), name="v24-legacy", offline=True, step=2)
        _, args, cfg = server.build_experiment_config(payload)
        cfg.pop("perception_policy")
        origin = Path.cwd()
        root = tempfile.mkdtemp()
        os.chdir(root)
        try:
            run = SimulateServer(args.name, str(origin / "frontend/static"),
                                 "results/checkpoints/" + args.name, cfg, verbose="error")
            for agent in run.game.agents.values():
                agent.scratch.template_path = str(origin / "data/prompts")
            run.simulate(2, stride=60)
        finally:
            os.chdir(origin)
        self.assertEqual(run.perception_policy, "legacy")
        self.assertTrue(all(a.perception_policy == "legacy" for a in run.game.agents.values()))
        self.assertFalse(any(a._percept_ready for a in run.game.agents.values()))


if __name__ == "__main__":
    unittest.main()
