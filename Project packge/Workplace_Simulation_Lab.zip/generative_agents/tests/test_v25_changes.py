# -*- coding: utf-8 -*-
"""V25: leadership style versions, evening life (no 19:00 sleep), no forced office rhythm,
world rule 7, first-person reflection prompts, attitudes in the daily state summary."""
import json
import os
import unittest
from unittest import mock

from modules.agent import Agent

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read(*parts):
    with open(os.path.join(ROOT, *parts), encoding="utf-8") as f:
        return f.read()


def load(name):
    return json.loads(read("data", "world_presets", name + ".json"))


class LeadershipStyleTests(unittest.TestCase):
    def setUp(self):
        self.cond = json.loads(read("data", "experiment_conditions.json"))

    def test_four_conditions_and_default_copy(self):
        # V26: only the final (habit) version remains
        self.assertEqual(set(self.cond), {"high_abuse", "low_abuse"})
        self.assertEqual(self.cond, json.loads(read("data", "experiment_conditions.default.json")))

    def test_behaviour_only_no_beliefs_or_after_feelings(self):
        for key, value in self.cond.items():
            text = value["leader_overrides"]["scratch"]["conduct"]
            for banned in ("打心底", "他认为", "脾气暴躁", "故意", "不觉得自己过分", "从不道歉", "心情不好", "不高兴", "保全自己的面子", "情绪稳定"):
                self.assertNotIn(banned, text, key)
            self.assertTrue(text.startswith("克劳斯"), key)

    def test_templates_use_matching_conditions(self):
        pairs = {"人设操纵-高辱虐组": "high_abuse", "人设操纵-低辱虐组": "low_abuse"}
        for name, cond in pairs.items():
            t = load(name)
            self.assertEqual(t["condition"], cond)
            self.assertIn("7. 【自主安排】", t["world_rules"])
        a, b = load("人设操纵-高辱虐组"), load("人设操纵-低辱虐组")
        self.assertEqual(a["custom_surveys"], b["custom_surveys"])
        self.assertEqual((a["research_design"]["condition_code"], b["research_design"]["condition_code"]),
                         ("persona_high", "persona_low"))


class EveningLifeTests(unittest.TestCase):
    def agent(self, leader=False):
        a = Agent.__new__(Agent)
        a._is_office_leader = lambda: leader
        a.office_rhythm = "rules_v25"
        return a

    def test_dorm_plans_are_not_sleep(self):
        a = self.agent()
        for text in ("下午 6 点下班，回休息宿舍区", "在休息宿舍区和家人视频通话", "在休息宿舍区看书放松"):
            self.assertEqual(a._normalize_office_activity(text, 19), text)
        self.assertEqual(a._normalize_office_activity("晚上11点在休息宿舍区睡觉", 23), "在休息宿舍区睡觉")
        self.assertEqual(a._normalize_office_activity("准备睡觉", 22), "在休息宿舍区准备睡觉")

    def test_no_forced_leader_visit_and_bedtime_fallback(self):
        a = self.agent()
        schedule = {"10:00": "在工位写方案", "12:00": "去茶水休息区吃午饭", "15:00": "在工位整理数据",
                    "18:00": "下班回休息宿舍区", "21:00": "在休息宿舍区和同事聊天", "23:00": "在休息宿舍区看书"}
        with mock.patch("modules.agent.utils.get_timer") as timer:
            timer.return_value.get_date.return_value.weekday.return_value = 2  # Wednesday
            out = a._apply_office_rhythm(dict(schedule))
        self.assertEqual(out["15:00"], "在工位整理数据")
        self.assertEqual(out["18:00"], "下班回休息宿舍区")
        self.assertEqual(out["21:00"], "在休息宿舍区和同事聊天")
        self.assertEqual(out["23:00"], "在休息宿舍区准备睡觉")  # no sleep planned -> fallback at the last night hour
        self.assertNotIn("研究进展", json.dumps(out, ensure_ascii=False))

    def test_monday_meeting_anchor(self):
        with mock.patch("modules.agent.utils.get_timer") as timer:
            timer.return_value.get_date.return_value.weekday.return_value = 0
            self.assertEqual(self.agent()._office_rhythm()["10:00"], "去会议区参加小组例会")
            self.assertEqual(self.agent(True)._office_rhythm()["10:00"], "在会议区主持小组例会")

    def test_event_templates_keep_v24_rhythm(self):
        for name in ("事件操纵-高辱虐组", "事件操纵-低辱虐组"):
            self.assertEqual(load(name)["office_rhythm"], "legacy_v24")
        a = self.agent()
        a.office_rhythm = "legacy_v24"
        self.assertEqual(a._office_rhythm()["15:00"], "去领导办公室汇报工作进展")

    def test_schedule_prompt_has_no_location_quota(self):
        text = read("data", "prompts", "schedule_daily.txt")
        self.assertNotIn("若干地点", text)
        self.assertNotIn("请安排到领导办公室", text)


class ReflectionPromptTests(unittest.TestCase):
    def test_first_person_feelings(self):
        for name in ("reflect_insights", "reflect_chat_memory", "retrieve_thought"):
            self.assertIn("第一人称", read("data", "prompts", name + ".txt"), name)
        self.assertIn("${agent}", read("data", "prompts", "reflect_focus.txt"))
        self.assertIn("不要写成旁观者的分析", read("data", "prompts", "reflect_insights.txt"))

    def test_state_summary_includes_attitudes_and_plans(self):
        text = read("data", "prompts", "retrieve_currently.txt")
        self.assertIn("最常打交道的人", text)
        self.assertIn("打算怎么对待他们", text)


if __name__ == "__main__":
    unittest.main()
