from __future__ import annotations

import copy
import json
import math
import shutil
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
STATIC_ROOT = ROOT / "frontend" / "static"
ASSET_ROOT = STATIC_ROOT / "assets" / "village"
TILEMAP_DIR = ASSET_ROOT / "tilemap"
TILEMAP_PATH = TILEMAP_DIR / "tilemap.json"
MAZE_PATH = ASSET_ROOT / "maze.json"
REPLAY_SPRITE_DIR = ASSET_ROOT / "agents" / "replay_sprites"

AGENT_TOWN_ROOT = Path(r"D:\AI\AI Town CN\agent-town-main for 建立地图\agent-town-main")
SOURCE_MAP = AGENT_TOWN_ROOT / "public" / "maps" / "office2.json"
SOURCE_TILESETS = AGENT_TOWN_ROOT / "public" / "tilesets"

WORLD = "the Ville"
SECTOR = "公司办公室"
TILE_SIZE = 48

AGENT_COORDS = {
    "阿伊莎": [5, 6],
    "玛丽亚": [8, 10],
    "沃尔夫冈": [11, 6],
    "克劳斯": [14, 15],
}

AGENT_WORKSTATIONS = {
    "阿伊莎": ["开放办公区", "1号工位"],
    "玛丽亚": ["开放办公区", "2号工位"],
    "沃尔夫冈": ["开放办公区", "3号工位"],
    "克劳斯": ["领导办公室", "领导办公桌"],
}

SPATIAL_TREE = {
    WORLD: {
        SECTOR: {
            "开放办公区": ["1号工位", "2号工位", "3号工位", "公共办公桌"],
            "领导办公室": ["领导办公桌", "领导椅", "文件柜"],
            "会议区": ["会议桌", "白板", "书柜"],
            "茶水休息区": ["沙发", "饮水机", "打印机"],
            "休息宿舍区": ["床", "休息沙发"],
        }
    }
}

LIVING_AREA = [WORLD, SECTOR, "休息宿舍区"]


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def layer(width: int, height: int, fill: int = 0) -> list[int]:
    return [fill for _ in range(width * height)]


def set_tile(data: list[int], width: int, height: int, x: int, y: int, gid: int) -> None:
    if 0 <= x < width and 0 <= y < height:
        data[y * width + x] = gid


def point_in_rect(px: float, py: float, rect: dict) -> bool:
    return (
        rect.get("x", 0) <= px <= rect.get("x", 0) + rect.get("width", 0)
        and rect.get("y", 0) <= py <= rect.get("y", 0) + rect.get("height", 0)
    )


def object_to_tile(obj: dict) -> tuple[int, int]:
    x = int(round(float(obj.get("x", 0)) / TILE_SIZE))
    y = int(round((float(obj.get("y", 0)) - float(obj.get("height", TILE_SIZE))) / TILE_SIZE))
    return x, y


def copy_tilesets(tilemap: dict) -> None:
    for tileset in tilemap["tilesets"]:
        basename = Path(tileset["image"]).name
        src = SOURCE_TILESETS / basename
        if not src.exists():
            raise FileNotFoundError(f"Missing Agent Town tileset: {src}")
        shutil.copy2(src, TILEMAP_DIR / basename)
        tileset["image"] = basename


def add_collision_tileset(tilemap: dict) -> int:
    firstgid = max(ts["firstgid"] + ts.get("tilecount", 0) for ts in tilemap["tilesets"])
    tilemap["tilesets"].append(
        {
            "columns": 10,
            "firstgid": firstgid,
            "image": "blocks_1.png",
            "imageheight": 256,
            "imagewidth": 320,
            "margin": 0,
            "name": "blocks",
            "spacing": 0,
            "tilecount": 80,
            "tileheight": 32,
            "tilewidth": 32,
        }
    )
    return firstgid


def make_tile_layer(name: str, width: int, height: int, data: list[int], layer_id: int, visible: bool = True) -> dict:
    return {
        "data": data,
        "height": height,
        "id": layer_id,
        "name": name,
        "opacity": 1,
        "type": "tilelayer",
        "visible": visible,
        "width": width,
        "x": 0,
        "y": 0,
    }


def rasterize_tile_objects(tilemap: dict, layer_name: str, new_id: int) -> dict | None:
    width = tilemap["width"]
    height = tilemap["height"]
    source = next((l for l in tilemap["layers"] if l.get("name") == layer_name), None)
    if not source or source.get("type") != "objectgroup":
        return None

    data = layer(width, height)
    for obj in source.get("objects", []):
        gid = obj.get("gid")
        if not gid:
            continue
        x, y = object_to_tile(obj)
        set_tile(data, width, height, x, y, gid)
    return make_tile_layer(layer_name, width, height, data, new_id)


def build_collision_layer(tilemap: dict, blocks_firstgid: int, new_id: int) -> dict:
    width = tilemap["width"]
    height = tilemap["height"]
    data = layer(width, height)
    floor = next(l for l in tilemap["layers"] if l.get("name") == "floor")["data"]
    ground = next(l for l in tilemap["layers"] if l.get("name") == "ground")["data"]
    walls = next(l for l in tilemap["layers"] if l.get("name") == "walls")["data"]

    for y in range(height):
        for x in range(width):
            i = y * width + x
            has_floor = bool(floor[i] or ground[i])
            blocked = (
                not has_floor
                or bool(walls[i])
                or x == 0
                or y == 0
                or x == width - 1
                or y == height - 1
            )
            if blocked:
                data[i] = blocks_firstgid + 1

    return make_tile_layer("Collisions", width, height, data, new_id, visible=False)


def convert_tilemap() -> None:
    tilemap = load_json(SOURCE_MAP)
    copy_tilesets(tilemap)
    blocks_firstgid = add_collision_tileset(tilemap)

    next_id = max(layer.get("id", 0) for layer in tilemap["layers"]) + 1
    converted_layers = []
    for current in tilemap["layers"]:
        if current.get("name") in {"props", "props-over", "collisions"}:
            continue
        converted_layers.append(current)

    for object_layer_name in ["props", "props-over"]:
        rasterized = rasterize_tile_objects(tilemap, object_layer_name, next_id)
        next_id += 1
        if rasterized:
            converted_layers.append(rasterized)

    converted_layers.append(build_collision_layer(tilemap, blocks_firstgid, next_id))

    tilemap["layers"] = converted_layers
    tilemap["tilewidth"] = TILE_SIZE
    tilemap["tileheight"] = TILE_SIZE
    write_json(TILEMAP_PATH, tilemap)


def addr(arena: str, obj: str) -> list[str]:
    return [SECTOR, arena, obj]


def area_for(x: int, y: int) -> tuple[str, str]:
    if 4 <= x <= 15 and 4 <= y <= 10:
        if x <= 6:
            return "开放办公区", "1号工位"
        if x <= 9:
            return "开放办公区", "2号工位"
        if x <= 12:
            return "开放办公区", "3号工位"
        return "开放办公区", "公共办公桌"

    if 15 <= x <= 26 and 2 <= y <= 10:
        if x >= 23:
            return "茶水休息区", "饮水机"
        if y <= 5:
            return "会议区", "书柜"
        return "会议区", "会议桌"

    if 4 <= x <= 15 and 11 <= y <= 19:
        if x <= 8:
            return "休息宿舍区", "床"
        if x <= 11:
            return "茶水休息区", "沙发"
        return "领导办公室", "领导办公桌"

    if 16 <= x <= 25 and 11 <= y <= 19:
        if y <= 14:
            return "茶水休息区", "打印机"
        return "休息宿舍区", "休息沙发"

    return "开放办公区", "公共办公桌"


def build_maze() -> None:
    tilemap = load_json(TILEMAP_PATH)
    width = tilemap["width"]
    height = tilemap["height"]
    collisions = next(l for l in tilemap["layers"] if l["name"] == "Collisions")["data"]

    tiles = []
    for y in range(height):
        for x in range(width):
            arena, obj = area_for(x, y)
            tile = {"coord": [x, y], "address": addr(arena, obj)}
            if collisions[y * width + x]:
                tile["collision"] = True
            tiles.append(tile)

    old_maze = load_json(MAZE_PATH) if MAZE_PATH.exists() else {}
    maze = {
        "world": WORLD,
        "tile_size": TILE_SIZE,
        "size": [height, width],
        "map": old_maze.get("map", {}),
        "camera": {"zoom_factor": 1, "zoom_range": [0.5, 10, 0.01]},
        "tile_address_keys": ["world", "sector", "arena", "game_object"],
        "tiles": tiles,
    }
    write_json(MAZE_PATH, maze)


def update_agents() -> None:
    for name, coord in AGENT_COORDS.items():
        path = ASSET_ROOT / "agents" / name / "agent.json"
        data = load_json(path)
        data["coord"] = coord
        data.setdefault("spatial", {})["tree"] = copy.deepcopy(SPATIAL_TREE)
        data["spatial"]["address"] = {
            "living_area": copy.deepcopy(LIVING_AREA),
            "睡觉": copy.deepcopy(LIVING_AREA) + ["床"],
            "工作": [WORLD, SECTOR] + AGENT_WORKSTATIONS[name],
        }
        if name == "克劳斯":
            data["scratch"]["daily_plan"] = "克劳斯上午在领导办公室安排团队工作，随后巡视开放办公区，与员工讨论研究进展，下午在会议区主持讨论并在办公室整理反馈。"
            data["scratch"]["lifestyle"] = "克劳斯通常早上7点醒来，白天在办公室管理团队，晚上10点左右在办公室休息宿舍区休息。"
        else:
            data["scratch"]["daily_plan"] = f"{name}白天在公司办公室工作，主要在自己的工位完成负责的工作，并会去会议区、茶水休息区与同事交流。"
            data["scratch"]["lifestyle"] = f"{name}通常早上醒来后进入办公室工作，白天在工位、会议区和茶水休息区之间活动，晚上10点左右在办公室休息宿舍区休息。"
        write_json(path, data)


def build_replay_sprites() -> None:
    REPLAY_SPRITE_DIR.mkdir(parents=True, exist_ok=True)
    for index, name in enumerate(AGENT_COORDS.keys()):
        src = ASSET_ROOT / "agents" / name / "texture.png"
        sprite = Image.open(src).convert("RGBA")
        frame = sprite.crop((32, 0, 64, 32))
        frame.save(REPLAY_SPRITE_DIR / f"persona_{index}.png")


def main() -> None:
    if not SOURCE_MAP.exists():
        raise FileNotFoundError(f"Agent Town map not found: {SOURCE_MAP}")
    convert_tilemap()
    build_maze()
    update_agents()
    build_replay_sprites()
    print("Agent Town office map imported")


if __name__ == "__main__":
    main()
