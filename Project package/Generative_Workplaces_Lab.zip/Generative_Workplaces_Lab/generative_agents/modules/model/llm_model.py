"""generative_agents.model.llm_model"""
import os
import time
import re
import json
import requests
from modules.utils.namespace import ModelType
from modules import utils
from modules.model.telemetry import write_metric


class ModelStyle:
    OPEN_AI = "openai"
    QIANFAN = "qianfan"
    SPARK_AI = "sparkai"
    ZHIPU_AI = "zhipuai"
    OLLAMA = "ollama"


class LLMModel:
    def __init__(self, base_url, model, embedding_model, keys, config=None):
        self._base_url = base_url
        self._model = model
        self._embedding_model = embedding_model
        self._config = config or {}
        self._timeout = self._config.get("timeout", 60)
        self._handle = self.setup(keys, config)
        self._meta_responses = []
        self._summary = {"total": [0, 0, 0]}
        self._enabled = True
        self._metrics_path = self._config.get("metrics_path", "")
        self._metrics_agent = self._config.get("agent_name", "")

    def embedding(self, text, retry=10):
        response = None
        for _ in range(retry):
            try:
                response = self._embedding(text)
            except Exception as e:
                print(f"LLMModel.embedding() caused an error: {e}")
                time.sleep(5)
                continue
            if response:
                break
        return response

    def _embedding(self, text):
        raise NotImplementedError("_embedding is not support for " + str(self.__class__))

    def completion(self, prompt, retry=10, callback=None, failsafe=None, caller="llm_normal", **kwargs):
        # 温度：调用点未显式指定时，采用运行配置的全局默认（config.temperature，出厂1.0）
        if "temperature" not in kwargs:
            try:
                kwargs["temperature"] = float((self._config or {}).get("temperature", 1.0))
            except (TypeError, ValueError):
                kwargs["temperature"] = 1.0
        started = time.perf_counter()
        response, self._meta_responses = None, []
        attempts, failed_attempts, last_error_type = 0, 0, ""
        self._call_usage = None
        self._summary.setdefault(caller, [0, 0, 0])
        for _ in range(retry):
            attempts += 1
            try:
                meta_response = self._completion(prompt, **kwargs).strip()
                self._meta_responses.append(meta_response)
                self._summary["total"][0] += 1
                self._summary[caller][0] += 1
                if callback:
                    response = callback(meta_response)
                else:
                    response = meta_response
            except Exception as e:
                print(f"LLMModel.completion() caused an error: {e}")
                failed_attempts += 1
                last_error_type = type(e).__name__
                status_code = getattr(e, "status_code", None)
                if status_code in {400, 401, 402, 403, 404}:
                    self._record_completion_metric(
                        caller, prompt, response, started, attempts,
                        failed_attempts, False, last_error_type,
                    )
                    raise
                time.sleep(5)
                response = None
                continue
            if response is not None:
                break
            failed_attempts += 1
        pos = 2 if response is None else 1
        self._summary["total"][pos] += 1
        self._summary[caller][pos] += 1
        self._record_completion_metric(
            caller, prompt, response, started, attempts,
            failed_attempts, response is not None, last_error_type,
        )
        return response or failsafe

    def _record_completion_metric(
        self, caller, prompt, response, started, attempts,
        failed_attempts, success, error_type,
    ):
        write_metric(self._metrics_path, {
            "kind": "llm_completion",
            "agent": self._metrics_agent,
            "caller": caller,
            "model": self._model,
            "thinking": deepseek_thinking(self._base_url, self._config) or "",
            "cheap_mode": bool(self._config.get("cheap_mode")),
            "success": bool(success),
            "attempts": attempts,
            "retries": max(0, attempts - 1),
            "failed_attempts": failed_attempts,
            "latency_ms": round((time.perf_counter() - started) * 1000, 3),
            "input_chars": len(prompt or ""),
            "output_chars": sum(len(str(item)) for item in self._meta_responses),
            "error_type": error_type or "",
            "usage": getattr(self, "_call_usage", None),
        })

    def _completion(self, prompt, **kwargs):
        raise NotImplementedError("_completion is not support for " + str(self.__class__))

    def is_available(self):
        return self._enabled

    def get_summary(self):
        des = {}
        for k, v in self._summary.items():
            des[k] = "S:{},F:{}/R:{}".format(v[1], v[2], v[0])
        return {"model": self._model, "summary": des}

    def disable(self):
        self._enabled = False

    @property
    def meta_responses(self):
        return self._meta_responses

    @classmethod
    def model_type(cls):
        return ModelType.LLM


def deepseek_thinking(base_url, config=None):
    """Thinking switch sent to the official DeepSeek API ("disabled" unless configured otherwise).

    Order: environment DEEPSEEK_THINKING, then config["thinking"], then "disabled".
    Returns "" for other endpoints, which are left untouched."""
    if "deepseek.com" not in str(base_url or ""):
        return ""
    value = os.environ.get("DEEPSEEK_THINKING") or (config or {}).get("thinking") or "disabled"
    value = str(value).strip().lower()
    return "enabled" if value in ("enabled", "on", "true", "1") else "disabled"


@utils.register_model
class OpenAILLMModel(LLMModel):
    def setup(self, keys, config):
        from openai import OpenAI
        if config is None:
            config = {}
        # 修复重复路径问题
        url = self._base_url.rstrip("/")
        if url.endswith("/chat/completions"):
            url = url.replace("/chat/completions", "")
        self._embedding_model = config.get("embedding_model", "text-embedding-3-small")
        # 按端点域名匹配对应的 API key（支持 OpenRouter / DeepSeek官方 / OpenAI官方 / 兼容端点）
        if "openrouter" in url:
            api_key = keys.get("OPENROUTER_API_KEY")
        elif "deepseek" in url:
            api_key = keys.get("DEEPSEEK_API_KEY")
        elif "openai.com" in url:
            api_key = keys.get("OPENAI_API_KEY")
        elif "generativelanguage.googleapis.com" in url:
            api_key = keys.get("GEMINI_API_KEY")
        elif "api.anthropic.com" in url:
            api_key = keys.get("ANTHROPIC_API_KEY")
        else:
            api_key = (keys.get("OPENAI_API_KEY") or keys.get("OPENROUTER_API_KEY")
                       or keys.get("DEEPSEEK_API_KEY"))
        if not api_key:
            raise ValueError("当前端点 {} 缺少对应的 API key（请在实验管理页的 API 设置中填写）".format(url))
        default_headers = {}
        if "openrouter.ai" in url:
            site_url = keys.get("OPENROUTER_SITE_URL") or os.getenv("OPENROUTER_SITE_URL")
            app_name = keys.get("OPENROUTER_APP_NAME") or os.getenv("OPENROUTER_APP_NAME")
            if site_url:
                default_headers["HTTP-Referer"] = site_url
            if app_name:
                default_headers["X-OpenRouter-Title"] = app_name
        if default_headers:
            return OpenAI(api_key=api_key, base_url=url, default_headers=default_headers, timeout=self._timeout)
        return OpenAI(api_key=api_key, base_url=url, timeout=self._timeout)

    def _embedding(self, text):
        response = self._handle.embeddings.create(input=text, model=self._embedding_model)
        return response.data[0].embedding

    def _completion(self, prompt, temperature=0.5):
        messages = [{"role": "user", "content": prompt}]
        extra = {}
        base_url = str(getattr(self._handle, "base_url", "") or "")
        if "openrouter" in base_url and os.environ.get("OPENROUTER_PROVIDER_SORT", "latency") != "off":
            # OpenRouter供应商按延迟优选，通常可降低每次调用0.5-1.5秒
            extra["extra_body"] = {"provider": {"sort": os.environ.get("OPENROUTER_PROVIDER_SORT", "latency")}}
        thinking = deepseek_thinking(base_url, self._config)
        if thinking:
            # DeepSeek 官方 V4/V4.1 默认开启思考（high），每次调用多出数百到数千个隐藏 token，
            # 慢很多且按输出计费；与试跑所用的 deepseek-chat（非思考）也不一致。默认关闭。
            extra.setdefault("extra_body", {})["thinking"] = {"type": thinking}
        if "api.anthropic.com" not in base_url:
            # Claude 4.7+ on the OpenAI-compatible endpoint rejects temperature below 1 (400 error),
            # so Claude runs at its default temperature; every other endpoint gets the configured one.
            extra["temperature"] = temperature
        response = self._handle.chat.completions.create(
            model=self._model,
            messages=messages,
            timeout=self._timeout,
            **extra,
        )
        usage = getattr(response, "usage", None)
        if usage is not None:
            if self._call_usage is None:
                self._call_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
            for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
                self._call_usage[key] += int(getattr(usage, key, 0) or 0)
            # V25.1: prompt tokens served from the provider's cache (DeepSeek reports
            # prompt_cache_hit_tokens; OpenAI/OpenRouter report prompt_tokens_details.cached_tokens).
            cached = getattr(usage, "prompt_cache_hit_tokens", None)
            if cached is None:
                details = getattr(usage, "prompt_tokens_details", None)
                cached = (details.get("cached_tokens") if isinstance(details, dict)
                          else getattr(details, "cached_tokens", None)) if details is not None else None
            if cached is not None:
                self._call_usage["cached_tokens"] = self._call_usage.get("cached_tokens", 0) + int(cached or 0)
        try:
            if getattr(response, "choices", None) and len(response.choices) > 0:
                return response.choices[0].message.content or ""
        except Exception:
            pass
        if isinstance(response, dict):
            if "choices" in response and response["choices"]:
                ch0 = response["choices"][0]
                msg = ch0.get("message", {})
                content = msg.get("content")
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    return "\n".join([p.get("text", "") for p in content if isinstance(p, dict)]).strip()
            out = response.get("output")
            if isinstance(out, list) and out:
                cont = out[0].get("content", [])
                texts = [c.get("text", "") for c in cont if isinstance(c, dict)]
                if texts:
                    return "\n".join(texts).strip()
            for k in ("message", "content", "text", "response"):
                v = response.get(k)
                if isinstance(v, str) and v.strip():
                    return v.strip()
                if isinstance(v, dict):
                    c = v.get("content") or v.get("text")
                    if isinstance(c, str):
                        return c.strip()
        return ""

    @classmethod
    def support_model(cls, model):
        return True

    @classmethod
    def creatable(cls, keys, config):
        return bool(keys.get("OPENAI_API_KEY") or keys.get("OPENROUTER_API_KEY")
                    or keys.get("DEEPSEEK_API_KEY") or keys.get("GEMINI_API_KEY") or keys.get("ANTHROPIC_API_KEY"))

    @classmethod
    def model_style(cls):
        return ModelStyle.OPEN_AI


@utils.register_model
class OllamaLLMModel(LLMModel):
    def setup(self, keys, config):
        return None

    def ollama_chat(self, messages, temperature, stream):
        headers = {"Content-Type": "application/json"}
        params = {"model": self._model, "messages": messages, "temperature": temperature, "stream": stream}
        response = requests.post(url=f"{self._base_url}/chat/completions", headers=headers, json=params, stream=stream)
        return response.json()

    def ollama_embeddings(self, text):
        headers = {"Content-Type": "application/json"}
        params = {"model": self._embedding_model, "input": text}
        response = requests.post(url=f"{self._base_url}/embeddings", headers=headers, json=params)
        return response.json()

    def _embedding(self, text):
        response = self.ollama_embeddings(text)
        return response["data"][0]["embedding"]

    def _completion(self, prompt, temperature=0.5):
        if "qwen3" in self._model and "\n/nothink" not in prompt:
            prompt += "\n/nothink"
        messages = [{"role": "user", "content": prompt}]
        response = self.ollama_chat(messages=messages, temperature=temperature, stream=False)
        if isinstance(response, dict):
            if "response" in response and isinstance(response["response"], str):
                return response["response"]
            if "output" in response:
                out = response["output"]
                if isinstance(out, list) and out:
                    cont = out[0].get("content", [])
                    texts = [c.get("text", "") for c in cont if isinstance(c, dict)]
                    if texts:
                        return "\n".join(texts).strip()
            if "choices" in response and response["choices"]:
                try:
                    ret = response["choices"][0]["message"]["content"]
                    return re.sub(r"<think>.*</think>", "", ret, flags=re.DOTALL)
                except Exception:
                    pass
        return ""

    @classmethod
    def support_model(cls, model):
        name = (model or "").lower()
        return (":" in name) or any(kw in name for kw in ["llama", "qwen", "phi", "mistral", "gemma", "yi", "bge"])

    @classmethod
    def creatable(cls, keys, config):
        return True

    @classmethod
    def model_style(cls):
        return ModelStyle.OLLAMA


@utils.register_model
class ZhipuAILLMModel(LLMModel):
    def setup(self, keys, config):
        from zhipuai import ZhipuAI
        return ZhipuAI(api_key=keys["ZHIPUAI_API_KEY"])

    def _embedding(self, text):
        response = self._handle.embeddings.create(model="embedding-2", input=text)
        return response.data[0].embedding

    def _completion(self, prompt, temperature=0.5):
        messages = [{"role": "user", "content": prompt}]
        response = self._handle.chat.completions.create(model=self._model, messages=messages, temperature=temperature)
        if len(response.choices) > 0:
            return response.choices[0].message.content
        return ""

    @classmethod
    def support_model(cls, model):
        return model in ("glm-4")

    @classmethod
    def creatable(cls, keys, config):
        return "ZHIPUAI_API_KEY" in keys

    @classmethod
    def model_style(cls):
        return ModelStyle.ZHIPU_AI


@utils.register_model
class QIANFANLLMModel(LLMModel):
    def setup(self, keys, config):
        handle = {k: keys[k] for k in ["QIANFAN_AK", "QIANFAN_SK"]}
        for k, v in handle.items():
            os.environ[k] = v
        return handle

    def _embedding(self, text):
        url = "https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={0}&client_secret={1}".format(
            self._handle["QIANFAN_AK"], self._handle["QIANFAN_SK"])
        payload = json.dumps("")
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        response = requests.request("POST", url, headers=headers, data=payload)
        url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/embeddings/embedding-v1?access_token=" + \
              str(response.json().get("access_token"))
        input = []
        input.append(text)
        payload = json.dumps({"input": input}, ensure_ascii=False)
        headers = {"Content-Type": "application/json"}
        response = requests.request("POST", url, headers=headers, data=payload)
        response = json.loads(response.text)
        return response["data"][0]["embedding"]

    def _completion(self, prompt, temperature=0.5):
        import qianfan
        messages = [{"role": "user", "content": prompt}]
        resp = qianfan.ChatCompletion().do(messages=messages, model=self._model, temperature=temperature)
        return resp["result"]

    @classmethod
    def support_model(cls, model):
        return model in ("ERNIE-Bot", "Yi-34B-Chat")

    @classmethod
    def creatable(cls, keys, config):
        return "QIANFAN_AK" in keys and "QIANFAN_SK" in keys

    @classmethod
    def model_style(cls):
        return ModelStyle.QIANFAN


@utils.register_model
class SparkAILLMModel(LLMModel):
    def setup(self, keys, config):
        spark_url_tpl = "wss://spark-api.xf-yun.com/{}/chat"
        handle = {"params": {}, "keys": {}}
        if self._model == "spark_v1.5":
            handle["params"] = {"domain": "general", "spark_url": spark_url_tpl.format("v1.1")}
        elif self._model == "spark_v2.0":
            handle["params"] = {"domain": "generalv2", "spark_url": spark_url_tpl.format("v2.1")}
        elif self._model == "spark_v3.0":
            handle["params"] = {"domain": "generalv3", "spark_url": spark_url_tpl.format("v3.1")}
        elif self._model == "spark_v3.5":
            handle["params"] = {"domain": "generalv3.5", "spark_url": spark_url_tpl.format("v3.5")}
        needed_keys = ["SPARK_APPID", "SPARK_API_SECRET", "SPARK_API_KEY"]
        handle["keys"] = {k: keys[k] for k in needed_keys}
        return handle

    def _completion(self, prompt, temperature=0.5, streaming=False):
        from sparkai.llm.llm import ChatSparkLLM
        from sparkai.core.messages import ChatMessage
        spark_llm = ChatSparkLLM(
            spark_api_url=self._handle["params"]["spark_url"],
            spark_app_id=self._handle["keys"]["SPARK_APPID"],
            spark_api_key=self._handle["keys"]["SPARK_API_KEY"],
            spark_api_secret=self._handle["keys"]["SPARK_API_SECRET"],
            spark_llm_domain=self._handle["params"]["domain"],
            temperature=temperature,
            streaming=streaming)
        messages = [ChatMessage(role="user", content=prompt)]
        resp = spark_llm.generate([messages])
        return resp

    @classmethod
    def support_model(cls, model):
        return model in ("spark_v1.5", "spark_v2.1", "spark_v3.1", "spark_v3.5")

    @classmethod
    def creatable(cls, keys, config):
        needed_keys = ["SPARK_APPID", "SPARK_API_SECRET", "SPARK_API_KEY"]
        return all(k in keys for k in needed_keys)

    @classmethod
    def model_style(cls):
        return ModelStyle.SPARK_AI


def create_llm_model(base_url, model, embedding_model, keys, config=None):
    for _, model_cls in utils.get_registered_model(ModelType.LLM).items():
        if model_cls.support_model(model) and model_cls.creatable(keys, config):
            return model_cls(base_url, model, embedding_model, keys, config=config)
    return None


def parse_llm_output(response, patterns, mode="match_last", ignore_empty=False):
    if isinstance(patterns, str):
        patterns = [patterns]
    rets = []
    for line in response.split("\n"):
        line = line.replace("**", "").strip()
        for pattern in patterns:
            if pattern:
                matchs = re.findall(pattern, line)
            else:
                matchs = [line]
            if len(matchs) >= 1:
                rets.append(matchs[0])
                break
    if not ignore_empty:
        assert rets, "Failed to match llm output"
    if mode == "match_first":
        return rets[0]
    if mode == "match_last":
        return rets[-1]
    if mode == "match_all":
        return rets
    return None
