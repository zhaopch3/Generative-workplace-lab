import requests
import json

print("=== 测试Ollama连接 ===")

# 测试1：直接API
try:
    response = requests.post(
        "http://localhost:11434/api/embeddings",
        json={"model": "mxbai-embed-large:latest", "prompt": "test"}
    )
    print(f"直接API状态码: {response.status_code}")
    if response.status_code == 200:
        print("✓ 直接API测试成功")
    else:
        print(f"✗ 错误: {response.text}")
except Exception as e:
    print(f"✗ 连接失败: {e}")

print("\n" + "="*50 + "\n")

# 测试2：OpenAI兼容API
try:
    response = requests.post(
        "http://localhost:11434/v1/embeddings",
        json={"model": "mxbai-embed-large:latest", "input": "test"},
        headers={"Authorization": "Bearer ollama"}
    )
    print(f"OpenAI兼容API状态码: {response.status_code}")
    if response.status_code == 200:
        print("✓ OpenAI兼容API测试成功")
    else:
        print(f"✗ 错误: {response.text}")
except Exception as e:
    print(f"✗ 连接失败: {e}")

print("\n" + "="*50 + "\n")

# 测试3：检查LlamaIndex配置
try:
    from llama_index.embeddings.ollama import OllamaEmbedding
    
    embedding = OllamaEmbedding(
        model_name="mxbai-embed-large:latest",
        base_url="http://localhost:11434"
    )
    
    result = embedding.get_text_embedding("test")
    print(f"✓ LlamaIndex嵌入成功，向量长度: {len(result)}")
except Exception as e:
    print(f"✗ LlamaIndex失败: {e}")