[English](./README.md) | 简体中文

# 职场模拟实验室：用生成式智能体模拟职场中的辱虐管理

这是一个用于组织行为研究的多智能体模拟平台。四个由大语言模型驱动的智能体组成一个职能团队（一名组长、三名组员），在一个像素风格的办公室里度过一周的工作日：安排日程、走动、交谈、形成记忆、产生情绪，并在预定时间填写问卷。研究者只设定初始条件（例如组长的领导风格），之后世界自由发展，不预先安排事件。

平台的主要用途是辱虐管理（abusive supervision）研究：同一组人物分别在“高辱虐”和“低辱虐”两种条件下运行，按配对种子比较结果，并用已发表研究的原始量表测量智能体的态度和行为。

本项目基于 [GenerativeAgentsCN](https://github.com/x-glacier/GenerativeAgentsCN)（[wounderland](https://github.com/Archermmt/wounderland) 的中文重构版，源自斯坦福 [Generative Agents](https://github.com/joonspk-research/generative_agents)）开发。上游项目的原始说明见 [docs/upstream_README.md](./docs/upstream_README.md)。

> 当前界面和智能体提示词均为中文。

## 主要功能

- **人设操纵实验**：组长的“领导风格”有高辱虐和低辱虐两个版本，依据 Tepper (2000) 的定义编写；其余人设、世界规则和初始条件在两组之间完全相同。
- **配对批量运行**：一次运行多组、多个重复的世界。两组中第 i 个世界使用同一个随机种子，因此抽到同一组人格，构成配对样本。多个世界并行运行，互不影响。
- **人格抽样**：每个智能体从 IPIP-50 真实受访者数据中抽取一组大五人格分数，按 BFI-10 的条目写成简短描述（可关闭）。
- **复现问卷**：内置从已发表的辱虐管理研究中整理的问卷，按原研究的作答人、时间框架和测量波次在 5 个工作日内施测，题目照抄原文。问卷可在“创建实验”页编辑或新增。
- **世界规则**：所有智能体共享的职场制度（作息、例会、分工、请假、意见反映等），为量表测量的行为提供现实中存在的渠道。
- **实时观察与回放**：在地图上实时观看智能体的行动与对话；运行结束后可逐步回放，并查看每一步的事件记录。
- **数据导出**：问卷作答、心理状态、行为与对话记录、模型调用记录均可按批次下载，同配置的世界自动归为一个可比组。

## 运行环境

- Windows 10/11（提供一键启动脚本）；macOS 和 Linux 可用命令行启动。
- Python 3.11（3.10–3.12 均可）。
- 内存 16 GB 及以上：每个运行中的世界约占 0.5–1 GB。
- 一个对话模型的 API key（如 OpenRouter 或 DeepSeek）。
- 记忆嵌入模型：可用云端服务，也可以用本地 Ollama（有独立显卡更快，不是必需）。

## 安装

1. 下载本仓库（GitHub 页面上的 Code → Download ZIP，或 `git clone`），解压到一个**路径里没有特殊符号**的文件夹。
2. 安装运行环境（只需一次，约 3–10 分钟，需要联网）：
   - Windows：双击 `Install.bat`。电脑上没有 Python 时，它会用 Windows 自带的 winget 安装 Python 3.11（或打开下载页面）；然后在项目文件夹里建立独立的 `.venv`，安装依赖，检查能否正常导入，并在装有 Ollama 时询问是否下载本地嵌入模型。在中国大陆连接官方软件源较慢时，会建议改用清华镜像。直接双击 `Start.bat` 也可以：没有 `.venv` 时会先自动运行安装程序。
   - macOS / Linux：在项目文件夹里运行 `bash install.sh`。

   所有依赖只装在项目文件夹的 `.venv` 中（约 600 MB），不影响电脑上的其他 Python；删除项目文件夹即可完全卸载。安装程序不会询问或保存 API key。环境出问题时，可以运行 `Install.bat --recreate`（macOS / Linux：`bash install.sh --recreate`）重建。

   手动安装也可以：`python -m venv .venv`，然后 `.venv\Scripts\pip install -r requirements.txt`（macOS / Linux：`.venv/bin/pip install -r requirements.txt`）。本地 HuggingFace 嵌入和百度千帆、智谱、讯飞星火通道所需的依赖在 `requirements-optional.txt` 中，用到时再装。

3. 启动：
   - Windows：双击 `Start.bat`。
   - macOS / Linux：`.venv/bin/python launch.py`。

   浏览器会自动打开 `http://127.0.0.1:5071/research`。程序在后台运行，关掉命令行窗口不会停止它，模拟会继续跑。要停止程序或升级到新版本时，先结束它：Windows 在 PowerShell 中运行 `Get-Process python | Stop-Process -Force`，macOS / Linux 运行 `pkill -f server.py`（正在运行的模拟会一起停止，已存档的世界之后可以接着跑）。升级后如果后台还在运行旧版本，启动器会提示。

## 第一次使用：填写 API 设置

点击顶部的“实验与存档”，展开“⚙ API 设置”。设置分为两部分，填好后点一次“保存两项设置”。

**① 对话模型**（智能体思考、计划和说话所用的模型）

| 服务商 | 说明 |
|---|---|
| OpenRouter（默认） | 一个 key 可用数百种模型，也可以同时承担记忆嵌入。 |
| DeepSeek 官方 | 推荐模型 `deepseek-flash`。程序默认关闭 DeepSeek 的思考模式（开启时每次调用会多生成数百到数千个隐藏 token，慢数倍且按输出计费）。 |
| OpenAI 官方 | 记忆嵌入自动使用 OpenAI 的 `text-embedding-3-small`。 |
| Google Gemini 官方 | 走 Gemini 的 OpenAI 兼容端点，key 在 Google AI Studio 申请。没有记忆嵌入通道，请在 ② 中另选（推荐本地 Ollama）。 |
| Anthropic Claude 官方 | 走 Claude 的 OpenAI 兼容端点，key 在 Claude Console 申请。Claude 新模型不接受自定义温度，程序以默认温度调用。没有记忆嵌入通道，请在 ② 中另选。 |
| 自定义兼容端点 | 任何 OpenAI 兼容的服务，例如本地 vLLM。 |

**② 记忆嵌入模型**（把记忆转换成向量，用于“想起相关往事”）

| 通道 | 说明 |
|---|---|
| 自动 | 跟随对话服务商；对话选 DeepSeek 时使用 OpenRouter；选 Gemini 或 Claude 时沿用已保存的嵌入设置。 |
| OpenRouter / OpenAI 云端 | 默认模型 `text-embedding-3-small`。 |
| 阿里云百炼（国内直连） | 默认模型 `text-embedding-v4`，在中国大陆无需代理。 |
| 本地 Ollama | 默认模型 `bge-m3:latest`，免费、不联网。需先安装 [Ollama](https://ollama.com/) 并执行 `ollama pull bge-m3`。 |
| 本地 HuggingFace | 需要额外安装约 2 GB 的依赖。 |
| 自定义兼容端点 | 任何 OpenAI 兼容的 `/embeddings` 服务。 |

两部分使用同一个服务商时，key 只需填一次。保存后点“测试连接”，看到“聊天正常”和“Embedding 正常”再开始实验。

API key 只保存在本机项目根目录的 `.env` 文件中，不会写进实验存档。请不要把 `.env` 上传到任何地方。

## 运行实验

### 单次运行（调试、观察）

1. 点击“创建实验”，填写实验名称，选择或载入一个世界模板。
2. 运行方式选“单次运行”，点“启动实验”。
3. 在“实验与存档”里点“查看”，可以在地图上实时观看。

### 批量运行（正式实验）

1. 点击“创建实验”，填写实验名称。
2. 运行方式选“批量运行”。
3. 在“实验分组”里按住 Ctrl，同时选中“人设操纵-高辱虐组”和“人设操纵-低辱虐组”。
4. 填写“每组重复数”（每组跑几个世界）和“同时运行数”（16 GB 内存建议不超过 6）。
5. 确认下方显示的世界总数无误后，点“启动实验”。
6. 在“实验与存档”页的“批量任务”面板查看进度。某个世界失败时，点“重跑失败/已停止项”，会从中断处继续。

批量运行时，每个世界的时长、步数和人设都取自模板文件；页面上方表单里的设置只用于单次运行。对话模型和嵌入模型使用 API 设置中的全局设置。

### 内置模板

| 模板 | 内容 |
|---|---|
| 人设操纵-高辱虐组 / 低辱虐组 | 市场运营部的一个小组（组长克劳斯，组员阿伊莎、玛丽亚、沃尔夫冈）。周一 08:00 开始，运行 5 个工作日（120 步，每步 60 分钟），不安排任何事件。两组只在组长的领导风格上不同：把九类具体言行写成克劳斯带组多年形成的固定习惯，只写别人看得到的言行，不用评价性的词（V26 定稿，见 `V26更新说明.md`）。 |
| 事件操纵-高辱虐组 / 低辱虐组 | 同一个团队，通过 8 个预定事件施加操纵；2 月 13 日 08:00 开始，运行 7 天（168 步）。 |
| Persona-manipulation-high-abuse / low-abuse、Event-manipulation-high-abuse / low-abuse | 上面四个模板的英文版（V27）：智能体用英文思考、说话和作答（Klaus、Ayesha、Maria、Wolfgang），其余设置逐项相同。 |

### 界面语言与模拟语言（V27）

- **界面语言**：界面默认英文（V27.2 起，因为评审多为英文读者）。页面右上角的“中 / EN”切换整个界面的文字，浏览器会记住选择，只影响显示，不影响任何数据。英文界面下，创建实验页只显示英文智能体和英文模板，智能体列表下方的链接可以显示中文的。
- **模拟语言**：由世界模板决定。上表的英文模板建出的是英文世界：提示词（`data/prompts_en/`）、人设、世界规则、领导风格、地点名称、问卷都是英文，作答也按英文格式解析；中文模板与以前完全相同。英文世界和中文世界的行为不同，**数据不能合并分析**；两者的可比组指纹不同，导出的 `experiment_manifest.csv` 有 `language` 一列。
- 英文问卷的题目全部来自可核对的来源（复现问卷原文、编码表或公开量表网页），每份问卷的出处写在 `data/i18n/surveys_en.json`。英文人设和领导风格是中文版的翻译，见 `data/i18n/content_en.json`；改了中文模板后运行 `python tools/build_en_assets.py` 重新生成英文版。

## 结果与数据

- 运行完成后，在“实验与存档”页的“批次历史”中点“整批下载”，得到一个压缩包；每个可比组在单独的子目录中。
- 原始文件位于 `generative_agents/results/`：

| 目录 | 内容 |
|---|---|
| `checkpoints/<世界名>/` | 每一步的完整存档（可从任意一步恢复或回放）和逐句对话记录 |
| `surveys/<世界名>/` | 每份问卷的作答（CSV 与 JSONL） |
| `psych/<世界名>/` | 智能体心理状态（情绪、压力、精力、社交意愿）的变化 |
| `monitor/<世界名>/` | 行为时间线（`timeline.jsonl`）和每次模型调用的记录（`model_calls.jsonl`，含耗时与 token 用量） |

## 时间与费用参考

以下为粗略估计，实际取决于模型、网络和并行数。

- 一个世界（5 个工作日）约调用对话模型 3,000–4,000 次，输入约 700 万 token。
- 使用 `deepseek-flash`（关闭思考）加本地嵌入时，一个世界约 1–1.5 小时；10 个世界同时跑 6 个，约 2.5–3 小时。
- 按 DeepSeek 非高峰价格，一个世界约 1 美元。DeepSeek 的高峰时段为北京时间工作日 9:00–12:00 和 14:00–18:00，其余时间半价。

### 便宜模式（V25.1，试跑用）

“创建实验”页点开“省钱选项（预算有限时开启）”，勾选“便宜模式”，可以减少模型调用：问卷提示词先放共同部分便于服务商缓存、同一时间的问卷合并作答、同一步看到的事件一次评定重要性、每步 60 分钟时不再细分每小时的计划等。离线对照中调用次数减少约 70%，输入量减少约 60%，时间预计缩短一半左右。便宜模式会略微改变作答和行为，世界自动单独分组，**只用于试跑、调提示词和比较模型，不用作正式数据**。不勾选时与主模式完全相同。详见 `V25.1更新说明.md`。

## 研究设计注意事项

- **同一项研究固定使用同一个对话模型和同一个嵌入模型。** 不同模型的行为和记忆检索结果不同，数据不能合并分析。服务商在同一模型名下也会更新版本，论文中应记录模型名称和运行日期，并让同一批次的各组在同一时期运行。
- 正式实验不要使用实时监控页的干预功能；被干预的世界会在记录中标记，不能作为自发行为的结果解释。
- 每条模型调用记录都保存了模型名和思考设置，可在事后核对。

## 版权与数据

- 复现问卷来自已发表的研究，其中部分量表受版权保护（例如 Maslach 职业倦怠量表）。在公开仓库中发布这些题目前，请确认已获得授权；否则应只公开构建脚本（`tools/build_v24_battery.py`），由使用者用自己的编码表在本地生成问卷文件 `data/scale_battery/battery_v1.json` 和模板中的问卷部分。
- `generative_agents/results/`（模拟数据）和 `.env`（API key）已在 `.gitignore` 中排除，不会被提交。

## 常见问题

| 现象 | 原因与处理 |
|---|---|
| 双击启动脚本提示“系统找不到指定的路径”或缺少依赖 | 环境没有装好。双击 `Install.bat`（macOS / Linux：`bash install.sh`）；仍有问题时加 `--recreate` 重建。 |
| 测试连接显示 Embedding 失败，提示 `SSLError` 或连接中断 | 与云端嵌入服务之间的网络不稳定（在中国大陆连接 OpenRouter 常见）。改用阿里云百炼或本地 Ollama。程序会自动重试约 1 分钟。 |
| 本地 Ollama 测试连接报 404 | 嵌入模型名不对，或没有下载模型。嵌入模型填 `bge-m3:latest`，并在命令行执行 `ollama pull bge-m3`。 |
| 运行很慢 | 查看 `monitor/<世界名>/model_calls.jsonl` 中的耗时。常见原因：模型开启了思考模式、嵌入服务经代理访问、同时运行的世界过多。 |
| 浏览器打不开页面 | 重新双击启动，看启动器给出的地址（5071 被占用时会改用 5072 等）；端口 5060 和 5061 会被浏览器拦截，程序默认从 5071 开始。 |
| 覆盖新版本后页面还是旧版本 | 后台还在运行旧程序。按上面的方法结束它，再重新启动；页面左上角显示版本号。 |

## 开发与测试

在 `generative_agents` 目录下运行全部测试：

```
python -m unittest discover -s tests -p "test_*.py"
```

项目结构：

```
launch.py                     启动器（寻找空闲端口并打开浏览器；日志在 logs/server.log）
generative_agents/
  server.py                   网页界面与实验管理
  start.py                    单个世界的模拟进程
  modules/                    智能体、记忆、模型调用、问卷、导出等
  data/prompts/               全部提示词模板
  data/world_presets/         世界模板（实验分组）
  data/scale_battery/         复现问卷
  frontend/                   页面、地图与人物素材
  tools/                      问卷装入、模板生成、地图构建等脚本
  tests/                      自动化测试
```

各版本的修改记录见 `changelog/` 文件夹；已知问题和研究构想见 `docs/待解决问题.md`。

## 致谢与许可

- 斯坦福大学 Generative Agents：Park, J. S., O’Brien, J. C., Cai, C. J., Morris, M. R., Liang, P., & Bernstein, M. S. (2023). *Generative Agents: Interactive Simulacra of Human Behavior*. UIST ’23.
- [wounderland](https://github.com/Archermmt/wounderland) 与 [GenerativeAgentsCN](https://github.com/x-glacier/GenerativeAgentsCN)。
- 人格抽样池：Open Psychometrics 公开的 IPIP 大五数据集（BIG5），处理方法见 `generative_agents/data/personality/SOURCE.md`。
- 辱虐管理的定义与测量：Tepper, B. J. (2000). Consequences of abusive supervision. *Academy of Management Journal, 43*(2), 178–190.
- 本项目沿用上游的 Apache License 2.0，见 [LICENSE](./LICENSE)。
