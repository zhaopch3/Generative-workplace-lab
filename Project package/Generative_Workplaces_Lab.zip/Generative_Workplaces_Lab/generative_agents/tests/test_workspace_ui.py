"""Workspace reorganization; retired tools must not remain callable."""
import copy
import unittest
from pathlib import Path
from unittest.mock import patch
from modules.research import data


class WorkspaceUITests(unittest.TestCase):
    def client_context(self):
        import server
        return server.create_app({}).test_client()

    def test_removed_tool_routes_and_files(self):
        root = Path(__file__).resolve().parents[1]
        for file in ('modules/research/analysis.py','modules/research/design.py','frontend/static/js/studio.js'):
            self.assertFalse((root/file).exists())
        with self.client_context() as client:
            for endpoint in ('/api/studio/analysis','/api/studio/analyses','/api/studio/analysis/old/download',
                             '/api/studio/designs','/api/studio/designs/preview','/api/studio/designs/old/run'):
                self.assertEqual(client.get(endpoint).status_code,404,endpoint)
                self.assertEqual(client.post(endpoint,json={}).status_code,404,endpoint)

    def test_home_has_tasks_and_archives_not_tools_or_marketing(self):
        with self.client_context() as client:
            text=client.get('/research').get_data(as_text=True)
        for expected in ('当前任务','最近批次','实验性功能','刷新状态'):
            self.assertIn(expected,text)
        for absent in ('让每一个世界','先确认数据','OB 分析','先讨论效应','01 · 回答','data-tab=', '运行分析','选择要读取的世界'):
            self.assertNotIn(absent,text)

    def test_experimental_tools_have_steps_and_explicit_start(self):
        with self.client_context() as client:
            text=client.get('/experimental').get_data(as_text=True)
        for expected in ('打开历史分支','打开运行诊断','打开问卷记录检查','请选择一个世界',
                         '预览分支与运行数量（不启动）','1. 选择来源存档','2. 设置分支和续跑时长','3. 核对后再启动'):
            self.assertIn(expected,text)
        self.assertNotIn('操纵位置',text)
        self.assertNotIn('id="analysis-',text)

    def test_overview_no_full_checkpoint_catalog_and_no_input_mutation(self):
        import server
        batch={'batch_id':'B1','label':'Batch','created_at':'2026-09-01','run_count':1,
               'statuses':{'已完成':1},'comparison_groups':[{'runs':[{'name':'W1'}]}]}
        experiments=[{'name':'W1','step':24,'files':['secret']},{'name':'solo','step':2}]
        saved=copy.deepcopy(batch)
        with patch.object(server,'scan_batches',return_value=[batch]),patch.object(server,'scan_experiments',return_value=experiments),patch.object(data,'latest_config',side_effect=AssertionError('must not read checkpoint contents')):
            with self.client_context() as client: response=client.get('/api/studio/overview')
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json['world_count'],2)
        self.assertEqual(response.json['single_worlds'][0]['name'],'solo')
        self.assertNotIn('secret',response.get_data(as_text=True))
        self.assertEqual(batch,saved)

    def test_retired_batch_design_input_rejected(self):
        import server
        manager=server.BatchManager()
        with patch.object(manager,'_start_thread') as start:
            with self.assertRaisesRegex(ValueError,'已移除'):
                manager.start({'_planned_worlds':[]})
            start.assert_not_called()

    def test_quality_remains_readonly_and_labels_scope(self):
        record={'provenance':{'run_id':'W1','file':'source.jsonl','line':1},'survey_id':'s',
                'schema':{'questions':[{'id':'q','type':'likert','min':1,'max':7}]},
                'row':{'agent':'a','survey_date':'20260101','survey_time':'22:00','q':99}}
        saved=copy.deepcopy(record)
        with patch.object(data,'records',return_value=iter([record,copy.deepcopy(record)])):
            result=data.quality_report([{'name':'W1'}])
        self.assertEqual(result['counts']['partial'],2)
        self.assertEqual(result['counts']['duplicates'],1)
        self.assertEqual(record,saved)
        self.assertIn('不包含独立补测任务',result['notes'][0])

    def test_branch_preview_does_not_start_worlds(self):
        from modules.research import branches
        proposal={'run_id':'W1','checkpoint':'simulate-x.json','source_time':'20260101-22:00',
                  'source_step':1,'checkpoint_sha256':'abc','reconstruction':'verified','world_count':2,
                  'variants':[],'steps':4,'replicates':1,'notes':[]}
        with patch.object(branches,'preview',return_value=proposal),patch.object(branches,'create') as start:
            with self.client_context() as client:
                response=client.post('/api/studio/branches/preview',json={})
                self.assertEqual(response.status_code,200)
                start.assert_not_called()
                response=client.post('/api/studio/branches',json={'confirm':3})
                self.assertEqual(response.status_code,400)
                start.assert_not_called()


if __name__=='__main__': unittest.main()
