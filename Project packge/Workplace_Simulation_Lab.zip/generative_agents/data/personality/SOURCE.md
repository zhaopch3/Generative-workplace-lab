# 大五人格抽样池来源

`ipip_big5_pool.csv` 由开放心理测量网站（Open Psychometrics）公开的 BIG5 数据集计算得到：
50 道 IPIP 大五题目，原始样本 19,719 份（2012 年前后在线收集，答题者同意数据用于研究）。

- 原始数据：http://openpsychometrics.org/_rawdata/ （BIG5.zip）；本项目使用的副本来自 https://github.com/haghish/openpsychometrics
- 纳入：50 题全部作答（无 0 = 缺答）且年龄 22–55 岁，共 9,830 份
- 计分：每个维度 10 题取平均（1–5 分）；反向题为 E2、E4、E6、E8、E10，N2、N4，A1、A3、A5、A7，C2、C4、C6、C8，O2、O4、O6
- 百分位：在这 9,830 份内部排序得到（0–100）
- 列：`source_row`（原始文件中的行号，从 0 开始）、`age`、五个维度分数及对应 `_pct` 百分位
- 原始答卷不随项目分发；样本以美国答题者为主（约四成），中国答题者很少，因此使用全样本

论文与 README 中请注明数据来源。
