"""Historical branch creation with explicit reconstruction and provenance."""
import copy
import datetime as dt
import os
import secrets
import shutil
from pathlib import Path
from .common import atomic_json, digest, fingerprint, read_json, safe_id
from .snapshots import isolate_state, pack_path

ROOT = Path("results")


def preview(spec):
    name = safe_id(spec.get("run_id"))
    filename = safe_id(spec.get("checkpoint"))
    if not filename.startswith("simulate-") or not filename.endswith(".json"):
        raise ValueError("请选择正式存档")
    source = ROOT / "checkpoints" / name / filename
    config = read_json(source)
    if not isinstance(config, dict):
        raise ValueError("存档不存在或已损坏")
    pack = pack_path(source, config)
    variants = spec.get("variants") or []
    if not 2 <= len(variants) <= 8:
        raise ValueError("请设置2至8个分支（包含对照分支）")
    labels = [str(v.get("label", "")).strip() for v in variants]
    if any(not label for label in labels) or len(labels) != len(set(labels)):
        raise ValueError("分支名称需要唯一且非空")
    for variant in variants:
        if set(variant.get("targets") or []) - set(config.get("agents", {})):
            raise ValueError("干预目标不在该世界中")
    steps = int(spec.get("steps", 24))
    repeats = int(spec.get("replicates", 1))
    if not 1 <= steps <= 10000 or not 1 <= repeats <= 20:
        raise ValueError("续跑步数1至10000，重复数1至20")
    return {"run_id": name, "checkpoint": filename, "source_time": config["time"],
            "source_step": config["step"], "checkpoint_sha256": digest(source),
            "reconstruction": "verified" if pack else "legacy_partial",
            "world_count": len(variants)*repeats, "variants": variants,
            "steps": steps, "replicates": repeats,
            "notes": ["分支从存档后的下一个模拟步开始；组内人物顺序行动。",
                      "共享历史的分支不是独立起点。正式推断需多个来源世界。",
                      "本地随机状态可以恢复；模型API输出仍有随机性。"] +
                     ([] if pack else ["旧存档缺少完整状态包，历史对话与记忆访问状态不能完整还原；仅适合探索性分支。"])}


def create(spec, batch_manager, hooks):
    proposal = preview(spec)
    if batch_manager.active():
        raise ValueError("当前有批量任务运行，请等待结束后创建分支")
    if hooks["probe_runtime"](proposal["run_id"]):
        raise ValueError("来源世界正在运行，请先停止")
    if proposal["reconstruction"] != "verified" and not spec.get("accept_legacy"):
        raise ValueError("此存档只能做探索性重建，请勾选已知悉旧存档局限")
    name = proposal["run_id"]
    source = ROOT / "checkpoints" / name / proposal["checkpoint"]
    original = read_json(source)
    batch_id = "F" + dt.datetime.now().strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(2)
    batch_root = ROOT / "batch" / batch_id
    batch_root.mkdir(parents=True, exist_ok=False)
    runs = []
    stride = int(original.get("stride", 10))
    start = dt.datetime.strptime(proposal["source_time"], "%Y%m%d-%H:%M") + dt.timedelta(minutes=stride)
    ports = iter(hooks["available_ports"](proposal["world_count"]))
    for vi, variant in enumerate(proposal["variants"], 1):
        for repeat in range(1, proposal["replicates"]+1):
            run_id = "%s-G%02d-%02d" % (batch_id, vi, repeat)
            folder = ROOT / "checkpoints" / run_id
            work = batch_root / "_prepare" / run_id
            isolate_state(source, original, work)
            folder.mkdir(parents=True, exist_ok=False)
            shutil.move(str(work / "storage"), str(folder / "storage"))
            conversation = read_json(work / "conversation.json", {})
            atomic_json(folder / "conversation.json", conversation)
            cfg = copy.deepcopy(original)
            # New lineage stores the exact source hash even for exploratory legacy branches.
            cfg["branch_parent"] = {"run_id": name, "checkpoint": proposal["checkpoint"],
                                    "sha256": proposal["checkpoint_sha256"],
                                    "reconstruction": proposal["reconstruction"],
                                    "cluster_id": (original.get("branch_parent") or {}).get("cluster_id", name),
                                    "replicate": repeat, "branch": variant["label"]}
            source_pack = pack_path(source, original)
            if source_pack:
                packed_copy = folder / original["_snapshot"]["pack"]
                packed_copy.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_pack, packed_copy)
            else:
                cfg.pop("_snapshot", None)
            cfg["measurement_policy"] = "passive"
            cfg.setdefault("agent_base", {})["measurement_policy"] = "passive"
            for agent in cfg.get("agents", {}).values():
                agent["measurement_policy"] = "passive"
            if repeat > 1:
                cfg.pop("_random_state", None)
                cfg["seed"] = int(spec.get("seed", 20260911)) + repeat
            cfg["_scenario_events_done"] = list(cfg.get("_scenario_events_done") or [])
            origin = cfg.get("simulation_start") or cfg.get("setup_payload", {}).get("start_time") or proposal["source_time"]
            simulation_day = (start.date() - dt.datetime.strptime(origin, "%Y%m%d-%H:%M").date()).days + 1
            if str(variant.get("text", "")).strip():
                cfg.setdefault("scheduled_events", []).append({
                    "id": "branch_intervention_" + str(vi), "day": simulation_day,
                    "time": start.strftime("%H:%M"), "text": variant["text"],
                    "targets": variant.get("targets") or [], "poignancy": 8})
            group_id = fingerprint({"parent": name, "variant": variant, "steps": proposal["steps"]})[:12]
            cfg["batch"] = {"batch_id": batch_id, "prefix": batch_id, "label": spec.get("title") or "历史分支",
                            "group": variant["label"], "condition": "B%02d" % vi,
                            "replicate": repeat, "config_id": group_id}
            cfg.setdefault("experiment", {})["condition"] = "B%02d" % vi
            # Include the pre-branch checkpoint as the starting state.
            atomic_json(folder / proposal["checkpoint"], cfg)
            runs.append({"name": run_id, "group": variant["label"], "condition": "B%02d" % vi,
                         "replicate": repeat, "port": next(ports), "status": "排队中",
                         "step": proposal["source_step"], "total": proposal["source_step"] + proposal["steps"],
                         "stride": stride, "offline": bool(spec.get("offline", False)), "resume": True,
                         "config_id": group_id, "proc": None, "cfg_path": "",
                         "config_summary": hooks["comparison_summary"](cfg.get("setup_payload", {}))})
    if digest(source) != proposal["checkpoint_sha256"]:
        raise ValueError("来源存档在准备期间改变，分支未启动")
    atomic_json(batch_root / "branch_plan.json", {**proposal, "spec": spec, "batch_id": batch_id})
    with batch_manager.lock:
        if batch_manager._active_unlocked():
            raise ValueError("批量任务状态发生变化，分支已保存但尚未启动")
        batch_manager.batch = {"batch_id": batch_id, "prefix": batch_id,
                              "label": spec.get("title") or "历史分支实验",
                              "created_at": dt.datetime.now().isoformat(timespec="seconds"),
                              "parallel": max(1, min(10, int(spec.get("parallel", 4)))),
                              "extra_keys": [], "runs": runs, "aggregated": False, "agg_dir": ""}
        batch_manager.generation += 1
        batch_manager._save_manifest_unlocked()
    batch_manager._start_thread()
    return {"batch_id": batch_id, "world_count": len(runs), "reconstruction": proposal["reconstruction"]}
