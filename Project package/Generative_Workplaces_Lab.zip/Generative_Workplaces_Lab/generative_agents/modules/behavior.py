# -*- coding: utf-8 -*-
"""行为指标模块（零LLM成本）

从已有的运行日志（results/monitor/<实验名>/steps.jsonl 与 timeline.jsonl）
离线计算组织行为学常用的行为指标，输出两张表：

1. behavior_daily：每行 = 一名智能体 × 一个模拟日
   - 各功能区停留分钟数（area_min__<区域名>，动态列）
   - work_min / rest_min：工作类 vs 休息类行为分钟数（按行为文本关键词归类）
   - first_work_time / sleep_onset：当日首次工作行为时间、入睡时间（HH:MM）
   - helping_acts：行为/对话文本中帮助类关键词出现次数（OCB的粗粒度行为计数）

2. dyad_daily：每行 = 一个有序智能体对 × 一个模拟日
   - copresence_min：同处同一功能区的分钟数（行为性接近/回避）
   - chat_events：时间线中涉及对方的对话记忆条数（行为性互动频次）

方法学说明：所有指标来自被动观测日志，智能体不知情（无需求特征问题）；
建议用于条件间比较而非绝对水平解释。
"""
import json
import os
import re
from collections import defaultdict

WORK_KEYWORDS = ("工作", "研究", "撰写", "汇报", "会议", "整理", "课题", "文献", "邮件", "报告", "分析")
REST_KEYWORDS = ("休息", "放松", "喝", "茶水", "闲聊", "聊天", "散步", "看电视", "吃")
SLEEP_KEYWORDS = ("睡",)
HELP_KEYWORDS = ("帮助", "帮忙", "协助", "支援", "指导", "安慰", "鼓励")

# V27 English worlds: the same categories, matched from a word start on the lower-cased text.
# Chinese text never matches them, so Chinese worlds are coded exactly as before.
_EN = {
    "work": (r"\bwork", r"\bresearch", r"\bwrit", r"\breport", r"\bmeeting", r"\borgani[sz]",
             r"\bliterature", r"\bemail", r"\banaly", r"\bdata\b", r"\bcampaign", r"\bdraft", r"\bdocument"),
    "rest": (r"\brest\b", r"\bresting\b", r"\brelax", r"\bdrink", r"\btea\b", r"\bcoffee", r"\bchat",
             r"\bwalk", r"\btv\b", r"\bwatch(?:ing)? tv", r"\beat\b", r"\beating\b", r"\blunch", r"\bbreak\b"),
    "sleep": (r"\bsleep", r"\basleep"),
    "help": (r"\bhelp", r"\bassist", r"\bsupport", r"\bguid", r"\bcoach", r"\bmentor", r"\bcomfort",
             r"\bencourag"),
}


def _has(text, keywords, en_key):
    if any(k in text for k in keywords):
        return True
    low = str(text or "").lower()
    return any(re.search(p, low) for p in _EN[en_key])


def _read_jsonl(path):
    rows = []
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        rows.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
    return rows


def _parse_time(s):
    """'20240213-09:30' -> (date_str, minutes_of_day)"""
    m = re.match(r"^(\d{8})-(\d{1,2}):(\d{2})$", s or "")
    if not m:
        return None, None
    return m.group(1), int(m.group(2)) * 60 + int(m.group(3))


_COORD_ARENA = None


def _coord_arena_map():
    """从 maze.json 构建 坐标->区域 查找表（真实位置归属，比address字段更准）。"""
    global _COORD_ARENA
    if _COORD_ARENA is None:
        _COORD_ARENA = {}
        try:
            with open(os.path.join("frontend", "static", "assets", "village", "maze.json"),
                      "r", encoding="utf-8") as f:
                maze = json.load(f)
            for t in maze.get("tiles", []):
                a = t.get("address") or []
                if len(a) >= 2:
                    _COORD_ARENA[tuple(t["coord"])] = a[1]
        except (OSError, json.JSONDecodeError):
            pass
    return _COORD_ARENA


def _arena_of(address, coord=None):
    """优先按坐标反查真实区域；无坐标或查不到时退回address字符串解析。"""
    if coord is not None:
        arena = _coord_arena_map().get(tuple(coord))
        if arena:
            return arena
    parts = [p for p in (address or "").split(":") if p]
    return parts[2] if len(parts) >= 3 else (parts[-1] if parts else "未知")


def _fmt_hhmm(minutes):
    if minutes is None:
        return ""
    return "{:02d}:{:02d}".format(minutes // 60, minutes % 60)


def compute(name, results_root="results"):
    """计算指定实验的行为指标。返回 (daily_rows, dyad_rows, arena_names)。"""
    steps = _read_jsonl(os.path.join(results_root, "monitor", name, "steps.jsonl"))
    timeline = _read_jsonl(os.path.join(results_root, "monitor", name, "timeline.jsonl"))
    if not steps:
        return [], [], []

    # 每步时长 = 与下一步的时间差（兼容续跑时步长变化）；最后一步用前一差值
    parsed = []
    for rec in steps:
        date, mod = _parse_time(rec.get("time", ""))
        if date is not None:
            parsed.append((date, mod, rec))
    durations = []
    for i, (date, mod, rec) in enumerate(parsed):
        if i + 1 < len(parsed):
            nd, nm, _ = parsed[i + 1]
            delta = (nm - mod) if nd == date else max(0, nm + 1440 - mod)
            delta = max(1, min(720, delta))
        else:
            delta = durations[-1] if durations else 10
        durations.append(delta)

    agents = set()
    for _, _, rec in parsed:
        agents.update((rec.get("agents") or {}).keys())
    agents = sorted(agents)

    daily = defaultdict(lambda: defaultdict(float))      # (date, agent) -> metric -> value
    firsts = {}                                          # (date, agent) -> first work minutes
    sleeps = {}                                          # (date, agent) -> sleep onset minutes
    dyad = defaultdict(float)                            # (date, a, b) -> copresence min
    arena_names = set()

    for (date, mod, rec), dur in zip(parsed, durations):
        arena_at = {}
        for ag, a in (rec.get("agents") or {}).items():
            arena = _arena_of(a.get("address", ""), a.get("coord"))
            arena_at[ag] = arena
            arena_names.add(arena)
            key = (date, ag)
            daily[key]["area_min__" + arena] += dur
            action = (a.get("action") or "")
            if _has(action, SLEEP_KEYWORDS, "sleep"):
                daily[key]["sleep_min"] += dur
                if key not in sleeps and mod >= 12 * 60:
                    sleeps[key] = mod
            elif _has(action, WORK_KEYWORDS, "work"):
                daily[key]["work_min"] += dur
                if key not in firsts:
                    firsts[key] = mod
            elif _has(action, REST_KEYWORDS, "rest"):
                daily[key]["rest_min"] += dur
            if _has(action, HELP_KEYWORDS, "help"):
                daily[key]["helping_acts"] += 1
        # 共处：同一功能区（排除"未知"）
        for i, a1 in enumerate(agents):
            for a2 in agents[i + 1:]:
                if a1 in arena_at and a2 in arena_at and arena_at[a1] == arena_at[a2] and arena_at[a1] != "未知":
                    dyad[(date, a1, a2)] += dur

    # 时间线：对话互动计数与帮助类对话
    chat_pair = defaultdict(int)  # (date, a, b) -> count
    for row in timeline:
        date, _ = _parse_time(row.get("sim_time", ""))
        if date is None:
            continue
        ag = row.get("agent", "")
        text = row.get("text", "") or ""
        if row.get("type") == "chat":
            for other in agents:
                if other != ag and other in text:
                    a1, a2 = sorted([ag, other])
                    chat_pair[(date, a1, a2)] += 1
                    break
        if row.get("type") in ("chat", "action") and _has(text, HELP_KEYWORDS, "help"):
            daily[(date, ag)]["helping_mentions"] += 1

    # V27.3: an English world (English agent names) gets English area names in its column headers.
    # The map itself is named in Chinese, so the areas are translated here; Chinese worlds are unchanged.
    from modules import lang as _lang
    english = any(ag in _lang.NAMES_ZH for ag in agents)
    label = (lambda a: _lang.LOCATIONS.get(a, "unknown" if a == "未知" else a).replace(" ", "_")) if english else (lambda a: a)
    arena_names = sorted(arena_names)
    daily_rows = []
    for (date, ag), metrics in sorted(daily.items()):
        row = {"run_id": name, "survey_date": date, "agent": ag,
               "work_min": round(metrics.get("work_min", 0), 1),
               "rest_min": round(metrics.get("rest_min", 0), 1),
               "sleep_min": round(metrics.get("sleep_min", 0), 1),
               "first_work_time": _fmt_hhmm(firsts.get((date, ag))),
               "sleep_onset": _fmt_hhmm(sleeps.get((date, ag))),
               "helping_acts": int(metrics.get("helping_acts", 0)),
               "helping_mentions": int(metrics.get("helping_mentions", 0))}
        for arena in arena_names:
            row["area_min__" + label(arena)] = round(metrics.get("area_min__" + arena, 0), 1)
        daily_rows.append(row)

    dyad_rows = []
    keys = set(dyad.keys()) | set(chat_pair.keys())
    for (date, a1, a2) in sorted(keys):
        dyad_rows.append({
            "run_id": name, "survey_date": date, "agent_a": a1, "agent_b": a2,
            "copresence_min": round(dyad.get((date, a1, a2), 0), 1),
            "chat_events": chat_pair.get((date, a1, a2), 0),
        })
    return daily_rows, dyad_rows, [label(a) for a in arena_names]


def to_csv_text(rows):
    """rows -> UTF-8-BOM CSV 文本。"""
    import csv
    import io
    if not rows:
        return "\ufeff"
    fields = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for r in rows:
        writer.writerow(r)
    return "\ufeff" + buf.getvalue()
