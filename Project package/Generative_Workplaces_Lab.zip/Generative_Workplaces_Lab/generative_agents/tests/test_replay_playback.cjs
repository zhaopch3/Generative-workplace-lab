// Run: node tests/test_replay_playback.cjs (no browser or model calls).
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const script = fs.readFileSync(path.join(__dirname, '../frontend/templates/live_script.html'), 'utf8');
const scheduler = script.split('// ====== 动画回放调度 ======')[1].split('let seek_fetch_timer')[0];
let now = 100000, tick, requests = 0, frames = [], resolveFetch, busy = false;
const sandbox = {
  latest_step: 5, earliest_step: 1, seekGeneration: 0, playing: false, playback_paused: false,
  playback_speed: 1, playbackFrameAt: 0, playback_poll: null, move_queues: {}, stepsAPI: '/steps',
  Date: {now: () => now}, setInterval: fn => {tick = fn; return 1;}, clearInterval: () => {},
  document: {getElementById: () => ({getAttribute: () => busy ? 'true' : 'false'})},
  setReviewMode: () => {},
  fetch: () => {requests++; return new Promise(resolve => {resolveFetch = resolve;});},
  applyFramePlayback: rec => {frames.push(rec.step); sandbox.playbackFrameAt = now;}
};
vm.createContext(sandbox);
vm.runInContext(scheduler, sandbox);
async function deliver(step) {
  resolveFetch({json: async () => ({ok:true, record:{step}})});
  await new Promise(resolve => setImmediate(resolve));
}
(async () => {
  sandbox.startPlayback(1); tick(); await deliver(1);
  now += 14999; tick(); assert.equal(requests, 1, 'Do not skip a stationary frame immediately');
  now++; tick(); assert.equal(requests, 2); await deliver(2);
  sandbox.playback_speed = 0.5;
  now += 29999; tick(); assert.equal(requests, 2, 'Fractional speed must retain 30 seconds');
  now++; busy = true; tick(); assert.equal(requests, 2, 'Wait for text to load');
  busy = false; now += 30000; tick(); assert.equal(requests, 3);
  sandbox.playback_paused = true; await deliver(3);
  assert.deepEqual(frames, [1,2], 'Pausing discards an in-flight frame');
  now += 30000; tick(); assert.equal(requests, 3);
  sandbox.playback_paused = false; tick(); assert.equal(requests, 4);
  sandbox.stopPlayback(); await deliver(3);
  assert.deepEqual(frames, [1,2], 'Stopping discards an in-flight frame');
  console.log('Replay reading interval, fractional speed, loading, pause and stop checks passed.');
})().catch(error => {console.error(error); process.exitCode = 1;});
