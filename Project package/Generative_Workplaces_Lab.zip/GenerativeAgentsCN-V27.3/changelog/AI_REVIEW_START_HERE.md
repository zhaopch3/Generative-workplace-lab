# V22 AI 审阅包：请先读此文件

这是从本机 V22 工作目录导出的当前文件快照，用于在规划 V23 前审阅现有实现。
导出日期：2026-10-25。未以 Git HEAD 导出，因此包含工作目录中已有的修改。

## 保留与排除

- 保留后端源码、前端模板/脚本/样式/地图与人物资源、测试、提示词、场景预设、批量实验示例、依赖声明及 V22 启动入口。
- 配置 JSON 中的凭据字段已清空；原始 .env 不在包中。模型与实验参数保留供审阅。
- 排除 Git 历史、Python 虚拟环境、缓存、results 下的全部模拟历史与 checkpoint、日志、备份、3d_archive 旧素材、历史交接说明及临时截图。
- 源代码中的版本注释和兼容逻辑保留，未改写项目实现。README 中部分旧版说明或截图链接仅作背景，当前入口以 launch_v22.py 和 V22使用说明.md 为准。

## 建议阅读顺序

1. V22使用说明.md；generative_agents/研究定位与创新点.md。
2. launch_v22.py；generative_agents/server.py；batch.py；batch_worker.py。
3. generative_agents/modules/：模拟、智能体、记忆、模型、行为、导出及嵌套子模块。
4. generative_agents/frontend/templates 与 static/js：研究界面、实时控制和回放。
5. generative_agents/data/：提示词、配置、场景；experiments/：批量示例。
6. generative_agents/tests/：已有的验证范围，不代表本次重新执行并通过。

## 可直接交给另一个 AI 的请求

我们计划在 V22 基础上设计 V23。请先阅读实际源码，再提出建议，不要立即大规模重构。
请围绕研究用途评估：多世界/批量实验隔离、模拟与记忆机制、三类干预及审计、
实验可复现性、研究数据导出、界面操作流程和可维护性。

请将“源码已实现”“存在具体缺陷”“需要运行验证”“未来功能建议”分开描述，
每项发现注明文件路径、函数或接口及证据；不要仅根据 README 断言功能完成。
按优先级给出问题、研究影响、最小修改方案和验收方法，最后列出适合 V23 的少量重点。
优先考虑能用现有场景和小规模实验验证的改进。

## 验证范围与运行提示

本次仅验证文件清单、ZIP 完整性、保留文件哈希、Python 语法、JSON 可解析性与常见凭据模式。
未重新运行模拟或测试，未验证外部服务或依赖安装；包不含实验结果，不能用于判断已有实验结论。
如需运行，请新建环境并自行配置模型服务/密钥；可先参考 requirements-v21.txt 的版本声明，
结合 requirements.txt 检查需要的可选依赖。已有 bat 指向本地 .venv，创建环境后才能使用。
V22 启动方式：在包根目录运行 python launch_v22.py --no-browser，默认端口 5071。
测试在 generative_agents 子目录执行：python -m unittest discover -s tests -p 'test_*.py'。

FILE_MANIFEST.json 列出了全部原项目入包文件的 SHA-256；sanitized=true 表示仅在包内清空了凭据字段。
