"""V27.4: the Chinese-language templates have English names with the suffix _CN."""
import json
import os
import re
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import server  # noqa: E402

HAN = re.compile(r"[一-鿿]")
NEW = ("Persona-manipulation-high-abuse_CN", "Persona-manipulation-low-abuse_CN",
       "Event-manipulation-high-abuse_CN", "Event-manipulation-low-abuse_CN")
NEW_EN = tuple(n[:-3] + "_EN" for n in NEW)


class TemplateNamesTest(unittest.TestCase):

    def test_every_template_name_is_english_with_a_language_suffix(self):
        names = sorted(p.stem for p in (ROOT / "data" / "world_presets").glob("*.json"))
        self.assertEqual(names, sorted(NEW + NEW_EN))
        for n in names:
            self.assertTrue(server._NAME_RE.match(n), n)
        self.assertEqual(sorted(server.PRESET_RENAMES.values()), sorted(NEW + NEW_EN))

    def test_cn_templates_are_chinese_worlds_and_pair_with_english_ones(self):
        for n in NEW:
            with open(server.preset_path(n), encoding="utf-8") as f:
                zh = json.load(f)
            with open(server.preset_path(n[:-3] + "_EN"), encoding="utf-8") as f:
                en = json.load(f)
            self.assertTrue(all(HAN.search(a) for a in zh["agents"]), n)
            self.assertFalse(any(HAN.search(a) for a in en["agents"]), n)
            self.assertEqual(zh["step"], en["step"])
            self.assertEqual(zh["research_design"].get("condition_code"), en["research_design"].get("condition_code"))

    def test_old_names_still_load(self):
        for old, new in server.PRESET_RENAMES.items():
            self.assertEqual(os.path.normpath(server.preset_path(old)),
                             os.path.normpath(os.path.join("data", "world_presets", new + ".json")))
        client = server.create_app({"runner": None}).test_client()
        a = client.get("/api/world_presets/get?name=" + "人设操纵-高辱虐组").get_json()
        b = client.get("/api/world_presets/get?name=Persona-manipulation-high-abuse_CN").get_json()
        self.assertTrue(a["ok"])
        self.assertEqual(a["payload"], b["payload"])
        c = client.get("/api/world_presets/get?name=Persona-manipulation-high-abuse").get_json()
        e = client.get("/api/world_presets/get?name=Persona-manipulation-high-abuse_EN").get_json()
        self.assertTrue(c["ok"])
        self.assertEqual(c["payload"], e["payload"])

    def test_comparable_group_id_unchanged_by_renaming(self):
        # the ID is computed from the template content, which the renaming does not touch
        with open(server.preset_path("Persona-manipulation-high-abuse_CN"), encoding="utf-8") as f:
            payload = json.load(f)
        self.assertEqual(server.comparison_signature(dict(payload, name="a")),
                         server.comparison_signature(dict(payload, name="b")))

    def test_upgrade_renames_or_removes_old_files(self):
        origin = os.getcwd()
        with tempfile.TemporaryDirectory() as root:
            d = Path(root) / "data" / "world_presets"
            d.mkdir(parents=True)
            src = ROOT / "data" / "world_presets"
            # same content as the new file -> old one removed
            shutil.copy(src / "Persona-manipulation-high-abuse_CN.json", d / "Persona-manipulation-high-abuse_CN.json")
            shutil.copy(src / "Persona-manipulation-high-abuse_CN.json", d / "人设操纵-高辱虐组.json")
            # only the old file -> renamed
            shutil.copy(src / "Persona-manipulation-low-abuse_CN.json", d / "人设操纵-低辱虐组.json")
            # changed by the user -> kept under the old name
            shutil.copy(src / "Event-manipulation-high-abuse_CN.json", d / "Event-manipulation-high-abuse_CN.json")
            (d / "事件操纵-高辱虐组.json").write_text(json.dumps({"agents": ["克劳斯"]}), encoding="utf-8")
            try:
                os.chdir(root)
                server.rename_old_presets()
            finally:
                os.chdir(origin)
            names = sorted(p.stem for p in d.glob("*.json"))
            self.assertEqual(names, sorted(["Persona-manipulation-high-abuse_CN", "Persona-manipulation-low-abuse_CN",
                                            "Event-manipulation-high-abuse_CN", "事件操纵-高辱虐组"]))

    def test_setup_page_hides_cn_templates_in_english(self):
        html = (ROOT / "frontend" / "templates" / "setup.html").read_text(encoding="utf-8")
        self.assertIn("function visiblePreset(n)", html)
        self.assertIn("/_CN$/.test(n)", html)
        self.assertNotIn("filter(visibleName).map(p => `<option", html)
        self.assertIn('["Persona-manipulation-high-abuse_CN","Persona-manipulation-low-abuse_CN"]', html)


if __name__ == "__main__":
    unittest.main()
