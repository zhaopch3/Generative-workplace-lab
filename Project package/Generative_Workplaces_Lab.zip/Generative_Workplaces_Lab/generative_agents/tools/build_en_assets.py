# -*- coding: utf-8 -*-
"""Build the English-world assets from the Chinese originals (V27; run from generative_agents/).

Inputs  : the Chinese agent folders, templates and conditions;
          data/i18n/content_en.json  (personas, world rules, events, leadership texts);
          data/i18n/surveys_en.json  (survey titles and item wording, with sources).
Outputs : frontend/static/assets/village/agents/{Klaus,Ayesha,Maria,Wolfgang}/  (agent.json + sprites)
          data/world_presets/{Persona,Event}-manipulation-{high,low}-abuse.json
          "translations": {"en": ...} in data/experiment_conditions.json and .default.json

Re-run after changing any Chinese template or the English content; the English templates
then match the Chinese ones field for field except for the language. tools/check_templates.py
style checks are in tests/test_v27_english.py.
"""
import copy
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from modules import lang  # noqa: E402

AGENTS_ROOT = os.path.join("frontend", "static", "assets", "village", "agents")
PRESETS = os.path.join("data", "world_presets")
CONTENT = os.path.join("data", "i18n", "content_en.json")
SURVEYS = os.path.join("data", "i18n", "surveys_en.json")


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def dump(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def name_en(name):
    return lang.NAMES.get(name, name)


def build_agents(content):
    for zh, en in lang.NAMES.items():
        src_dir = os.path.join(AGENTS_ROOT, zh)
        dst_dir = os.path.join(AGENTS_ROOT, en)
        os.makedirs(dst_dir, exist_ok=True)
        for asset in ("portrait.png", "texture.png"):
            shutil.copyfile(os.path.join(src_dir, asset), os.path.join(dst_dir, asset))
        agent = load(os.path.join(src_dir, "agent.json"))
        text = content["agents"][zh]
        agent["name"] = en
        agent["portrait"] = "assets/village/agents/{}/portrait.png".format(en)
        agent["currently"] = text["currently"]
        scratch = dict(agent["scratch"])
        scratch.update(text["scratch"])
        agent["scratch"] = scratch
        agent["spatial"] = lang.translate_spatial(agent["spatial"])
        agent["workstation"] = lang.LOCATIONS.get(agent.get("workstation", ""), agent.get("workstation", ""))
        agent["language"] = "en"
        agent.pop("village_persona_v22", None)   # Chinese reference copy of the old town persona, never used
        dump(os.path.join(dst_dir, "agent.json"), agent)
        print("agent", zh, "->", en)


# V27.2: the battery grade appended to a survey source ("<scale> | <grade>"), in English
GRADE_EN = {"可直接用": "full scale as published", "已按题数挑选": "items selected to match the reported count",
            "题数少于原文": "fewer items than reported"}


def translate_survey(schema, surveys_en):
    out = copy.deepcopy(schema)
    src = out.get("source")
    if isinstance(src, str) and " | " in src:
        head, grade = src.rsplit(" | ", 1)
        out["source"] = head + " | " + GRADE_EN.get(grade, grade)
    tr = surveys_en.get(out.get("id"), {})
    for key in ("display_title", "title", "instructions"):
        if tr.get(key):
            out[key] = tr[key]
    by_id = tr.get("questions") or {}
    for q in out.get("questions", []):
        for key, value in (by_id.get(q.get("id")) or {}).items():
            q[key] = value
        if isinstance(q.get("text"), str):
            q["text"] = q["text"].replace("{对象}", "{ratee}")   # V27.2: English placeholder for the ratee
    for key in ("targets", "raters", "ratees"):
        if isinstance(out.get(key), list):
            out[key] = [name_en(n) for n in out[key]]
    return out


def build_templates(content, surveys_en):
    for zh_name, en_name in content["templates"].items():
        src = load(os.path.join(PRESETS, zh_name + ".json"))
        t = copy.deepcopy(src)
        t["language"] = "en"
        t["agents"] = [name_en(n) for n in src.get("agents", [])]
        if src.get("world_rules"):
            t["world_rules"] = content["world_rules"]
        t["custom_surveys"] = [translate_survey(s, surveys_en) for s in src.get("custom_surveys", [])]
        events = []
        for e in src.get("scheduled_events") or []:
            e = copy.deepcopy(e)
            if e.get("text"):
                e["text"] = content["events"][e["text"]]
            for key in ("actor", "object"):
                if e.get(key):
                    e[key] = name_en(e[key])
            if isinstance(e.get("targets"), list):
                e["targets"] = [name_en(n) for n in e["targets"]]
            events.append(e)
        if "scheduled_events" in src:
            t["scheduled_events"] = events
        if src.get("persona_overrides"):
            raise SystemExit("persona_overrides in {} need an English version".format(zh_name))
        if src.get("shared_context"):
            raise SystemExit("shared_context in {} needs an English version".format(zh_name))
        dump(os.path.join(PRESETS, en_name + ".json"), t)
        print("template", zh_name, "->", en_name)


def build_conditions(content):
    for path in (os.path.join("data", "experiment_conditions.json"),
                 os.path.join("data", "experiment_conditions.default.json")):
        conditions = load(path)
        for key, entry in conditions.items():
            text = content["conditions"].get(key)
            if not text:
                continue
            en = {"description": text["description"], "leader": name_en(entry.get("leader", ""))}
            overrides = copy.deepcopy(entry.get("leader_overrides") or {})
            overrides.setdefault("scratch", {})["conduct"] = text["conduct"]
            en["leader_overrides"] = overrides
            entry["translations"] = {"en": en}
        dump(path, conditions)
        print("conditions", path)


def main():
    content = load(CONTENT)
    surveys_en = load(SURVEYS)["surveys"]
    build_agents(content)
    build_templates(content, surveys_en)
    build_conditions(content)


if __name__ == "__main__":
    main()
