"""Small filesystem primitives shared by research services."""
import hashlib
import json
import os
import re
import tempfile
from pathlib import Path

ID = re.compile(r"^[\w\-.\u4e00-\u9fff]{1,120}$")


def safe_id(value):
    value = str(value or "")
    if not ID.fullmatch(value) or value in (".", ".."):
        raise ValueError("无效的记录标识")
    return value


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.flush()
            os.fsync(handle.fileno())
        import time
        for attempt in range(8):
            try:
                os.replace(temp, path)
                break
            except PermissionError:
                if attempt == 7:
                    raise
                time.sleep(.025 * (attempt+1))
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def digest(path):
    result = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def jsonl(path):
    if not Path(path).is_file():
        return
    with open(path, encoding="utf-8") as handle:
        for number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
                if not isinstance(value, dict):
                    raise ValueError("not an object")
                yield number, value, None
            except ValueError:
                yield number, None, "损坏的JSONL行"


def fill_prev_coords(records):
    """V23: give each agent the previous frame's cell when a step log lacks it.

    Step logs written before V23 stored only the destination, so replay could
    not animate the recorded path and relocated every agent instead.  The
    previous frame's coordinate is exactly where that step's path started.
    """
    out, last = [], {}
    for record in records:
        agents = {}
        for name, agent in (record.get("agents") or {}).items():
            agent = dict(agent)
            if not agent.get("prev_coord") and name in last:
                agent["prev_coord"] = last[name]
                agent.setdefault("navigation_policy", "legacy")
            if agent.get("coord"):
                last[name] = agent["coord"]
            agents[name] = agent
        out.append({**record, "agents": agents})
    return out
