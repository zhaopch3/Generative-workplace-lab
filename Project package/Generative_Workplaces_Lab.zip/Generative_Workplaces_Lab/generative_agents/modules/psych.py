# -*- coding: utf-8 -*-
"""结构化心理状态（阶段四）

每个智能体维护四个连续心理变量（1-10）：
    mood      情绪效价：1=非常消极，10=非常积极
    stress    压力水平：1=毫无压力，10=压力极大
    energy    精力水平：1=精疲力竭，10=精力充沛
    sociality 社交意愿：1=极度回避社交，10=渴望社交

三种更新机制：
1. 自然漂移（drift，纯本地计算，零成本）：精力在清醒时缓慢消耗、睡眠时恢复；
   情绪与压力向各自基线缓慢回归（情绪调节的"享乐适应"）。
2. 事件评估（appraisal，LLM调用，由显著性阈值门控）：当一段时间内感知到的
   事件累计显著性超过阈值，让智能体以第一人称评估这些事件对自身状态的影响，
   输出各变量的增量（每次每变量限 [-3, +3]）。
3. 研究者直接设定（干预面板），用于自变量操纵。

状态通过 _base_desc 注入所有提示词，因此会真实影响日程规划、行动选择与对话。
"""

VARS = ("mood", "stress", "energy", "sociality")

VAR_LABELS = {
    "mood": "情绪",
    "stress": "压力",
    "energy": "精力",
    "sociality": "社交意愿",
}

# V27 English worlds: the same five bands per variable.
_BANDS_EN = {
    "mood": [(2.5, "feeling very low"), (4.5, "feeling somewhat low"), (6.5, "in an even mood"),
             (8.5, "in a good mood"), (10.1, "in a very good mood")],
    "stress": [(2.5, "hardly any stress"), (4.5, "not much stress"), (6.5, "moderate stress"),
               (8.5, "fairly high stress"), (10.1, "extreme stress, close to breaking down")],
    "energy": [(2.5, "exhausted"), (4.5, "rather tired"), (6.5, "average energy"),
               (8.5, "full of energy"), (10.1, "bursting with energy")],
    "sociality": [(2.5, "strongly wants to be alone and avoid others"), (4.5, "not very keen on company"),
                  (6.5, "neutral about company"), (8.5, "happy to talk with others"),
                  (10.1, "very eager to talk with others")],
}
VAR_LABELS_EN = {"mood": "mood", "stress": "stress", "energy": "energy", "sociality": "sociality"}

DEFAULTS = {"mood": 6.0, "stress": 4.0, "energy": 8.0, "sociality": 6.0}

# 漂移参数（单位：每模拟小时）
ENERGY_DRAIN_PER_HOUR = 0.35      # 清醒时精力消耗
ENERGY_RECOVER_PER_HOUR = 1.2     # 睡眠时精力恢复
REGRESSION_PER_HOUR = 0.15        # 情绪/压力/社交意愿向基线回归速率

# 评估触发阈值：自上次评估以来累计感知显著性
APPRAISAL_POIGNANCY_THRESHOLD = 8
# 评估冷却：两次LLM评估之间至少间隔的模拟分钟数（控制成本）
APPRAISAL_COOLDOWN_MINUTES = 60


def clamp(value, lo=1.0, hi=10.0):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return lo
    return max(lo, min(hi, value))


class PsychState:
    def __init__(self, values=None, baselines=None):
        values = values or {}
        baselines = baselines or {}
        self.values = {k: clamp(values.get(k, DEFAULTS[k])) for k in VARS}
        # 基线 = 人格设定的稳态（回归目标）；默认取初始值
        self.baselines = {k: clamp(baselines.get(k, self.values[k])) for k in VARS}

    # ---------------- 序列化 ----------------
    def to_dict(self):
        return {
            "values": {k: round(v, 2) for k, v in self.values.items()},
            "baselines": {k: round(v, 2) for k, v in self.baselines.items()},
        }

    @classmethod
    def from_dict(cls, data):
        data = data or {}
        if "values" in data or "baselines" in data:
            return cls(data.get("values"), data.get("baselines"))
        # 兼容直接给 {mood: 7, ...} 的简写（配置器/干预用）
        return cls(data, data)

    # ---------------- 自然漂移 ----------------
    def drift(self, minutes, sleeping=False):
        if minutes <= 0:
            return
        hours = minutes / 60.0
        if sleeping:
            self.values["energy"] = clamp(
                self.values["energy"] + ENERGY_RECOVER_PER_HOUR * hours
            )
        else:
            self.values["energy"] = clamp(
                self.values["energy"] - ENERGY_DRAIN_PER_HOUR * hours
            )
        for key in ("mood", "stress", "sociality"):
            gap = self.baselines[key] - self.values[key]
            step = REGRESSION_PER_HOUR * hours
            if abs(gap) <= step:
                self.values[key] = self.baselines[key]
            else:
                self.values[key] += step if gap > 0 else -step
            self.values[key] = clamp(self.values[key])

    # ---------------- 增量与设定 ----------------
    def apply_deltas(self, deltas, limit=3.0):
        applied = {}
        for key in VARS:
            if key not in (deltas or {}):
                continue
            try:
                d = float(deltas[key])
            except (TypeError, ValueError):
                continue
            d = max(-limit, min(limit, d))
            if d == 0:
                continue
            self.values[key] = clamp(self.values[key] + d)
            applied[key] = round(d, 2)
        return applied

    def set_values(self, values):
        applied = {}
        for key in VARS:
            if key not in (values or {}):
                continue
            v = values[key]
            if v is None or v == "":
                continue
            self.values[key] = clamp(v)
            applied[key] = self.values[key]
        return applied

    # ---------------- 文本化（进入提示词） ----------------
    @staticmethod
    def _level_word(key, v):
        from modules import lang
        if lang.is_en():
            bands = _BANDS_EN[key if key in _BANDS_EN else "sociality"]
            for hi, word in bands:
                if v < hi:
                    return word
            return word
        if key == "mood":
            bands = [(2.5, "情绪非常低落"), (4.5, "情绪有些低落"), (6.5, "心情平稳"),
                     (8.5, "心情不错"), (10.1, "心情非常好")]
        elif key == "stress":
            bands = [(2.5, "几乎没有压力"), (4.5, "压力不大"), (6.5, "压力中等"),
                     (8.5, "压力较大"), (10.1, "压力极大、接近崩溃")]
        elif key == "energy":
            bands = [(2.5, "精疲力竭"), (4.5, "比较疲惫"), (6.5, "精力一般"),
                     (8.5, "精力充沛"), (10.1, "活力满满")]
        else:
            bands = [(2.5, "极度想独处、回避他人"), (4.5, "不太想与人交往"), (6.5, "对社交持平常心"),
                     (8.5, "愿意与人交流"), (10.1, "非常渴望与人交流")]
        for hi, word in bands:
            if v < hi:
                return word
        return word
        return word

    def describe(self):
        parts = []
        for key in VARS:
            v = self.values[key]
            # V23: words only; numeric readings would be copied straight into survey answers.
            parts.append(self._level_word(key, v))
        from modules import lang
        return lang.L("、", ", ").join(parts)

    def snapshot(self):
        return {k: round(self.values[k], 2) for k in VARS}


def failsafe_appraisal(total_poignancy):
    """离线/解析失败时的保守评估：显著事件带来轻度压力与情绪扰动。"""
    deltas = {}
    if total_poignancy >= APPRAISAL_POIGNANCY_THRESHOLD:
        deltas["stress"] = min(1.0, total_poignancy / 16.0)
        if total_poignancy >= 20:
            deltas["mood"] = -0.5
    return deltas
