# -*- coding: utf-8 -*-
"""V24 live injection: world settings, withdrawal, shared context in the fixed layer,
scheduled thoughts / settings / psych, and one decision after learning of an injection."""
import json
import os
import tempfile
import unittest
from pathlib import Path

import server
from modules import utils
from modules.research import scenario, world_check

ROOT = Path(__file__).resolve().parents[1]
PRESETS = ROOT / "data" / "world_presets"


def load(name):
    return json.loads((PRESETS / (name + ".json")).read_text(encoding="utf-8"))


class World:
    """An offline event-template world that can be stepped and injected into."""

    def __init__(self, name, **extra):
        from start import SimulateServer
        payload = load("Event-manipulation-low-abuse_CN")
        payload.update(name=name, offline=True, step=10, shuffle_think_order=False, **extra)
        _, args, self.cfg = server.build_experiment_config(payload)
        self.origin = Path.cwd()
        self.root = tempfile.mkdtemp()
        os.chdir(self.root)
        try:
            self.run = SimulateServer(args.name, str(self.origin / "frontend/static"),
                                      "results/checkpoints/" + args.name, self.cfg, verbose="error")
        finally:
            os.chdir(self.origin)
        for agent in self.run.game.agents.values():
            agent.scratch.template_path = str(self.origin / "data/prompts")
        self.name = args.name

    def step(self, n=1):
        os.chdir(self.root)
        try:
            self.run.simulate(n, stride=60)
            self.run.start_step += n
        finally:
            os.chdir(self.origin)

    def inject(self, **item):
        item.setdefault("intervention_id", "iv_" + item.get("kind", "x"))
        os.chdir(self.root)
        try:
            return self.run.apply_intervention(item, self.run.start_step + 1)
        finally:
            os.chdir(self.origin)

    def reactions(self):
        path = Path(self.root) / "results" / "monitor" / self.name / "injection_reactions.jsonl"
        if not path.exists():
            return []
        return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]

    def agent(self, name):
        return self.run.game.get_agent(name)


def switch_to(activity, area, minutes=60):
    """Make one agent's react_to_injection answer 'switch' (offline answers 'continue')."""
    def install(agent):
        original = agent.completion

        def completion(hint, *args, **kwargs):
            if hint == "react_to_injection":
                return {"continue": False, "activity": activity, "area": area, "minutes": minutes}
            return original(hint, *args, **kwargs)
        agent.completion = completion
    return install


class FixedLayerTests(unittest.TestCase):
    def test_shared_context_is_a_world_fact_not_currently(self):
        payload = dict(load("Event-manipulation-low-abuse_CN"), name="v24-shared", shared_context="本季度项目经费削减了三成。")
        _, _, cfg = server.build_experiment_config(payload)
        for name, agent_cfg in cfg["agents"].items():
            facts = agent_cfg["scratch"]["world_facts"]
            self.assertEqual(facts[-1]["text"], "本季度项目经费削减了三成。")
            self.assertNotIn("经费削减", agent_cfg.get("currently", ""))
            self.assertIn("【目前的情况】：本季度项目经费削减了三成。", world_check.render_persona(name, agent_cfg))

    def test_world_facts_respect_start_expiry_and_revocation(self):
        from modules.prompt.scratch import Scratch
        world = World("v24-facts")  # sets the simulation clock
        now = utils.get_timer().get_date("%Y%m%d-%H:%M")
        scratch = Scratch("测试", "", {"world_facts": [
            {"text": "甲", "from": None},
            {"text": "乙", "from": "20990101-00:00"},
            {"text": "丙", "from": None, "expires": "20000101-00:00"},
            {"text": "丁", "from": None, "revoked": now},
        ]})
        self.assertEqual(scratch.active_world_facts(), ["甲"])
        self.assertIn("【目前的情况】：甲", scratch.fixed_block())
        del world


class ScheduledKindsTests(unittest.TestCase):
    def payload(self, events):
        return {"agents": ["阿伊莎", "玛丽亚"], "scheduled_events": events}

    def test_thought_setting_and_psych_can_be_scheduled(self):
        scenario.validate_scenario(self.payload([
            {"day": 2, "time": "09:00", "kind": "thought", "targets": ["阿伊莎"],
             "text": "想早点完成报告", "persistent": True, "persist_days": 2},
            {"day": 2, "time": "09:00", "kind": "world_setting", "text": "报销一律由领导签字"},
            {"day": 3, "time": "09:00", "kind": "world_event", "text": "", "targets": ["玛丽亚"],
             "scope": "selected", "psych": {"stress": 8}},
        ]))

    def test_invalid_scheduled_items_are_rejected(self):
        for event in (
            {"day": 2, "time": "09:00", "kind": "thought", "text": "没有对象"},
            {"day": 2, "time": "09:00", "kind": "world_setting", "text": ""},
            {"day": 2, "time": "09:00", "text": "x", "psych": {"anger": 5}},
            {"day": 2, "time": "09:00", "text": "x", "psych": {"stress": 12}},
        ):
            with self.assertRaises(ValueError):
                scenario.validate_scenario(self.payload([event]))


class LiveInjectionTests(unittest.TestCase):
    def test_world_setting_enters_fixed_layer_and_can_be_withdrawn(self):
        world = World("v24-setting")
        world.step(2)
        record = world.inject(kind="world_setting", text="从今天起，报销一律由克劳斯亲自签字。", scope="all")
        self.assertEqual(sorted(record["targets"]), sorted(world.run.game.agents))
        self.assertTrue(record["persistent"])
        for agent in world.run.game.agents.values():
            self.assertIn("【目前的情况】：从今天起，报销一律由克劳斯亲自签字。", agent.scratch.fixed_block())
        history = [record]
        self.assertEqual(len(server.active_persistent_interventions(history)), 1)
        world.step(1)
        revoke = world.inject(kind="revoke", revoke_id="iv_world_setting", intervention_id="iv_revoke")
        history.append(revoke)
        self.assertEqual(revoke["status"], "applied")
        for agent in world.run.game.agents.values():
            self.assertNotIn("报销", agent.scratch.fixed_block())
        self.assertEqual(server.active_persistent_interventions(history), [])
        with self.assertRaises(ValueError):
            world.inject(kind="revoke", revoke_id="iv_world_setting", intervention_id="iv_revoke2")

    def test_every_recipient_decides_once_at_next_think(self):
        world = World("v24-react-keep")
        world.step(2)
        world.inject(kind="world_event", text="办公室的空调坏了，屋里很热。", scope="all")
        world.step(1)
        rows = world.reactions()
        self.assertEqual(sorted(r["agent"] for r in rows), sorted(world.run.game.agents))
        self.assertTrue(all(r["intervention_ids"] == ["iv_world_event"] and not r["changed"] for r in rows))
        world.step(2)  # handled once; seeing the event again does not trigger another decision
        self.assertEqual(len(world.reactions()), len(rows))

    def test_switch_becomes_current_action_in_chosen_area(self):
        world = World("v24-react-switch")
        world.step(2)
        switch_to("玛丽亚去会议区和同事商量怎么应对新规定", "会议区", 60)(world.agent("玛丽亚"))
        world.inject(kind="thought", targets=["玛丽亚"], text="得找同事商量一下新规定。")
        world.step(1)
        maria = world.agent("玛丽亚")
        self.assertIn("商量怎么应对新规定", maria.get_event().get_describe())
        self.assertIn("会议区", maria.get_event().address)
        self.assertEqual(maria.action.duration, 60)
        row = [r for r in world.reactions() if r["agent"] == "玛丽亚"][0]
        self.assertTrue(row["changed"])
        timeline = Path(world.root) / "results" / "monitor" / world.name / "timeline.jsonl"
        types = [json.loads(l)["type"] for l in timeline.read_text(encoding="utf-8").splitlines()]
        self.assertIn("injection_reaction", types)

    def test_react_off_and_legacy_worlds_do_not_decide(self):
        world = World("v24-react-off")
        world.step(2)
        world.inject(kind="world_event", text="楼下在施工。", scope="all", react=False)
        world.step(1)
        self.assertEqual(world.reactions(), [])
        legacy = World("v24-react-legacy")
        legacy.run.injection_reaction = False
        for agent in legacy.run.game.agents.values():
            agent.injection_reaction = False
        legacy.step(2)
        legacy.inject(kind="world_event", text="楼下在施工。", scope="all")
        legacy.step(1)
        self.assertEqual(legacy.reactions(), [])

    def test_local_event_reaches_those_who_see_it(self):
        world = World("v24-react-local")
        world.step(2)  # next step is 10:00, when the team goes to the meeting area
        location = next(k for k in world.run.game.maze.address_tiles if k.endswith("会议区:会议桌"))
        world.inject(kind="world_event", text="会议桌上放着一份没署名的匿名信。", scope="local",
                     location=location)
        world.step(1)
        maze = world.run.game.maze
        present = {n for n, st in world.run.agent_status.items()
                   if maze.tile_at(st["coord"]).get_address("arena")[-1] == "会议区"}
        self.assertTrue(present)
        world.step(1)
        seen = {r["agent"] for r in world.reactions() if "iv_world_event" in r["intervention_ids"]}
        self.assertEqual(seen, present)


if __name__ == "__main__":
    unittest.main()


class ItemOrderTests(unittest.TestCase):
    def schema(self, **extra):
        from modules import survey
        return survey.validate_schema({"id": "s1", "questions": [
            {"id": "q%d" % i, "text": "题%d" % i} for i in range(1, 9)], **extra})

    def test_items_are_shuffled_reproducibly_when_enabled(self):
        from modules import survey
        plain = self.schema()
        self.assertFalse(plain["randomize_items"])
        self.assertEqual(survey.ordered_for_asking(plain, "k"), (plain, None))
        schema = self.schema(randomize_items=True)
        asked, order = survey.ordered_for_asking(schema, "w|甲||s1|20240213-22:00")
        again, order2 = survey.ordered_for_asking(schema, "w|甲||s1|20240213-22:00")
        other, order3 = survey.ordered_for_asking(schema, "w|乙||s1|20240213-22:00")
        self.assertEqual(order, order2)
        self.assertEqual(sorted(order), ["q%d" % i for i in range(1, 9)])
        self.assertNotEqual(order, order3)
        self.assertEqual([q["id"] for q in schema["questions"]], ["q%d" % i for i in range(1, 9)])
        row = survey.row_for_csv({"_item_order": order}, schema)
        self.assertEqual(row["_item_order"], "|".join(order))
        self.assertIn("_item_order", survey.csv_fieldnames(schema))


class SurveyScheduleTests(unittest.TestCase):
    def test_last_day_and_new_time_frames(self):
        from modules import survey
        schema = survey.validate_schema({"id": "s", "days": [4, "last", 2], "time_frame": "week",
                                         "questions": [{"id": "q1", "text": "t"}]})
        self.assertEqual(schema["days"], [2, 4, "last"])
        self.assertEqual(survey.resolve_days(schema["days"], 7), [2, 4, 7])
        for frame in ("today", "recent", "week", "general"):
            survey.validate_schema({"id": "s", "time_frame": frame, "questions": [{"id": "q1", "text": "t"}]})
        with self.assertRaises(survey.SchemaError):
            survey.validate_schema({"id": "s", "time_frame": "month", "questions": [{"id": "q1", "text": "t"}]})

    def test_schedule_warnings(self):
        from modules.research.world_check import survey_schedule_warnings
        three = {"start_time": "20240213-08:00", "step": 72, "stride": 60}
        self.assertEqual(survey_schedule_warnings({"id": "a", "days": [1, "last"], "trigger_time": "21:00"}, three), [])
        warn = survey_schedule_warnings({"id": "b", "days": [5], "trigger_time": "21:00"}, three)
        self.assertEqual(len(warn), 2)
        self.assertIn("一次也不会施测", warn[1])

    def test_last_day_survey_runs_on_final_day_only(self):
        world = World("v24-lastday")
        world.run.config["custom_surveys"].append({
            "id": "final_wave", "title": "最终波", "display_title": "工作日志", "trigger_time": "21:00",
            "mode": "self", "targets": ["阿伊莎"], "include_reason": False, "days": ["last"], "time_frame": "week",
            "questions": [{"id": "q1", "text": "这一周我感到很累", "type": "likert", "min": 1, "max": 5}]})
        world.step(72)   # 3 days from 02-13 08:00
        path = Path(world.root) / "results" / "surveys" / world.name / "custom_final_wave.jsonl"
        dates = [json.loads(l)["survey_date"] for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
        self.assertEqual(dates, ["20240215"])
