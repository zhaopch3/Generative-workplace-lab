"""Local Research Studio endpoints; mutations require same-origin JSON."""
import time
import threading
from pathlib import Path
from urllib.parse import urlsplit
from flask import Blueprint, jsonify, request, render_template
from . import data, branches
from .common import read_json, jsonl, safe_id, fill_prev_coords

def register(app, hooks):
    bp = Blueprint("studio", __name__)
    cache = {"time": 0, "data": None}
    lock = threading.Lock()

    def catalog():
        with lock:
            if cache["data"] is None or time.monotonic()-cache["time"] > 8:
                cache["data"] = data.catalog(hooks["scan_batches"](), hooks["scan_experiments"]())
                cache["time"] = time.monotonic()
            return cache["data"]

    def selected(body):
        names = set(body.get("worlds") or [])
        worlds = [w for w in catalog()["worlds"] if w["name"] in names]
        if not names or len(worlds) != len(names):
            raise ValueError("请选择有效的历史世界")
        return worlds

    @bp.before_request
    def protect():
        if request.method == "POST":
            origin = request.headers.get("Origin")
            if origin and urlsplit(origin).netloc != request.host:
                return jsonify(ok=False, error="不接受跨站写入"), 403
            if not request.is_json:
                return jsonify(ok=False, error="请使用JSON请求"), 415

    @bp.errorhandler(ValueError)
    def bad(exc):
        return jsonify(ok=False, error=str(exc)), 400

    @bp.route("/research")
    def page():
        return render_template("research.html")

    @bp.route("/experimental")
    def experimental():
        return render_template("experimental.html")

    @bp.route("/api/studio/overview")
    def overview():
        # Landing page needs task metadata, not questionnaire contents.
        batches = hooks["scan_batches"]()
        experiments = hooks["scan_experiments"]()
        batch_names = {r["name"] for b in batches for g in b.get("comparison_groups", []) for r in g["runs"]}
        recent = [{k: b.get(k) for k in ("batch_id", "label", "created_at", "run_count", "statuses", "legacy")}
                  for b in sorted(batches, key=lambda b: b.get("created_at", ""), reverse=True)[:6]]
        single = [{k: e.get(k) for k in ("name", "step", "time", "running")}
                  for e in experiments if e["name"] not in batch_names]
        return jsonify(ok=True, world_count=len(experiments), batch_count=len(batches),
                       batches=recent, single_worlds=single[:8])

    @bp.route("/api/studio/catalog")
    def listing():
        return jsonify(ok=True, **catalog())

    @bp.route("/api/studio/quality", methods=["POST"])
    def quality():
        return jsonify(ok=True, **data.quality_report(selected(request.json)))

    @bp.route("/api/studio/branches/preview", methods=["POST"])
    def branch_preview():
        return jsonify(ok=True, **branches.preview(request.json))

    @bp.route("/api/studio/branches", methods=["POST"])
    def branch_create():
        proposal = branches.preview(request.json)
        if request.json.get("confirm") != proposal["world_count"]:
            raise ValueError("请确认分支数量及API费用")
        result = branches.create(request.json, hooks["batch"], hooks)
        cache["time"] = 0
        return jsonify(ok=True, **result)

    @bp.route("/api/studio/world/<name>/checkpoints")
    def checkpoints(name):
        folder = Path("results/checkpoints") / safe_id(name)
        rows = []
        for path in sorted(folder.glob("simulate-*.json")):
            cfg = read_json(path, {})
            rows.append({"file": path.name, "time": cfg.get("time"), "step": cfg.get("step"), "agents": list(cfg.get("agents", {})),
                         "format": (cfg.get("_snapshot") or {}).get("format", 0)})
        return jsonify(ok=True, checkpoints=rows)

    @bp.route("/api/studio/world/<name>/events")
    def events(name):
        name = safe_id(name)
        def integer(key, default, minimum=0, maximum=None):
            try:
                value = int(request.args.get(key, default))
            except (TypeError, ValueError):
                raise ValueError("{} 必须是整数".format(key))
            if value < minimum or (maximum is not None and value > maximum):
                raise ValueError("{} 超出允许范围".format(key))
            return value

        step = integer("step", 0) if "step" in request.args else None
        paged = "offset" in request.args or "limit" in request.args
        offset = integer("offset", 0)
        limit = integer("limit", 100, 1, 500)
        source = request.args.get("source", "")
        if source not in ("", "timeline", "tasks", "replay"):
            raise ValueError("无效的事件来源")
        types = set(filter(None, request.args.get("types", "").split(",")))
        rows = []
        invalid_rows = 0
        timeline = Path("results/monitor") / name / "timeline.jsonl"
        for kind, path in (("timeline", Path("results/monitor")/name/"timeline.jsonl"),
                           ("tasks", Path("results/tasks")/name/"tasks.jsonl")):
            if source and source != kind and not (source == "replay" and kind == "timeline"):
                continue
            for _, row, error in jsonl(path):
                if error:
                    invalid_rows += 1
                else:
                    rows.append({**row, "kind": kind})
        conversation_path = Path("results/checkpoints") / name / "conversation.json"
        has_conversations = conversation_path.is_file()
        if source == "replay" and has_conversations:
            # Exact recorded timestamps only; never assign an unmatched conversation to a guessed step.
            time_steps = {r.get("time"): r.get("step") for r in steps(name)}
            for row in rows:
                time_steps.setdefault(row.get("sim_time"), row.get("step"))
            conversations = read_json(conversation_path)
            if not isinstance(conversations, dict):
                invalid_rows += 1
                conversations = {}
            for sim_time, sessions in conversations.items():
                if not isinstance(sessions, list):
                    invalid_rows += 1
                    continue
                for session in sessions:
                    if not isinstance(session, dict):
                        invalid_rows += 1
                        continue
                    for context, turns in session.items():
                        if not isinstance(turns, list):
                            invalid_rows += 1
                            continue
                        valid = []
                        for turn in turns:
                            if (isinstance(turn, (list, tuple)) and len(turn) == 2
                                    and all(isinstance(v, str) for v in turn)):
                                valid.append(turn)
                            else:
                                invalid_rows += 1
                        if valid:
                            participants = list(dict.fromkeys(t[0] for t in valid))
                            rows.append({"kind": "conversation", "type": "dialogue",
                                         "step": time_steps.get(sim_time), "sim_time": sim_time,
                                         "agent": "、".join(participants), "participants": participants,
                                         "context": context, "turns": valid,
                                         "text": "\n\n".join(f"{speaker}：{text}" for speaker, text in valid)})
            rows.sort(key=lambda r: str(r.get("sim_time") or ""))
        agent = request.args.get("agent")
        query = request.args.get("q", "").casefold()
        import json
        rows = [r for r in rows if (not agent or r.get("agent")==agent or agent in r.get("participants", []))
                and (step is None or str(r.get("step")) == str(step))
                and (not types or r.get("type") in types)
                and (not query or query in json.dumps(r,ensure_ascii=False).casefold())]
        # Pagination preserves file order, including multiple events within one step.
        # Keep the diagnostic page's existing latest-1000 contract when unpaged.
        page = rows[offset:offset+limit] if paged else rows[-1000:]
        end = offset + len(page)
        return jsonify(ok=True, total=len(rows), events=page, offset=offset,
                       next_offset=end if paged and end < len(rows) else None,
                       has_timeline=timeline.is_file(), has_conversations=has_conversations,
                       invalid_rows=invalid_rows)

    @bp.route("/api/studio/operations", methods=["POST"])
    def operations():
        from .operations import summarize
        return jsonify(ok=True, **summarize(selected(request.json)))

    def steps(name):
        path = Path("results/monitor") / safe_id(name) / "steps.jsonl"
        return fill_prev_coords([row for _,row,error in jsonl(path) if not error])

    @bp.route("/api/studio/world/<name>/steps/meta")
    def steps_meta(name):
        rows = steps(name)
        return jsonify(min=rows[0]["step"] if rows else 0, max=rows[-1]["step"] if rows else 0,
                       latest_time=rows[-1]["time"] if rows else "")

    @bp.route("/api/studio/world/<name>/steps")
    def step(name):
        value = request.args.get("step", type=int)
        row = next((r for r in steps(name) if r["step"] == value), None)
        return jsonify(ok=bool(row), record=row)

    @bp.route("/research/world/<name>")
    def viewer(name):
        rows = steps(name)
        if not rows:
            raise ValueError("该世界没有可回放的轨迹记录")
        cfg = data.latest_config(name)
        positions = {n: a.get("prev_coord") or a.get("coord") for n,a in rows[0]["agents"].items()}
        return render_template("live.html", persona_names=list(positions), persona_init_pos=positions,
                               navigation_policy=cfg.get("navigation_policy", "legacy"),
                               sim_name=name, condition=cfg.get("batch",{}).get("group") or cfg.get("experiment",{}).get("condition",""),
                               zoom=0, embed=False, historical=True,
                               steps_api="/api/studio/world/"+name+"/steps")

    app.register_blueprint(bp)
