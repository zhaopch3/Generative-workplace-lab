# -*- coding: utf-8 -*-
import json
import os
import tempfile
import unittest
from unittest import mock

import server
from modules import exporter


class BatchWorkflowTests(unittest.TestCase):
    def test_terminal_runtime_registry_skips_slow_http_probe(self):
        with tempfile.TemporaryDirectory() as root:
            old_checkpoints = server.CHECKPOINTS_PATH
            server.CHECKPOINTS_PATH = root
            try:
                name = "finished-world"
                folder = os.path.join(root, name)
                os.makedirs(folder)
                with open(os.path.join(folder, server.RUNTIME_FILE), "w", encoding="utf-8") as f:
                    json.dump({"name": name, "port": 5999, "status": "finished"}, f)
                with mock.patch("urllib.request.urlopen") as urlopen:
                    self.assertIsNone(server.probe_runtime(name))
                urlopen.assert_not_called()
            finally:
                server.CHECKPOINTS_PATH = old_checkpoints

    def test_atomic_json_retries_transient_windows_replace_failure(self):
        with tempfile.TemporaryDirectory() as root:
            path = os.path.join(root, "manifest.json")
            transient = PermissionError("target is temporarily busy")
            real_replace = os.replace
            calls = {"count": 0}

            def flaky_replace(source, target):
                calls["count"] += 1
                if calls["count"] == 1:
                    raise transient
                return real_replace(source, target)

            with mock.patch.object(server.os, "replace", side_effect=flaky_replace), \
                    mock.patch.object(server.time, "sleep") as sleep:
                server._atomic_json(path, {"ok": True})
            with open(path, "r", encoding="utf-8") as f:
                self.assertEqual(json.load(f), {"ok": True})
            self.assertEqual(calls["count"], 2)
            sleep.assert_called_once()

    def test_comparison_signature_ignores_run_identity_but_not_design(self):
        base = {
            "name": "run-01", "step": 48, "stride": 60,
            "agents": ["甲", "乙"], "condition": "low",
            "custom_surveys": [{"id": "s1", "questions": [{"id": "q1", "min": 1, "max": 5}]}],
            "_batch": {"batch_id": "old", "replicate": 1},
        }
        replicate = json.loads(json.dumps(base, ensure_ascii=False))
        replicate["name"] = "run-02"
        replicate["_batch"] = {"batch_id": "new", "replicate": 2}
        changed = json.loads(json.dumps(base, ensure_ascii=False))
        changed["custom_surveys"][0]["questions"][0]["max"] = 7
        self.assertEqual(server.comparison_signature(base), server.comparison_signature(replicate))
        self.assertNotEqual(server.comparison_signature(base), server.comparison_signature(changed))

    def test_batch_is_split_into_comparable_config_groups(self):
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                batch_dir = os.path.join("results", "batch", "b")
                os.makedirs(batch_dir)
                runs = []
                designs = {
                    "b-low-01": {"name": "b-low-01", "step": 48, "stride": 60,
                                 "condition": "low", "agents": ["甲"],
                                 "custom_surveys": [{"id": "full"}]},
                    "b-low-02": {"name": "b-low-02", "step": 48, "stride": 60,
                                 "condition": "low", "agents": ["甲"],
                                 "custom_surveys": [{"id": "full"}]},
                    "b-high-01": {"name": "b-high-01", "step": 48, "stride": 60,
                                  "condition": "high", "agents": ["甲"],
                                  "custom_surveys": []},
                }
                for name, payload in designs.items():
                    checkpoint = os.path.join("results", "checkpoints", name)
                    os.makedirs(checkpoint)
                    with open(os.path.join(checkpoint, "simulate-1.json"), "w", encoding="utf-8") as f:
                        json.dump({"setup_payload": payload}, f, ensure_ascii=False)
                    group = "low" if "low" in name else "high"
                    runs.append({"name": name, "group": group, "condition": group,
                                 "replicate": 1, "status": "已完成"})
                with open(os.path.join(batch_dir, server.BATCH_MANIFEST), "w", encoding="utf-8") as f:
                    json.dump({"batch_id": "b", "prefix": "b", "label": "测试批次",
                               "created_at": "now", "parallel": 1, "runs": runs}, f,
                              ensure_ascii=False)
                groups = server.comparison_groups_for_batch("b")
                self.assertEqual(len(groups), 2)
                self.assertEqual(sorted(group["run_count"] for group in groups), [1, 2])
                with self.assertRaisesRegex(ValueError, "不能合并成一份数据"):
                    server.aggregate_prefix("b")
            finally:
                os.chdir(old_cwd)

    def test_new_batches_get_unique_ids_even_with_same_display_name(self):
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                payload = {
                    "name_prefix": "同名批次", "conditions": ["low", "high"],
                    "replicates": 1, "parallel": 1, "agents": ["甲"],
                    "step": 2, "stride": 10, "offline": True,
                }
                ids = []
                with mock.patch.object(server, "_available_ports", return_value=[5101, 5102]):
                    for _ in range(2):
                        manager = server.BatchManager()
                        manager._start_thread = mock.Mock()
                        info = manager.start(payload)
                        ids.append(info["batch_id"])
                        self.assertEqual(info["label"], "同名批次")
                        self.assertEqual(len(manager.batch["runs"]), 2)
                        self.assertTrue(all("-G0" in run["name"] for run in manager.batch["runs"]))
                self.assertNotEqual(ids[0], ids[1])
            finally:
                os.chdir(old_cwd)

    def test_batch_parallel_is_capped_at_ten(self):
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                manager = server.BatchManager()
                manager._start_thread = mock.Mock()
                payload = {
                    "name_prefix": "并行上限测试", "conditions": ["low"],
                    "replicates": 1, "parallel": 99, "agents": ["甲"],
                    "step": 2, "stride": 10, "offline": True,
                }
                with mock.patch.object(server, "_available_ports", return_value=[5101]):
                    info = manager.start(payload)
                self.assertEqual(info["parallel"], 10)
                self.assertEqual(manager.batch["parallel"], 10)
            finally:
                os.chdir(old_cwd)

    def test_snapshot_does_not_reacquire_non_reentrant_lock(self):
        manager = server.BatchManager()
        manager.batch = {
            "batch_id": "b", "prefix": "b", "parallel": 1,
            "created_at": "now", "aggregated": False, "agg_dir": "",
            "runs": [{
                "name": "b-g-01", "group": "g", "condition": "c",
                "replicate": 1, "port": 5002, "status": "运行中",
                "step": 1, "total": 2, "cfg_path": "unused", "error": "",
            }],
        }
        snapshot = manager.snapshot()
        self.assertTrue(snapshot["active"])
        self.assertEqual(snapshot["runs"][0]["replicate"], 1)

    def test_same_time_surveys_merge_into_qualtrics_style_row(self):
        with tempfile.TemporaryDirectory() as root:
            old_root = exporter.RESULTS_ROOT
            exporter.RESULTS_ROOT = root
            try:
                survey_dir = os.path.join(root, "surveys", "run-1")
                os.makedirs(survey_dir)
                rows = [
                    ("custom_a.jsonl", {"survey_id": "a", "run_id": "run-1",
                     "survey_date": "20240101", "survey_time": "20240101-22:00",
                     "agent": "甲", "q1": 3}),
                    ("custom_b.jsonl", {"survey_id": "b", "run_id": "run-1",
                     "survey_date": "20240101", "survey_time": "20240101-22:00",
                     "agent": "甲", "q2": 5}),
                ]
                for filename, row in rows:
                    with open(os.path.join(survey_dir, filename), "w", encoding="utf-8") as f:
                        f.write(json.dumps(row, ensure_ascii=False) + "\n")
                output = exporter.build_responses([{
                    "name": "run-1", "batch_id": "batch-1", "group": "g",
                    "condition": "c", "replicate": 1,
                }])
                self.assertEqual(len(output), 1)
                self.assertEqual(output[0]["survey_ids"], "a|b")
                self.assertEqual(output[0]["a__q1"], 3)
                self.assertEqual(output[0]["b__q2"], 5)
            finally:
                exporter.RESULTS_ROOT = old_root

    def test_failed_run_with_checkpoint_is_requeued_as_resume(self):
        manager = server.BatchManager()
        manager.batch = {
            "batch_id": "b", "prefix": "b", "parallel": 1,
            "created_at": "now", "aggregated": False, "agg_dir": "",
            "runs": [{
                "name": "b-g-01", "group": "g", "condition": "c",
                "replicate": 1, "port": 5002, "status": "失败",
                "step": 0, "total": 10, "stride": 10, "offline": True,
                "cfg_path": "unused", "error": "boom",
            }],
        }
        manager._disk_step = lambda name: 4
        manager._save_manifest_unlocked = lambda: None

        class AliveThread:
            @staticmethod
            def is_alive():
                return True

        manager.thread = AliveThread()
        self.assertEqual(manager.retry_failed(), 1)
        run = manager.batch["runs"][0]
        self.assertTrue(run["resume"])
        self.assertEqual(run["step"], 4)
        self.assertEqual(run["status"], "排队中")

    def test_latest_manifest_restores_live_child_after_main_restart(self):
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                batch_dir = os.path.join("results", "batch", "recover")
                checkpoint_dir = os.path.join("results", "checkpoints", "recover-g-01")
                os.makedirs(batch_dir)
                os.makedirs(checkpoint_dir)
                with open(os.path.join(checkpoint_dir, "simulate-5.json"), "w", encoding="utf-8") as f:
                    json.dump({"step": 5}, f)
                manifest = {
                    "batch_id": "recover", "prefix": "recover", "parallel": 1,
                    "created_at": "now", "runs": [{
                        "name": "recover-g-01", "group": "g", "condition": "c",
                        "replicate": 1, "port": 5002, "status": "运行中",
                        "step": 4, "total": 10, "stride": 10, "offline": True,
                        "cfg_path": "unused", "error": "",
                    }],
                }
                with open(os.path.join(batch_dir, server.BATCH_MANIFEST), "w", encoding="utf-8") as f:
                    json.dump(manifest, f, ensure_ascii=False)
                manager = server.BatchManager()
                manager._start_thread = mock.Mock()
                live = {"status": "paused", "port": 5311, "step": 6,
                        "cockpit_url": "/cockpit"}
                with mock.patch.object(server, "probe_runtime", return_value=live):
                    self.assertTrue(manager.restore_latest())
                run = manager.batch["runs"][0]
                self.assertEqual(run["status"], "运行中")
                self.assertEqual(run["port"], 5311)
                self.assertEqual(run["step"], 6)
                self.assertEqual(run["live"]["status"], "paused")
                manager._start_thread.assert_called_once_with()
            finally:
                os.chdir(old_cwd)

    def test_restored_unreachable_child_is_requeued_instead_of_failed(self):
        manager = server.BatchManager()
        manager.batch = {
            "batch_id": "recover", "prefix": "recover", "parallel": 1,
            "created_at": "now", "aggregated": False, "agg_dir": "",
            "runs": [{
                "name": "recover-g-01", "group": "g", "condition": "c",
                "replicate": 1, "port": 5002, "status": "运行中",
                "step": 0, "total": 24, "stride": 60, "offline": False,
                "cfg_path": "unused", "error": "", "proc": None,
                "live": None, "_misses": 2,
            }],
        }
        manager.generation = 1
        manager._poll_child = mock.Mock(return_value=None)
        manager._disk_step = mock.Mock(return_value=0)
        manager._save_manifest_unlocked = mock.Mock(return_value=True)

        def end_loop(_seconds):
            manager.generation += 1

        with mock.patch.object(server.time, "sleep", side_effect=end_loop):
            manager._loop(generation=1)

        run = manager.batch["runs"][0]
        self.assertEqual(run["status"], "排队中")
        self.assertFalse(run["resume"])
        self.assertEqual(run["error"], "")

    def test_restored_child_without_process_handle_can_be_stopped(self):
        manager = server.BatchManager()
        manager.batch = {
            "batch_id": "b", "prefix": "b", "parallel": 1,
            "created_at": "now", "aggregated": False, "agg_dir": "",
            "runs": [{
                "name": "b-g-01", "group": "g", "condition": "c",
                "replicate": 1, "port": 5002, "status": "运行中",
                "step": 1, "total": 10, "proc": None, "live": {"status": "running"},
            }],
        }
        manager._request_child_stop = mock.Mock(return_value=True)
        manager._save_manifest_unlocked = mock.Mock()
        self.assertEqual(manager.stop(), 1)
        self.assertEqual(manager.batch["runs"][0]["status"], "已停止")
        manager._request_child_stop.assert_called_once_with(5002)

    def test_delete_releases_finished_runner_before_removing_files(self):
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                name = "delete-check"
                for sub in ("checkpoints", "surveys", "psych", "monitor", "interventions"):
                    path = os.path.join("results", sub, name)
                    os.makedirs(path)
                    with open(os.path.join(path, "data.txt"), "w", encoding="utf-8") as f:
                        f.write("x")

                class FinishedRunner:
                    state = {"status": "finished"}

                    def __init__(self):
                        self.name = name

                holder = {"runner": FinishedRunner()}
                app = server.create_app(holder)
                real_rmtree = server.shutil.rmtree

                def checked_rmtree(path):
                    self.assertIsNone(holder["runner"])
                    return real_rmtree(path)

                with mock.patch.object(server.shutil, "rmtree", side_effect=checked_rmtree):
                    response = app.test_client().post(
                        "/api/delete_experiment", json={"name": name}
                    )
                self.assertEqual(response.status_code, 200)
                self.assertTrue(response.get_json()["ok"])
            finally:
                os.chdir(old_cwd)

    def test_stopped_batch_can_be_deleted_as_one_unit(self):
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                batch_id = "batch-delete"
                run_names = ["batch-delete-G01-01", "batch-delete-G01-02"]
                batch_dir = os.path.join("results", "batch", batch_id)
                os.makedirs(batch_dir)
                manifest = {
                    "batch_id": batch_id,
                    "prefix": batch_id,
                    "label": "待删除批次",
                    "runs": [{"name": name, "status": "已停止"} for name in run_names],
                }
                with open(os.path.join(batch_dir, server.BATCH_MANIFEST), "w", encoding="utf-8") as f:
                    json.dump(manifest, f, ensure_ascii=False)
                for name in run_names:
                    for sub in ("checkpoints", "surveys", "psych", "monitor", "interventions"):
                        folder = os.path.join("results", sub, name)
                        os.makedirs(folder)
                        with open(os.path.join(folder, "data.txt"), "w", encoding="utf-8") as f:
                            f.write("x")

                manager = server.BatchManager()
                manager.batch = {
                    "batch_id": batch_id, "prefix": batch_id, "parallel": 1,
                    "created_at": "now", "aggregated": False, "agg_dir": "",
                    "runs": [{"name": name, "status": "已停止"} for name in run_names],
                }
                holder = {"runner": None}
                with mock.patch.object(server, "BATCH", manager):
                    response = server.create_app(holder).test_client().post(
                        "/api/delete_batch", json={"batch_id": batch_id}
                    )
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.get_json()["deleted_worlds"], 2)
                self.assertIsNone(manager.batch)
                self.assertFalse(os.path.exists(batch_dir))
                for name in run_names:
                    for sub in ("checkpoints", "surveys", "psych", "monitor", "interventions"):
                        self.assertFalse(os.path.exists(os.path.join("results", sub, name)))
            finally:
                os.chdir(old_cwd)

    def test_running_batch_delete_is_refused(self):
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                batch_id = "batch-running"
                batch_dir = os.path.join("results", "batch", batch_id)
                os.makedirs(batch_dir)
                with open(os.path.join(batch_dir, server.BATCH_MANIFEST), "w", encoding="utf-8") as f:
                    json.dump({
                        "batch_id": batch_id, "prefix": batch_id,
                        "runs": [{"name": "batch-running-G01-01", "status": "运行中"}],
                    }, f, ensure_ascii=False)
                manager = server.BatchManager()
                manager.batch = {
                    "batch_id": batch_id, "prefix": batch_id, "parallel": 1,
                    "created_at": "now", "runs": [{
                        "name": "batch-running-G01-01", "status": "运行中",
                    }],
                }
                with mock.patch.object(server, "BATCH", manager):
                    response = server.create_app({"runner": None}).test_client().post(
                        "/api/delete_batch", json={"batch_id": batch_id}
                    )
                self.assertEqual(response.status_code, 409)
                self.assertTrue(os.path.isdir(batch_dir))
            finally:
                os.chdir(old_cwd)

    def test_batch_marked_deleting_is_immediately_hidden_from_history(self):
        with tempfile.TemporaryDirectory() as root:
            old_cwd = os.getcwd()
            os.chdir(root)
            try:
                batch_id = "batch-deleting"
                batch_dir = os.path.join("results", "batch", batch_id)
                os.makedirs(batch_dir)
                with open(os.path.join(batch_dir, server.BATCH_MANIFEST), "w", encoding="utf-8") as f:
                    json.dump({
                        "batch_id": batch_id, "prefix": batch_id,
                        "runs": [{"name": "batch-deleting-G01-01", "status": "已停止"}],
                    }, f, ensure_ascii=False)
                with open(os.path.join(batch_dir, server.BATCH_DELETE_MARKER), "w", encoding="utf-8") as f:
                    f.write("now")
                self.assertEqual(server.scan_batches(), [])
                manager = server.BatchManager()
                self.assertFalse(manager.restore_latest())
                self.assertIsNone(manager.batch)
            finally:
                os.chdir(old_cwd)


if __name__ == "__main__":
    unittest.main()
