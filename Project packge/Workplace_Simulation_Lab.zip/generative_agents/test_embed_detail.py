import requests
import json

# 测试实际的embedding调用
url = "http://localhost:11434/api/embeddings"
data = {
    "model": "bge-m3:latest",
    "prompt": "这是 阿伊莎 在 2025年02月13日的计划"
}

print("发送请求...")
response = requests.post(url, json=data)
print(f"状态码: {response.status_code}")

if response.status_code == 200:
    result = response.json()
    print(f"Embedding长度: {len(result.get('embedding', []))}")
else:
    print(f"错误响应: {response.text}")

# 测试不同的API端点
print("\n测试 /v1/embeddings 端点...")
url2 = "http://localhost:11434/v1/embeddings"
response2 = requests.post(url2, json=data)
print(f"状态码: {response2.status_code}")