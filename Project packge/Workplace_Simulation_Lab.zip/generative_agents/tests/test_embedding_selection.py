import copy
import json
import unittest
from pathlib import Path

import server


ROOT = Path(__file__).resolve().parents[1]


class EmbeddingSelectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = json.loads(
            (ROOT / "data/world_presets/人设操纵-低辱虐组.json").read_text(encoding="utf-8")
        )

    def build(self, embedding_type):
        payload = copy.deepcopy(self.base)
        payload.update(
            name="embedding-selection-test-" + (embedding_type or "inherit"),
            embedding_type=embedding_type,
            offline=False,
        )
        return server.build_experiment_config(payload)[2]

    def test_ollama_bge_m3_is_locked_into_checkpoint_config(self):
        cfg = self.build("ollama")
        emb = cfg["agent_base"]["associate"]["embedding"]
        self.assertEqual(emb["type"], "ollama")
        self.assertEqual(emb["model"], "bge-m3:latest")
        self.assertEqual(cfg["model_assignment"]["embedding"], emb)

    def test_openrouter_small_embedding_is_locked_into_checkpoint_config(self):
        cfg = self.build("openrouter")
        emb = cfg["agent_base"]["associate"]["embedding"]
        self.assertEqual(emb["type"], "openrouter")
        self.assertEqual(emb["model"], "openai/text-embedding-3-small")
        self.assertEqual(cfg["setup_payload"]["embedding_type"], "openrouter")

    def test_unknown_embedding_type_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "Embedding"):
            self.build("unknown")


if __name__ == "__main__":
    unittest.main()
