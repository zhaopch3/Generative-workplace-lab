"""Historical replay reads the selected world's records without running agents."""
import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from flask import Flask
from modules.research import api


class ReplayTimelineTests(unittest.TestCase):
    def test_original_dialogue_is_distinct_and_exactly_timed(self):
        app = Flask(__name__)
        api.register(app, {})
        origin = Path.cwd()
        with tempfile.TemporaryDirectory() as folder:
            os.chdir(folder)
            try:
                monitor = Path('results/monitor/demo')
                monitor.mkdir(parents=True)
                (monitor / 'steps.jsonl').write_text(json.dumps({'step': 3, 'time': '20240213-11:30'})+'\n', encoding='utf-8')
                (monitor / 'timeline.jsonl').write_text(json.dumps({'step': 4, 'sim_time': '20240213-12:30',
                    'agent': '克劳斯', 'type': 'chat', 'text': '这只是摘要'})+'\n', encoding='utf-8')
                checkpoint = Path('results/checkpoints/demo')
                checkpoint.mkdir(parents=True)
                dialogue = {'20240213-11:30': [{'阿伊莎 -> 克劳斯 @ 办公室': [
                    ['阿伊莎', '需要一些资料。'], ['克劳斯', '<script>我来提供资料。</script>']]}],
                    '20240213-11:45': [{'未匹配步骤': [['克劳斯', '只有时间记录。']]}]}
                path = checkpoint / 'conversation.json'
                path.write_text(json.dumps(dialogue, ensure_ascii=False), encoding='utf-8')
                before = {p: p.read_bytes() for p in Path('results').rglob('*') if p.is_file()}
                client = app.test_client()
                url = '/api/studio/world/demo/events'
                response = client.get(url, query_string={'source':'replay', 'step':3,
                    'types':'dialogue', 'agent':'克劳斯', 'q':'提供资料', 'offset':0}).json
                self.assertEqual(response['total'], 1)
                self.assertTrue(response['has_conversations'])
                row = response['events'][0]
                self.assertEqual(row['turns'], dialogue['20240213-11:30'][0]['阿伊莎 -> 克劳斯 @ 办公室'])
                self.assertEqual(row['step'], 3)
                self.assertIn('阿伊莎：需要一些资料。', row['text'])
                self.assertIn('克劳斯：<script>我来提供资料。</script>', row['text'])
                self.assertEqual(client.get(url+'?source=replay&step=4&types=dialogue&offset=0').json['total'], 0)
                all_rows = client.get(url+'?source=replay&types=dialogue&offset=0').json['events']
                self.assertEqual(len(all_rows), 2)
                self.assertIsNone(all_rows[1]['step'])
                self.assertEqual(client.get(url+'?source=timeline&offset=0').json['total'], 1)
                self.assertEqual(client.get(url+'?source=replay&types=chat&offset=0').json['events'][0]['text'], '这只是摘要')
                self.assertEqual(client.get('/api/studio/world/other/events?source=replay&offset=0').json['events'], [])
                self.assertEqual(before, {p: p.read_bytes() for p in Path('results').rglob('*') if p.is_file()})
            finally:
                os.chdir(origin)

    def test_history_filter_pagination_rendering_and_readonly(self):
        project = Path(__file__).resolve().parents[1]
        app = Flask(__name__, template_folder=str(project / 'frontend/templates'))
        api.register(app, {})  # No runner, model, or batch manager is needed.
        origin = Path.cwd()
        with tempfile.TemporaryDirectory() as folder:
            os.chdir(folder)
            try:
                monitor = Path('results/monitor/世界A')
                monitor.mkdir(parents=True)
                rows = [{'step': 1, 'sim_time': '20240213-09:30', 'agent': '阿伊莎',
                         'type': 'thought', 'text': f'思考 {i}'} for i in range(1005)]
                rows += [{'step': 2, 'sim_time': '20240213-10:30', 'agent': '玛丽亚',
                          'type': 'chat', 'text': '<script>原始对话</script>\n第二行'}]
                timeline = monitor / 'timeline.jsonl'
                timeline.write_text('\n'.join(json.dumps(r, ensure_ascii=False) for r in rows) + '\nbroken\n', encoding='utf-8')
                (monitor / 'steps.jsonl').write_text(json.dumps({'step': 1, 'time': '20240213-09:30',
                    'agents': {'阿伊莎': {'coord': [1, 2]}}})+'\n', encoding='utf-8')
                other = Path('results/monitor/世界B')
                other.mkdir()
                (other / 'timeline.jsonl').write_text(json.dumps({'step':1, 'text':'other world'}), encoding='utf-8')
                tasks = Path('results/tasks/世界A')
                tasks.mkdir(parents=True)
                (tasks / 'tasks.jsonl').write_text(json.dumps({'step':1,'text':'task only'}), encoding='utf-8')
                files = list(Path('results').rglob('*.jsonl'))
                hashes = {p:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
                client = app.test_client()
                url = '/api/studio/world/世界A/events'
                first = client.get(url, query_string={'source':'timeline','step':1,'offset':0,'limit':500}).json
                self.assertEqual(first['total'], 1005)
                self.assertEqual(first['events'][0]['text'], '思考 0')
                self.assertEqual(first['next_offset'], 500)
                self.assertEqual(first['invalid_rows'], 1)
                last = client.get(url, query_string={'source':'timeline','step':1,'offset':1000,'limit':500}).json
                self.assertEqual(len(last['events']), 5)
                self.assertEqual(last['events'][-1]['text'], '思考 1004')
                self.assertIsNone(last['next_offset'])
                filtered = client.get(url, query_string={'source':'timeline','step':2,'agent':'玛丽亚',
                    'types':'chat','q':'原始对话','offset':0}).json
                self.assertEqual(filtered['events'], [{**rows[-1], 'kind':'timeline'}])
                self.assertEqual(client.get(url+'?step=1&types=chat&offset=0').json['total'], 0)
                legacy = client.get(url).json
                self.assertEqual(len(legacy['events']), 1000)
                self.assertEqual(legacy['events'][-1]['text'], 'task only')
                missing = client.get('/api/studio/world/missing/events?offset=0').json
                self.assertFalse(missing['has_timeline'])
                self.assertEqual(missing['events'], [])
                for query in ('step=bad','step=-1','offset=-1','limit=0','limit=501','source=bad'):
                    self.assertEqual(client.get(url+'?'+query).status_code, 400, query)
                with patch.object(api.data, 'latest_config', return_value={}):
                    page = client.get('/research/world/世界A')
                self.assertEqual(page.status_code, 200)
                html = page.get_data(as_text=True)
                self.assertIn('历史事件时间线', html)
                self.assertIn('replay-timeline.js', html)
                self.assertIn('全部历史记录', html)
                self.assertEqual(hashes, {p:hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
                self.assertEqual(set(files), set(Path('results').rglob('*.jsonl')))
            finally:
                os.chdir(origin)


if __name__ == '__main__':
    unittest.main()
