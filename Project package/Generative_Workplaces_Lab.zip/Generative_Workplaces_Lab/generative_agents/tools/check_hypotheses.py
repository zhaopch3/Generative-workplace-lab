# -*- coding: utf-8 -*-
"""V24: rough replication check of the included hypotheses on one downloaded batch.

Run from generative_agents/:

    python tools/check_hypotheses.py <编码总表_无损合并.xlsx> <整批下载.zip 或解压后的目录> [输出.csv] [--boot 5000]

This is a screening tool, not the paper's analysis:
- each variable is scored per person (world x agent) as the mean of its items rescaled to 0-1,
  averaged over administrations; dyadic surveys are scored for the ratee, averaged over raters;
- variables that were experimental manipulations of abuse use the condition (high = 1, low = 0);
- direct effects: OLS slope of Y on X; supported = predicted sign and p < .05;
- mediation: every path (X->M1, M1->M2, ..., M->Y, each controlling X and earlier mediators)
  significant and the product in the predicted sign;
- persons are treated as independent (nesting in worlds is ignored), so p-values are optimistic.
With --boot N (2026-10-29) every hypothesis is judged instead by a cluster bootstrap that resamples
whole worlds (N draws, fixed seed): direct effects by the 95% percentile interval of the slope,
mediation by the 95% interval of the indirect effect (product of the paths, as in Preacher & Hayes);
supported = interval excludes 0 in the predicted sign (a predicted null: interval includes 0).
Corrections to the coding sheet (prediction signs, reverse-keyed items, design mismatches) are read
from data/analysis/hypothesis_corrections.json.
"""
import collections
import csv
import io
import json
import os
import re
import sys
import zipfile

import numpy as np
from scipy import stats

sys.path.insert(0, os.getcwd())
sys.path.insert(0, os.path.join(os.getcwd(), "tools"))
import build_v24_battery as battery  # noqa: E402

CORRECTIONS = os.path.join("data", "analysis", "hypothesis_corrections.json")
MANIPULATION_NAME = re.compile(r"manipulat|condition", re.I)


class Export:
    """responses.csv and codebook.csv from every group folder of a downloaded batch."""

    def __init__(self, path):
        self.responses, self.codebook = [], collections.defaultdict(list)
        if os.path.isdir(path):
            files = {os.path.relpath(os.path.join(r, f), path).replace(os.sep, "/"): os.path.join(r, f)
                     for r, _, fs in os.walk(path) for f in fs}
            read = lambda key: open(files[key], encoding="utf-8-sig").read()  # noqa: E731
        else:
            z = zipfile.ZipFile(path)
            files = {n: n for n in z.namelist()}
            read = lambda key: z.read(files[key]).decode("utf-8-sig")  # noqa: E731
        seen_codebook = False
        for name in sorted(files):
            if name.endswith("responses.csv"):
                self.responses += list(csv.DictReader(io.StringIO(read(name))))
            elif name.endswith("codebook.csv") and not seen_codebook:
                for row in csv.DictReader(io.StringIO(read(name))):
                    self.codebook[row["survey_id"]].append(row)
                seen_codebook = True
        conds = sorted({r["condition"] for r in self.responses})
        self.high = next(c for c in conds if "high" in c)
        self.low = next(c for c in conds if "low" in c)
        self.replicates = sorted({r["replicate"] for r in self.responses})


def reversed_anchor(question):
    lo, hi = (question.get("min_label") or "").lower(), (question.get("max_label") or "").lower()
    return "agree" in lo and "disagree" in hi and "disagree" not in lo


class Scorer:
    def __init__(self, export, corrections):
        self.export = export
        self.reverse = corrections.get("reverse_items", [])
        self.cache = {}

    def reverse_ids(self, survey):
        ids = {q["id"] for q in survey["questions"] if reversed_anchor(q)}
        for entry in self.reverse:
            if survey["id"] in entry["surveys"]:
                ids ^= set(entry["items"])
        return ids

    def scores(self, survey):
        sid = survey["id"]
        if sid in self.cache:
            return self.cache[sid]
        rev = self.reverse_ids(survey)
        cols = [c for c in self.export.codebook[sid] if c["type"] in ("likert", "number")]
        acc = collections.defaultdict(list)
        for r in self.export.responses:
            if sid not in r["survey_ids"].split("|"):
                continue
            vals = []
            for c in cols:
                v = r.get(c["column"], "")
                if v == "":
                    continue
                lo, hi = float(c["min"]), float(c["max"])
                x = (float(v) - lo) / (hi - lo) if hi > lo else float(v)
                vals.append(1 - x if c["question_id"] in rev else x)
            if vals:
                person = r["ratee"] if survey.get("mode") == "dyadic" and r["ratee"] else r["agent"]
                acc[(r["condition"], r["replicate"], person)].append(sum(vals) / len(vals))
        self.cache[sid] = {k: sum(v) / len(v) for k, v in acc.items()}
        return self.cache[sid]


def ols(y, xs):
    X = np.column_stack([np.ones(len(y))] + xs)
    n, k = X.shape
    if n <= k + 1:
        return None
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ beta
    cov = (resid @ resid / (n - k)) * np.linalg.pinv(X.T @ X)
    se = np.sqrt(np.diag(cov))
    with np.errstate(divide="ignore", invalid="ignore"):
        p = 2 * stats.t.sf(np.abs(beta / se), n - k)
    return beta[1:], p[1:]


def effect_of(arr, n_m):
    """Slope of Y on X (no mediator) or the product of the mediation paths."""
    X, Y = arr[:, 0], arr[:, -1]
    if n_m == 0:
        res = ols(Y, [X])
        return None if res is None else res[0][0]
    prev, effect = [X], 1.0
    for i in range(n_m):
        res = ols(arr[:, i + 1], prev)
        if res is None:
            return None
        effect *= res[0][-1]
        prev = prev + [arr[:, i + 1]]
    res = ols(Y, prev)
    return None if res is None else effect * res[0][-1]


def cluster_boot(arr, clusters, n_m, draws, seed=20261029):
    """95% percentile interval of the effect, resampling whole worlds with replacement."""
    est = effect_of(arr, n_m)
    if est is None:
        return None, None, None
    names = sorted(set(clusters))
    rows = {c: np.where(clusters == c)[0] for c in names}
    rng = np.random.default_rng(seed)
    values = []
    with np.errstate(all="ignore"):
        for _ in range(draws):
            pick = rng.choice(len(names), len(names), replace=True)
            idx = np.concatenate([rows[names[i]] for i in pick])
            sample = arr[idx]
            if np.std(sample[:, 0]) == 0 or np.std(sample[:, -1]) == 0:
                continue
            v = effect_of(sample, n_m)
            if v is not None and np.isfinite(v):
                values.append(v)
    if len(values) < draws * 0.5:
        return None, None, None
    lo, hi = np.percentile(values, [2.5, 97.5])
    return float(lo), float(hi), float(est)


def id_list(text):
    if not text:
        return []
    try:
        value = json.loads(text)
    except (TypeError, ValueError):
        return [text]
    return value if isinstance(value, list) else [value]


def main(workbook, export_path, out_csv=None, boot=0):
    corrections = json.load(open(CORRECTIONS, encoding="utf-8"))
    overrides = {(c["paper_id"], c["study_id"], c["h_id"]): c["prediction"] for c in corrections["prediction_overrides"]}
    manipulated = {(v["paper_id"], v["study_id"], v["var_id"]) for v in corrections["manipulated_abuse_variables"]["variables"]}
    mismatch = {c["paper_id"]: c["reason"] for c in corrections["design_mismatch"]}

    data = json.load(open(battery.BATTERY_PATH, encoding="utf-8"))
    var_survey = {(s["paper_id"], s["study_id"], s["var_id"]): e["survey"] for e in data["surveys"] for s in e["sources"]}
    _, hyp_rows = battery.load_rows(workbook)
    decision = "实施决定（2026-10-25）"
    hyps = [h for h in hyp_rows if str(h.get(decision) or "").startswith("纳入")
            and h["paper_id"] not in battery.EXCLUDED_PAPERS
            and (h["paper_id"], h["study_id"], str(h["h_id"]).split("_")[0]) not in battery.EXCLUDED_HYPOTHESES
            and (battery.INCLUDE_PENDING or True)]

    export = Export(export_path)
    scorer = Scorer(export, corrections)
    units_world = [(c, r) for c in (export.high, export.low) for r in export.replicates]

    def variable(h, vid, name):
        key = (h["paper_id"], h["study_id"], vid)
        if key in manipulated:
            return ("condition", None)
        if key in var_survey:
            return ("survey", var_survey[key])
        if re.search(r"abus", str(name or ""), re.I) and MANIPULATION_NAME.search(str(name or "")):
            return ("condition", None)
        return None

    def table(vars_, with_clusters=False):
        maps = [scorer.scores(s) for kind, s in vars_ if kind == "survey"]
        common = set.intersection(*[set(m) for m in maps]) if maps else set()
        if len(common) >= 8:
            units, level = sorted(common), "person"
        else:
            units, level = units_world, "world"
        cols = []
        for kind, s in vars_:
            if kind == "condition":
                cols.append([1.0 if u[0] == export.high else 0.0 for u in units])
                continue
            sc = scorer.scores(s)
            if level == "person":
                cols.append([sc[u] for u in units])
            else:
                agg = collections.defaultdict(list)
                for k, v in sc.items():
                    agg[(k[0], k[1])].append(v)
                cols.append([float(np.mean(agg[u])) if agg.get(u) else np.nan for u in units])
        arr = np.array(cols, dtype=float).T
        keep = ~np.isnan(arr).any(axis=1)
        if with_clusters:
            clusters = np.array(["{}|{}".format(u[0], u[1]) for u in units])[keep]
            return arr[keep], level, clusters
        return arr[keep], level

    results = []
    for h in hyps:
        key = (h["paper_id"], h["study_id"], h["h_id"])
        model = (id_list(h["模型类型"]) or ["?"])[0]
        pred = overrides.get(key, h["预测形式"])
        row = {"paper": h["paper_id"], "study": h["study_id"], "h": h["h_id"], "model": model,
               "prediction": pred, "corrected": "是" if key in overrides else "",
               "X": h["X名称"], "M": h["M名称"], "Y": h["Y名称"], "status": "", "detail": ""}
        results.append(row)
        if "行为记录" in str(h.get(decision)):
            row["status"] = "行为记录（未检验）"; continue
        if h["paper_id"] in mismatch:
            row["status"] = "设计不对应"; row["detail"] = mismatch[h["paper_id"]]; continue
        if pred not in ("positive", "negative", "no_effect"):
            row["status"] = "无法检验"; row["detail"] = "预测形式 " + str(pred); continue
        x = variable(h, h["X编号"], h["X名称"])
        y = variable(h, h["Y编号"], h["Y名称"])
        ms = [variable(h, m, n) for m, n in zip(id_list(h["M编号"]), id_list(h["M名称"]) or [None] * 9)]
        if x is None or y is None or any(m is None for m in ms):
            row["status"] = "无法检验"; row["detail"] = "变量未在问卷中"; continue
        arr, level, clusters = table([x] + ms + [y], with_clusters=True)
        if len(arr) < 6 or np.std(arr[:, 0]) == 0 or np.std(arr[:, -1]) == 0:
            row["status"] = "无法检验"; row["detail"] = "变量没有变异"; continue
        X, Ms, Y = arr[:, 0], [arr[:, i + 1] for i in range(len(ms))], arr[:, -1]
        sign = 1 if pred == "positive" else -1
        if boot:
            lo, hi, est = cluster_boot(arr, clusters, len(ms), boot)
            if lo is None:
                row["status"] = "无法检验"; row["detail"] = "抽样后没有变异"; continue
            excludes = lo > 0 or hi < 0
            ok = (not excludes) if pred == "no_effect" else (excludes and np.sign(est) == sign)
            row["status"] = "支持" if ok else "不支持"
            row["detail"] = "{} n={} 世界={} {}={:+.3f} 95%CI[{:+.3f},{:+.3f}]".format(
                level, len(Y), len(set(clusters)), "间接效应" if ms else "b", est, lo, hi)
            continue
        if not Ms:
            b, p = ols(Y, [X])
            ok = p[0] >= .05 if pred == "no_effect" else (p[0] < .05 and np.sign(b[0]) == sign)
            row["status"] = "支持" if ok else "不支持"
            row["detail"] = "{} n={} b={:+.2f} p={:.3f}".format(level, len(Y), b[0], p[0])
            continue
        paths, prev, effect = [], [X], 1.0
        for M in Ms:
            b, p = ols(M, prev)
            paths.append((b[-1], p[-1])); effect *= b[-1]; prev = prev + [M]
        b, p = ols(Y, prev)
        paths.append((b[-1], p[-1])); effect *= b[-1]
        significant = all(pp < .05 for _, pp in paths)
        # A predicted null mediation is reproduced when the indirect path is not significant
        # (before 2026-10-29 such hypotheses were always counted as unsupported).
        ok = (not significant) if pred == "no_effect" else (significant and np.sign(effect) == sign)
        row["status"] = "支持" if ok else "不支持"
        row["detail"] = "{} n={} 路径 ".format(level, len(Y)) + " ".join("{:+.2f}(p={:.3f})".format(c, pp) for c, pp in paths)

    counts = collections.Counter(r["status"] for r in results)
    tested = counts["支持"] + counts["不支持"]
    print("纳入假设 {} 条：{}".format(len(results), dict(counts)))
    print("已检验 {} 条，支持 {} 条（{:.0f}%）".format(tested, counts["支持"], 100 * counts["支持"] / max(1, tested)))
    by_model = collections.defaultdict(collections.Counter)
    for r in results:
        by_model[r["model"]][r["status"]] += 1
    for m, c in sorted(by_model.items()):
        t = c["支持"] + c["不支持"]
        print("  {:26s} 支持 {}/{}{}".format(m, c["支持"], t, " ({:.0f}%)".format(100 * c["支持"] / t) if t else ""))
    if out_csv:
        with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(results[0]))
            w.writeheader()
            w.writerows(results)
        print("->", out_csv)
    return results


if __name__ == "__main__":
    argv = sys.argv[1:]
    boot = 0
    if "--boot" in argv:
        i = argv.index("--boot")
        boot = int(argv[i + 1])
        argv = argv[:i] + argv[i + 2:]
    if len(argv) not in (2, 3):
        sys.exit(__doc__)
    main(*argv, boot=boot)
