# -*- coding: utf-8 -*-
"""V26: the habit version is the persona manipulation; retired templates are removed once."""
import json
import os
import re
import sys
import tempfile
import unittest
import unittest.mock
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import server  # noqa: E402


def conditions(name):
    data = json.load(open(ROOT / "data" / name, encoding="utf-8"))
    return data.get("conditions", data)


def template(name):
    return json.load(open(ROOT / "data" / "world_presets" / (name + ".json"), encoding="utf-8"))


class FinalPersonaTests(unittest.TestCase):
    def test_habit_text_with_nine_matching_items(self):
        c = conditions("experiment_conditions.json")
        self.assertEqual(c, conditions("experiment_conditions.default.json"))
        high = c["high_abuse"]["leader_overrides"]["scratch"]["conduct"]
        low = c["low_abuse"]["leader_overrides"]["scratch"]["conduct"]
        for text in (high, low):
            self.assertEqual(re.findall(r"^(\d)\. ", text, re.M), [str(i) for i in range(1, 10)])
            self.assertTrue(text.startswith("克劳斯带组多年，形成了一套固定的说话和做事习惯"))
        for word in ("刻薄", "尖酸", "阴阳怪气", "刁难", "撒谎", "坏话", "伤害", "无能"):
            self.assertNotIn(word, high)
        self.assertIn("从不动手", high)

    def test_only_two_persona_templates(self):
        names = sorted(p.stem for p in (ROOT / "data" / "world_presets").glob("*.json"))
        self.assertEqual([n for n in names if n.startswith("Persona-manipulation") and n.endswith("_CN")],
                         ["Persona-manipulation-high-abuse_CN", "Persona-manipulation-low-abuse_CN"])
        self.assertFalse([n for n in names if re.search(r"[\u4e00-\u9fff]", n)])
        high, low = template("Persona-manipulation-high-abuse_CN"), template("Persona-manipulation-low-abuse_CN")
        self.assertEqual(sorted(k for k in set(high) | set(low) if high.get(k) != low.get(k)),
                         ["condition", "research_design"])

    def test_config_carries_text_for_klaus_only(self):
        payload = template("Persona-manipulation-high-abuse_CN")
        payload.update(name="v26-habit", offline=True)
        _, _, cfg = server.build_experiment_config(payload)
        self.assertIn("具体来说，他习惯：", cfg["agents"]["克劳斯"]["scratch"]["conduct"])
        self.assertNotIn("conduct", cfg["agents"]["阿伊莎"].get("scratch", {}))

    def test_condition_text_enters_comparison_signature(self):
        payload = template("Persona-manipulation-high-abuse_CN")
        before = server.comparison_signature(payload)
        edited = {"high_abuse": {"leader_overrides": {"scratch": {"conduct": "旧的简略版"}}}}
        with unittest.mock.patch.object(server, "_condition_definition", lambda name, *a: edited.get(name)):
            self.assertNotEqual(server.comparison_signature(payload), before)
        self.assertNotEqual(before, server.comparison_signature(template("Persona-manipulation-low-abuse_CN")))

    def test_retired_templates_removed_once(self):
        origin = Path.cwd()
        with tempfile.TemporaryDirectory() as root:
            os.chdir(root)
            try:
                d = Path("data/world_presets"); d.mkdir(parents=True)
                for name in server.RETIRED_PRESETS + ("我的模板",):
                    (d / (name + ".json")).write_text("{}", encoding="utf-8")
                server.retire_old_presets()
                self.assertEqual(sorted(p.stem for p in d.glob("*.json")), ["我的模板"])
                (d / "人设操纵详细版-高辱虐组.json").write_text("{}", encoding="utf-8")
                server.retire_old_presets()   # runs once only: a template saved later is kept
                self.assertTrue((d / "人设操纵详细版-高辱虐组.json").exists())
            finally:
                os.chdir(origin)


if __name__ == "__main__":
    unittest.main()
