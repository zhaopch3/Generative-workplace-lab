# -*- coding: utf-8 -*-
"""Day-level pairing used by tools/check_within.py, and the reverse-item corrections file."""
import datetime as dt
import json
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))
os.chdir(ROOT)

import check_within as cw  # noqa: E402


def t(day, hm):
    return dt.datetime(2024, 2, day, *map(int, hm.split(":")))


class ChainTests(unittest.TestCase):
    def test_same_session_and_next_morning(self):
        x = [(t(12, "17:00"), 0.5), (t(13, "17:00"), 0.2)]
        m = [(t(12, "17:00"), 0.4), (t(13, "17:00"), 0.1)]
        y = [(t(13, "08:00"), 0.9), (t(14, "08:00"), 0.3)]
        self.assertEqual(cw.chains([x, m, y]), [[0.5, 0.4, 0.9], [0.2, 0.1, 0.3]])

    def test_lag_limit_and_strict_outcome(self):
        x = [(t(12, "21:00"), 1.0)]
        y_far = [(t(14, "17:00"), 0.0)]          # 44 h later: dropped
        self.assertEqual(cw.chains([x, y_far]), [])
        y_same = [(t(12, "21:00"), 0.3), (t(13, "17:00"), 0.7)]
        self.assertEqual(cw.chains([x, y_same]), [[1.0, 0.3]])
        self.assertEqual(cw.chains([x, y_same], later_last=True), [[1.0, 0.7]])


class CorrectionsTests(unittest.TestCase):
    def test_reverse_items_well_formed(self):
        d = json.load(open(ROOT / "data" / "analysis" / "hypothesis_corrections.json", encoding="utf-8"))
        battery = json.load(open(ROOT / "data" / "scale_battery" / "battery_v1.json", encoding="utf-8"))
        items = {e["survey"]["id"]: {q["id"] for q in e["survey"]["questions"]} for e in battery["surveys"]}
        seen = set()
        for entry in d["reverse_items"]:
            self.assertTrue(entry["reason"])
            for sid in entry["surveys"]:
                self.assertIn(sid, items)
                self.assertNotIn(sid, seen)              # one entry per survey (entries are XOR-ed)
                seen.add(sid)
                self.assertTrue(set(entry["items"]) <= items[sid])
                self.assertLess(len(entry["items"]), len(items[sid]))
        self.assertIn("b_p001_s1_v11", seen)             # affective commitment


if __name__ == "__main__":
    unittest.main()
