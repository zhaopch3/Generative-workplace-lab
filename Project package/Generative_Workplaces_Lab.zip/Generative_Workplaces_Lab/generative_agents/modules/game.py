"""generative_agents.game"""

import os
import copy

from modules.utils import GenerativeAgentsMap, GenerativeAgentsKey
from modules import utils
from .maze import Maze
from .agent import Agent


class Game:
    """The Game"""

    def __init__(self, name, static_root, config, conversation, logger=None):
        self.name = name
        self.static_root = static_root
        self.record_iterval = config.get("record_iterval", 30)
        self.logger = logger or utils.IOLogger()
        maze_config = copy.deepcopy(config.get("_maze_config") or self.load_static(config["maze"]["path"]))
        if config.get("navigation_policy") == "office-solid-v1" and not config.get("_maze_config"):
            from .navigation import build_navigation
            maze_config = build_navigation(maze_config, static_root)
        if config.get("language", "zh") == "en" and not config.get("_maze_config"):
            # V27: English map names (a resumed world keeps the names saved with it).
            from modules import lang
            maze_config = lang.translate_maze(maze_config)
        self.maze = Maze(maze_config, self.logger)
        self.conversation = conversation
        self.agents = {}
        if "agent_base" in config:
            agent_base = config["agent_base"]
        else:
            agent_base = {}
        # 历史补测会在独立工作目录中加载存档副本。内部覆盖项只在内存配置中
        # 使用，正常模拟仍沿用原来的 results/checkpoints/<name>/storage。
        storage_root = config.get("_storage_root") or os.path.join(
            f"results/checkpoints/{name}", "storage"
        )
        if not os.path.isdir(storage_root):
            os.makedirs(storage_root)
        for name, agent in config["agents"].items():
            agent_config = utils.update_dict(
                copy.deepcopy(agent_base), self.load_static(agent["config_path"])
            )
            agent_config = utils.update_dict(agent_config, agent)
            if self.maze.navigation and not self.maze.walkable(agent_config["coord"]):
                if config.get("_snapshot"):
                    raise ValueError("Snapshot contains an invalid navigation position")
                agent_config["coord"] = self.maze.nearest_walkable(agent_config["coord"])
                config["agents"][name]["coord"] = list(agent_config["coord"])

            agent_config["storage_root"] = os.path.join(storage_root, name)
            agent_config["metrics_path"] = config.get("_metrics_path") or os.path.join(
                "results", "monitor", self.name, "model_calls.jsonl"
            )
            self.agents[name] = Agent(agent_config, self.maze, self.conversation, self.logger)
        if "_tile_events" in config:
            from modules.memory.event import Event
            for row in self.maze.tiles:
                for tile in row:
                    tile._events = {}
            for state in config["_tile_events"]:
                tile = self.maze.tile_at(state["coord"])
                tile._events = {key: Event.from_dict(value) for key, value in state["events"].items()}
                tile.event_cnt = state["count"]

    def get_agent(self, name):
        return self.agents[name]

    def agent_think(self, name, status):
        agent = self.get_agent(name)
        plan = agent.think(status, self.agents)
        action_info = agent.action.abstract()
        action_event = agent.get_event()
        if getattr(action_event, "researcher_injected", False):
            action_info.update({
                "researcher_injected": True,
                "intervention_id": getattr(action_event, "intervention_id", None),
                "event_id": getattr(action_event, "event_id", None),
            })
        info = {
            "currently": agent.scratch.currently,
            "associate": agent.associate.abstract(),
            "concepts": {c.node_id: c.abstract() for c in agent.concepts},
            "chats": [
                {"name": "self" if n == agent.name else n, "chat": c}
                for n, c in agent.chats
            ],
            "action": action_info,
            "schedule": agent.schedule.abstract(),
            "address": agent.get_tile().get_address(as_list=False),
        }
        if (
            utils.get_timer().daily_duration() - agent.last_record
        ) > self.record_iterval:
            info["record"] = True
            agent.last_record = utils.get_timer().daily_duration()
        else:
            info["record"] = False
        if agent.llm_available():
            info["llm"] = agent._llm.get_summary()
        title = "{}.summary @ {}".format(
            name, utils.get_timer().get_date("%Y%m%d-%H:%M:%S")
        )
        self.logger.info("\n{}\n{}\n".format(utils.split_line(title), agent))
        return {"plan": plan, "info": info}

    def load_static(self, path):
        return utils.load_dict(os.path.join(self.static_root, path))

    def reset_game(self, keys):
        for a_name, agent in self.agents.items():
            agent.reset(keys)
            title = "{}.reset".format(a_name)
            self.logger.info("\n{}\n{}\n".format(utils.split_line(title), agent))


def create_game(name, static_root, config, conversation, logger=None):
    """Create the game"""

    utils.set_timer(**config.get("time", {}))
    GenerativeAgentsMap.set(GenerativeAgentsKey.GAME, Game(name, static_root, config, conversation, logger=logger))
    return GenerativeAgentsMap.get(GenerativeAgentsKey.GAME)


def get_game():
    """Get the gloabl game"""

    return GenerativeAgentsMap.get(GenerativeAgentsKey.GAME)
