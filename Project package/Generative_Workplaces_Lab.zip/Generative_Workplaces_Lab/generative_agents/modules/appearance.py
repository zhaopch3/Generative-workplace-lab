# -*- coding: utf-8 -*-
"""Random character appearance by recolouring an existing sprite sheet (V23).

Every texture.png is a 96x128 sheet (3 walk frames x 4 directions, 32x32 each);
portrait.png is the front idle frame (x=32, y=0).  Each opaque colour of a base
sprite is labelled hair / skin / top / bottom / keep by where it sits in the
front frame, then hair, top and bottom are moved onto ramps drawn from natural
hair colours and office clothing colours, keeping each colour's relative
brightness so shading survives.  Skin, outlines and eyes are kept.

This is tier 1 (no new art).  A layered "paper doll" generator with our own
parts would replace the base-sprite choice later; the output format stays the same.
"""
import colorsys
import os
import random

from PIL import Image

AGENTS_ROOT = os.path.join("frontend", "static", "assets", "village", "agents")
# Non-human sprites are never used as a random base.
NON_HUMAN = {"沃尔夫冈", "亚当", "Wolfgang", "Adam"}

HAIR = [(0.07, 0.45, 0.28), (0.07, 0.55, 0.42), (0.06, 0.60, 0.58), (0.03, 0.60, 0.52),
        (0.11, 0.45, 0.85), (0.0, 0.0, 0.75), (0.0, 0.0, 0.20), (0.60, 0.15, 0.26),
        (0.09, 0.35, 0.65)]
TOPS = [(0.60, 0.45, 0.60), (0.58, 0.25, 0.85), (0.0, 0.0, 0.95), (0.33, 0.35, 0.55),
        (0.95, 0.40, 0.60), (0.75, 0.25, 0.60), (0.0, 0.0, 0.35), (0.12, 0.50, 0.80),
        (0.50, 0.40, 0.55), (0.0, 0.0, 0.62)]
BOTTOMS = [(0.60, 0.35, 0.33), (0.0, 0.0, 0.22), (0.08, 0.30, 0.38), (0.60, 0.15, 0.52),
           (0.0, 0.0, 0.48)]


def _hsv(c):
    return colorsys.rgb_to_hsv(*(x / 255.0 for x in c[:3]))


def base_names(root=AGENTS_ROOT):
    names = []
    for name in sorted(os.listdir(root)):
        if name in NON_HUMAN:
            continue
        if os.path.exists(os.path.join(root, name, "texture.png")):
            names.append(name)
    return names


def classify(texture):
    """colour (r,g,b) -> 'hair' | 'skin' | 'top' | 'bottom' | 'keep'."""
    front = texture.crop((32, 0, 64, 32)).load()
    positions = {}
    for y in range(32):
        for x in range(32):
            c = front[x, y]
            if c[3] > 0:
                positions.setdefault(c[:3], []).append((x, y))
    labels = {}
    for colour, pts in positions.items():
        h, s, v = _hsv(colour)
        mean_y = sum(y for _, y in pts) / len(pts)
        in_face = sum(1 for x, y in pts if 11 <= y <= 18 and 9 <= x <= 22) / len(pts)
        if v < 0.2:
            labels[colour] = "keep"                      # outlines
        elif in_face >= 0.3 and (h <= 0.14 or h >= 0.97) and s < 0.7 and v > 0.25:
            labels[colour] = "skin"
        elif in_face >= 0.8 and len(pts) <= 6:
            labels[colour] = "keep"                      # eyes, mouth
        elif mean_y < 12.5:
            labels[colour] = "hair"
        elif mean_y < 23.5:
            labels[colour] = "top"
        else:
            labels[colour] = "bottom"
    return labels


def _ramp(colours, target):
    th, ts, tv = target
    values = sorted(_hsv(c)[2] for c in colours)
    mid = values[len(values) // 2] or 0.5
    out = {}
    for c in colours:
        _h, _s, v = _hsv(c)
        rel = v / mid
        r, g, b = colorsys.hsv_to_rgb(th, min(1.0, ts * (0.7 + 0.3 * rel)), max(0.0, min(1.0, tv * rel)))
        out[c] = (int(r * 255), int(g * 255), int(b * 255))
    return out


def recolor(texture, rng, labels=None):
    labels = labels or classify(texture)
    groups = {}
    for colour, label in labels.items():
        groups.setdefault(label, []).append(colour)
    choice = {}
    mapping = {}
    for label, palette in (("hair", HAIR), ("top", TOPS), ("bottom", BOTTOMS)):
        if groups.get(label):
            target = rng.choice(palette)
            choice[label] = target
            mapping.update(_ramp(groups[label], target))
    out = texture.copy()
    px = out.load()
    for y in range(out.height):
        for x in range(out.width):
            c = px[x, y]
            if c[3] > 0 and c[:3] in mapping:
                px[x, y] = mapping[c[:3]] + (c[3],)
    return out, choice


def generate(dst_folder, seed, base=None, root=AGENTS_ROOT):
    """Write texture.png and portrait.png for a new random look; return its recipe."""
    rng = random.Random("appearance-%s" % seed)
    base = base or rng.choice(base_names(root))
    texture = Image.open(os.path.join(root, base, "texture.png")).convert("RGBA")
    new_texture, choice = recolor(texture, rng)
    os.makedirs(dst_folder, exist_ok=True)
    new_texture.save(os.path.join(dst_folder, "texture.png"))
    new_texture.crop((32, 0, 64, 32)).save(os.path.join(dst_folder, "portrait.png"))
    return {"method": "recolor_v1", "base": base, "seed": str(seed),
            "palette": {k: [round(x, 3) for x in v] for k, v in choice.items()}}
