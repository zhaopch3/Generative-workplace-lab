# -*- coding: utf-8 -*-
"""Print the final persona of every agent and the differences between templates.

Usage (from generative_agents/):  python tools/check_templates.py [模板名 ...]
Without names, all templates in data/world_presets are checked; templates are
compared pairwise within the same manipulation family.
"""
import json
import os
import sys

sys.path.insert(0, os.getcwd())

from modules.research import world_check  # noqa: E402


def main(names):
    folder = os.path.join("data", "world_presets")
    names = names or sorted(f[:-5] for f in os.listdir(folder) if f.endswith(".json"))
    items, failed = [], False
    for name in names:
        with open(os.path.join(folder, name + ".json"), "r", encoding="utf-8") as f:
            payload = json.load(f)
        result, _cfg = world_check.preview_payload(payload)
        print("=" * 70)
        print("模板：", name)
        for line in result["errors"]:
            failed = True
            print("  [错误]", line)
        for line in result["warnings"]:
            print("  [提示]", line)
        for agent, text in result["personas"].items():
            print("-" * 30, agent)
            print(text)
        items.append((name, payload, result["personas"]))
    families = {}
    for item in items:
        families.setdefault((item[1].get("research_design") or {}).get("manipulation", "other"), []).append(item)
    for family, group in families.items():
        comparison = world_check.compare_worlds(group)
        print("=" * 70)
        print("比较（{}）".format(family))
        for line in comparison["manipulated"]:
            print("  操纵差异：", line)
        for line in comparison["other"]:
            print("  非操纵差异：", line)
        if not comparison["other"]:
            print("  除声明的操纵外完全相同")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
