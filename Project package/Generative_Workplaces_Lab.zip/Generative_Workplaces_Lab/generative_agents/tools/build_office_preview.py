import argparse
import json
import os
import sys
from collections import deque
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from modules.maze import Maze


STATIC_ROOT = os.path.join("frontend", "static")
MAZE_PATH = os.path.join(STATIC_ROOT, "assets", "village", "maze.json")
AGENT_ROOT = os.path.join(STATIC_ROOT, "assets", "village", "agents")

AGENTS = ["阿伊莎", "克劳斯", "玛丽亚", "沃尔夫冈"]

TARGETS = {
    "1号工位": [5, 6],
    "2号工位": [8, 10],
    "3号工位": [11, 6],
    "领导办公桌": [14, 15],
    "会议桌": [18, 7],
    "白板": [20, 4],
    "打印机": [21, 11],
    "饮水机": [24, 4],
    "沙发": [10, 13],
    "休息沙发": [18, 16],
    "床": [7, 12],
}

LOCATIONS = {
    "1号工位": "公司办公室，开放办公区，1号工位",
    "2号工位": "公司办公室，开放办公区，2号工位",
    "3号工位": "公司办公室，开放办公区，3号工位",
    "领导办公桌": "公司办公室，领导办公室，领导办公桌",
    "会议桌": "公司办公室，会议区，会议桌",
    "白板": "公司办公室，会议区，白板",
    "打印机": "公司办公室，茶水休息区，打印机",
    "饮水机": "公司办公室，茶水休息区，饮水机",
    "沙发": "公司办公室，茶水休息区，沙发",
    "休息沙发": "公司办公室，休息宿舍区，休息沙发",
    "床": "公司办公室，休息宿舍区，床",
}

ROUTES = {
    "阿伊莎": [
        ("1号工位", "整理研究材料"),
        ("会议桌", "前往会议区参加进度讨论"),
        ("领导办公桌", "去领导办公室汇报"),
        ("饮水机", "到茶水区倒水"),
        ("休息沙发", "到休息区短暂恢复"),
        ("1号工位", "回到工位继续工作"),
    ],
    "玛丽亚": [
        ("2号工位", "打开电脑检查任务"),
        ("会议桌", "前往会议区讨论方案"),
        ("打印机", "到打印机旁取资料"),
        ("沙发", "在茶水区和同事交流"),
        ("2号工位", "回到工位整理笔记"),
    ],
    "沃尔夫冈": [
        ("3号工位", "准备会议材料"),
        ("白板", "到白板前梳理思路"),
        ("会议桌", "加入会议区讨论"),
        ("饮水机", "去茶水区喝水"),
        ("3号工位", "回到工位写进展报告"),
    ],
    "克劳斯": [
        ("领导办公桌", "查看团队进度"),
        ("1号工位", "走到开放办公区检查工作"),
        ("会议桌", "召集团队短会"),
        ("领导办公桌", "回办公室记录管理决定"),
        ("休息沙发", "到休息区巡视"),
        ("领导办公桌", "回到领导办公室"),
    ],
}

CONVERSATIONS = {
    "20250213-09:06": "\n地点：the Ville，公司办公室，开放办公区，1号工位\n\n克劳斯：阿伊莎，十分钟后到会议区，我要看你今天的进展。\n阿伊莎：好的，我会把材料带过去。\n",
    "20250213-09:18": "\n地点：the Ville，公司办公室，会议区，会议桌\n\n玛丽亚：我把昨天的访谈摘要整理好了。\n沃尔夫冈：我补充一页人机协作的框架。\n克劳斯：别泛泛而谈，今天必须有明确结论。\n",
    "20250213-09:34": "\n地点：the Ville，公司办公室，领导办公室，领导办公桌\n\n阿伊莎：这是我整理出的初步材料。\n克劳斯：先放桌上，下午我要看到更完整的版本。\n",
    "20250213-09:48": "\n地点：the Ville，公司办公室，茶水休息区，沙发\n\n玛丽亚：刚才的会有点紧张，你还好吗？\n阿伊莎：还好，我先缓一下再继续写。\n",
}


def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def is_walkable(maze, coord):
    x, y = coord
    return 0 <= x < maze.maze_width and 0 <= y < maze.maze_height and not maze.tile_at(coord).collision


def nearest_walkable(maze, coord):
    if is_walkable(maze, coord):
        return list(coord)
    queue = deque([tuple(coord)])
    seen = {tuple(coord)}
    while queue:
        x, y = queue.popleft()
        if 0 <= x < maze.maze_width and 0 <= y < maze.maze_height and is_walkable(maze, [x, y]):
            return [x, y]
        for nxt in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
            nx, ny = nxt
            if 0 <= nx < maze.maze_width and 0 <= ny < maze.maze_height and nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    raise ValueError(f"No walkable tile near {coord}")


def path_between(maze, source, target):
    source = nearest_walkable(maze, source)
    target = nearest_walkable(maze, target)
    if source == target:
        return [source]
    return [list(p) for p in maze.find_path(source, target)]


def load_agent(agent_name):
    return load_json(os.path.join(AGENT_ROOT, agent_name, "agent.json"))


def build_agent_track(maze, agent_name):
    route = ROUTES[agent_name]
    current = TARGETS[route[0][0]]
    frames = []
    for target_name, action in route:
        target = TARGETS[target_name]
        path = path_between(maze, current, target)
        if frames and path:
            path = path[1:]
        if not path:
            path = [target]
        for coord in path:
            frames.append(
                {
                    "movement": coord,
                    "location": LOCATIONS[target_name],
                    "action": action,
                }
            )
        for _ in range(10):
            frames.append(
                {
                    "movement": list(target),
                    "location": LOCATIONS[target_name],
                    "action": action,
                }
            )
        current = target
    return frames


def build_preview(run_name, start_time, sec_per_step):
    maze = Maze(load_json(MAZE_PATH), None)
    tracks = {agent: build_agent_track(maze, agent) for agent in AGENTS}
    max_frames = max(len(track) for track in tracks.values())

    all_movement = {"description": {}, "conversation": dict(CONVERSATIONS)}
    persona_init_pos = {}

    for agent in AGENTS:
        agent_data = load_agent(agent)
        first_target = ROUTES[agent][0][0]
        persona_init_pos[agent] = list(TARGETS[first_target])
        all_movement["description"][agent] = {
            "currently": agent_data.get("currently", ""),
            "scratch": agent_data.get("scratch", {}),
        }
        all_movement["0"] = all_movement.get("0", {})
        all_movement["0"][agent] = {
            "location": LOCATIONS[first_target],
            "movement": list(TARGETS[first_target]),
            "description": "准备开始办公室工作",
        }

    for idx in range(1, max_frames + 1):
        frame = {}
        for agent, track in tracks.items():
            row = track[min(idx - 1, len(track) - 1)]
            frame[agent] = row
        all_movement[str(idx)] = frame

    result = {
        "start_datetime": datetime.strptime(start_time, "%Y%m%d-%H:%M").isoformat(),
        "stride": 120,
        "sec_per_step": sec_per_step,
        "persona_init_pos": persona_init_pos,
        "all_movement": all_movement,
    }

    out_dir = os.path.join("results", "compressed", run_name)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "movement.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    report_path = os.path.join(out_dir, "simulation.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"# Office Preview\n\nRun: `{run_name}`\n\n")
        f.write("This deterministic preview is for visual QA only, not experiment data.\n")

    return out_path, max_frames


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", default="office-preview-walk-001")
    parser.add_argument("--start", default="20250213-09:00")
    parser.add_argument("--sec-per-step", type=int, default=60)
    args = parser.parse_args()

    out_path, frames = build_preview(args.name, args.start, args.sec_per_step)
    print(f"Wrote {out_path} with {frames} movement frames.")


if __name__ == "__main__":
    main()
