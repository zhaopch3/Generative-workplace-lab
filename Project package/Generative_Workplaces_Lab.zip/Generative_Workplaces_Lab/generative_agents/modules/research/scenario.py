"""Explicit, versioned scenario rules; no condition-dependent outcome formulas."""
import datetime
import json
from pathlib import Path
from modules import utils
from .common import atomic_json


def validate_scenario(payload):
    agents = set(payload.get("agents", []))
    seen = set()
    for index, event in enumerate(payload.get("scheduled_events") or []):
        key = str(event.get("id") or "event_%d" % index)
        if key in seen:
            raise ValueError("定时事件ID重复")
        seen.add(key)
        day = int(event.get("day", 1))
        datetime.datetime.strptime(str(event.get("time", "09:00")), "%H:%M")
        psych_values = event.get("psych") or {}
        if not isinstance(psych_values, dict):
            raise ValueError("定时事件的心理状态设定格式无效")
        from modules import psych as psych_mod
        for name, value in psych_values.items():
            if name not in psych_mod.VARS:
                raise ValueError("未知的心理状态变量：%s" % name)
            if not 1 <= float(value) <= 10:
                raise ValueError("心理状态设定必须在 1 到 10 之间")
        if day < 1 or not (str(event.get("text", "")).strip() or psych_values):
            raise ValueError("定时事件需要正整数模拟日及事件内容")
        if set(event.get("targets") or []) - agents:
            raise ValueError("定时事件目标不在世界内")
        kind = event.get("kind", "world_event")
        # V24: thoughts / intents and standing world settings can be scheduled too.
        if kind not in ("world_event", "specified_action", "thought", "world_setting"):
            raise ValueError("定时事件类型只能是 world_event、specified_action、thought 或 world_setting")
        if kind == "thought" and not event.get("targets"):
            raise ValueError("定时想法需要指定接收的智能体")
        if kind == "world_setting" and not str(event.get("text", "")).strip():
            raise ValueError("定时世界设定需要填写内容")
        if psych_values and kind in ("world_event",) and (event.get("scope") or "all") == "local":
            raise ValueError("按现场感知传播的事件不能附带心理状态设定")
        if kind == "specified_action":
            if event.get("actor") not in agents:
                raise ValueError("定时指定行为需要世界内的行为者")
            if event.get("object") and event.get("object") not in agents:
                raise ValueError("定时指定行为的对象不在世界内")
        event["id"] = key
    seen = set()
    for index, task in enumerate(payload.get("work_tasks") or []):
        key = str(task.get("id") or "task_%d" % index)
        if key in seen or not str(task.get("title", "")).strip():
            raise ValueError("工作任务需要唯一ID和名称")
        seen.add(key)
        if task.get("agent") not in agents or float(task.get("effort_minutes", 0)) <= 0:
            raise ValueError("工作任务需要有效负责人和正的工作量")
        if float(task.get("capacity_per_hour", 60)) <= 0:
            raise ValueError("任务每小时可积累的工作分钟必须为正")
        task["id"] = key


def apply_due_events(server, step):
    now = utils.get_timer().get_date()
    start = server.config.get("simulation_start") or server.config.get("setup_payload", {}).get("start_time")
    if not start:
        start = now.strftime("%Y%m%d-%H:%M")
    origin = datetime.datetime.strptime(start, "%Y%m%d-%H:%M").date()
    done = server.config.setdefault("_scenario_events_done", [])
    applied = []
    for event in server.config.get("scheduled_events") or []:
        if event["id"] in done:
            continue
        target = datetime.datetime.combine(origin + datetime.timedelta(days=int(event["day"])-1),
                                           datetime.datetime.strptime(event["time"], "%H:%M").time())
        if now >= target:
            targets = event.get("targets") or []
            kind = event.get("kind", "world_event")
            record = server.apply_intervention({
                **event,
                "kind": kind,
                "scope": event.get("scope") or ("selected" if targets else "all"),
                "targets": targets,
                "intervention_id": "scenario_" + event["id"],
                "event_id": "event_" + event["id"],
                "scheduled_time": target.strftime("%Y%m%d-%H:%M"),
                "scenario_event_id": event["id"],
                "source": "scheduled",
            }, step)
            if record:
                record["scheduled_time"] = target.strftime("%Y%m%d-%H:%M")
                record["scenario_event_id"] = event["id"]
                applied.append(record)
            done.append(event["id"])
    task_done = server.config.setdefault("_task_announcements", [])
    for task in server.config.get("work_tasks") or []:
        if task["id"] not in task_done:
            record = server.apply_intervention({
                "targets": [task["agent"]], "text": _L("工作任务：%s。%s。计划工作量 %s 分钟。",
                                                       "Work task: %s. %s. Planned effort: %s minutes.")
                    % (task["title"], task.get("description", ""), task["effort_minutes"]),
                "kind": "thought", "intervention_id": "task_" + task["id"],
                "poignancy": 7, "persistent": False, "source": "work_task",
            }, step)
            if record:
                applied.append(record)
            task_done.append(task["id"])
    return applied


def observe_tasks(server, step, stride, step_agents):
    """Operational work allocation proxy, explicitly not a validated performance score."""
    tasks = server.config.get("work_tasks") or []
    if not tasks:
        return
    progress = server.config.setdefault("_task_progress", {})
    time = utils.get_timer().get_date("%Y%m%d-%H:%M")
    rows = []
    available = {task["agent"]: max(0, stride) for task in tasks}
    for task in tasks:
        state = progress.setdefault(task["id"], {"minutes": 0.0, "completed_at": None})
        action = step_agents.get(task["agent"], {}).get("action", {})
        text = json.dumps(action, ensure_ascii=False) if isinstance(action, dict) else str(action)
        keyword = task.get("keyword") or task["title"]
        allocation = min(available[task["agent"]], float(task.get("capacity_per_hour", 60)) * max(0, stride) / 60)
        if keyword and keyword in text and state["completed_at"] is None:
            allocation = min(allocation, float(task["effort_minutes"]) - state["minutes"])
            available[task["agent"]] -= allocation
            state["minutes"] = min(float(task["effort_minutes"]), state["minutes"] + allocation)
            if state["minutes"] >= float(task["effort_minutes"]):
                state["completed_at"] = time
        rows.append({"run_id": server.name, "step": step, "time": time, "task_id": task["id"],
                     "agent": task["agent"], "title": task["title"], **state,
                     "required_minutes": task["effort_minutes"],
                     "measurement": "action_keyword_work_allocation_proxy_v1"})
    path = Path("results/tasks") / server.name
    path.mkdir(parents=True, exist_ok=True)
    with open(path / "tasks.jsonl", "a", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    atomic_json(path / "latest.json", rows)


def _L(zh, en):
    from modules.lang import L
    return L(zh, en)
