import requests
import json

# 测试不同的embedding模型
models = ["bge-m3:latest", "mxbai-embed-large:latest", "nomic-embed-text:latest"]

for model in models:
    print(f"\n测试模型: {model}")
    try:
        # 方式1：直接API调用
        response = requests.post(
            "http://localhost:11434/api/embeddings",
            json={"model": model, "prompt": "test"}
        )
        print(f"  API响应: {response.status_code}")
        
        # 方式2：检查模型信息
        info = requests.post(
            "http://localhost:11434/api/show",
            json={"name": model}
        )
        if info.status_code == 200:
            print(f"  模型信息: OK")
    except Exception as e:
        print(f"  错误: {e}")