# -*- coding: utf-8 -*-
"""历史批组补测。

本模块只读取正式 checkpoint；问卷回答在独立进程和独立向量存储副本中
完成，所有产物写入 results/posthoc_surveys。它不负责正常模拟中的定时问卷。
"""
from __future__ import annotations

import copy
import csv
import datetime as dt
import hashlib
import io
import json
import os
import re
import secrets
import shutil
import threading
import time
import traceback
import zipfile
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed

from modules import survey as survey_engine
from modules import utils


ROOT = os.path.join("results", "posthoc_surveys")
_SAFE = re.compile(r"^[\w\-.\u4e00-\u9fff]+$")
_TIME = re.compile(r"^(?:[01]\d|2[0-3]):[0-5]\d$")

RESPONSE_META = [
    "posthoc_task_id", "batch_id", "config_group_id", "config_group",
    "condition", "run_id", "frame_id", "simulation_day", "scheduled_time",
    "actual_time", "source_step", "source_checkpoint", "source_checkpoint_sha256",
    "survey_id", "survey_title", "agent", "ratee", "model", "generated_at",
]


def _atomic_json(path, value):
    from modules.research.common import atomic_json
    atomic_json(path, value)


def _read_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return default


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def checkpoint_options(run_name, checkpoints_root=os.path.join("results", "checkpoints")):
    """Return chronologically sorted complete checkpoint metadata."""
    if not _SAFE.match(run_name or ""):
        return []
    folder = os.path.join(checkpoints_root, run_name)
    out = []
    if not os.path.isdir(folder):
        return out
    for filename in sorted(os.listdir(folder)):
        if not (filename.startswith("simulate-") and filename.endswith(".json")):
            continue
        path = os.path.join(folder, filename)
        # 正式存档名已经包含完整模拟时间。优先从文件名解析，避免为了列出
        # 30个世界的时间点而反复读取数百个大型JSON。
        match = re.match(r"^simulate-(\d{8})-(\d{4})\.json$", filename)
        data = None
        if match:
            stamp = dt.datetime.strptime("{}-{}".format(*match.groups()), "%Y%m%d-%H%M")
        else:
            data = _read_json(path)
            if not isinstance(data, dict):
                continue
            raw_time = data.get("time", "")
            if isinstance(raw_time, dict):
                raw_time = raw_time.get("start", "")
            try:
                stamp = dt.datetime.strptime(str(raw_time), "%Y%m%d-%H:%M")
            except ValueError:
                continue
        out.append({
            "file": filename,
            "path": path,
            "time": stamp.strftime("%Y%m%d-%H:%M"),
            "display_time": stamp.strftime("%Y-%m-%d %H:%M"),
            "date": stamp.strftime("%Y%m%d"),
            "clock": stamp.strftime("%H:%M"),
            "step": int(data.get("step", 0) or 0) if data else 0,
            "_stamp": stamp,
        })
    return out


def match_checkpoint(options, simulation_day, scheduled_time):
    """Match day N to the first same-day checkpoint at/after HH:MM."""
    try:
        day = int(simulation_day)
    except (TypeError, ValueError):
        raise ValueError("模拟日必须是正整数")
    if day < 1 or day > 3660:
        raise ValueError("模拟日必须在 1 到 3660 之间")
    if not _TIME.match(str(scheduled_time or "")):
        raise ValueError("测量时间必须是 HH:MM")
    if not options:
        return None
    first = options[0]["_stamp"]
    target_date = first.date() + dt.timedelta(days=day - 1)
    hour, minute = (int(part) for part in scheduled_time.split(":"))
    target = dt.datetime.combine(target_date, dt.time(hour, minute))
    for option in options:
        stamp = option["_stamp"]
        if stamp.date() == target_date and stamp >= target:
            selected = {key: value for key, value in option.items() if key != "_stamp"}
            if not selected.get("step"):
                data = _read_json(selected["path"], {}) or {}
                selected["step"] = int(data.get("step", 0) or 0)
            return selected
    return None


def _latest_checkpoint(run_name):
    options = checkpoint_options(run_name)
    if not options:
        return {}, []
    data = _read_json(options[-1]["path"], {}) or {}
    return data, options


def group_catalog(group):
    """Build the UI catalog from a verified comparison group."""
    runs = group.get("runs") or []
    if not runs:
        raise ValueError("该配置组没有世界")
    latest, _ = _latest_checkpoint(runs[0]["name"])
    if not latest:
        raise ValueError("该配置组没有可读取的checkpoint")
    schemas = []
    for raw in latest.get("custom_surveys") or []:
        try:
            schema = survey_engine.validate_schema(raw)
            schema.pop("completed_dates", None)
            schemas.append(schema)
        except survey_engine.SchemaError:
            continue
    worlds = []
    all_start, all_end = [], []
    for run in runs:
        options = checkpoint_options(run["name"])
        worlds.append({
            "name": run["name"], "condition": run.get("condition", ""),
            "checkpoint_count": len(options),
            "start_time": options[0]["display_time"] if options else "",
            "end_time": options[-1]["display_time"] if options else "",
        })
        if options:
            all_start.append(options[0]["_stamp"])
            all_end.append(options[-1]["_stamp"])
    return {
        "agents": list((latest.get("agents") or {}).keys()),
        "surveys": schemas,
        "worlds": worlds,
        "coverage_start": min(all_start).strftime("%Y-%m-%d %H:%M") if all_start else "",
        "coverage_end": max(all_end).strftime("%Y-%m-%d %H:%M") if all_end else "",
    }


def _clean_schemas(existing, added):
    out, seen = {}, set()
    for raw in list(existing or []) + list(added or []):
        schema = survey_engine.validate_schema(raw)
        schema.pop("completed_dates", None)
        if schema["id"] in seen:
            raise ValueError("问卷id重复：{}".format(schema["id"]))
        seen.add(schema["id"])
        out[schema["id"]] = schema
    return out


def prepare_task(batch_id, group, frames, added_surveys=None):
    """Validate a request and lock each world/frame to one checkpoint."""
    if not _SAFE.match(batch_id or "") or not _SAFE.match(group.get("group_id", "")):
        raise ValueError("批次或配置组标识不合法")
    catalog = group_catalog(group)
    schemas = _clean_schemas(catalog["surveys"], added_surveys or [])
    if not isinstance(frames, list) or not frames:
        raise ValueError("请至少添加一个测量时间帧")
    agents = catalog["agents"]
    normalized_frames = []
    for index, raw in enumerate(frames):
        frame = raw if isinstance(raw, dict) else {}
        day = int(frame.get("day", 0) or 0)
        clock = str(frame.get("time", "")).strip()
        # Reuse match validation even before world-specific matching.
        match_checkpoint([], day, clock)
        requested_agents = frame.get("agents") if "agents" in frame else agents
        selected_agents = [a for a in (requested_agents or []) if a in agents]
        selected_surveys = [str(s) for s in (frame.get("surveys") or [])]
        if not selected_agents:
            raise ValueError("时间帧{}没有可用的填写智能体".format(index + 1))
        if not selected_surveys:
            raise ValueError("时间帧{}至少选择一份问卷".format(index + 1))
        unknown = [sid for sid in selected_surveys if sid not in schemas]
        if unknown:
            raise ValueError("找不到问卷：{}".format("、".join(unknown)))
        normalized_frames.append({
            "id": "F{:02d}".format(index + 1), "day": day, "time": clock,
            "agents": selected_agents, "surveys": selected_surveys,
        })

    locked_worlds, total_calls, dyadic_calls, missing = [], 0, 0, 0
    for run in group.get("runs") or []:
        options = checkpoint_options(run["name"])
        locked_frames = []
        for frame in normalized_frames:
            matched = match_checkpoint(options, frame["day"], frame["time"])
            entry = copy.deepcopy(frame)
            if matched:
                entry.update({
                    "status": "ready", "checkpoint": matched["file"],
                    "checkpoint_path": matched["path"], "actual_time": matched["time"],
                    "source_step": matched["step"],
                    "source_checkpoint_sha256": sha256_file(matched["path"]),
                })
                for sid in frame["surveys"]:
                    schema = schemas[sid]
                    if schema.get("mode") == "dyadic":
                        allowed_raters = schema.get("raters") or agents
                        raters = [a for a in frame["agents"] if a in allowed_raters]
                        ratees = [a for a in (schema.get("ratees") or agents) if a in agents]
                        pair_count = sum(1 for r in raters for e in ratees if r != e)
                        total_calls += pair_count
                        dyadic_calls += pair_count
                    else:
                        allowed = schema.get("targets") or agents
                        total_calls += len([a for a in frame["agents"] if a in allowed])
            else:
                entry.update({"status": "missing", "error": "同日计划时间之后没有完整存档"})
                missing += 1
            locked_frames.append(entry)
        locked_worlds.append({
            "name": run["name"], "condition": run.get("condition", ""),
            "group": run.get("group", group.get("label", "")),
            "frames": locked_frames,
        })
    if dyadic_calls:
        latest, _ = _latest_checkpoint((group.get("runs") or [{}])[0].get("name", ""))
        embedding = ((latest.get("agent_base") or {}).get("associate") or {}).get("embedding") or {}
        kind = embedding.get("type", "")
        key_name = {"openrouter": "OPENROUTER_API_KEY", "openai": "OPENAI_API_KEY"}.get(kind)
        key = (
            os.getenv(key_name, "")
            or (latest.get("api_keys") or {}).get(key_name, "")
            or embedding.get("api_key", "")
        ) if key_name else "available"
        if key_name and not key:
            raise ValueError(
                "所选互评问卷需要{}进行关系记忆检索，但当前未设置{}；请先在实验管理的API设置中补充，或先只做自评补测。".format(
                    "OpenRouter" if kind == "openrouter" else "OpenAI", key_name
                )
            )
    used_survey_ids = []
    for frame in normalized_frames:
        for sid in frame["surveys"]:
            if sid not in used_survey_ids:
                used_survey_ids.append(sid)
    selected_schemas = {sid: schemas[sid] for sid in used_survey_ids}
    return {
        "batch_id": batch_id, "group_id": group["group_id"],
        "group_label": group.get("label", ""), "verified": bool(group.get("verified")),
        "agents": agents, "schemas": selected_schemas, "frames": normalized_frames,
        "worlds": locked_worlds, "estimated_calls": total_calls,
        "missing_frame_worlds": missing,
    }


def _task_dir(batch_id, group_id, task_id):
    for part in (batch_id, group_id, task_id):
        if not _SAFE.match(part or ""):
            raise ValueError("补测任务路径参数不合法")
    return os.path.join(ROOT, batch_id, group_id, task_id)


def _world_result_path(task_dir, run_name):
    return os.path.join(task_dir, "worlds", run_name + ".json")


def _job_key(frame_id, survey_id, agent, ratee=""):
    return "|".join((frame_id, survey_id, agent, ratee or ""))


def _prepare_embedding_for_readonly(config, semantic_required):
    """Allow keyless self-report snapshots; dyadic semantic retrieval keeps its provider."""
    associate = (config.get("agent_base") or {}).get("associate") or {}
    embedding = associate.get("embedding") or {}
    kind = embedding.get("type", "")
    key_name = {"openrouter": "OPENROUTER_API_KEY", "openai": "OPENAI_API_KEY"}.get(kind)
    if not key_name:
        return
    key = os.getenv(key_name) or (config.get("api_keys") or {}).get(key_name) or embedding.get("api_key")
    if key:
        embedding["api_key"] = key
        return
    if semantic_required:
        raise ValueError(
            "互评问卷需要使用原来的{}向量通道检索人物关系记忆；请先在实验管理的API设置中补充{}。".format(
                "OpenRouter" if kind == "openrouter" else "OpenAI", key_name
            )
        )
    # 自评快照只按checkpoint中的memory id读取已有节点，不执行相似度查询。
    # 使用同进程的mock模型只为满足索引加载，不会重算或替换任何原向量。
    associate["embedding"] = {"type": "mock", "model": "posthoc-readonly"}


def _load_game(checkpoint_path, run_name, task_dir, semantic_required=False):
    """Load one checkpoint into an isolated storage copy without advancing time."""
    from modules.game import create_game
    from start import apply_env_overrides

    raw = _read_json(checkpoint_path)
    if not isinstance(raw, dict):
        raise ValueError("checkpoint无法读取：{}".format(checkpoint_path))
    config = copy.deepcopy(raw)
    raw_time = config.get("time", "")
    if isinstance(raw_time, dict):
        raw_time = raw_time.get("start", "")
    config["time"] = {"start": raw_time}
    for agent_name, agent in (config.get("agents") or {}).items():
        agent["config_path"] = os.path.join(
            "assets", "village", "agents", agent_name.replace(" ", "_"), "agent.json"
        )
    from modules.research.snapshots import isolate_state, restore_random
    work_root = os.path.join(task_dir, "_working", run_name)
    conversation, reconstruction = isolate_state(checkpoint_path, config, work_root)
    work_storage = os.path.join(work_root, "storage")
    config["_reconstruction"] = reconstruction
    config.setdefault("agent_base", {})["measurement_policy"] = "passive"
    for agent in config.get("agents", {}).values():
        agent["measurement_policy"] = "passive"
    config["_storage_root"] = work_storage
    config["_metrics_path"] = os.path.join(task_dir, "model_calls", run_name + ".jsonl")
    apply_env_overrides(config)
    _prepare_embedding_for_readonly(config, semantic_required)
    # V27: answer in the world's own language (process-wide, like the simulation itself).
    from modules import lang
    lang.set_language(config.get("language", "zh"))
    game = create_game(
        "posthoc-{}-{}".format(os.path.basename(task_dir), run_name),
        "frontend/static", config, conversation, logger=utils.create_io_logger("error"),
    )
    game.reset_game(keys=config.get("api_keys") or {})
    restore_random(config)
    return game, config


def _response_metadata(manifest, world, frame, schema, row, checkpoint_hash, model):
    return {
        "posthoc_task_id": manifest["task_id"],
        "batch_id": manifest["batch_id"],
        "config_group_id": manifest["group_id"],
        "config_group": manifest.get("group_label", ""),
        "condition": world.get("condition", ""),
        "run_id": world["name"],
        "frame_id": frame["id"],
        "simulation_day": frame["day"],
        "scheduled_time": frame["time"],
        "actual_time": frame.get("actual_time", ""),
        "source_step": frame.get("source_step", 0),
        "source_checkpoint": frame.get("checkpoint", ""),
        "source_checkpoint_sha256": checkpoint_hash,
        "survey_id": schema["id"],
        "survey_title": schema.get("title", schema["id"]),
        "agent": row.get("agent", ""),
        "ratee": row.get("ratee", ""),
        "model": model or "",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def execute_world(task_dir, run_name):
    """Process-pool entrypoint. Successful job keys are never called twice on retry."""
    manifest = _read_json(os.path.join(task_dir, "manifest.json"), {}) or {}
    world = next((w for w in manifest.get("worlds", []) if w.get("name") == run_name), None)
    if world is None:
        raise ValueError("任务清单中没有世界：{}".format(run_name))
    result_path = _world_result_path(task_dir, run_name)
    previous = _read_json(result_path, {}) or {}
    responses = list(previous.get("responses") or [])
    issues = [i for i in (previous.get("issues") or []) if i.get("status") == "skipped"]
    successful = {row.get("job_key") for row in responses if row.get("job_key")}
    schemas = manifest.get("schemas") or {}
    cancel_marker = os.path.join(task_dir, "cancel.marker")

    for frame in world.get("frames") or []:
        if os.path.exists(cancel_marker):
            break
        if frame.get("status") != "ready":
            key = "{}|missing".format(frame["id"])
            if not any(i.get("job_key") == key for i in issues):
                issues.append({
                    "job_key": key, "status": "skipped", "run_id": run_name,
                    "frame_id": frame["id"], "survey_id": "", "agent": "", "ratee": "",
                    "error": frame.get("error", "没有可用存档"),
                })
            continue
        checkpoint_path = frame["checkpoint_path"]
        expected_hash = frame["source_checkpoint_sha256"]
        pack_unchanged = True
        try:
            from modules.research.snapshots import pack_path
            pack_path(checkpoint_path, _read_json(checkpoint_path, {}))
        except ValueError:
            pack_unchanged = False
        if sha256_file(checkpoint_path) != expected_hash or not pack_unchanged:
            issues.append({
                "job_key": frame["id"] + "|hash-before", "status": "failed",
                "run_id": run_name, "frame_id": frame["id"], "survey_id": "",
                "agent": "", "ratee": "", "error": "来源checkpoint在补测前发生变化",
            })
            continue
        try:
            semantic_required = any(
                schemas[sid].get("mode") == "dyadic" for sid in frame.get("surveys") or []
            )
            game, config = _load_game(
                checkpoint_path, run_name, task_dir, semantic_required=semantic_required
            )
        except Exception as exc:  # noqa: BLE001
            issues.append({
                "job_key": frame["id"] + "|load", "status": "failed",
                "run_id": run_name, "frame_id": frame["id"], "survey_id": "",
                "agent": "", "ratee": "", "error": "加载存档失败：{}".format(exc),
            })
            continue

        jobs = []
        frame_issues = []
        all_agents = list(game.agents.keys())
        condition = world.get("condition", "")
        survey_date = frame["actual_time"][:8]
        model_map = (config.get("model_assignment") or {}).get("per_agent") or {}
        base_model = (config.get("model_assignment") or {}).get("base", "")
        # Freeze every context before the first completion request.
        for sid in frame.get("surveys") or []:
            schema = schemas[sid]
            if schema.get("mode") == "dyadic":
                allowed_raters = schema.get("raters") or all_agents
                raters = [a for a in frame.get("agents", []) if a in game.agents and a in allowed_raters]
                ratees = [a for a in (schema.get("ratees") or all_agents) if a in game.agents]
                for rater in raters:
                    for ratee in ratees:
                        if rater == ratee:
                            continue
                        key = _job_key(frame["id"], sid, rater, ratee)
                        if key in successful:
                            continue
                        try:
                            snapshot = game.get_agent(rater).snapshot_dyadic_survey(ratee, schema)
                            jobs.append((key, rater, ratee, schema, snapshot))
                        except Exception as exc:  # noqa: BLE001
                            frame_issues.append((key, sid, rater, ratee, exc))
            else:
                allowed = schema.get("targets") or all_agents
                targets = [a for a in frame.get("agents", []) if a in game.agents and a in allowed]
                for agent_name in targets:
                    key = _job_key(frame["id"], sid, agent_name)
                    if key in successful:
                        continue
                    try:
                        snapshot = game.get_agent(agent_name).snapshot_survey_context(schema)
                        jobs.append((key, agent_name, "", schema, snapshot))
                    except Exception as exc:  # noqa: BLE001
                        frame_issues.append((key, sid, agent_name, "", exc))

        lanes = {}
        for job in jobs:
            lanes.setdefault(job[1], []).append(job)

        def run_lane(lane):
            lane_out = []
            for key, agent_name, ratee, schema, snapshot in lane:
                if os.path.exists(cancel_marker):
                    break
                agent = game.get_agent(agent_name)
                try:
                    if ratee:
                        row = agent.complete_dyadic_survey(
                            schema, ratee, condition, run_name, survey_date, snapshot=snapshot
                        )
                    else:
                        row = agent.complete_custom_survey(
                            schema, condition, run_name, survey_date, snapshot=snapshot
                        )
                    if (row.get("_quality") or {}).get("status") in ("invalid", "partial"):
                        raise ValueError("问卷包含缺失或无效答案，已保留为失败项，可重试")
                    model = model_map.get(row.get("agent")) or base_model
                    meta = _response_metadata(manifest, world, frame, schema, row, expected_hash, model)
                    meta["reconstruction"] = config.get("_reconstruction", "legacy_partial")
                    answers = {q["id"]: row.get(q["id"]) for q in schema["questions"]}
                    if schema.get("include_reason", True):
                        answers["reason"] = row.get("reason", "")
                    answers["_quality"] = row.get("_quality", {"status": "legacy_unverified"})
                    answers["_measurement_policy"] = "passive"
                    with persistence_lock:
                        responses.append({"job_key": key, "meta": meta, "answers": answers})
                        successful.add(key)
                        _atomic_json(result_path, {"run_id": run_name, "responses": responses, "issues": issues})
                    lane_out.append((key, schema, row, None))
                except Exception as exc:  # noqa: BLE001
                    lane_out.append((key, schema, None, exc))
            return lane_out

        persistence_lock = threading.Lock()
        completed = []
        if lanes:
            with ThreadPoolExecutor(max_workers=min(4, len(lanes))) as executor:
                for lane_result in executor.map(run_lane, lanes.values()):
                    completed.extend(lane_result)
        for key, schema, row, exc in completed:
            if exc is not None:
                frame_issues.append((key, schema["id"], key.split("|")[2], key.split("|")[3], exc))
                continue
            if key in successful:
                continue
            model = model_map.get(row.get("agent")) or base_model
            meta = _response_metadata(manifest, world, frame, schema, row, expected_hash, model)
            answers = {q["id"]: row.get(q["id"], "") for q in schema["questions"]}
            if schema.get("include_reason", True):
                answers["reason"] = row.get("reason", "")
            meta["reconstruction"] = config.get("_reconstruction", "legacy_partial")
            answers["_quality"] = row.get("_quality", {"status": "legacy_unverified"})
            answers["_measurement_policy"] = "passive"
            responses.append({"job_key": key, "meta": meta, "answers": answers})
            successful.add(key)
        for key, sid, agent_name, ratee, exc in frame_issues:
            issues = [i for i in issues if i.get("job_key") != key]
            issues.append({
                "job_key": key, "status": "failed", "run_id": run_name,
                "frame_id": frame["id"], "survey_id": sid, "agent": agent_name,
                "ratee": ratee, "error": "{}: {}".format(type(exc).__name__, exc)[:1000],
            })
        pack_unchanged = True
        try:
            pack_path(checkpoint_path, config)
        except ValueError:
            pack_unchanged = False
        if sha256_file(checkpoint_path) != expected_hash or not pack_unchanged:
            responses = [r for r in responses if r.get("meta", {}).get("frame_id") != frame["id"]]
            issues.append({
                "job_key": frame["id"] + "|hash-after", "status": "failed",
                "run_id": run_name, "frame_id": frame["id"], "survey_id": "",
                "agent": "", "ratee": "", "error": "来源checkpoint在补测期间发生变化，已丢弃该时间帧结果",
            })
        _atomic_json(result_path, {"run_id": run_name, "responses": responses, "issues": issues})

    payload = {"run_id": run_name, "responses": responses, "issues": issues}
    responses.sort(key=lambda item: item.get("job_key", ""))
    _atomic_json(result_path, payload)
    working = os.path.abspath(os.path.join(task_dir, "_working", run_name))
    working_root = os.path.abspath(os.path.join(task_dir, "_working"))
    if os.path.commonpath((working, working_root)) == working_root and os.path.isdir(working):
        shutil.rmtree(working, ignore_errors=True)
    return {"run_id": run_name, "responses": len(responses), "issues": len(issues)}


def _csv_value(value):
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False)
    return value


def write_aggregates(task_dir):
    manifest = _read_json(os.path.join(task_dir, "manifest.json"), {}) or {}
    schemas = manifest.get("schemas") or {}
    responses, issues = [], []
    for world in manifest.get("worlds") or []:
        result = _read_json(_world_result_path(task_dir, world["name"]), {}) or {}
        responses.extend(result.get("responses") or [])
        issues.extend(result.get("issues") or [])
    process_result = _read_json(os.path.join(task_dir, "worlds", "_process.json"), {}) or {}
    issues.extend(process_result.get("issues") or [])

    question_columns = []
    for sid, schema in schemas.items():
        question_columns.extend([sid + "___quality", sid + "___measurement_policy"])
        for question in schema.get("questions") or []:
            question_columns.append("{}__{}".format(sid, question["id"]))
        if schema.get("include_reason", True):
            question_columns.append("{}__reason".format(sid))
    response_path = os.path.join(task_dir, "responses.csv")
    with open(response_path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=RESPONSE_META + ["reconstruction"] + question_columns, extrasaction="ignore")
        writer.writeheader()
        for item in responses:
            row = dict(item.get("meta") or {})
            sid = row.get("survey_id", "")
            for key, value in (item.get("answers") or {}).items():
                row["{}__{}".format(sid, key)] = _csv_value(value)
            writer.writerow(row)

    long_meta = RESPONSE_META + ["reconstruction", "question_id", "question_text", "question_type", "value"]
    with open(os.path.join(task_dir, "answers_long.csv"), "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=long_meta)
        writer.writeheader()
        for item in responses:
            meta = item.get("meta") or {}
            schema = schemas.get(meta.get("survey_id"), {})
            question_map = {q["id"]: q for q in schema.get("questions") or []}
            for key, value in (item.get("answers") or {}).items():
                if key.startswith("_"):
                    continue
                q = question_map.get(key, {"text": "评分原因", "type": "open"})
                writer.writerow({
                    **meta, "question_id": key, "question_text": q.get("text", ""),
                    "question_type": q.get("type", ""), "value": _csv_value(value),
                })

    with open(os.path.join(task_dir, "codebook.csv"), "w", encoding="utf-8-sig", newline="") as handle:
        fields = ["survey_id", "survey_title", "mode", "question_id", "column", "type", "text", "min", "max", "options"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for sid, schema in schemas.items():
            for q in schema.get("questions") or []:
                writer.writerow({
                    "survey_id": sid, "survey_title": schema.get("title", sid),
                    "mode": schema.get("mode", "self"), "question_id": q["id"],
                    "column": "{}__{}".format(sid, q["id"]), "type": q.get("type", ""),
                    "text": q.get("text", ""), "min": q.get("min", ""),
                    "max": q.get("max", ""), "options": "/".join(q.get("options") or []),
                })

    issue_fields = ["status", "run_id", "frame_id", "survey_id", "agent", "ratee", "error", "job_key"]
    with open(os.path.join(task_dir, "issues.csv"), "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=issue_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(issues)
    return {"responses": len(responses), "issues": len(issues)}


class TaskManager:
    def __init__(self, root=ROOT, max_worlds=4):
        self.root = root
        self.max_worlds = max(1, min(4, int(max_worlds)))
        self.lock = threading.Lock()
        self.threads = {}
        self._recover_interrupted()

    def _recover_interrupted(self):
        if not os.path.isdir(self.root):
            return
        for base, _, files in os.walk(self.root):
            if "status.json" not in files:
                continue
            path = os.path.join(base, "status.json")
            status = _read_json(path, {}) or {}
            if status.get("status") in ("queued", "running", "cancelling"):
                status.update({"status": "interrupted", "message": "主服务曾重启，可点击重试继续未完成项"})
                _atomic_json(path, status)

    def create(self, prepared, title=""):
        task_id = "P{}-{}".format(time.strftime("%Y%m%d-%H%M%S"), secrets.token_hex(2))
        base = task_id
        number = 1
        while os.path.exists(_task_dir(prepared["batch_id"], prepared["group_id"], task_id)):
            number += 1
            task_id = "{}-{}".format(base, number)
        task_dir = _task_dir(prepared["batch_id"], prepared["group_id"], task_id)
        os.makedirs(os.path.join(task_dir, "worlds"), exist_ok=False)
        manifest = copy.deepcopy(prepared)
        manifest.update({
            "task_id": task_id, "title": (str(title or "").strip() or "历史批组补测")[:80],
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"), "version": 1,
        })
        _atomic_json(os.path.join(task_dir, "manifest.json"), manifest)
        _atomic_json(os.path.join(task_dir, "status.json"), {
            "task_id": task_id, "status": "queued", "completed_worlds": 0,
            "total_worlds": len(manifest["worlds"]), "responses": 0, "issues": 0,
            "message": "等待执行", "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        })
        self.start(manifest["batch_id"], manifest["group_id"], task_id)
        return self.get(manifest["batch_id"], manifest["group_id"], task_id)

    def _paths(self, batch_id, group_id, task_id):
        task_dir = _task_dir(batch_id, group_id, task_id)
        return task_dir, os.path.join(task_dir, "status.json")

    def get(self, batch_id, group_id, task_id):
        task_dir, status_path = self._paths(batch_id, group_id, task_id)
        manifest = _read_json(os.path.join(task_dir, "manifest.json"))
        status = _read_json(status_path)
        if not manifest or not status:
            return None
        return {**status, "batch_id": batch_id, "group_id": group_id,
                "title": manifest.get("title", "历史批组补测"),
                "created_at": manifest.get("created_at", ""),
                "estimated_calls": manifest.get("estimated_calls", 0),
                "download_url": "/api/posthoc/tasks/{}/download?batch_id={}&group_id={}".format(
                    task_id, batch_id, group_id
                ) if status.get("responses", 0) else ""}

    def list_group(self, batch_id, group_id):
        base = os.path.join(self.root, batch_id, group_id)
        if not os.path.isdir(base):
            return []
        out = []
        for task_id in sorted(os.listdir(base), reverse=True):
            try:
                item = self.get(batch_id, group_id, task_id)
            except ValueError:
                item = None
            if item:
                out.append(item)
        return out

    def find(self, task_id):
        if not _SAFE.match(task_id or "") or not os.path.isdir(self.root):
            return None
        for batch_id in os.listdir(self.root):
            batch_dir = os.path.join(self.root, batch_id)
            if not os.path.isdir(batch_dir):
                continue
            for group_id in os.listdir(batch_dir):
                candidate = os.path.join(batch_dir, group_id, task_id)
                if os.path.isdir(candidate):
                    item = self.get(batch_id, group_id, task_id)
                    if item:
                        return batch_id, group_id, item
        return None

    def start(self, batch_id, group_id, task_id):
        key = (batch_id, group_id, task_id)
        with self.lock:
            thread = self.threads.get(key)
            if thread and thread.is_alive():
                raise ValueError("该补测任务正在运行")
            task_dir, _ = self._paths(*key)
            marker = os.path.join(task_dir, "cancel.marker")
            if os.path.exists(marker):
                os.remove(marker)
            thread = threading.Thread(target=self._run, args=key, daemon=True)
            self.threads[key] = thread
            thread.start()

    def _run(self, batch_id, group_id, task_id):
        task_dir, status_path = self._paths(batch_id, group_id, task_id)
        process_result = os.path.join(task_dir, "worlds", "_process.json")
        if os.path.exists(process_result):
            os.remove(process_result)
        manifest = _read_json(os.path.join(task_dir, "manifest.json"), {}) or {}
        worlds = [w["name"] for w in manifest.get("worlds") or []]
        status = _read_json(status_path, {}) or {}
        status.update({"status": "running", "message": "正在加载存档并执行补测",
                       "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S")})
        _atomic_json(status_path, status)
        completed = 0
        process_errors = []
        try:
            with ProcessPoolExecutor(max_workers=min(self.max_worlds, max(1, len(worlds)))) as pool:
                futures = {pool.submit(execute_world, task_dir, name): name for name in worlds}
                for future in as_completed(futures):
                    name = futures[future]
                    try:
                        future.result()
                    except Exception as exc:  # noqa: BLE001
                        process_errors.append({
                            "status": "failed", "run_id": name, "frame_id": "",
                            "survey_id": "", "agent": "", "ratee": "",
                            "job_key": name + "|process",
                            "error": "{}\n{}".format(exc, traceback.format_exc())[:4000],
                        })
                    completed += 1
                    aggregate = write_aggregates(task_dir)
                    status.update({"completed_worlds": completed, **aggregate,
                                   "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S")})
                    _atomic_json(status_path, status)
        except Exception as exc:  # noqa: BLE001
            process_errors.append({"status": "failed", "run_id": "", "frame_id": "",
                                   "survey_id": "", "agent": "", "ratee": "",
                                   "job_key": "manager", "error": str(exc)})
        if process_errors:
            _atomic_json(os.path.join(task_dir, "process_issues.json"), process_errors)
            # Merge process-level failures into the public issues file via a synthetic result.
            _atomic_json(os.path.join(task_dir, "worlds", "_process.json"),
                         {"run_id": "", "responses": [], "issues": process_errors})
        aggregate = write_aggregates(task_dir)
        cancelled = os.path.exists(os.path.join(task_dir, "cancel.marker"))
        final = "cancelled" if cancelled else (
            "failed" if aggregate["responses"] == 0 and aggregate["issues"] else
            "partial" if aggregate["issues"] else "completed"
        )
        status.update({
            "status": final, **aggregate,
            "message": {"cancelled": "已停止", "failed": "补测失败", "partial": "部分完成",
                        "completed": "补测完成"}[final],
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        })
        _atomic_json(status_path, status)

    def cancel(self, batch_id, group_id, task_id):
        task_dir, status_path = self._paths(batch_id, group_id, task_id)
        if not os.path.isdir(task_dir):
            return None
        with open(os.path.join(task_dir, "cancel.marker"), "w", encoding="utf-8") as handle:
            handle.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
        status = _read_json(status_path, {}) or {}
        status.update({"status": "cancelling", "message": "正在停止；已发出的模型请求会先结束"})
        _atomic_json(status_path, status)
        return status

    def retry(self, batch_id, group_id, task_id):
        item = self.get(batch_id, group_id, task_id)
        if not item:
            return None
        if item["status"] in ("queued", "running", "cancelling"):
            raise ValueError("任务尚未结束")
        self.start(batch_id, group_id, task_id)
        return self.get(batch_id, group_id, task_id)

    def bundle(self, batch_id, group_id, task_id):
        task_dir, _ = self._paths(batch_id, group_id, task_id)
        if not os.path.isdir(task_dir):
            return None
        write_aggregates(task_dir)
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            for filename in ("responses.csv", "answers_long.csv", "codebook.csv", "issues.csv",
                             "manifest.json", "status.json"):
                path = os.path.join(task_dir, filename)
                if os.path.isfile(path):
                    archive.write(path, filename)
            metrics_dir = os.path.join(task_dir, "model_calls")
            if os.path.isdir(metrics_dir):
                for filename in sorted(os.listdir(metrics_dir)):
                    if filename.endswith(".jsonl"):
                        archive.write(os.path.join(metrics_dir, filename), os.path.join("model_calls", filename))
            worlds_dir = os.path.join(task_dir, "worlds")
            if os.path.isdir(worlds_dir):
                for filename in sorted(os.listdir(worlds_dir)):
                    if filename.endswith(".json"):
                        archive.write(os.path.join(worlds_dir, filename), os.path.join("worlds", filename))
        buffer.seek(0)
        return buffer
