"""generative_agents.storage"""
