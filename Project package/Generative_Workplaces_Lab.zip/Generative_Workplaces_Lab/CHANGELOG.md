# Changelog

A summary of the versions of Workplace Simulation Lab. The newest version is first.

## V27.4 (2026-11-07): template names state the language of the world

- The eight built-in world templates have English names with a language suffix: `_EN` for English-language worlds, `_CN` for Chinese-language worlds (for example `Persona-manipulation-high-abuse_EN` and `Persona-manipulation-high-abuse_CN`). Until V27.3 the `_EN` templates had no suffix and the `_CN` templates had names in Chinese.
- Only the file names changed. The template contents are byte-identical, and the comparable-group ID is computed from the contents, so worlds run before and after the renaming belong to the same comparable group and can be pooled.
- Old names still work wherever a template is requested by name. An installation upgraded by overwriting renames its old files on start, and keeps any old file whose content the user changed.
- The English interface lists the `_EN` templates. The `_CN` templates are listed after clicking the link under the agent list.
- The README is retitled “Simulating Organizational Behavior with Generative Agents”: the platform serves organizational behavior research in general, and abusive supervision is its first application.
- The browser tab title showed V27.2; it now shows V27.4.
- Six new tests. All 191 tests pass.

## V27.3 (2026-11-03): no Chinese left in the English interface or in English worlds

- Batch status words (Running, Queued, Completed, Failed, Stopped) and status summaries are shown in English.
- In English worlds, the area columns of `behavior_agent_daily.csv` have English names (for example `area_min__open_office_area`). The values are unchanged.
- In English worlds, the built-in daily questionnaire (off by default) names the agents in English, so the team lead keeps his role when it is switched on.
- A few missing translations were added, and the Replay link of finished batch worlds works again.
- English agents are listed first, with the team (Klaus, Ayesha, Maria, Wolfgang) at the front.
- Checked page by page in an offline English batch, including the exported data. The server log is the only place where Chinese text remains.

## V27.2 (2026-11-01): English by default, more model providers, replication tools

- The interface opens in English.
- Launcher and installer messages are bilingual, and the root folder was tidied.
- Official Gemini and Claude APIs added as model providers.
- Replication analysis: reverse-keyed items are scored in the hypothesis checker, and diary hypotheses get a within-person test.

## V27.1 (2026-10-29): start-up fix

- Fixed “Server did not become ready” when a folder holds many finished worlds.

## V27 (2026-10-29): English version

- Interface language switch (English or Chinese).
- English worlds: English prompts, personas, world rules, leadership styles, place names and questionnaires, with answers parsed in English formats. English and Chinese worlds never share a comparable group.

## V26 (2026-10-29): final persona manipulation and an installer

- The leadership style of the persona manipulation is fixed to the “habit” version: the team lead’s concrete behaviours, written as habits formed over years of leading the team, with no evaluative words and no description of motives.
- Installer for new users (`Install.bat`, `install.sh`), which creates a separate Python environment inside the project folder.

## V25.1–V25.4 (2026-10-28): leadership-style versions, budget mode, map background

- V25.4: the habit version of the leadership style.
- V25.3: an office-floor background around the map.
- V25.2: a brief, stable version of the leadership style for comparison runs; the launcher no longer opens an old version after an upgrade.
- V25.1: budget mode for pilots and prompt tuning. Budget-mode worlds form their own comparable group and are never pooled with main-mode worlds.

## V25 (2026-10-28): behaviour-only leadership styles and daily routine

- Leadership styles describe only the team lead’s behaviour.
- Agents no longer go to bed right after work; the hard-coded office routine was removed.
- Reflections are written as first-person feelings, and each day’s “current state” includes the agent’s views of and plans towards the people around them.

## V24 (late October 2026): real-time control and the replication questionnaires

- Real-time injection by the researcher (back end).
- Questionnaire scheduling and custom questionnaires on the setup page.
- The replication questionnaires loaded into the persona-manipulation templates.
- Personality descriptions shortened to a BFI-10-style text; work setting, leadership style and run length settled; world rules added.

## V23 (late October 2026): formal experiments

- Batch runs of a pair of templates, where world *i* of both groups uses the same seed and therefore the same personalities; templates are checked before a batch starts.
- Experimental conditions change only the team lead’s leadership-style field. Fixed background and leadership-style fields go into every prompt and are never rewritten.
- Questionnaires are answered from the day’s experiences and conversations, retrieved earlier memories, and impressions of coworkers.
- Big Five personalities drawn from real IPIP respondents. Character, replay and live-view improvements, and a redesigned setup page.

## V22 (October 2026): three kinds of intervention

- Researcher interventions in a running world: an event happens (with a chosen audience), a thought or intention is written into one agent, or an agent’s next action is specified. Each is confirmed on a review card, can be scheduled for a later simulated time, and is logged with its ID, time, people involved and the checkpoint it was applied to. Specified actions are flagged and cannot be read as spontaneous behaviour.
