# -*- coding: utf-8 -*-
"""V23: template consistency, fixed background, personality sampling, survey context,
scheduled leader actions, chat ending, persistent intents, day-limited surveys."""
import copy
import json
import os
import re
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import server
from modules import personality, survey, utils
from modules.prompt.scratch import Scratch
from modules.research import world_check

ROOT = Path(__file__).resolve().parents[1]
PRESETS = ROOT / "data" / "world_presets"


def load(name):
    return json.loads((PRESETS / (name + ".json")).read_text(encoding="utf-8"))


class TemplateTests(unittest.TestCase):
    def build(self, name, **extra):
        payload = load(name)
        payload.update(name="v23-test-" + str(abs(hash(name)) % 10000), **extra)
        return payload, server.build_experiment_config(payload)[2]

    def test_persona_templates_differ_only_in_leader_conduct(self):
        items = []
        for name in ("人设操纵-高辱虐组", "人设操纵-低辱虐组"):
            payload, cfg = self.build(name)
            result = world_check.check_world(payload, cfg)
            self.assertEqual(result["errors"], [])
            items.append((name, payload, result["personas"]))
        comparison = world_check.compare_worlds(items)
        self.assertEqual(comparison["other"], [])
        high, low = items[0][2], items[1][2]
        for agent in ("阿伊莎", "玛丽亚", "沃尔夫冈"):
            self.assertEqual(high[agent], low[agent])
        self.assertNotEqual(high["克劳斯"], low["克劳斯"])
        strip = lambda text: re.sub(r"【领导风格】：.*?\n\n", "\n", text, flags=re.S)  # noqa: E731
        self.assertEqual(strip(high["克劳斯"]), strip(low["克劳斯"]))

    def test_condition_label_reaches_exports(self):
        _, high = self.build("人设操纵-高辱虐组")
        _, low = self.build("人设操纵-低辱虐组")
        self.assertEqual(high["experiment"]["condition"], "persona_high")
        self.assertEqual(low["experiment"]["condition"], "persona_low")

    def test_event_templates_share_persona_and_differ_in_events(self):
        _, high = self.build("事件操纵-高辱虐组")
        _, low = self.build("事件操纵-低辱虐组")
        self.assertEqual(high["agents"]["克劳斯"]["scratch"], low["agents"]["克劳斯"]["scratch"])
        self.assertEqual(len(high["scheduled_events"]), 8)
        self.assertTrue(all(e["kind"] == "specified_action" for e in high["scheduled_events"]))
        self.assertNotEqual([e["text"] for e in high["scheduled_events"]],
                            [e["text"] for e in low["scheduled_events"]])

    def test_condition_and_override_conflict_is_blocked(self):
        payload = load("人设操纵-高辱虐组")
        payload["name"] = "v23-conflict"
        payload["persona_overrides"] = {"克劳斯": {"conduct": "克劳斯总是鼓励员工。"}}
        with self.assertRaisesRegex(ValueError, "模板核对未通过"):
            server.build_experiment_config(payload)

    def test_construct_label_in_persona_is_blocked(self):
        payload = load("事件操纵-低辱虐组")
        payload["name"] = "v23-label"
        payload["persona_overrides"] = {"阿伊莎": {"learned": "阿伊莎经常遭受辱虐管理。"}}
        with self.assertRaisesRegex(ValueError, "辱虐"):
            server.build_experiment_config(payload)

    def test_agents_see_neutral_survey_titles(self):
        _, cfg = self.build("人设操纵-高辱虐组")
        for schema in cfg["custom_surveys"]:
            self.assertTrue(schema["display_title"])
            self.assertFalse([t for t in world_check.BANNED_TERMS if t in schema["display_title"]])

    def test_template_parameters(self):
        payload = load("人设操纵-高辱虐组")
        self.assertEqual((payload["step"], payload["stride"], payload["chat_iter"]), (120, 60, 8))
        self.assertEqual(payload["survey_context"]["budget_tokens"], 8000)


class PersonalityTests(unittest.TestCase):
    def test_same_seed_same_people_different_seed_different_people(self):
        agents = ["克劳斯", "阿伊莎", "玛丽亚", "沃尔夫冈"]
        a = personality.sample_profiles(agents, 3)
        b = personality.sample_profiles(agents, 3)
        c = personality.sample_profiles(agents, 4)
        self.assertEqual(a, b)
        self.assertNotEqual([p["source_row"] for p in a.values()], [p["source_row"] for p in c.values()])
        self.assertEqual(len({p["source_row"] for p in a.values()}), 4)
        for profile in a.values():
            self.assertFalse(re.search(r"\d", profile["text"]))

    def test_levels_cover_nine_bands(self):
        self.assertEqual(personality.level_from_percentile(0), 1)
        self.assertEqual(personality.level_from_percentile(50), 5)
        self.assertEqual(personality.level_from_percentile(100), 9)
        self.assertIn("既不", personality.describe_domain("openness", 5))
        self.assertTrue(personality.describe_domain("openness", 9).startswith("极其"))

    def test_paired_worlds_share_personality(self):
        payload = load("事件操纵-高辱虐组")
        configs = []
        for name in ("事件操纵-高辱虐组", "事件操纵-低辱虐组"):
            p = load(name)
            p.update(name="v23-pair-" + name[-3:], seed=7)
            configs.append(server.build_experiment_config(p)[2])
        self.assertEqual(configs[0]["personality"]["profiles"], configs[1]["personality"]["profiles"])
        self.assertTrue(payload["personality"]["enabled"])


class PersonaLayerTests(unittest.TestCase):
    def setUp(self):
        utils.set_timer("20240214-09:00")
        self.scratch = Scratch("阿伊莎", "阿伊莎今天心情一般。", {
            "age": 22, "innate": "性格", "learned": "员工", "lifestyle": "上班", "daily_plan": "工作",
            "background": "阿伊莎在资源上完全依赖克劳斯。", "conduct": "",
        })
        self.scratch.template_path = str(ROOT / "data" / "prompts")

    def test_background_survives_daily_rewrite_of_currently(self):
        self.scratch.currently = "阿伊莎觉得昨天过得还行。"
        text = self.scratch._base_desc()
        self.assertIn("【固定背景】：阿伊莎在资源上完全依赖克劳斯。", text)
        self.assertIn("阿伊莎觉得昨天过得还行。", text)

    def test_persistent_intent_expires(self):
        self.scratch.config["intents"] = [
            {"text": "想找机会和玛丽亚和好", "expires": "20240215-09:00"},
            {"text": "已过期的打算", "expires": "20240214-08:00"},
        ]
        text = self.scratch._base_desc()
        self.assertIn("【持续的打算】：想找机会和玛丽亚和好", text)
        self.assertNotIn("已过期的打算", text)

    def test_psych_text_has_no_numbers(self):
        from modules.psych import PsychState
        self.assertFalse(re.search(r"\d", PsychState().describe()))


class SurveyTests(unittest.TestCase):
    def test_schema_keeps_v23_fields(self):
        schema = survey.validate_schema({"id": "x", "title": "辱虐（研究者看）", "display_title": "今日问卷",
                                         "time_frame": "general", "days": [1],
                                         "questions": [{"id": "q1", "text": "题", "min": 1, "max": 5}]})
        self.assertEqual((schema["display_title"], schema["time_frame"], schema["days"]), ("今日问卷", "general", [1]))
        with self.assertRaises(survey.SchemaError):
            # V24 added "recent" and "week"; anything else is still rejected.
            survey.validate_schema({"id": "x", "time_frame": "month",
                                    "questions": [{"id": "q1", "text": "题"}]})

    def test_unparseable_answer_is_retried(self):
        utils.set_timer("20240214-21:00")
        scratch = Scratch("阿伊莎", "", {"age": 22, "innate": "", "learned": "", "lifestyle": "", "daily_plan": ""})
        scratch.template_path = str(ROOT / "data" / "prompts")
        schema = survey.validate_schema({"id": "x", "questions": [{"id": "q1", "text": "题", "min": 1, "max": 5}]})
        prompt = scratch.prompt_custom_survey(schema, "20240214-21:00", "上下文")
        self.assertIsNone(prompt["callback"]("not json"))
        self.assertEqual(prompt["callback"]('{"q1": 3, "reason": "r"}')["q1"], 3)
        self.assertEqual(prompt["retry"], 3)
        self.assertIn("今日工作日志", prompt["prompt"])
        self.assertNotIn("智能体", prompt["prompt"])

    def test_context_budget_estimate(self):
        from modules import survey_context
        self.assertEqual(survey_context.estimate_tokens("你好abc"), 2 + int(0.3 * 3) + 1)


class ChatTests(unittest.TestCase):
    def make_agent(self, name, script):
        from modules.agent import Agent
        agent = Agent.__new__(Agent)
        agent.name, agent.chat_iter, agent._monitor_buffer = name, 8, []
        agent.conversation, agent.logger = {}, SimpleNamespace(info=lambda *a, **k: None)
        agent.scratch = SimpleNamespace(config={})
        agent.schedule = SimpleNamespace(daily_schedule=[1])
        agent.path = []
        agent._skip_react = lambda other: False
        event = SimpleNamespace(fit=lambda **k: False, address=["w", "办公室", "会议区"])
        agent.get_event = lambda *a, **k: event
        agent.associate = SimpleNamespace(retrieve_chats=lambda *a, **k: [])
        agent.scheduled = []
        agent.schedule_chat = lambda *a, **k: agent.scheduled.append(a)

        def completion(func, *args, **kwargs):
            if func == "decide_chat":
                return True
            if func == "summarize_relation":
                return "关系一般"
            if func == "summarize_chats":
                return "两人聊了几句"
            if func == "generate_chat":
                return script.pop(0)
            raise AssertionError(func)
        agent.completion = completion
        return agent

    def test_speaker_ends_chat_in_same_call(self):
        utils.set_timer("20240214-10:00")
        a = self.make_agent("甲", [("你好", False), ("我先回去改了", True), ("不该出现", False)])
        b = self.make_agent("乙", [("你好", False), ("不该出现", False)])
        a.conversation = b.conversation = {}
        self.assertTrue(a._chat_with(b, "focus"))
        chats = next(iter(a.conversation.values()))[0]
        lines = next(iter(chats.values()))
        self.assertEqual([t for _, t in lines], ["你好", "你好", "我先回去改了"])
        self.assertEqual(a.last_chat_meta["ended_by_speaker"], True)
        self.assertEqual(a.last_chat_meta["rounds"], 2)
        self.assertIn("乙", a.scratch.config["relations"])

    def test_cap_of_eight_rounds(self):
        utils.set_timer("20240214-10:00")
        a = self.make_agent("甲", [("继续", False)] * 10)
        b = self.make_agent("乙", [("继续", False)] * 10)
        a.conversation = b.conversation = {}
        a._chat_with(b, "focus")
        self.assertEqual(a.last_chat_meta["utterances"], 16)
        self.assertTrue(a.last_chat_meta["hit_cap"])

    def test_generate_chat_callback_reads_end_flag(self):
        utils.set_timer("20240214-10:00")
        scratch = Scratch("甲", "", {"age": 1, "innate": "", "learned": "", "lifestyle": "", "daily_plan": ""})
        scratch.template_path = str(ROOT / "data" / "prompts")
        tile = SimpleNamespace(get_address=lambda *a, **k: ["w", "办公室", "会议区"])
        event = SimpleNamespace(get_describe=lambda *a, **k: "在工作")
        other = SimpleNamespace(name="乙", get_event=lambda *a, **k: event)
        assoc = SimpleNamespace(retrieve_focus=lambda *a, **k: [], retrieve_chats=lambda *a, **k: [])
        agent = SimpleNamespace(name="甲", associate=assoc, get_tile=lambda: tile, get_event=lambda *a, **k: event)
        prompt = scratch.prompt_generate_chat(agent, other, "关系一般", [])
        self.assertIn("结束对话", prompt["prompt"])
        self.assertEqual(prompt["callback"]('{"甲": "我先走了", "结束对话": true}'), ("我先走了", True))
        self.assertEqual(prompt["callback"]('{"甲": "你呢？", "结束对话": false}'), ("你呢？", False))


class OfflineWorldTests(unittest.TestCase):
    """Two offline days of the event template: scheduled leader action, survey context, days filter."""

    def test_event_template_two_days(self):
        from start import SimulateServer
        origin = Path.cwd()
        payload = load("事件操纵-高辱虐组")
        payload.update(name="v23-offline-event", offline=True, step=30)
        _, args, cfg = server.build_experiment_config(payload)
        with tempfile.TemporaryDirectory() as root:
            os.chdir(root)
            try:
                run = SimulateServer(args.name, str(origin / "frontend/static"),
                                     "results/checkpoints/" + args.name, cfg, verbose="error")
                for agent in run.game.agents.values():
                    agent.scratch.template_path = str(origin / "data/prompts")
                run.simulate(30, stride=60)
                rows = [json.loads(line) for line in
                        open("results/interventions/%s/interventions.jsonl" % args.name, encoding="utf-8")]
                first = [r for r in rows if r.get("intervention_id") == "scenario_d2_high_1"]
                self.assertEqual(len(first), 1)
                self.assertEqual(first[0]["status"], "applied")
                self.assertEqual(sorted(first[0]["targets"]), ["克劳斯", "阿伊莎"])
                # Each day starts a fresh schedule (V22 appended day 2 after day 1).
                for agent in run.game.agents.values():
                    self.assertTrue(all(plan["start"] < 1440 for plan in agent.schedule.daily_schedule))
                leader = run.game.get_agent("克劳斯")
                described = [leader.associate.find_concept(n).describe for n in leader.associate.memory["event"]]
                self.assertTrue(any("方案很愚蠢" in d for d in described))
                # Personality check ran on day 1 only; daily surveys carry context metadata.
                big5 = [json.loads(l) for l in open("results/surveys/%s/custom_big5_check.jsonl" % args.name,
                                                    encoding="utf-8")]
                self.assertEqual({r["survey_date"] for r in big5}, {"20240213"})
                abuse = [json.loads(l) for l in open("results/surveys/%s/custom_abusive_self.jsonl" % args.name,
                                                     encoding="utf-8")]
                self.assertTrue(abuse)
                self.assertEqual(abuse[0]["_context"]["context_version"], "three_layer_v1")
                self.assertLessEqual(abuse[0]["_context"]["est_tokens"], 8000)
                # Day-2 context for 阿伊莎 lists today's episodes only under today's heading.
                aisha = run.game.get_agent("阿伊莎")
                text = aisha.snapshot_survey_context(cfg["custom_surveys"][2])["context_text"]
                today_block = text.split("【今天（")[1].split("【")[0]
                self.assertIn("方案很愚蠢", today_block)
                self.assertNotIn("沙发", today_block)
            finally:
                os.chdir(origin)


if __name__ == "__main__":
    unittest.main()


class AgentRosterTests(unittest.TestCase):
    def test_all_agents_are_office_compatible_and_neutral(self):
        agents = server.list_available_agents()
        self.assertGreaterEqual(len(agents), 26)
        self.assertTrue(all(a["office_compatible"] for a in agents))
        for a in agents:
            cfg = json.loads((ROOT / "frontend/static/assets/village/agents" / a["name"] / "agent.json")
                             .read_text(encoding="utf-8"))
            text = json.dumps({k: cfg.get(k) for k in ("currently", "scratch")}, ensure_ascii=False)
            self.assertFalse([t for t in world_check.BANNED_TERMS if t in text], a["name"])
            self.assertIn("background", cfg["scratch"])

    def test_random_appearance_is_reproducible(self):
        from modules import appearance
        from PIL import Image
        with tempfile.TemporaryDirectory() as root:
            a = appearance.generate(os.path.join(root, "a"), seed="x1",
                                    root=str(ROOT / "frontend/static/assets/village/agents"))
            b = appearance.generate(os.path.join(root, "b"), seed="x1",
                                    root=str(ROOT / "frontend/static/assets/village/agents"))
            self.assertEqual(a, b)
            self.assertNotIn(a["base"], appearance.NON_HUMAN)
            tex = Image.open(os.path.join(root, "a", "texture.png"))
            self.assertEqual(tex.size, (96, 128))
            self.assertEqual(Image.open(os.path.join(root, "a", "portrait.png")).size, (32, 32))


class ReplayTests(unittest.TestCase):
    def test_old_step_logs_get_previous_cell_for_animation(self):
        from modules.research.common import fill_prev_coords
        rows = [{"step": 1, "agents": {"甲": {"coord": [1, 1], "path": []}}},
                {"step": 2, "agents": {"甲": {"coord": [1, 3], "path": [[1, 2], [1, 3]]}}}]
        out = fill_prev_coords(rows)
        self.assertNotIn("prev_coord", out[0]["agents"]["甲"])
        self.assertEqual(out[1]["agents"]["甲"]["prev_coord"], [1, 1])
        self.assertNotIn("prev_coord", rows[1]["agents"]["甲"])  # input untouched
        kept = fill_prev_coords([{"step": 3, "agents": {"甲": {"coord": [2, 2], "prev_coord": [2, 1]}}}])
        self.assertEqual(kept[0]["agents"]["甲"]["prev_coord"], [2, 1])
