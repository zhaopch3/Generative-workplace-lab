# -*- coding: utf-8 -*-
"""批量执行器的单run工作进程（由 batch.py 启动，不需要手动运行）。"""
import argparse
import json

from start import SimulateServer

STATIC_ROOT = "frontend/static"
CHECKPOINTS_PATH = "results/checkpoints"

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--step", type=int, required=True)
    parser.add_argument("--stride", type=int, required=True)
    parser.add_argument("--verbose", default="info")
    args = parser.parse_args()

    with open(args.config, "r", encoding="utf-8") as f:
        config = json.load(f)

    server = SimulateServer(
        args.name,
        STATIC_ROOT,
        f"{CHECKPOINTS_PATH}/{args.name}",
        config,
        start_step=0,
        verbose=args.verbose,
        log_file="batch.log",
    )
    server.simulate(args.step, args.stride)
    print(f"[worker] {args.name} finished")
