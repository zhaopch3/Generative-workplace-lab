import os
import queue
import tempfile
import json
from pathlib import Path
from types import SimpleNamespace

from modules.memory.event import Event
from server import SimulationRunner
from start import SimulateServer


class FakeAssociate:
    def __init__(self):
        self.rows = []

    def add_node(self, kind, event, poignancy):
        self.rows.append((kind, event, poignancy))
        return object()


class FakeTile:
    def __init__(self, coord=(1, 1), address=None):
        self.coord = coord
        self.address = address or ["world", "office", "room"]
        self.events = []

    def get_address(self, *args, **kwargs):
        return list(self.address)

    def add_event(self, event):
        if event not in self.events:
            self.events.append(event)

    def remove_events(self, event=None, **kwargs):
        if event in self.events:
            self.events.remove(event)


class FakeAgent:
    def __init__(self, name, tile):
        self.name, self.coord, self.tile = name, list(tile.coord), tile
        self.associate = FakeAssociate()
        self.status = {"poignancy": 0}
        self.scratch = SimpleNamespace(currently="原状态", config={})
        self._psych_buffer, self._monitor_buffer = [], []
        self.forced = None
        self.psych = None

    def get_tile(self):
        return self.tile

    def make_event(self, subject, text, address):
        return Event(subject, describe=text, address=address)

    def set_psych(self, values):
        self.psych = values

    def inject_forced_action(self, text, address, **kwargs):
        self.forced = {"text": text, "address": address, **kwargs}

    def notify_injection(self, kind, text, intervention_id=None):
        self.notified = getattr(self, "notified", []) + [(kind, text, intervention_id)]


class FakeMaze:
    def __init__(self, tile):
        self.tile = tile
        self.address_tiles = {"world:office:room": {tile.coord}}

    def get_address_tiles(self, address):
        return {self.tile.coord}

    def tile_at(self, coord):
        return self.tile


def fake_server():
    tile = FakeTile()
    agents = {name: FakeAgent(name, tile) for name in ("甲", "乙")}
    game = SimpleNamespace(
        agents=agents,
        maze=FakeMaze(tile),
        get_agent=lambda name: agents[name],
    )
    server = SimulateServer.__new__(SimulateServer)
    server.game = game
    server.config = {}
    server._transient_world_events = []
    server._preintervention_checkpoint = lambda item, step: ("before.json", "abc")
    server._append_intervention_record = lambda record: None
    server.logger = SimpleNamespace(info=lambda *a, **k: None, warning=lambda *a, **k: None)
    return server, agents, tile


def base(kind, **extra):
    data = {
        "kind": kind,
        "intervention_id": "iv_test",
        "event_id": "evt_test",
        "created_at": "2026-09-13T12:00:00+0800",
        "text": "测试内容",
        "poignancy": 8,
        "psych": {},
    }
    data.update(extra)
    return data


def test_world_event_is_one_event_with_shared_provenance():
    server, agents, tile = fake_server()
    record = server.apply_intervention(base("world_event", scope="all", targets=[]), 3)
    assert len(tile.events) == 1
    event = tile.events[0]
    assert event.event_id == "evt_test"
    assert event.intervention_id == "iv_test"
    assert event.researcher_injected is True
    assert [row[1] for row in agents["甲"].associate.rows] == [event]
    assert [row[1] for row in agents["乙"].associate.rows] == [event]
    assert record["source_checkpoint_sha256"] == "abc"
    assert record["targets"] == ["甲", "乙"]


def test_local_world_event_uses_normal_perception_instead_of_direct_memory():
    server, agents, tile = fake_server()
    record = server.apply_intervention(
        base("world_event", scope="local", location="world:office:room"), 4
    )
    assert len(tile.events) == 1
    assert all(not agent.associate.rows for agent in agents.values())
    assert record["targets"] == []


def test_thought_is_private_and_persistent_only_when_requested():
    server, agents, _ = fake_server()
    record = server.apply_intervention(
        base("thought", targets=["甲"], persistent=True, event_id=None), 5
    )
    kind, event, _ = agents["甲"].associate.rows[0]
    assert kind == "thought"
    assert event.intervention_id == "iv_test"
    assert event.researcher_injected is True
    # V23: persistent thoughts live in the fixed intents layer, not in `currently`
    # (which the daily update rewrites).
    assert agents["甲"].scratch.currently == "原状态"
    assert [i["text"] for i in agents["甲"].scratch.config["intents"]] == ["测试内容"]
    assert not agents["乙"].associate.rows
    assert record["targets"] == ["甲"]


def test_specified_action_reaches_agent_action_channel():
    server, agents, _ = fake_server()
    record = server.apply_intervention(
        base("specified_action", actor="甲", object="乙", targets=["甲"]), 6
    )
    assert agents["甲"].forced["address"] == ["<persona>", "乙"]
    assert agents["甲"].forced["intervention_id"] == "iv_test"
    assert record["researcher_injected"] is True
    assert record["actor"] == "甲"


def test_queue_validates_and_persists_future_action():
    runner = SimulationRunner.__new__(SimulationRunner)
    runner.name = "queue-test"
    runner.config = {"agents": {"甲": {}, "乙": {}}}
    runner.interventions_queue = queue.Queue()
    runner.bus = SimpleNamespace(publish=lambda payload: None)
    old = os.getcwd()
    with tempfile.TemporaryDirectory() as folder:
        os.chdir(folder)
        try:
            public = runner.queue_intervention({
                "kind": "specified_action",
                "actor": "甲",
                "object": "乙",
                "text": "甲向乙说明新的安排",
                "scheduled_time": "2026-09-14T10:30",
            })
            assert public["scheduled_time"] == "20260914-10:30"
            assert public["targets"] == ["甲"]
            assert "_pending_path" not in public
            queued = runner.interventions_queue.get_nowait()
            assert os.path.isfile(queued["_pending_path"])
            try:
                runner.queue_intervention({
                    "kind": "world_event", "scope": "selected", "text": "事件"
                })
                raise AssertionError("missing selected targets should fail")
            except ValueError:
                pass
        finally:
            os.chdir(old)


def test_offline_step_executes_and_audits_specified_action():
    import server as server_module

    origin = Path.cwd()
    preset = json.loads(
        (origin / "data/world_presets/人设操纵-低辱虐组.json").read_text(encoding="utf-8")
    )
    preset.update(
        name="v22-intervention-offline-check",
        offline=True,
        step=1,
        start_time="20240213-10:00",
        stride=60,
        custom_surveys=[],
        legacy_survey=False,
    )
    _, args, config = server_module.build_experiment_config(preset)
    interventions = queue.Queue()
    interventions.put(base(
        "specified_action",
        actor="克劳斯",
        object="玛丽亚",
        targets=["克劳斯"],
        text="克劳斯走向玛丽亚并说明新的工作安排",
    ))
    with tempfile.TemporaryDirectory() as folder:
        os.chdir(folder)
        try:
            run = SimulateServer(
                args.name,
                str(origin / "frontend/static"),
                "results/checkpoints/" + args.name,
                config,
                verbose="error",
                control={"interventions": interventions},
            )
            for agent in run.game.agents.values():
                agent.scratch.template_path = str(origin / "data/prompts")
            run.simulate(1, stride=60)
            records = [
                json.loads(line)
                for line in Path(run.interventions_log_path()).read_text(encoding="utf-8").splitlines()
            ]
            assert records[-1]["kind"] == "specified_action"
            assert records[-1]["researcher_injected"] is True
            timeline = [
                json.loads(line)
                for line in Path(run.timeline_log_path()).read_text(encoding="utf-8").splitlines()
            ]
            action_rows = [row for row in timeline if row.get("type") == "action" and row.get("agent") == "克劳斯"]
            assert action_rows and action_rows[-1]["researcher_injected"] is True
            assert action_rows[-1]["intervention_id"] == "iv_test"
        finally:
            os.chdir(origin)
