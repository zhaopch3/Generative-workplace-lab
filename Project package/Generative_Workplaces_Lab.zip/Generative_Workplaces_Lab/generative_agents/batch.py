# -*- coding: utf-8 -*-
"""批量实验执行器（阶段四）

一条命令并行执行多个run（如 strict×3 + lenient×3），结束后自动合并各run的
问卷数据、心理状态时间序列与干预日志，并输出按条件分组的描述统计。

用法：
    python batch.py --config experiments/batch_example.json
    python batch.py --config experiments/batch_example.json --dry-run   # 只校验配置

批量配置文件格式见 experiments/batch_example.json。
每个run是独立子进程（模拟器的时钟是全局单例，进程隔离保证run之间互不污染）。
"""
import argparse
import copy
import csv
import json
import os
import subprocess
import sys
import time

# 复用配置构建（含schema校验、人设覆盖、条件应用）
from server import build_experiment_config


def expand_runs(batch):
    """支持两种写法：显式runs列表，或 conditions × replicates 自动展开。"""
    if batch.get("runs"):
        return list(batch["runs"])
    conditions = batch.get("conditions") or [""]
    replicates = int(batch.get("replicates", 1))
    pattern = batch.get("name_pattern", "{batch}-{condition}-r{i}")
    runs = []
    for cond in conditions:
        for i in range(1, replicates + 1):
            runs.append({
                "name": pattern.format(
                    batch=batch.get("batch_name", "batch"),
                    condition=cond or "none", i=i,
                ),
                "condition": cond,
            })
    return runs


def build_all_configs(batch):
    """为每个run构建完整模拟config（共用base，覆盖name/condition/seed等）。"""
    base = batch.get("base") or {}
    prepared = []
    for run in expand_runs(batch):
        payload = copy.deepcopy(base)
        payload.update({k: v for k, v in run.items() if k != "overrides"})
        # run级覆盖（如个别run改问卷或人设）
        for key, value in (run.get("overrides") or {}).items():
            payload[key] = value
        name, args, config = build_experiment_config(payload)
        prepared.append({
            "name": name,
            "condition": payload.get("condition", ""),
            "step": args.step,
            "stride": args.stride,
            "config": config,
        })
    return prepared


def run_batch(batch, parallel=2, dry_run=False):
    batch_name = batch.get("batch_name", "batch")
    batch_dir = os.path.join("results", "batch", batch_name)
    if os.path.exists(batch_dir):
        raise SystemExit(f"批次目录已存在：{batch_dir}（换个 batch_name 或删除旧目录）")
    prepared = build_all_configs(batch)
    print(f"批次「{batch_name}」共 {len(prepared)} 个run：")
    for p in prepared:
        total_min = p["step"] * p["stride"]
        print(f"  - {p['name']}（条件={p['condition'] or '无'}，{p['step']}步×{p['stride']}分钟 ≈ 模拟{total_min/1440:.1f}天）")
    if dry_run:
        print("dry-run 校验通过，未执行。")
        return

    os.makedirs(os.path.join(batch_dir, "configs"), exist_ok=True)
    os.makedirs(os.path.join(batch_dir, "logs"), exist_ok=True)

    pending = []
    for p in prepared:
        cfg_path = os.path.join(batch_dir, "configs", f"{p['name']}.json")
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(p["config"], f, ensure_ascii=False)
        pending.append((p, cfg_path))

    running = []  # (proc, p, log_handle, start_ts)
    done = []
    parallel = max(1, int(parallel))
    while pending or running:
        while pending and len(running) < parallel:
            p, cfg_path = pending.pop(0)
            log_path = os.path.join(batch_dir, "logs", f"{p['name']}.log")
            log_handle = open(log_path, "w", encoding="utf-8")
            proc = subprocess.Popen(
                [sys.executable, "-u", "batch_worker.py",
                 "--name", p["name"], "--config", cfg_path,
                 "--step", str(p["step"]), "--stride", str(p["stride"])],
                stdout=log_handle, stderr=subprocess.STDOUT,
            )
            running.append((proc, p, log_handle, time.time()))
            print(f"[启动] {p['name']} (pid={proc.pid})")
        time.sleep(3)
        still = []
        for proc, p, log_handle, start_ts in running:
            code = proc.poll()
            if code is None:
                still.append((proc, p, log_handle, start_ts))
            else:
                log_handle.close()
                status = "完成" if code == 0 else f"失败(code={code})"
                print(f"[{status}] {p['name']}，耗时 {time.time()-start_ts:.0f}s")
                done.append((p, code))
        running = still

    failed = [p["name"] for p, code in done if code != 0]
    if failed:
        print(f"\n警告：以下run失败（见 {batch_dir}/logs/）：{failed}")
    aggregate(batch_name, [p for p, code in done if code == 0])
    print(f"\n批次完成。汇总数据位于 {batch_dir}/")


# ---------------------------------------------------------------------------
# 数据汇总
# ---------------------------------------------------------------------------
def _read_jsonl(path):
    rows = []
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
    return rows


def _write_csv(path, rows, extra_first=()):
    if not rows:
        return 0
    fields = list(extra_first)
    for row in rows:
        for k in row:
            if k not in fields:
                fields.append(k)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            out = {k: ("|".join(v) if isinstance(v, list) else v) for k, v in row.items()}
            writer.writerow(out)
    return len(rows)


def aggregate(batch_name, runs, out_dir=None):
    batch_dir = out_dir or os.path.join("results", "batch", batch_name)
    os.makedirs(batch_dir, exist_ok=True)
    surveys_merged = {}     # survey_id -> rows
    psych_rows = []
    intervention_rows = []
    for p in runs:
        name, condition = p["name"], p.get("condition") or "none"
        group = p.get("group") or condition

        def add_identity(row):
            row["run_id"] = name
            row["group"] = group
            if str(row.get("condition", "")).lower() in ("", "unknown", "none", "无"):
                row["condition"] = condition
            return row

        # legacy 每日问卷
        legacy = _read_jsonl(os.path.join("results", "surveys", name, "daily_survey.jsonl"))
        for row in legacy:
            surveys_merged.setdefault("daily_survey", []).append(add_identity(row))
        # 自定义问卷
        sdir = os.path.join("results", "surveys", name)
        if os.path.isdir(sdir):
            for fn in os.listdir(sdir):
                if fn.startswith("custom_") and fn.endswith(".jsonl"):
                    sid = fn[len("custom_"):-len(".jsonl")]
                    for row in _read_jsonl(os.path.join(sdir, fn)):
                        surveys_merged.setdefault(sid, []).append(add_identity(row))
        # 心理状态时间序列
        for row in _read_jsonl(os.path.join("results", "psych", name, "psych.jsonl")):
            psych_rows.append(add_identity(row))
        # 干预日志
        for row in _read_jsonl(os.path.join("results", "interventions", name, "interventions.jsonl")):
            add_identity(row)
            row.pop("psych", None) if not row.get("psych") else None
            intervention_rows.append(row)

    for sid, rows in surveys_merged.items():
        n = _write_csv(os.path.join(batch_dir, f"merged_{sid}.csv"), rows)
        print(f"  合并问卷 {sid}: {n} 行 -> merged_{sid}.csv")
    n = _write_csv(os.path.join(batch_dir, "merged_psych.csv"), psych_rows,
                   extra_first=("run_id", "condition", "step", "sim_time", "agent"))
    if n:
        print(f"  合并心理状态: {n} 行 -> merged_psych.csv")
    n = _write_csv(os.path.join(batch_dir, "merged_interventions.csv"), intervention_rows)
    if n:
        print(f"  合并干预日志: {n} 行 -> merged_interventions.csv")

    # 按条件分组的描述统计（数值列均值），写 summary.csv
    summary_lines = []
    for sid, rows in surveys_merged.items():
        by_cond = {}
        for row in rows:
            by_cond.setdefault(str(row.get("condition", "none")), []).append(row)
        numeric_cols = set()
        for row in rows:
            for k, v in row.items():
                if isinstance(v, (int, float)) and k not in ("step",):
                    numeric_cols.add(k)
        for cond, crows in sorted(by_cond.items()):
            for col in sorted(numeric_cols):
                vals = [r[col] for r in crows if isinstance(r.get(col), (int, float))]
                if vals:
                    mean = sum(vals) / len(vals)
                    summary_lines.append({
                        "survey": sid, "condition": cond, "variable": col,
                        "n": len(vals), "mean": round(mean, 3),
                    })
    if summary_lines:
        _write_csv(os.path.join(batch_dir, "summary_by_condition.csv"), summary_lines)
        print("  条件分组均值 -> summary_by_condition.csv")
        print("\n按条件分组均值预览：")
        for line in summary_lines[:18]:
            print("   {survey} | {condition} | {variable}: mean={mean} (n={n})".format(**line))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="批量实验执行器")
    parser.add_argument("--config", type=str, required=True, help="批量配置JSON路径")
    parser.add_argument("--parallel", type=int, default=0, help="并行run数（默认取配置文件中的值或2）")
    parser.add_argument("--dry-run", action="store_true", help="只校验配置不执行")
    args = parser.parse_args()
    with open(args.config, "r", encoding="utf-8") as f:
        batch = json.load(f)
    parallel = args.parallel or int(batch.get("parallel", 2))
    run_batch(batch, parallel=parallel, dry_run=args.dry_run)
