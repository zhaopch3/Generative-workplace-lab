# -*- coding: utf-8 -*-
import json
import os
import tempfile
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest import mock

from modules.model.llm_model import LLMModel
from modules.storage.index import ExactCachedEmbedding
from start import SimulateServer


class FlakyLLM(LLMModel):
    def setup(self, keys, config):
        return None

    def _completion(self, prompt, **kwargs):
        if not hasattr(self, "calls"):
            self.calls = 0
        self.calls += 1
        if self.calls == 1:
            raise TimeoutError("temporary")
        return "answer"


class CountingEmbedding:
    model_name = "embedding-test"

    def __init__(self):
        self.calls = 0

    def get_query_embedding(self, text):
        self.calls += 1
        return [float(len(text)), float(self.calls)]

    def get_text_embedding(self, text):
        return self.get_query_embedding(text)


class PerformanceOptimizationTests(unittest.TestCase):
    def test_llm_metrics_record_lengths_latency_and_retry(self):
        with tempfile.TemporaryDirectory() as root:
            path = os.path.join(root, "model_calls.jsonl")
            model = FlakyLLM(
                "https://example.invalid/v1",
                "test-model",
                "embedding-test",
                {},
                config={"metrics_path": path, "agent_name": "甲"},
            )
            with mock.patch("modules.model.llm_model.time.sleep", return_value=None):
                output = model.completion("hello", retry=2, caller="unit_call")
            self.assertEqual(output, "answer")
            with open(path, "r", encoding="utf-8") as stream:
                rows = [json.loads(line) for line in stream if line.strip()]
            self.assertEqual(len(rows), 1)
            row = rows[0]
            self.assertEqual(row["kind"], "llm_completion")
            self.assertEqual(row["agent"], "甲")
            self.assertEqual(row["caller"], "unit_call")
            self.assertEqual(row["attempts"], 2)
            self.assertEqual(row["retries"], 1)
            self.assertEqual(row["failed_attempts"], 1)
            self.assertEqual(row["input_chars"], 5)
            self.assertEqual(row["output_chars"], 6)
            self.assertGreaterEqual(row["latency_ms"], 0)
            self.assertTrue(row["success"])

    def test_embedding_cache_requires_exact_namespace_and_text(self):
        with tempfile.TemporaryDirectory() as root:
            path = os.path.join(root, "model_calls.jsonl")
            source = CountingEmbedding()
            cached = ExactCachedEmbedding(
                source, "provider-a|model-a|endpoint-a", path, "甲"
            )
            first = cached.get_query_embedding("完全相同的文本")
            second = cached.get_query_embedding("完全相同的文本")
            self.assertEqual(first, second)
            self.assertEqual(source.calls, 1)

            other_source = CountingEmbedding()
            other_namespace = ExactCachedEmbedding(
                other_source, "provider-a|model-a|endpoint-b", path, "甲"
            )
            other_namespace.get_query_embedding("完全相同的文本")
            self.assertEqual(other_source.calls, 1)

            cached.get_query_embedding("不同文本")
            self.assertEqual(source.calls, 2)
            with open(path, "r", encoding="utf-8") as stream:
                rows = [json.loads(line) for line in stream if line.strip()]
            self.assertEqual([row["cache_hit"] for row in rows], [False, True, False, False])

    def test_concurrent_identical_embeddings_share_one_real_request(self):
        class SlowEmbedding(CountingEmbedding):
            def get_query_embedding(self, text):
                time.sleep(0.03)
                return super().get_query_embedding(text)

        source = SlowEmbedding()
        cached = ExactCachedEmbedding(
            source, "concurrent-provider|model|endpoint", "", "甲"
        )
        with ThreadPoolExecutor(max_workers=4) as executor:
            vectors = list(executor.map(
                cached.get_query_embedding,
                ["同一条并发文本"] * 4,
            ))
        self.assertEqual(source.calls, 1)
        self.assertTrue(all(vector == vectors[0] for vector in vectors))

    def test_survey_jobs_parallelize_agents_but_serialize_each_agent(self):
        simulate = SimulateServer.__new__(SimulateServer)
        simulate.config = {"performance": {"survey_parallel": 2}}
        guard = threading.Lock()
        active_by_agent = {"甲": 0, "乙": 0}
        max_total = [0]
        order = []

        def job(agent, label):
            def run():
                with guard:
                    active_by_agent[agent] += 1
                    self.assertEqual(active_by_agent[agent], 1)
                    max_total[0] = max(max_total[0], sum(active_by_agent.values()))
                    order.append("start-" + label)
                time.sleep(0.03)
                with guard:
                    order.append("end-" + label)
                    active_by_agent[agent] -= 1
                return label
            return run

        jobs = [
            ("甲", job("甲", "甲-1")),
            ("乙", job("乙", "乙-1")),
            ("甲", job("甲", "甲-2")),
        ]
        results = simulate._run_survey_jobs(jobs)
        self.assertEqual(results, ["甲-1", "乙-1", "甲-2"])
        self.assertEqual(max_total[0], 2)
        self.assertLess(order.index("end-甲-1"), order.index("start-甲-2"))

    def test_all_due_custom_surveys_freeze_before_first_completion(self):
        events = []

        class FakeAgent:
            def __init__(self, name):
                self.name = name

            def snapshot_survey_context(self, schema=None):
                events.append("snapshot-" + self.name)
                return {"frozen": self.name}

            def complete_custom_survey(
                self, schema, condition, run_id, survey_date, snapshot=None
            ):
                self.assert_frozen(events)
                events.append("complete-{}-{}".format(self.name, schema["id"]))
                return {"agent": self.name, "survey_id": schema["id"]}

            @staticmethod
            def assert_frozen(current_events):
                if len([item for item in current_events if item.startswith("snapshot-")]) != 4:
                    raise AssertionError("completion started before every context was frozen")

            @staticmethod
            def to_dict():
                return {}

        agents = {name: FakeAgent(name) for name in ("甲", "乙")}

        class FakeGame:
            def __init__(self):
                self.agents = agents

            @staticmethod
            def get_agent(name):
                return agents[name]

        class FakeTimer:
            @staticmethod
            def daily_duration():
                return 12 * 60

            @staticmethod
            def get_date(fmt=None):
                if fmt == "%Y%m%d":
                    return "20240101"
                if fmt == "%H:%M":
                    return "12:00"
                return "20240101-12:00"

        simulate = SimulateServer.__new__(SimulateServer)
        simulate.name = "run"
        simulate.game = FakeGame()
        simulate.logger = mock.Mock()
        simulate.custom_survey_rows = {}
        simulate.load_custom_survey_rows = mock.Mock(side_effect=lambda _sid: [])
        simulate.write_custom_survey_rows = mock.Mock()
        simulate.config = {
            "agents": {"甲": {}, "乙": {}},
            "experiment": {"condition": "c"},
            "performance": {"survey_parallel": 2},
            "custom_surveys": [
                {"id": "s1", "trigger_time": "00:00", "targets": ["甲", "乙"]},
                {"id": "s2", "trigger_time": "00:00", "targets": ["甲", "乙"]},
            ],
        }
        with mock.patch("start.utils.get_timer", return_value=FakeTimer()):
            simulate.maybe_complete_custom_surveys()
        self.assertEqual(events[:4], ["snapshot-甲", "snapshot-乙", "snapshot-甲", "snapshot-乙"])
        self.assertEqual(
            [row["agent"] for row in simulate.custom_survey_rows["s1"]],
            ["甲", "乙"],
        )
        self.assertEqual(
            [row["agent"] for row in simulate.custom_survey_rows["s2"]],
            ["甲", "乙"],
        )


if __name__ == "__main__":
    unittest.main()
