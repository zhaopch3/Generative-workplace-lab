# -*- coding: utf-8 -*-
"""V24: the analysis corrections table points at surveys and items that exist in the battery."""
import json
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class CorrectionsTableTests(unittest.TestCase):
    def setUp(self):
        with open(os.path.join(ROOT, "data", "analysis", "hypothesis_corrections.json"), encoding="utf-8") as f:
            self.corr = json.load(f)
        with open(os.path.join(ROOT, "data", "scale_battery", "battery_v1.json"), encoding="utf-8") as f:
            self.surveys = {e["survey"]["id"]: e["survey"] for e in json.load(f)["surveys"]}

    def test_reverse_items_exist(self):
        for entry in self.corr["reverse_items"]:
            for sid in entry["surveys"]:
                self.assertIn(sid, self.surveys)
                ids = {q["id"] for q in self.surveys[sid]["questions"]}
                self.assertTrue(set(entry["items"]) <= ids, sid)

    def test_overrides_use_known_predictions(self):
        for c in self.corr["prediction_overrides"]:
            self.assertIn(c["prediction"], ("positive", "negative", "no_effect"))
            self.assertTrue(c["reason"])

    def test_reversed_anchor_surveys_exist(self):
        for sid in self.corr["reversed_anchor_surveys"]["surveys"]:
            self.assertIn(sid, self.surveys)


if __name__ == "__main__":
    unittest.main()
