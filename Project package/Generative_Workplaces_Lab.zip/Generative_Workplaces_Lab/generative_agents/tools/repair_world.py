# -*- coding: utf-8 -*-
"""Check worlds for files cut off by a full disk, and repair them from the state packs.

When the disk fills up during a run, the memory files (storage/) and conversation.json can be
left half-written; resuming the world then fails with a JSONDecodeError. Every checkpoint
simulate-*.json is written atomically and points to a state pack (statepacks/*.zip) holding
the memory and conversations of that same step, so the world can be put back to that step.

Run from the generative_agents folder, with the Python of the project's .venv:

    python tools/repair_world.py B20261029-152110            check all worlds whose name starts with this
    python tools/repair_world.py B20261029-152110-G01-06 --fix   repair this world
    python tools/repair_world.py B20261029-152110-G02 --reset    worlds with no usable checkpoint:
                                                                  clear them so a retry starts afresh

--fix moves the damaged files to results/repair_backup/ (nothing is deleted), drops checkpoints
that cannot be read, and restores storage/ and conversation.json from the state pack of the
newest good checkpoint. Then resume the world as usual (it continues from that step).
--reset is for worlds that failed before their first checkpoint: a retry would load their
half-written memory again, so their folders (results/*/<world>) are moved to results/repair_backup/
and the batch's "retry failed" then starts them from the beginning with the same settings.
Only use --fix / --reset on worlds that are NOT running.
"""
import argparse
import hashlib
import json
import os
import shutil
import sys
import time
import zipfile

ROOT = os.path.join("results", "checkpoints")


def readable(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def good_checkpoint(folder):
    """Newest checkpoint that parses and whose state pack is present and intact; plus the newer bad ones."""
    names = sorted(f for f in os.listdir(folder) if f.startswith("simulate-") and f.endswith(".json"))
    bad = []
    for name in reversed(names):
        cfg = readable(os.path.join(folder, name))
        spec = (cfg or {}).get("_snapshot") or {}
        pack = os.path.join(folder, spec.get("pack", "")) if spec.get("pack") else ""
        if cfg is not None and pack and os.path.isfile(pack) and sha256(pack) == spec.get("sha256"):
            return name, cfg, pack, bad
        bad.append(name)
    return None, None, None, bad


def damaged_state(folder):
    out = []
    conv = os.path.join(folder, "conversation.json")
    if os.path.exists(conv) and readable(conv) is None:
        out.append("conversation.json")
    storage = os.path.join(folder, "storage")
    for root, _, files in os.walk(storage):
        for f in files:
            if f.endswith(".json") and readable(os.path.join(root, f)) is None:
                out.append(os.path.relpath(os.path.join(root, f), folder))
    return out


def check(name):
    folder = os.path.join(ROOT, name)
    ck, cfg, pack, bad = good_checkpoint(folder)
    damaged = damaged_state(folder)
    if ck is None:
        status = "无可用存档点（无法修复，只能重跑）"
    elif bad or damaged:
        status = "已损坏，可修复到第 {} 步".format(cfg.get("step"))
    else:
        status = "正常（第 {} 步）".format(cfg.get("step"))
    print("{}: {}".format(name, status))
    for b in bad:
        print("    读不了的存档点：", b)
    for d in damaged:
        print("    写坏的文件：", d)
    return ck, cfg, pack, bad, damaged


def fix(name):
    ck, cfg, pack, bad, damaged = check(name)
    if ck is None or not (bad or damaged):
        return
    folder = os.path.join(ROOT, name)
    backup = os.path.join("results", "repair_backup", "{}-{}".format(name, time.strftime("%Y%m%d-%H%M%S")))
    os.makedirs(backup)
    for b in bad:
        shutil.move(os.path.join(folder, b), os.path.join(backup, b))
    for item in ("storage", "conversation.json"):
        if os.path.exists(os.path.join(folder, item)):
            shutil.move(os.path.join(folder, item), os.path.join(backup, item))
    with zipfile.ZipFile(pack) as archive:
        for info in archive.infolist():
            if info.filename == "conversation.json" or info.filename.startswith("storage/"):
                target = os.path.realpath(os.path.join(folder, info.filename))
                if not target.startswith(os.path.realpath(folder) + os.sep):
                    raise SystemExit("状态包包含非法路径：" + info.filename)
                archive.extract(info, folder)
    left = damaged_state(folder)
    if left:
        raise SystemExit("修复后仍有文件读不了：" + "、".join(left))
    print("  已修复：回到第 {} 步（{}）。原文件已移到 {}".format(cfg.get("step"), ck, backup))
    print("  现在可以在批量页面继续 / 重试这个世界。")


def reset(name):
    ck, cfg, pack, bad, damaged = check(name)
    if ck is not None:
        print("  有可用存档点，不重置（请用 --fix）")
        return
    backup = os.path.join("results", "repair_backup", "{}-{}".format(name, time.strftime("%Y%m%d-%H%M%S")))
    moved = []
    for sub in sorted(os.listdir("results")):
        if sub in ("batch", "repair_backup"):
            continue
        path = os.path.join("results", sub, name)
        if os.path.exists(path):
            os.makedirs(backup, exist_ok=True)
            shutil.move(path, os.path.join(backup, sub))
            moved.append(sub)
    print("  已清空（{}），原文件移到 {}；在批量页面重试失败的世界，它会从头开始".format("、".join(moved), backup))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("prefix", help="世界名称，或批次编号（检查名称以它开头的所有世界）")
    parser.add_argument("--fix", action="store_true", help="修复（只在世界没有运行时使用）")
    parser.add_argument("--reset", action="store_true", help="没有可用存档点的世界：清空，以便重试时从头开始")
    args = parser.parse_args()
    if not os.path.isdir(ROOT):
        raise SystemExit("请在 generative_agents 文件夹中运行（找不到 results/checkpoints）")
    names = sorted(n for n in os.listdir(ROOT) if n.startswith(args.prefix) and os.path.isdir(os.path.join(ROOT, n)))
    if not names:
        raise SystemExit("没有名称以 {} 开头的世界".format(args.prefix))
    for name in names:
        if args.reset:
            reset(name)
        elif args.fix:
            fix(name)
        else:
            check(name)


if __name__ == "__main__":
    sys.exit(main())
