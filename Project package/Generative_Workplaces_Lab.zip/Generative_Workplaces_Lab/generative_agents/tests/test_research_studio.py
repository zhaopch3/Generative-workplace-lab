import copy
import datetime
import json
import os
import random
import tempfile
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch, Mock
from modules import survey, utils
from modules.research import data, snapshots, branches
from modules.research.common import atomic_json, digest, safe_id

SCHEMA={"id":"outcome","title":"Outcome","mode":"dyadic","include_reason":False,
        "questions":[{"id":"q1","type":"likert","text":"one","min":1,"max":7},
                     {"id":"q2","type":"likert","text":"two","min":1,"max":7,"reverse":True}]}

class ResearchTests(unittest.TestCase):
    def test_invalid_scores_are_not_clamped_or_neutral(self):
        for answer in ('{"q1":99,"q2":true}','{"q1":2.5}','broken'):
            row=survey.parse_answers(answer,SCHEMA)
            self.assertIsNone(row["q1"])
            self.assertIn(row["_quality"]["status"],("partial","invalid"))
        row=survey.parse_answers('{"q1":7,"q2":1}',SCHEMA)
        self.assertEqual(row["_quality"]["status"],"valid")

    def test_identity_rejects_path_traversal(self):
        for value in ("..","../x","C:/x","a/b","a\\b"):
            with self.assertRaises(ValueError):safe_id(value)

    def test_atomic_write_retries_transient_windows_lock(self):
        with tempfile.TemporaryDirectory() as root:
            target=Path(root)/"status.json"
            original=os.replace
            calls=[]
            def replace(a,b):
                calls.append(1)
                if len(calls)==1:raise PermissionError("reader lock")
                return original(a,b)
            with patch("os.replace",replace):
                atomic_json(target,{"status":"finished"})
            self.assertEqual(json.loads(target.read_text())["status"],"finished")

    def test_snapshot_pack_hash_and_fresh_frame_isolation(self):
        with tempfile.TemporaryDirectory() as root:
            root=Path(root);source=root/"world";source.mkdir()
            checkpoint=source/"simulate-20240101-2200.json"
            pack=source/"state.zip"
            with zipfile.ZipFile(pack,"w") as z:
                z.writestr("storage/agent/index.json",'{"old":true}')
                z.writestr("conversation.json",'{"today":[]}')
                z.writestr("world.json",'{"format":2}')
            cfg={"_snapshot":{"format":2,"pack":"state.zip","sha256":digest(pack)}}
            atomic_json(checkpoint,cfg)
            work=root/"work"
            conversation,mode=snapshots.isolate_state(checkpoint,cfg,work)
            self.assertEqual(mode,"verified")
            (work/"storage/agent/index.json").write_text("mutated")
            snapshots.isolate_state(checkpoint,cfg,work)
            self.assertEqual(json.loads((work/"storage/agent/index.json").read_text()),{"old":True})
            self.assertEqual(conversation,{"today":[]})
            with open(pack,"ab") as f:f.write(b"tampered")
            with self.assertRaises(ValueError):snapshots.pack_path(checkpoint,cfg)

    def test_pack_rejects_zip_slip(self):
        with tempfile.TemporaryDirectory() as root:
            p=Path(root)/"bad.zip"
            with zipfile.ZipFile(p,"w") as z:z.writestr("../escape","bad")
            with self.assertRaises(ValueError):snapshots.extract_pack(p,Path(root)/"work")

    def test_random_state_roundtrip(self):
        random.seed(98);cfg={"_random_state":json.loads(json.dumps(random.getstate()))}
        expected=[random.random() for _ in range(6)]
        snapshots.restore_random(cfg)
        self.assertEqual(expected,[random.random() for _ in range(6)])

    def test_passive_dyadic_retrieval_restores_access_on_failure(self):
        from modules.agent import Agent
        agent=Agent.__new__(Agent)
        agent.measurement_policy="passive"
        agent._resolved_config={"survey_context":{"version":"v22_full_memory"}}
        node=SimpleNamespace(metadata={"access":"old"})
        index=SimpleNamespace(_index=SimpleNamespace(docstore=SimpleNamespace(docs={"n":node})))
        agent.associate=SimpleNamespace(index=index,_retrieve_config={"limit":4})
        def fail(ratee):
            node.metadata["access"]="new"
            agent.associate._retrieve_config["limit"]=1
            raise RuntimeError("embedding error")
        agent._snapshot_dyadic_survey=fail
        with self.assertRaises(RuntimeError):agent.snapshot_dyadic_survey("target")
        self.assertEqual(node.metadata["access"],"old")
        self.assertEqual(agent.associate._retrieve_config,{"limit":4})
        self.assertFalse(index.strict_retrieval)

    def test_offline_two_steps_snapshot_and_restore(self):
        import server
        from start import SimulateServer, get_config_from_log
        origin=Path.cwd()
        preset=json.loads((origin/"data/world_presets/Persona-manipulation-low-abuse_CN.json").read_text(encoding="utf-8"))
        preset.update(name="v21-offline-check",offline=True,step=2,start_time="20240213-21:00",stride=60,
                      custom_surveys=[],legacy_survey=False)
        _,args,cfg=server.build_experiment_config(preset)
        with tempfile.TemporaryDirectory() as root:
            os.chdir(root)
            try:
                run=SimulateServer(args.name,str(origin/"frontend/static"),"results/checkpoints/"+args.name,
                                   cfg,verbose="error")
                # Scratch templates are read-only original assets in this isolated fixture.
                for agent in run.game.agents.values():agent.scratch.template_path=str(origin/"data/prompts")
                run.simulate(2,stride=60)
                files=sorted(Path(run.checkpoints_folder).glob("simulate-*.json"))
                self.assertEqual(len(files),2)
                checkpoint=json.loads(files[-1].read_text(encoding="utf-8"))
                self.assertEqual(checkpoint["_snapshot"]["format"],2)
                self.assertTrue(checkpoint["_tile_events"])
                self.assertIn("_psych_last_drift",next(iter(checkpoint["agents"].values())))
                self.assertTrue(snapshots.pack_path(files[-1],checkpoint).exists())
                # End-of-step cognitive position must be restored separately from
                # the pending movement destination for the next ordered turn.
                restored=copy.deepcopy(checkpoint)
                restored["time"]={"start":checkpoint["time"]}
                restored["_storage_root"]=str(Path(root)/"isolated/storage")
                snapshots.isolate_state(files[-1],checkpoint,Path(root)/"isolated")
                from modules.game import create_game
                restored_game=create_game("isolated",str(origin/"frontend/static"),restored,{},logger=utils.create_io_logger("error"))
                for name,agent in restored_game.agents.items():
                    self.assertEqual(list(agent.coord),checkpoint["agents"][name]["_cognitive_coord"])
            finally:os.chdir(origin)

    def test_branch_copies_are_separate_and_preserve_source_hash(self):
        import server
        origin=Path.cwd()
        with tempfile.TemporaryDirectory() as root:
            os.chdir(root)
            try:
                source=Path("results/checkpoints/source")
                source.mkdir(parents=True)
                pack=source/"state.zip"
                with zipfile.ZipFile(pack,"w") as z:
                    z.writestr("storage/agent/value.json",'{"memory":"past"}')
                    z.writestr("conversation.json","{}")
                cfg={"time":"20240101-22:00","step":2,"stride":60,"agents":{"employee":{}},
                     "_snapshot":{"format":2,"pack":"state.zip","sha256":digest(pack)}}
                checkpoint=source/"simulate-20240101-2200.json";atomic_json(checkpoint,cfg)
                before=digest(checkpoint)
                manager=server.BatchManager()
                spec={"run_id":"source","checkpoint":checkpoint.name,"steps":3,"offline":True,
                      "variants":[{"label":"control","text":""},{"label":"treatment","text":"Support"}]}
                hooks={"probe_runtime":lambda n:False,"available_ports":lambda n:range(6100,6100+n),
                       "comparison_summary":lambda c:{}}
                with patch.object(manager,"_start_thread"):
                    result=branches.create(spec,manager,hooks)
                self.assertEqual(result["world_count"],2)
                self.assertEqual(digest(checkpoint),before)
                runs=manager.batch["runs"]
                self.assertEqual(runs[0]["total"],5)
                left=Path("results/checkpoints")/runs[0]["name"]/"storage/agent/value.json"
                right=Path("results/checkpoints")/runs[1]["name"]/"storage/agent/value.json"
                left.write_text('{"changed":true}')
                self.assertEqual(json.loads(right.read_text()),{"memory":"past"})
            finally:os.chdir(origin)

    def test_api_catalog_and_readonly_viewer(self):
        import server
        with patch.object(server,"scan_batches",return_value=[]),patch.object(server,"scan_experiments",return_value=[]):
            app=server.create_app({})
            with app.test_client() as client:
                self.assertEqual(client.get("/research").status_code,200)
                self.assertEqual(client.get("/api/studio/catalog").json["worlds"],[])
                response=client.post("/api/studio/quality",json={"worlds":["missing"]})
                self.assertEqual(response.status_code,400)
                response=client.post("/api/studio/quality",json={},headers={"Origin":"https://other-site.example"})
                self.assertEqual(response.status_code,403)

if __name__=="__main__":unittest.main()
