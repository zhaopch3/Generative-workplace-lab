"""generative_agents.prompt.scratch"""

import random
import datetime
import re
import json
from string import Template

from modules import utils
from modules.memory import Event
from modules.model import parse_llm_output
from modules import lang
from modules.lang import L


def _yes_en(response):
    """English worlds: read a yes/no answer ("Answer: Yes"); a bare substring test would
    also match "know", "not", "now" ... (the Chinese worlds keep their original rule)."""
    low = str(response or "").lower()
    found = re.findall(r"answer\W*(yes|no)\b", low)
    if found:
        return found[-1] == "yes"
    head = re.match(r"\W*(yes|no)\b", low)
    if head:
        return head.group(1) == "yes"
    return not re.search(r"\bno\b", low)


def _match_option(text, options):
    """English worlds: map the model's answer to one of the listed names, ignoring case,
    quotes, brackets and a leading "the" ("The Meeting Area." -> "meeting area")."""
    clean = str(text or "").strip().strip("<>[]()\"'`*.:;, ").lower()
    if clean.startswith("the "):
        clean = clean[4:]
    for option in options:
        if clean == option.lower():
            return option
    for option in sorted(options, key=len, reverse=True):
        if option.lower() in clean:
            return option
    return text


def _survey_display(schema):
    """Neutral title shown to the agent; the researcher title stays in exports (V23)."""
    title = str(schema.get("display_title") or "").strip() or L("今日工作日志", "Today's work log")
    frame = schema.get("time_frame", "today")
    hint = {
        "general": L("题目问的是一般情况，而不只是今天。", "The questions ask about how things generally are, not only today."),
        "recent": L("题目问的是最近这几天的情况。", "The questions ask about the last few days."),
        "week": L("题目问的是这一周以来的情况。", "The questions ask about this week so far."),
    }.get(frame, L("题目问的是今天的情况。", "The questions ask about today."))
    return title, hint


class Scratch:
    def __init__(self, name, currently, config):
        self.name = name
        self.currently = currently
        self.config = config
        self.template_path = lang.prompt_dir()
        self.psych_text = ""  # 由Agent每步更新；非空时注入所有 base_desc

    def build_prompt(self, template, data):
        with open(f"{self.template_path}/{template}.txt", "r", encoding="utf-8") as file:
            file_content = file.read()

        template = Template(file_content)
        filled_content = template.substitute(data)

        return filled_content

    def _parse_survey_json(self, response, fields, failsafe):
        from modules.survey import parse_answers
        return parse_answers(response, {
            "questions": [{"id": field, "type": "likert", "min": 1, "max": 7} for field in fields],
            "include_reason": True,
        })

    @staticmethod
    def _active_items(items):
        """Entries that have started, have not expired and were not withdrawn."""
        now = utils.get_timer().get_date()
        active = []
        for item in items or []:
            if item.get("revoked"):
                continue
            start = item.get("from")
            if start and utils.to_date(start, "%Y%m%d-%H:%M") > now:
                continue
            expires = item.get("expires")
            if expires and utils.to_date(expires, "%Y%m%d-%H:%M") <= now:
                continue
            text = str(item.get("text", "") or "").strip()
            if text:
                active.append(text)
        return active

    def active_intents(self):
        """Researcher-injected persistent intents that have not expired (V23)."""
        return self._active_items(self.config.get("intents"))

    def active_world_facts(self):
        """V24: standing facts about the world (shared context, live world settings)."""
        return self._active_items(self.config.get("world_facts"))

    def fixed_block(self):
        """Fixed background, conduct and intents: never rewritten by the daily update (V23)."""
        lines = []
        background = str(self.config.get("background", "") or "").strip()
        conduct = str(self.config.get("conduct", "") or "").strip()
        if background:
            lines.append(L("【固定背景】：", "[Background]: ") + background)
        rules = str(self.config.get("world_rules", "") or "").strip()
        if rules:
            lines.append(L("【世界规则】：\n", "[World rules]:\n") + rules)
        if conduct:
            lines.append(L("【领导风格】：", "[Leadership style]: ") + conduct)
        facts = self.active_world_facts()
        if facts:
            lines.append(L("【目前的情况】：", "[Current situation]: ") + L("；", "; ").join(facts))
        intents = self.active_intents()
        if intents:
            lines.append(L("【持续的打算】：", "[Ongoing intentions]: ") + L("；", "; ").join(intents))
        return "\n".join(lines)

    def _base_desc(self):
        block = self.fixed_block()
        return self.build_prompt(
            "base_desc",
            {
                "name": self.name,
                "age": self.config["age"],
                "innate": self.config["innate"],
                "learned": self.config["learned"],
                "lifestyle": self.config["lifestyle"],
                "daily_plan": self.config["daily_plan"],
                "fixed_block": (block + "\n") if block else "",
                "date": utils.get_timer().daily_format_cn(),
                "currently": self.currently,
            }
        ) + (L("\n【当前的身心状态】：{}", "\n[Current state of mind and body]: {}").format(self.psych_text) if self.psych_text else "")

    def prompt_poignancy_event(self, event):
        prompt = self.build_prompt(
            "poignancy_event",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "event": event.get_describe(),
            }
        )

        def _callback(response):
            pattern = [
                L("评分[:： ]+(\d{1,2})", "(?:Rating|Score)[:： ]+(\d{1,2})"),
                "(\d{1,2})",
            ]
            return int(parse_llm_output(response, pattern, "match_last"))

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": random.choice(list(range(10))) + 1,
        }

    def prompt_poignancy_chat(self, event):
        prompt = self.build_prompt(
            "poignancy_chat",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "event": event.get_describe(),
            }
        )

        def _callback(response):
            pattern = [
                L("评分[:： ]+(\d{1,2})", "(?:Rating|Score)[:： ]+(\d{1,2})"),
                "(\d{1,2})",
            ]
            return int(parse_llm_output(response, pattern, "match_last"))

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": random.choice(list(range(10))) + 1,
        }

    def prompt_wake_up(self):
        prompt = self.build_prompt(
            "wake_up",
            {
                "base_desc": self._base_desc(),
                "lifestyle": self.config["lifestyle"],
                "agent": self.name,
            }
        )

        def _callback(response):
            patterns = [
                "(\d{1,2}):00",
                "(\d{1,2})",
                "\d{1,2}",
            ]
            wake_up_time = int(parse_llm_output(response, patterns))
            if wake_up_time > 11:
                wake_up_time = 11
            return wake_up_time

        return {"prompt": prompt, "callback": _callback, "failsafe": 6}

    def prompt_schedule_init(self, wake_up):
        prompt = self.build_prompt(
            "schedule_init",
            {
                "base_desc": self._base_desc(),
                "lifestyle": self.config["lifestyle"],
                "agent": self.name,
                "wake_up": wake_up,
            }
        )

        def _callback(response):
            patterns = [
                "\d{1,2}\. (.*)。",
                "\d{1,2}\. (.*)",
                "\d{1,2}\) (.*)。",
                "\d{1,2}\) (.*)",
                "(.*)。",
                "(.*)",
            ]
            return parse_llm_output(response, patterns, mode="match_all")

        failsafe = L([
            "早上6点起床并完成早餐的例行工作",
            "早上7点吃早餐",
            "早上8点看书",
            "中午12点吃午饭",
            "下午1点小睡一会儿",
            "晚上7点放松一下，看电视",
            "晚上11点睡觉",
        ], [
            "wake up and complete the morning routine at 6:00 am",
            "eat breakfast at 7:00 am",
            "read a book at 8:00 am",
            "have lunch at 12:00 pm",
            "take a short nap at 1:00 pm",
            "relax and watch TV at 7:00 pm",
            "go to bed at 11:00 pm",
        ])
        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}

    def prompt_schedule_daily(self, wake_up, daily_schedule):
        hourly_schedule = ""
        for i in range(wake_up):
            hourly_schedule += f"[{i}:00] " + L("睡觉", "sleeping") + "\n"
        for i in range(wake_up, 24):
            hourly_schedule += f"[{i}:00] " + L("<活动>", "<activity>") + "\n"

        prompt = self.build_prompt(
            "schedule_daily",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "daily_schedule": L("；", "; ").join(daily_schedule),
                "hourly_schedule": hourly_schedule,
            }
        )

        failsafe = L({
            "6:00": "起床并完成早晨的例行工作",
            "7:00": "吃早餐",
            "8:00": "读书",
            "9:00": "读书",
            "10:00": "读书",
            "11:00": "读书",
            "12:00": "吃午饭",
            "13:00": "小睡一会儿",
            "14:00": "小睡一会儿",
            "15:00": "小睡一会儿",
            "16:00": "继续工作",
            "17:00": "继续工作",
            "18:00": "回家",
            "19:00": "放松，看电视",
            "20:00": "放松，看电视",
            "21:00": "睡前看书",
            "22:00": "准备睡觉",
            "23:00": "睡觉",
        }, {
            "6:00": "wake up and complete the morning routine",
            "7:00": "eat breakfast",
            "8:00": "read a book",
            "9:00": "read a book",
            "10:00": "read a book",
            "11:00": "read a book",
            "12:00": "have lunch",
            "13:00": "take a short nap",
            "14:00": "take a short nap",
            "15:00": "take a short nap",
            "16:00": "continue working",
            "17:00": "continue working",
            "18:00": "go home",
            "19:00": "relax and watch TV",
            "20:00": "relax and watch TV",
            "21:00": "read before bed",
            "22:00": "get ready for bed",
            "23:00": "sleeping",
        })

        def _callback(response):
            patterns = [
                "\[(\d{1,2}:\d{2})\] " + re.escape(self.name) + L("(.*)。", " (?:is )?(.*?)\\.?$"),
                "\[(\d{1,2}:\d{2})\] " + re.escape(self.name) + L("(.*)", " (.*)"),
                "\[(\d{1,2}:\d{2})\] " + L("(.*)。", "(.*?)\\.?$"),
                "\[(\d{1,2}:\d{2})\] " + "(.*)",
            ]
            outputs = parse_llm_output(response, patterns, mode="match_all")
            assert len(outputs) >= 5, "less than 5 schedules"
            return {s[0]: s[1] for s in outputs}

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}

    def prompt_schedule_decompose(self, plan, schedule):
        def _plan_des(plan):
            start, end = schedule.plan_stamps(plan, time_format="%H:%M")
            return L(f'{start} 至 {end}，{self.name} 计划 {plan["describe"]}',
                     f'from {start} to {end}, {self.name}: {plan["describe"]}')

        indices = range(
            max(plan["idx"] - 1, 0), min(plan["idx"] + 2, len(schedule.daily_schedule))
        )

        start, end = schedule.plan_stamps(plan, time_format="%H:%M")
        increment = max(int(plan["duration"] / 100) * 5, 5)

        prompt = self.build_prompt(
            "schedule_decompose",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "plan": L("；", "; ").join([_plan_des(schedule.daily_schedule[i]) for i in indices]),
                "increment": increment,
                "start": start,
                "end": end,
            }
        )

        def _callback(response):
            patterns = [
                L("\d{1,2}\) .*\*计划\* (.*)[\(（]+耗时[:： ]+(\d{1,2})[,， ]+剩余[:： ]+\d*[\)）]",
                  "\d{1,2}\) .*\*plan\* (.*?) ?\(duration in minutes: (\d{1,2}), minutes left: \d*\)"),
            ]
            schedules = parse_llm_output(response, patterns, mode="match_all")
            schedules = [(s[0].strip("."), int(s[1])) for s in schedules]
            left = plan["duration"] - sum([s[1] for s in schedules])
            if left > 0:
                schedules.append((plan["describe"], left))
            return schedules

        failsafe = [(plan["describe"], 10) for _ in range(int(plan["duration"] / 10))]
        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}

    def prompt_react_to_injection(self, agent, news, memories, areas):
        """V24: decide what to do next after learning of an injected event / setting / thought.

        ``news`` is a list of (kind, text); the agent may keep its schedule or switch.
        """
        now_minutes = utils.get_timer().daily_duration()
        upcoming = []
        for plan in agent.schedule.daily_schedule:
            start, end = agent.schedule.plan_stamps(plan)
            if end <= now_minutes:
                continue
            s, e = agent.schedule.plan_stamps(plan, time_format="%H:%M")
            upcoming.append(L("[{} 至 {}] {}", "[{} to {}] {}").format(s, e, plan["describe"]))
            if len(upcoming) >= 4:
                break
        lead = L({"thought": "想到", "world_setting": "得知（此后一直如此）", "world_event": "得知"},
                 {"thought": "thought", "world_setting": "learned (true from now on)", "world_event": "learned"})
        news_text = "\n".join(L("- {}：{}", "- {}: {}").format(lead.get(kind, L("得知", "learned")), text) for kind, text in news)
        address = agent.get_tile().get_address()
        prompt = self.build_prompt(
            "react_to_injection",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "time": utils.get_timer().get_date("%H:%M"),
                "location": L("，", ", ").join(address[-2:]) if address else "",
                "current": agent.get_event().get_describe(False) if agent.action else L("空闲", "idle"),
                "upcoming": "\n".join(upcoming) or L("（今天没有其他安排）", "(nothing else planned today)"),
                "news": news_text,
                "memory": "\n".join("- " + m for m in memories) or L("（没有特别相关的记忆）", "(no especially relevant memories)"),
                "areas": L("、", ", ").join(areas) or L("（当前所在地点）", "(the current location)"),
            }
        )

        def _callback(response):
            assert "{" in response and "}" in response
            data = json.loads("{" + response.split("{", 1)[1].rsplit("}", 1)[0] + "}")
            keep = data.get("继续原安排", data.get("keep_schedule"))
            if isinstance(keep, str):
                keep = keep.strip().lower() in ("true", "是", "yes")
            if keep:
                return {"continue": True}
            activity = str(data.get("接下来做什么", data.get("next_activity", "")) or "").strip()
            assert activity, "missing activity"
            try:
                minutes = int(float(data.get("持续分钟", data.get("minutes", 30))))
            except (TypeError, ValueError):
                minutes = 30
            return {"continue": False, "activity": activity,
                    "area": str(data.get("地点", data.get("area", "")) or "").strip(),
                    "minutes": max(5, min(240, minutes))}

        return {"prompt": prompt, "callback": _callback, "failsafe": {"continue": True}, "retry": 3}

    def prompt_schedule_revise(self, action, schedule):
        plan, _ = schedule.current_plan()
        start, end = schedule.plan_stamps(plan, time_format="%H:%M")
        act_start_minutes = utils.daily_duration(action.start)
        original_plan, new_plan = [], []

        def _plan_des(start, end, describe):
            if not isinstance(start, str):
                start = start.strftime("%H:%M")
            if not isinstance(end, str):
                end = end.strftime("%H:%M")
            return L("[{} 至 {}] {}", "[{} to {}] {}").format(start, end, describe)

        for de_plan in plan["decompose"]:
            de_start, de_end = schedule.plan_stamps(de_plan, time_format="%H:%M")
            original_plan.append(_plan_des(de_start, de_end, de_plan["describe"]))
            if de_plan["start"] + de_plan["duration"] <= act_start_minutes:
                new_plan.append(_plan_des(de_start, de_end, de_plan["describe"]))
            elif de_plan["start"] <= act_start_minutes:
                new_plan.extend(
                    [
                        _plan_des(de_start, action.start, de_plan["describe"]),
                        _plan_des(
                            action.start, action.end, action.event.get_describe(False)
                        ),
                    ]
                )

        original_plan, new_plan = "\n".join(original_plan), "\n".join(new_plan)

        prompt = self.build_prompt(
            "schedule_revise",
            {
                "agent": self.name,
                "start": start,
                "end": end,
                "original_plan": original_plan,
                "duration": action.duration,
                "event": action.event.get_describe(),
                "new_plan": new_plan,
            }
        )

        def _callback(response):
            patterns = [
                "^\[(\d{1,2}:\d{1,2}) ?- ?(\d{1,2}:\d{1,2})\] (.*)",
                "^\[(\d{1,2}:\d{1,2}) ?~ ?(\d{1,2}:\d{1,2})\] (.*)",
                "^\[(\d{1,2}:\d{1,2}) ?至 ?(\d{1,2}:\d{1,2})\] (.*)",
            ] + ([] if not lang.is_en() else [
                "^\[(\d{1,2}:\d{1,2}) ?to ?(\d{1,2}:\d{1,2})\] (.*)",
            ])
            schedules = parse_llm_output(response, patterns, mode="match_all")
            decompose = []
            for start, end, describe in schedules:
                m_start = utils.daily_duration(utils.to_date(start, "%H:%M"))
                m_end = utils.daily_duration(utils.to_date(end, "%H:%M"))
                decompose.append(
                    {
                        "idx": len(decompose),
                        "describe": describe,
                        "start": m_start,
                        "duration": m_end - m_start,
                    }
                )
            return decompose

        return {"prompt": prompt, "callback": _callback, "failsafe": plan["decompose"]}

    def prompt_determine_sector(self, describes, spatial, address, tile):
        live_address = spatial.find_address("living_area", as_list=True)[:-1]
        curr_address = tile.get_address("sector", as_list=True)

        prompt = self.build_prompt(
            "determine_sector",
            {
                "agent": self.name,
                "live_sector": live_address[-1],
                "live_arenas": ", ".join(i for i in spatial.get_leaves(live_address)),
                "current_sector": curr_address[-1],
                "current_arenas": ", ".join(i for i in spatial.get_leaves(curr_address)),
                "daily_plan": self.config["daily_plan"],
                "areas": ", ".join(i for i in spatial.get_leaves(address)),
                "complete_plan": describes[0],
                "decomposed_plan": describes[1],
            }
        )

        sectors = spatial.get_leaves(address)
        arenas = {}
        for sec in sectors:
            arenas.update(
                {a: sec for a in spatial.get_leaves(address + [sec]) if a not in arenas}
            )
        failsafe = random.choice(sectors)

        def _callback(response):
            patterns = [
                ".*should go to[:： ]*(.*?)\\.?$",
                "(.+?)\\.?$",
            ] if lang.is_en() else [
                ".*应该去[:： ]*(.*)。",
                ".*应该去[:： ]*(.*)",
                "(.+)。",
                "(.+)",
            ]
            sector = parse_llm_output(response, patterns)
            if lang.is_en():
                sector = _match_option(sector, list(sectors) + list(arenas))
            if sector in sectors:
                return sector
            if sector in arenas:
                return arenas[sector]
            for s in sectors:
                if sector.startswith(s):
                    return s
            return failsafe

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}

    def prompt_determine_arena(self, describes, spatial, address):
        prompt = self.build_prompt(
            "determine_arena",
            {
                "agent": self.name,
                "target_sector": address[-1],
                "target_arenas": ", ".join(i for i in spatial.get_leaves(address)),
                "daily_plan": self.config["daily_plan"],
                "complete_plan": describes[0],
                "decomposed_plan": describes[1],
            }
        )

        arenas = spatial.get_leaves(address)
        failsafe = random.choice(arenas)

        def _callback(response):
            patterns = [
                ".*should go to[:： ]*(.*?)\\.?$",
                "(.+?)\\.?$",
            ] if lang.is_en() else [
                ".*应该去[:： ]*(.*)。",
                ".*应该去[:： ]*(.*)",
                "(.+)。",
                "(.+)",
            ]
            arena = parse_llm_output(response, patterns)
            if lang.is_en():
                arena = _match_option(arena, arenas)
            return arena if arena in arenas else failsafe

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}

    def prompt_determine_object(self, describes, spatial, address):
        objects = spatial.get_leaves(address)

        prompt = self.build_prompt(
            "determine_object",
            {
                "activity": describes[1],
                "objects": ", ".join(objects),
            }
        )

        failsafe = random.choice(objects)

        def _callback(response):
            # pattern = ["The most relevant object from the Objects is: <(.+?)>", "<(.+?)>"]
            patterns = [
                ".*(?:object|answer) is[:： ]*(.*?)\\.?$",
                "(.+?)\\.?$",
            ] if lang.is_en() else [
                ".*是[:： ]*(.*)。",
                ".*是[:： ]*(.*)",
                "(.+)。",
                "(.+)",
            ]
            obj = parse_llm_output(response, patterns)
            if lang.is_en():
                obj = _match_option(obj, objects)
            return obj if obj in objects else failsafe

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}

    def prompt_describe_emoji(self, describe):
        prompt = self.build_prompt(
            "describe_emoji",
            {
                "action": describe,
            }
        )

        def _callback(response):
            # 正则表达式：匹配大多数emoji
            emoji_pattern = u"([\U0001F600-\U0001F64F]|"   # 表情符号
            emoji_pattern += u"[\U0001F300-\U0001F5FF]|"   # 符号和图标
            emoji_pattern += u"[\U0001F680-\U0001F6FF]|"   # 运输和地图符号
            emoji_pattern += u"[\U0001F700-\U0001F77F]|"   # 午夜符号
            emoji_pattern += u"[\U0001F780-\U0001F7FF]|"   # 英镑符号
            emoji_pattern += u"[\U0001F800-\U0001F8FF]|"   # 合成扩展
            emoji_pattern += u"[\U0001F900-\U0001F9FF]|"   # 补充符号和图标
            emoji_pattern += u"[\U0001FA00-\U0001FA6F]|"   # 补充符号和图标
            emoji_pattern += u"[\U0001FA70-\U0001FAFF]|"   # 补充符号和图标
            emoji_pattern += u"[\U00002702-\U000027B0]+)"  # 杂项符号

            emoji = re.compile(emoji_pattern, flags=re.UNICODE).findall(response)
            if len(emoji) > 0:
                response = "Emoji: " + "".join(i for i in emoji)
            else:
                response = ""

            return parse_llm_output(response, ["Emoji: (.*)"])[:3]

        return {"prompt": prompt, "callback": _callback, "failsafe": "💭", "retry": 1}

    def prompt_describe_event(self, subject, describe, address, emoji=None):
        prompt = self.build_prompt(
            "describe_event",
            {
                "action": describe,
            }
        )

        e_describe = describe.replace("(", "").replace(")", "").replace("<", "").replace(">", "")
        now_word = L("此时", " is ")
        if e_describe.startswith(subject + now_word):
            e_describe = e_describe.replace(subject + now_word, "", 1)
        failsafe = Event(
            subject, L("此时", "is"), e_describe, describe=describe, address=address, emoji=emoji
        )

        def _callback(response):
            response_list = response.replace(")", ")\n").split("\n")
            for response in response_list:
                if len(response.strip()) < 7:
                    continue
                if response.count("(") > 1 or response.count(")") > 1 or response.count("（") > 1 or response.count("）") > 1:
                    continue

                patterns = [
                    "[\(（]<(.+?)>[,， ]+<(.+?)>[,， ]+<(.*)>[\)）]",
                    "[\(（](.+?)[,， ]+(.+?)[,， ]+(.*)[\)）]",
                ]
                outputs = parse_llm_output(response, patterns)
                if len(outputs) == 3:
                    return Event(*outputs, describe=describe, address=address, emoji=emoji)

            return None

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}

    def prompt_describe_object(self, obj, describe):
        prompt = self.build_prompt(
            "describe_object",
            {
                "object": obj,
                "agent": self.name,
                "action": describe,
            }
        )

        def _callback(response):
            patterns = [
                "<" + obj + "> ?" + "(.*)。",
                "<" + obj + "> ?" + "(.*)",
            ]
            return parse_llm_output(response, patterns)

        return {"prompt": prompt, "callback": _callback, "failsafe": L("空闲", "idle")}

    def prompt_decide_chat(self, agent, other, focus, chats):
        def _status_des(a):
            event = a.get_event()
            if a.path:
                return L(f"{a.name} 正去往 {event.get_describe(False)}", f"{a.name} is on the way to {event.get_describe(False)}")
            return event.get_describe()

        context = L("。", ". ").join(
            [c.describe for c in focus["events"]]
        )
        context += "\n" + L("。", ". ").join([c.describe for c in focus["thoughts"]])
        date_str = utils.get_timer().get_date("%Y-%m-%d %H:%M:%S")
        chat_history = ""
        if chats:
            chat_history = L(f" {agent.name} 和 {other.name} 上次在 {chats[0].create} 聊过关于 {chats[0].describe} 的话题",
                             f" {agent.name} and {other.name} last talked at {chats[0].create} about {chats[0].describe}")
        a_des, o_des = _status_des(agent), _status_des(other)

        prompt = self.build_prompt(
            "decide_chat",
            {
                "context": context,
                "date": date_str,
                "chat_history": chat_history,
                "agent_status": a_des,
                "another_status": o_des,
                "agent": agent.name,
                "another": other.name,
            }
        )

        def _callback(response):
            if lang.is_en():
                return _yes_en(response)
            if "No" in response or "no" in response or "否" in response or "不" in response:
                return False
            return True

        return {"prompt": prompt, "callback": _callback, "failsafe": False}

    def prompt_decide_chat_terminate(self, agent, other, chats):
        conversation = "\n".join(["{}: {}".format(n, u) for n, u in chats])
        conversation = (
            conversation or L("[对话尚未开始]", "[The conversation has not started yet]")
        )

        prompt = self.build_prompt(
            "decide_chat_terminate",
            {
                "conversation": conversation,
                "agent": agent.name,
                "another": other.name,
            }
        )

        def _callback(response):
            if lang.is_en():
                return _yes_en(response)
            if "No" in response or "no" in response or "否" in response or "不" in response:
                return False
            return True

        return {"prompt": prompt, "callback": _callback, "failsafe": False}

    def prompt_decide_wait(self, agent, other, focus):
        if lang.is_en():
            # Examples of the original Stanford prompt (decide_to_react), in English worlds.
            ex1 = {
                "context": "Jane is Liz's house mate. Jane and Liz exchanged a conversation about saying good morning at 07:05am, October 25, 2022.",
                "date": "2022-10-25 07:09",
                "agent": "Jane", "another": "Liz",
                "status": "Jane is on the way to using the bathroom",
                "another_status": "Liz is already using the bathroom",
                "action": "using the bathroom", "another_action": "using the bathroom",
                "reason": "Reasoning: Both Jane and Liz want to use the bathroom. It would be strange for both Jane and Liz to use the bathroom at the same time. So, since Liz is already using the bathroom, the best option for Jane is to wait on using the bathroom.\n",
                "answer": "Answer: <Option A>",
            }
            ex2 = {
                "context": "Sam is Sarah's friend. Sam and Sarah exchanged a conversation about favorite movies at 11pm, October 24, 2022.",
                "date": "2022-10-25 12:40",
                "agent": "Sam", "another": "Sarah",
                "status": "Sam is on the way to going for a walk",
                "another_status": "Sarah is already doing her laundry",
                "action": "going for a walk", "another_action": "doing her laundry",
                "reason": "Reasoning: Sam is likely going to be in his room going for a walk. Sarah, on the other hand, is likely doing her laundry in the laundry room. Since Sam and Sarah need to use different areas, their actions do not conflict. So, since Sam and Sarah are going to be in different areas, Sam should continue going for a walk.\n",
                "answer": "Answer: <Option B>",
            }
        else:
            ex1 = {
                "context": "简是丽兹的室友。2022-10-25 07:05，简和丽兹互相问候了早上好。",
                "date": "2022-10-25 07:09",
                "agent": "简",
                "another": "丽兹",
                "status": "简 正要去浴室",
                "another_status": "丽兹 已经在 使用浴室",
                "action": "使用浴室",
                "another_action": "使用浴室",
                "reason": "推理：简和丽兹都想用浴室。简和丽兹同时使用浴室会很奇怪。所以，既然丽兹已经在用浴室了，对简来说最好的选择就是等着用浴室。\n",
                "answer": "答案：<选项A>",
            }
            ex2 = {
                "context": "山姆是莎拉的朋友。2022-10-24 23:00，山姆和莎拉就最喜欢的电影进行了交谈。",
                "date": "2022-10-25 12:40",
                "agent": "山姆",
                "another": "莎拉",
                "status": "山姆 正要去吃午饭",
                "another_status": "莎拉 已经在 洗衣服",
                "action": "吃午饭",
                "another_action": "洗衣服",
                "reason": "推理：山姆可能会在餐厅吃午饭。莎拉可能会去洗衣房洗衣服。由于山姆和莎拉需要使用不同的区域，他们的行为并不冲突。所以，由于山姆和莎拉将在不同的区域，山姆现在继续吃午饭。\n",
                "answer": "答案：<选项B>",
            }
        example1 = self.build_prompt("decide_wait_example", ex1)
        example2 = self.build_prompt("decide_wait_example", ex2)

        def _status_des(a):
            event, loc = a.get_event(), ""
            if event.address:
                loc = L(" 在 {} 的 {}", " at the {} in the {}").format(
                    *(L((event.address[-2], event.address[-1]), (event.address[-1], event.address[-2]))))
            if not a.path:
                return L(f"{a.name} 已经在 {event.get_describe(False)}{loc}", f"{a.name} is already {event.get_describe(False)}{loc}")
            return L(f"{a.name} 正要去 {event.get_describe(False)}{loc}", f"{a.name} is on the way to {event.get_describe(False)}{loc}")

        context = ". ".join(
            [c.describe for c in focus["events"]]
        )
        context += "\n" + ". ".join([c.describe for c in focus["thoughts"]])

        task = self.build_prompt(
            "decide_wait_example",
            {
                "context": context,
                "date": utils.get_timer().get_date("%Y-%m-%d %H:%M"),
                "agent": agent.name,
                "another": other.name,
                "status": _status_des(agent),
                "another_status": _status_des(other),
                "action": agent.get_event().get_describe(False),
                "another_action": other.get_event().get_describe(False),
                "reason": "",
                "answer": "",
            }
        )

        prompt = self.build_prompt(
            "decide_wait",
            {
                "examples_1": example1,
                "examples_2": example2,
                "task": task,
            }
        )

        def _callback(response):
            if lang.is_en():
                found = re.findall(r"option\W*([ab])\b", str(response or "").lower())
                return bool(found) and found[-1] == "a"
            return "A" in response

        return {"prompt": prompt, "callback": _callback, "failsafe": False}

    def prompt_summarize_relation(self, agent, other_name):
        nodes = agent.associate.retrieve_focus([other_name], 50)

        prompt = self.build_prompt(
            "summarize_relation",
            {
                "context": "\n".join(["{}. {}".format(idx, n.describe) for idx, n in enumerate(nodes)]),
                "agent": agent.name,
                "another": other_name,
            }
        )

        def _callback(response):
            return response

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": agent.name + L(" 正在看着 ", " is looking at ") + other_name,
        }

    def prompt_generate_chat(self, agent, other, relation, chats):
        focus = [relation, other.get_event().get_describe()]
        if len(chats) > 4:
            focus.append("; ".join("{}: {}".format(n, t) for n, t in chats[-4:]))
        nodes = agent.associate.retrieve_focus(focus, 15)
        memory = "\n- " + "\n- ".join([n.describe for n in nodes])
        chat_nodes = agent.associate.retrieve_chats(other.name)
        pass_context = ""
        for n in chat_nodes:
            delta = utils.get_timer().get_delta(n.create)
            if delta > 480:
                continue
            pass_context += L(f"{delta} 分钟前，{agent.name} 和 {other.name} 进行过对话。{n.describe}\n",
                              f"{delta} minutes ago, {agent.name} and {other.name} had a conversation. {n.describe}\n")

        address = agent.get_tile().get_address()
        if len(pass_context) > 0:
            prev_context = L(f'\n背景：\n"""\n{pass_context}"""\n\n', f'\nContext:\n"""\n{pass_context}"""\n\n')
        else:
            prev_context = ""
        curr_context = L(
            f"{agent.name} {agent.get_event().get_describe(False)} 时，看到 {other.name} {other.get_event().get_describe(False)}。",
            f"While {agent.name} is {agent.get_event().get_describe(False)}, {agent.name} sees {other.name} {other.get_event().get_describe(False)}."
        )

        conversation = "\n".join(["{}: {}".format(n, u) for n, u in chats])
        conversation = (
            conversation or L("[对话尚未开始]", "[The conversation has not started yet]")
        )

        prompt = self.build_prompt(
            "generate_chat",
            {
                "agent": agent.name,
                "base_desc": self._base_desc(),
                "memory": memory,
                "address": L(f"{address[-2]}，{address[-1]}", f"{address[-1]} in the {address[-2]}"),
                "current_time": utils.get_timer().get_date("%H:%M"),
                "previous_context": prev_context,
                "current_context": curr_context,
                "another": other.name,
                "conversation": conversation,
            }
        )

        def _callback(response):
            assert "{" in response and "}" in response
            json_content = utils.load_dict(
                "{" + response.split("{")[1].split("}")[0] + "}"
            )
            text = json_content[agent.name].replace("\n\n", "\n").strip(" \n\"'“”‘’")
            # V23: as in the original Stanford converse.py, the speaker decides in the
            # same call whether the conversation ends after this utterance.
            end = json_content.get("结束对话", json_content.get("end", False))
            if isinstance(end, str):
                end = end.strip().lower() in ("true", "是", "yes", "1")
            return text, bool(end)

        return {
            "prompt": prompt,
            "callback": _callback,
            # On model failure end the chat rather than loop on a filler line.
            "failsafe": (L("嗯", "Hmm."), True),
        }

    def prompt_generate_chat_check_repeat(self, agent, chats, content):
        conversation = "\n".join(["{}: {}".format(n, u) for n, u in chats])
        conversation = (
                conversation or L("[对话尚未开始]", "[The conversation has not started yet]")
        )

        prompt = self.build_prompt(
            "generate_chat_check_repeat",
            {
                "conversation": conversation,
                "content": f"{agent.name}: {content}",
                "agent": agent.name,
            }
        )

        def _callback(response):
            if lang.is_en():
                return _yes_en(response)
            if "No" in response or "no" in response or "否" in response or "不" in response:
                return False
            return True

        return {"prompt": prompt, "callback": _callback, "failsafe": False}

    def prompt_summarize_chats(self, chats):
        conversation = "\n".join(["{}: {}".format(n, u) for n, u in chats])

        prompt = self.build_prompt(
            "summarize_chats",
            {
                "conversation": conversation,
            }
        )

        def _callback(response):
            return response.strip()

        if len(chats) > 1:
            failsafe = L("{} 和 {} 之间的普通对话", "an ordinary conversation between {} and {}").format(chats[0][0], chats[1][0])
        else:
            failsafe = L("{} 说的话没有得到回应", "{} said something and got no reply").format(chats[0][0])

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": failsafe,
        }

    def prompt_reflect_focus(self, nodes, topk):
        prompt = self.build_prompt(
            "reflect_focus",
            {
                "agent": self.name,
                "reference": "\n".join(["{}. {}".format(idx, n.describe) for idx, n in enumerate(nodes)]),
                "number": topk,
            }
        )

        def _callback(response):
            pattern = ["^\d{1}\. (.*)", "^\d{1}\) (.*)", "^\d{1} (.*)"]
            return parse_llm_output(response, pattern, mode="match_all")

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": [
                L("{} 是谁？", "Who is {}?").format(self.name),
                L("{} 住在哪里？", "Where does {} live?").format(self.name),
                L("{} 今天要做什么？", "What does {} need to do today?").format(self.name),
            ],
        }

    def prompt_reflect_insights(self, nodes, topk):
        fallback_evidence = [nodes[0].node_id] if nodes else []
        prompt = self.build_prompt(
            "reflect_insights",
            {
                "agent": self.name,
                "reference": "\n".join(["{}. {}".format(idx, n.describe) for idx, n in enumerate(nodes)]),
                "number": topk,
            }
        )

        def _callback(response):
            patterns = [
                L("^\d{1}[\. ]+(.*)[。 ]*[\(（]+.*序号[:： ]+([\d,， ]+)[\)）]",
                  "^\d{1}[\. ]+(.*?)[. ]*\(+.*(?:because of|statements?|numbers?)[:： ]+([\d, ]+)\)"),
                L("^\d{1}[\. ]+(.*)[。 ]*[\(（]([\d,， ]+)[\)）]",
                  "^\d{1}[\. ]+(.*?)[. ]*\(([\d, ]+)\)"),
            ]
            insights, outputs = [], parse_llm_output(
                response, patterns, mode="match_all"
            )
            if outputs:
                for output in outputs:
                    if isinstance(output, str):
                        insight, node_ids = output, []
                    elif len(output) == 2:
                        insight, reason = output
                        indices = [int(e.strip()) for e in reason.split(",")]
                        node_ids = [nodes[i].node_id for i in indices if i < len(nodes)]
                    insights.append([insight.strip(), node_ids])
                return insights
            raise Exception("Can not find insights")

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": [
                [
                    L("{} 在考虑下一步该做什么", "{} is thinking about what to do next").format(self.name),
                    fallback_evidence,
                ]
            ],
        }

    def prompt_reflect_chat_planing(self, chats):
        all_chats = "\n".join(["{}: {}".format(n, c) for n, c in chats])

        prompt = self.build_prompt(
            "reflect_chat_planing",
            {
                "conversation": all_chats,
                "agent": self.name,
            }
        )

        def _callback(response):
            return response

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": L(f"{self.name} 进行了一次对话", f"{self.name} had a conversation"),
        }

    def prompt_reflect_chat_memory(self, chats):
        all_chats = "\n".join(["{}: {}".format(n, c) for n, c in chats])

        prompt = self.build_prompt(
            "reflect_chat_memory",
            {
                "conversation": all_chats,
                "agent": self.name,
            }
        )

        def _callback(response):
            return response

        return {
            "prompt": prompt,
            "callback": _callback,
            # "failsafe": f"{self.name} had a sonversation",
            "failsafe": L(f"{self.name} 进行了一次对话", f"{self.name} had a conversation"),
        }

    def prompt_retrieve_plan(self, nodes):
        statements = [
            n.create.strftime("%Y-%m-%d %H:%M") + ": " + n.describe for n in nodes
        ]

        prompt = self.build_prompt(
            "retrieve_plan",
            {
                "description": "\n".join(statements),
                "agent": self.name,
                "date": utils.get_timer().get_date("%Y-%m-%d"),
            }
        )

        def _callback(response):
            pattern = [
                "^\d{1,2}\. (.*)。",
                "^\d{1,2}\. (.*)",
                "^\d{1,2}\) (.*)。",
                "^\d{1,2}\) (.*)",
            ]
            return parse_llm_output(response, pattern, mode="match_all")

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": [r.describe for r in random.choices(nodes, k=5)],
        }

    def prompt_retrieve_thought(self, nodes):
        statements = [
            n.create.strftime("%Y-%m-%d %H:%M") + L("：", ": ") + n.describe for n in nodes
        ]

        prompt = self.build_prompt(
            "retrieve_thought",
            {
                "description": "\n".join(statements),
                "agent": self.name,
            }
        )

        def _callback(response):
            return response

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": L("{} 应该遵循昨天的日程", "{} should follow yesterday's schedule").format(self.name),
        }

    def prompt_retrieve_currently(self, plan_note, thought_note):
        time_stamp = (
            utils.get_timer().get_date() - datetime.timedelta(days=1)
        ).strftime("%Y-%m-%d")

        prompt = self.build_prompt(
            "retrieve_currently",
            {
                "agent": self.name,
                "time": time_stamp,
                "currently": self.currently,
                "plan": ". ".join(plan_note),
                "thought": thought_note,
                "current_time": utils.get_timer().get_date("%Y-%m-%d"),
            }
        )

        def _callback(response):
            pattern = L([
                "^状态: (.*)。",
                "^状态: (.*)",
            ], [
                "^Status: (.*)",
            ])
            return parse_llm_output(response, pattern)

        return {
            "prompt": prompt,
            "callback": _callback,
            "failsafe": self.currently,
        }

    def prompt_psych_appraisal(self, events_text, psych_desc, total_poignancy):
        from modules import psych as psych_mod

        failsafe = psych_mod.failsafe_appraisal(total_poignancy)
        prompt = self.build_prompt(
            "psych_appraisal",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "events": events_text,
                "psych_desc": psych_desc,
            },
        )

        def _callback(response):
            import json as _json
            import re as _re
            text = (response or "").strip()
            try:
                data = _json.loads(text)
            except _json.JSONDecodeError:
                m = _re.search(r"\{.*\}", text, flags=_re.DOTALL)
                if not m:
                    return failsafe
                try:
                    data = _json.loads(m.group(0))
                except _json.JSONDecodeError:
                    return failsafe
            if not isinstance(data, dict):
                return failsafe
            out = {}
            for key in psych_mod.VARS:
                if key in data:
                    out[key] = data[key]
            return out

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}

    def prompt_custom_survey_dyadic(self, schema, ratee, survey_time, ratee_context, self_context):
        from modules import survey as survey_engine

        failsafe = survey_engine.failsafe_answers(schema)
        prompt = self.build_prompt(
            "custom_survey_dyadic",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "ratee": ratee,
                "survey_title": _survey_display(schema)[0],
                "time_frame_hint": _survey_display(schema)[1],
                "survey_time": survey_time,
                "ratee_context": ratee_context,
                "self_context": (L('\n{}自己今天的状态概况：\n"""\n{}\n"""\n', '\nAn overview of how {} is doing today:\n"""\n{}\n"""\n').format(self.name, self_context)
                                 if str(self_context or "").strip() else ""),
                "questions": survey_engine.question_prompt_lines(schema, ratee=ratee),
                "format_example": survey_engine.format_example(schema),
            },
        )

        def _callback(response):
            answers = survey_engine.parse_answers(response, schema)
            # V23: an unparseable answer is retried (returning None) instead of
            # being accepted as missing on the first attempt.
            if (answers.get("_quality") or {}).get("status") == "invalid":
                return None
            return answers

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe, "retry": 3}

    def prompt_custom_survey(self, schema, survey_time, context):
        from modules import survey as survey_engine

        failsafe = survey_engine.failsafe_answers(schema)
        prompt = self.build_prompt(
            "custom_survey",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "survey_title": _survey_display(schema)[0],
                "time_frame_hint": _survey_display(schema)[1],
                "survey_time": survey_time,
                "context": context,
                "questions": survey_engine.question_prompt_lines(schema),
                "format_example": survey_engine.format_example(schema),
            },
        )

        def _callback(response):
            answers = survey_engine.parse_answers(response, schema)
            # V23: an unparseable answer is retried (returning None) instead of
            # being accepted as missing on the first attempt.
            if (answers.get("_quality") or {}).get("status") == "invalid":
                return None
            return answers

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe, "retry": 3}

    # ------------------------------------------------------------------
    # Cheap mode (V25.1): cache-friendly survey layout, merged surveys, batched importance
    # ------------------------------------------------------------------
    def _cache_survey_fields(self, survey_time, context, earlier, ratee):
        about = L("、与 {} 有关的", " involving {}").format(ratee) if ratee else ""
        return {
            "base_desc": self._base_desc(),
            "agent": self.name,
            "survey_time": survey_time,
            "about": about,
            "context": context,
            "earlier": (L('\n与问卷有关、{}还想起的更早经历：\n"""\n{}\n"""\n', '\nEarlier experiences related to the survey that {} also remembers:\n"""\n{}\n"""\n').format(self.name, earlier)
                        if str(earlier or "").strip() else ""),
            "survey_about": L("关于 {} 的", " about {}").format(ratee) if ratee else "",
            "no_contact": (L("没有与 {} 的相关互动时，按 {} 的整体感受作答。", "If there was no relevant interaction with {}, answer from {}'s overall impression.").format(ratee, self.name)
                           if ratee else ""),
        }

    def prompt_custom_survey_cache(self, schema, survey_time, context, earlier, ratee=None):
        """One questionnaire, shared context first (H1)."""
        from modules import survey as survey_engine

        failsafe = survey_engine.failsafe_answers(schema)
        fields = self._cache_survey_fields(survey_time, context, earlier, ratee)
        fields.update({
            "survey_title": _survey_display(schema)[0],
            "time_frame_hint": _survey_display(schema)[1],
            "questions": survey_engine.question_prompt_lines(schema, ratee=ratee),
            "format_example": survey_engine.format_example(schema),
        })
        prompt = self.build_prompt("custom_survey_cache", fields)

        def _callback(response):
            answers = survey_engine.parse_answers(response, schema)
            if (answers.get("_quality") or {}).get("status") == "invalid":
                return None
            return answers

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe, "retry": 3}

    def prompt_custom_survey_merged(self, schemas, survey_time, context, earlier, ratee=None):
        """Several questionnaires in one call (H5). Returns {index: answers}; a questionnaire
        whose answer is unusable is left out, so the caller can ask it on its own."""
        from modules import survey as survey_engine

        keys = ["S{}".format(i + 1) for i in range(len(schemas))]
        blocks, example = [], {}
        for key, schema in zip(keys, schemas):
            title, hint = _survey_display(schema)
            blocks.append(L("【问卷 {}】《{}》。{}\n题目如下：\n{}", "[Survey {}] \"{}\". {}\nQuestions:\n{}").format(
                key, title, hint, survey_engine.question_prompt_lines(schema, ratee=ratee)))
            example[key] = json.loads(survey_engine.format_example(schema))
        fields = self._cache_survey_fields(survey_time, context, earlier, ratee)
        fields.update({
            "count": len(schemas),
            "blocks": "\n\n".join(blocks),
            "keys": L("、", ", ").join(keys),
            "format_example": json.dumps(example, ensure_ascii=False),
        })
        prompt = self.build_prompt("custom_survey_merged", fields)

        def _callback(response):
            text = (response or "").strip()
            try:
                data = json.loads(text)
            except json.JSONDecodeError:
                match = re.search(r"\{.*\}", text, flags=re.DOTALL)
                if not match:
                    return None
                try:
                    data = json.loads(match.group(0))
                except json.JSONDecodeError:
                    return None
            if not isinstance(data, dict):
                return None
            out = {}
            for index, (key, schema) in enumerate(zip(keys, schemas)):
                sub = data.get(key)
                if not isinstance(sub, dict):
                    continue
                answers = survey_engine.parse_answers(json.dumps(sub, ensure_ascii=False), schema)
                if (answers.get("_quality") or {}).get("status") != "invalid":
                    out[index] = answers
            return out or None

        return {"prompt": prompt, "callback": _callback, "failsafe": {}, "retry": 3}

    def prompt_poignancy_batch(self, items):
        """Importance of several perceived events in one call (H3). items: [(kind, describe)]."""
        lines = [L("{}. （{}）{}", "{}. ({}) {}").format(i + 1, L("对话", "conversation") if kind == "chat" else L("事件", "event"), text)
                 for i, (kind, text) in enumerate(items)]
        example = json.dumps([[3, 1, 7, 2, 5, 1, 4, 6][i % 8] for i in range(len(items))])
        prompt = self.build_prompt("poignancy_batch", {
            "base_desc": self._base_desc(),
            "agent": self.name,
            "count": len(items),
            "events": "\n".join(lines),
            "example": example,
        })

        def _callback(response):
            match = re.search(r"\[[^\[\]]*\]", response or "", flags=re.DOTALL)
            if not match:
                return None
            try:
                values = json.loads(match.group(0))
            except json.JSONDecodeError:
                return None
            if not isinstance(values, list) or len(values) != len(items):
                return None
            out = []
            for v in values:
                if isinstance(v, bool):
                    return None
                if isinstance(v, str) and v.strip().isdigit():
                    v = int(v.strip())
                try:
                    n = int(v)
                except (TypeError, ValueError):
                    return None
                if not 1 <= n <= 10 or n != v:
                    return None
                out.append(n)
            return out

        return {"prompt": prompt, "callback": _callback, "failsafe": None, "retry": 3}

    def prompt_daily_survey_employee(self, condition, run_id, survey_date, context):
        fields = [
            "perceived_leader_strictness",
            "stress",
            "psychological_safety",
            "leader_trust",
            "work_engagement",
            "turnover_intention",
        ]
        failsafe = {
            "perceived_leader_strictness": 4,
            "stress": 4,
            "psychological_safety": 4,
            "leader_trust": 4,
            "work_engagement": 4,
            "turnover_intention": 4,
            "reason": L("问卷解析失败，使用中性默认值。", "Survey answer could not be parsed; neutral defaults used."),
        }
        prompt = self.build_prompt(
            "daily_survey_employee",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "condition": condition,
                "run_id": run_id,
                "survey_date": survey_date,
                "context": context,
            },
        )

        def _callback(response):
            return self._parse_survey_json(response, fields, failsafe)

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}

    def prompt_daily_survey_leader(self, condition, run_id, survey_date, context):
        fields = [
            "self_rated_leader_strictness",
            "stress",
            "team_trust",
            "management_engagement",
            "psychological_resource_recovery",
            "emotional_exhaustion",
        ]
        failsafe = {
            "self_rated_leader_strictness": 4,
            "stress": 4,
            "team_trust": 4,
            "management_engagement": 4,
            "psychological_resource_recovery": 4,
            "emotional_exhaustion": 4,
            "reason": L("问卷解析失败，使用中性默认值。", "Survey answer could not be parsed; neutral defaults used."),
        }
        prompt = self.build_prompt(
            "daily_survey_leader",
            {
                "base_desc": self._base_desc(),
                "agent": self.name,
                "condition": condition,
                "run_id": run_id,
                "survey_date": survey_date,
                "context": context,
            },
        )

        def _callback(response):
            return self._parse_survey_json(response, fields, failsafe)

        return {"prompt": prompt, "callback": _callback, "failsafe": failsafe}
